module.exports = {
  plugins: {
    autoprefixer: {}
  },
  // css:{
	 //  loaderOptions:{
		//   sass:{
		// 	  data:`@import "~@/static/css/color.scss";`
		//   }
	 //  }
  // }
}
