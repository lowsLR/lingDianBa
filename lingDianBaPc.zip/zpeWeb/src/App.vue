<template>
	<div id="app">
		<keep-alive>
			<router-view></router-view>
		</keep-alive>
	</div>
</template>

<script>
	import {
		mapState,
		mapMutations
	} from 'vuex'
	export default {
		name: 'app',
		created() {
			// 读取用户登录信息(本地缓存)
			let userInfo = this.$ls.get('userInfo')
			if (userInfo) {
				// console.log('用户登录信息：', userInfo);
				
				// 更新Vuex数据（登录状态、用户数据）
				this.login(userInfo);
				// console.log(this.$store.state.userInfo.token);
			}

			// beforeunload监听页面刷新事件
			window.addEventListener('beforeunload', this.saveStore)
		},
		destroyed() {
			// 销毁监听刷新事件
			window.removeEventListener('beforeunload', this.saveStore)
		},
		methods: {
			...mapMutations(['login']),
			
			saveStore() {
				// 页面刷新保存当前vuex的状态
				sessionStorage.setItem('store', JSON.stringify(this.$store.state.saveState))
			}
		}
	}
</script>

<style lang="scss">
	// @import url("static/css/global.css");
	#app {
		font-family: Microsoft YaHei, 'Avenir', Helvetica, Arial, sans-serif;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
		text-align: center;
		/* color: #2c3e50;
  margin-top: 60px; */
	}
	
	.container {
		width: 990px;
		height: auto;
		margin: 0 auto;
		overflow: hidden;
		position: relative;
	}

	.rd50 {
		-webkit-border-radius: 50%;
		-moz-border-radius: 50%;
		border-radius: 50%;
	}

	.flex {
		display: -webkit-box;
		display: -webkit-flex;
		display: -ms-flexbox;
		display: flex;
	}

	.flex-pack-center {
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		-ms-flex-pack: center;
		justify-content: center;
	}

	.flex-pack-end {
		-webkit-box-pack: end;
		-webkit-justify-content: flex-end;
		-ms-flex-pack: end;
		justify-content: flex-end;
	}

	.flex-align-center {
		-webkit-box-align: center;
		-webkit-align-items: center;
		-ms-flex-align: center;
		align-items: center;
	}

	.flex-1 {
		-webkit-box-flex: 1;
		-webkit-flex: 1;
		-ms-flex: 1;
		flex: 1;
	}

	.flex-no-wrap {
		-webkit-flex-wrap: nowrap;
		-moz-flex-wrap: nowrap;
		-ms-flex-wrap: nowrap;
		-o-flex-wrap: nowrap;
		flex-wrap: nowrap;
	}
</style>
