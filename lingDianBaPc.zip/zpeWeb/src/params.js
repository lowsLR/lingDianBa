const configKey = [
	"web_navigation_index",//:网页端首页导航
	"web_navigation_videotape",//:pc端录像导航;
	"web_navigation_video",//:pc端视频导航;
	'web_navigation_tv',//pc端电视台导航
	"web_navigation_new",//:pc端新闻导航;
	"web_navigation_data",//:pc端数据导航;
	"web_index_screen",//:pc端首页筛选,
	
]


export default{			
	configKey
}