
const BWU = {
	
	
	//验证非法字符
	 checkStr(strTest) {
	     var pat = new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]", "i");
	     var strArr = strTest.split("");
	     for (var i = 0; i < strArr.length; i++) {
	         var str = strTest.charAt(i);
	         if (pat.test(strArr[i]) == true) {
	             strArr[i] = "()";
	             console.log("含有非法字符");
	             return false
	         }
	     }
	     return true
	 },  
	 /*
	 qq验证
	 */
	qq_validation(qq) {
	     var filter = /^\s*[.0-9]{5,11}\s*$/;
	     if (!filter.test(qq)) {
	         return false;
	     } else {
	         return true;
	     }
	 },
	 /*
	 邮箱验证
	 */
	 email_validation(v){
	 		let reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
	 		if(reg.test(v)){
	 			return true;
	 		}else{
	 			return false;
	 		}
	 	},
		/*
	 	 * 判断身份证
	 	 */
	 	card_validation:function(cardid){
	 		if(!(/^[1-9]{1}[0-9]{14}$|^[1-9]{1}[0-9]{16}([0-9]|[xX])$/.test(cardid))) {
	 			return false;
	 		} else {
	 			return true;
	 		}
	 	},
	 	/*
	 	 * 判断手机号
	 	 */
	 	phone_validation:function(phone) {
	 		if(!(/^1(3|4|5|7|8)\d{9}$/.test(phone))) {
	 			return false;
	 		} else {
	 			return true;
	 		}
	 	},
	 	/*
	 	 * 车牌判断
	 	 */
	 	plate_number_validation:function(str) {
	 		if(str.length == 7) {
	 			var express = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1}$/;
	 			if(!express.test(str)) {
	 				return false;
	 			} else {
	 				return true;
	 			}
	 		} else {
	 			return false;
	 		}
	 	},
	 	/*
	 	 * 判断是pc还是移动端
	 	 */
	 	gomatch:function() {
	         if ((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i))) {
	             return "mobile";
	         }
	         else {
	             return "pc";
	         }
	                 
	     },
	     /*
	      * 判断系统
	      */
	     getxitong:function() {
	 	    var u = navigator.userAgent, app = navigator.appVersion;
	 	    var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1;
	 	    var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	 	    if (isAndroid) {
	 	       return "android";
	 	    }
	 	    if (isIOS) {
	 		   return "ios";
	 	    }
	 	},
	
	
	/*伪装我是接口*/
	bwReq(bd){
		bd&&!bd.hideLoading&&uni.showLoading();
		return new Promise((r,e) => {
			let n = Math.ceil(Math.random()*1000); 
			setTimeout(function() {
				bd&&!bd.hideLoading&&uni.hideLoading();
				if(n > 0){
					r();
				}else{
					e();
				}
			}, 600);
		}) 
	},
	/*截取时间*/
	splitTime(time,arr = [3,4],zh = false){
		let timearr = time.replace(" ", ":").replace(/\:/g, "-").split("-");
		// return timearr[3]+':'+timearr[4]+':'+timearr[5];
		return timearr[3]+':'+timearr[4];
	},
	splitTimeZH(time){
		let timearr = time.replace(" ", ":").replace(/\:/g, "-").split("-");
		// return timearr[3]+':'+timearr[4]+':'+timearr[5];
		return timearr[1]+'月'+timearr[2]+'日';
	},
	/*截取时间*/
	// splitTime(time,arr = [3,4],zh = false){
	// 	let timearr = time.replace(" ", ":").replace(/\:/g, "-").split("-");
	// 	// return timearr[3]+':'+timearr[4]+':'+timearr[5];
	// 	let str = ''
	// 	if(!zh){
	// 		arr.forEach((item,index) => {
	// 			if(item < 3){
	// 				if(index < arr.length -1){
	// 					str += timearr[item]+'-'
	// 				}else{
	// 					str += timearr[item]
	// 				}
	// 			}else{
	// 				if(index < arr.length -1){
	// 					str += timearr[item]+':'
	// 				}else{
	// 					str += timearr[item]
	// 				}
	// 			}
	// 		})
	// 	}else{
	// 		arr.forEach((item,index) => {
	// 			if(item < 3){
	// 				if(index < arr.length -1){
	// 					str += timearr[item]+'-'
	// 				}else{
	// 					str += timearr[item]
	// 				}
	// 			}else{
	// 				if(index < arr.length -1){
	// 					str += timearr[item]+':'
	// 				}else{
	// 					str += timearr[item]
	// 				}
	// 			}
	// 		})
	// 	}
	// 	return str;
	// 	// return timearr[3]+':'+timearr[4];
	// },
	/*返回剩余时间*/
	returnRemainTime(time){
		let timestamp = (new Date()).getTime();
		return (time-timestamp);
	},
	returnSplitTime(op){
		if(typeof op.time == 'string'){
			let timearr = val.replace(" ", ":").replace(/\:/g, "-").split("-");
			let str = '';
			op.getList.forEach((item,index) => {
				str += timearr[item]
			})
			return str;
		} 
	},
	
	
	/*返回聊天时间*/
	returnMsgTime(timespan){
			let dateTime = new Date(timespan);
		  let year = dateTime.getFullYear();
		  let month = dateTime.getMonth() + 1;
		  let day = dateTime.getDate();
		  let hour = dateTime.getHours();
		  let minute = dateTime.getMinutes();
		  let second = dateTime.getSeconds();
		  // let now_new = Date.parse(now.toDateString());  //获取当天时间戳
			let now_new = Date.parse(new Date());  //获取现在时间戳
		  let milliseconds = 0;
		  let timeSpanStr;
		  milliseconds = now_new - timespan;
		  if (milliseconds <= 1000 * 60 * 1) {
		    timeSpanStr = '刚刚';
		  }
		  else if (1000 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60) {
		    timeSpanStr = Math.round((milliseconds / (1000 * 60))) + '分钟前';
		  }
		  else if (1000 * 60 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24) {
		    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60)) + '小时前';
		  }
		  else if (1000 * 60 * 60 * 24 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 15) {
		    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24)) + '天前';
		  }
		  else if (milliseconds > 1000 * 60 * 60 * 24 * 15 && year == now.getFullYear()) {
		    timeSpanStr = month + '-' + day + ' ' + hour + ':' + minute;
		  } else {
		    timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute;
		  }
		  return timeSpanStr;
	},
	/*时间戳转时间*/
	timesToTime(timestamp){
		let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
		let Y = date.getFullYear() + '年';
		let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '月';
		let D = date.getDate() + '日 ';
		let h = date.getHours() + ':';
		let m = date.getMinutes()<10?'0'+date.getMinutes()+ ':':date.getMinutes()+ ':';
		let s = date.getSeconds()<10?'0'+date.getSeconds():date.getSeconds();
		return Y + M + D + h + m + s;
	},
	/*返回当天时间*/
	returnNowTime(str){
		let now = new Date(),
				year = now.getFullYear(), //得到年份
				month = now.getMonth(),//得到月份
				date = now.getDate(),//得到日期
				day = now.getDay(),//得到周几
				hour = now.getHours(),//得到小时
				minu = now.getMinutes(),//得到分钟
				sec = now.getSeconds(),//得到秒
　　    MS = now.getMilliseconds(),//获取毫秒
				week;
				month = month + 1;
		if (month < 10) month = "0" + month;
		if (date < 10) date = "0" + date;
		if (hour < 10) hour = "0" + hour;
		if (minu < 10) minu = "0" + minu;
		if (sec < 10) sec = "0" + sec;
		if (MS < 100) MS = "0" + MS;
		let arr_week = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
		week = arr_week[day];
		let time = "";
		let dj = {
			'YYYY' : year,
			'MM' : month,
			'DD' : date,
			'hh' : hour,
			'mm' : minu,
			'ss' : sec,
			'we' : week,
		} 
		if(str){
			time = str.replace('YYYY',dj['YYYY'])
			.replace('MM',dj['MM'])
			.replace('DD',dj['DD'])
			.replace('hh',dj['hh'])
			.replace('mm',dj['mm'])
			.replace('ss',dj['ss'])
			.replace('we',dj['we']);
		}else{
		// time = year + "年" + month + "月" + date + "日" + " " + hour + ":" + minu + ":" + sec + " " + week;
			time = year + "年" + month + "月" + date + "日"
		}
		return time;
		
	},
	json2xml(jsonstring) {
	  //将xml字符串格式化
	  return this.writeXML(jsonstring);;
	},
	//xml转json
	xml2json(xmlstring) {
	  //将xml字符串转为json
	  let json = this.parseXML(xmlstring);
	  //将json对象转为格式化的字符串
	  return JSON.parse(this.dump(json));
	},
	
	//  Dump the data into JSON format
	dump ( data, offset ) {
	    if ( typeof(offset) == "undefined" ) offset = "";
	    let nextoff = offset + "  ";
	    switch ( typeof(data) ) {
	    case "string":
	        return '"'+this.escapeString(data)+'"';
	        break;
	    case "number":
	        return data;
	        break;
	    case "boolean":
	        return data ? "true" : "false";
	        break;
	    case "undefined":
	        return "null";
	        break;
	    case "object":
	        if ( data == null ) {
	            return "null";
	        } else if ( data.constructor == Array ) {
	            let array = [];
	            for ( let i=0; i<data.length; i++ ) {
	                array[i] = this.dump( data[i], nextoff );
	            }
	            return "[\n"+nextoff+array.join( ",\n"+nextoff )+"\n"+offset+"]";
	        } else {
	            let array = [];
	            for ( let key in data ) {
	                let val = this.dump( data[key], nextoff );
	//              if ( key.match( /[^A-Za-z0-9_]/ )) {
	                    key = '"'+this.escapeString( key )+'"';
	//              }
	                array[array.length] = key+": "+val;
	            }
	            if ( array.length == 1 && ! array[0].match( /[\n\{\[]/ ) ) {
	                return "{ "+array[0]+" }";
	            }
	            return "{\n"+nextoff+array.join( ",\n"+nextoff )+"\n"+offset+"}";
	        }
	        break;
	    default:
	        return data;
	        // unsupported data type
	        break;
	    }
	},
	
	//  escape '\' and '"'
	escapeString ( str ) {
	    return str.replace( /\\/g, "\\\\" ).replace( /\"/g, "\\\"" );
	},
	/*
	需要引入xmldom
	*/
	parseXML(xml) {
		let doc = new DOMParser().parseFromString(xml, 'text/xml');
		let test = this.parseDOM(doc);
		return test['#document'];
		// let root;
		// if (window.DOMParser) {
		// 	let xmldom = new DOMParser();
		// 	//      xmldom.async = false;           // DOMParser is always sync-mode
		// 	let dom = xmldom.parseFromString(xml, "application/xml");
		// 	if (!dom) return;
		// 	root = dom.documentElement;
		// } else if (window.ActiveXObject) {
		// 	xmldom = new ActiveXObject('Microsoft.XMLDOM');
		// 	xmldom.async = false;
		// 	xmldom.loadXML(xml);
		// 	root = xmldom.documentElement;
		// }
		// if (!root) return;
		// return this.parseDOM(root);
		
	},
	
	/**
	 * 将XML的Document对象转换为JSON字符串
	 * @param xmlDoc xml的Document对象
	 * @return string
	 */
	convertToJSON(xmlDoc) {
	    //准备JSON字符串和缓存（提升性能）
	    let jsonStr = "";
	    let buffer = new Array();
	
	    buffer.push("{");
	    //获取xml文档的所有子节点
	    let nodeList = xmlDoc.childNodes;
			// console.log("所有子节点",nodeList.toString() )
	    generate(nodeList);
	
	    /**
	     * 中间函数，用于递归解析xml文档对象，并附加到json字符串中
	     * @param node_list xml文档的的nodeList
	     */
	    function generate(node_list) {
	
	        for (let i = 0; i < node_list.length; i++) {
	            let curr_node = node_list[i];
	            //忽略子节点中的换行和空格
	            if (curr_node.nodeType == 3) {
	                continue;
	            }
	            //如果子节点还包括子节点，则继续进行遍历
	            if (curr_node.childNodes.length > 1) {
	                buffer.push("\"" + curr_node.nodeName + "\": {");
	                generate(curr_node.childNodes);
	            } else {
	                let firstChild = curr_node.childNodes[0];
	
	                if (firstChild != null) {
	                    //nodeValue不为null
	                    buffer.push("\"" + curr_node.nodeName + "\":\"" + firstChild.nodeValue + "\"");
	                } else {
	                    //nodeValue为null
	                    buffer.push("\"" + curr_node.nodeName + "\":\"\"");
	                }
	
	            }
	            if (i < (node_list.length - 2)) {
	                buffer.push(",");
	            } else {
	                break;
	            }
	        }
	        //添加末尾的"}"
	        buffer.push("}");
	    }
	
	    jsonStr = buffer.join("");
	    return jsonStr;
	},
	
	
	//xml数据转成json对象的数据
	 xmlTojson(xmlObj, nodename, isarray){
	        let obj = xmlObj;
	        let itemobj = {};
	        let nodenames = "";
	        let getAllAttrs = function(node){//递归解析xml 转换成json对象
	            let _itemobj = {};
	            let notNull = false;
	            let nodechilds = node.childNodes;
	            let childlenght = nodechilds.length;
	            let _attrs = node.attributes;
	            let firstnodeName = "#text";
	            try{
	                firstnodeName = nodechilds[0].nodeName;
	            }catch(e){
	
	            }
	            if((childlenght > 0 && firstnodeName != "#text") || _attrs.length > 0){
	                let _childs = nodechilds;
	                let _childslength = nodechilds.length;
	                let _fileName_ = "";
	                if(undefined != _attrs){
	                    let _attrslength = _attrs.length;
	                    for(let i = 0; i < _attrslength; i++){//解析xml节点属性
	                        let attrname = _attrs[i].nodeName;
	                        let attrvalue = _attrs[i].nodeValue;
	                        _itemobj[attrname] = attrvalue;
	                    }
	                }
	                for (let j = 0; j < _childslength; j++) {//解析xml子节点
	                    let _node = _childs[j];
	                    let _fildName = _node.nodeName;
	                    if("#text" == _fildName){break;};
	                    if(_itemobj[_fildName] != undefined){//如果有重复的节点需要转为数组格式
	                        if(!(_itemobj[_fildName] instanceof Array)){
	                            let a = _itemobj[_fildName];
	                            _itemobj[_fildName] = [a];//如果该节点出现大于一个的情况 把第一个的值存放到数组中
	                        }
	                    }
	                    let _fildValue = getAllAttrs(_node);
	                    try{
	                        _itemobj[_fildName].push(_fildValue);
	                    }catch(e){
	                        _itemobj[_fildName] = _fildValue;
	                        _itemobj["length"] = 1;
	                    }
	                }
	           }else{
	                _itemobj = (node.textContent == undefined) ? node.text : node.textContent;
	           }
	           return _itemobj;
	        };
	
	        if(nodename){
	            nodenames = nodename.split("/")
	        }
	        for(let i = 0;i < nodenames.length; i++){
	            obj = obj.find(nodenames[i]);
	        }
	        obj.forEach(function(key, item){
	            if(itemobj[item.nodeName] != undefined){
	                if(!(itemobj[item.nodeName] instanceof Array)){
	                    let a = itemobj[item.nodeName];
	                    itemobj[item.nodeName] = [a];
	                }
	                itemobj[item.nodeName].push(getAllAttrs(item));
	            }else{
	                if(nodenames.length > 0){
	                    itemobj[item.nodeName] = getAllAttrs(item);
	                }else{
	                    itemobj[item.firstChild.nodeName] = getAllAttrs(item.firstChild);
	                }
	            }
	        });
	
	        if(nodenames.length > 1){
	            itemobj = itemobj[nodenames[nodenames.length-1]];
	        }
	        if(isarray && !(itemobj instanceof Array) && itemobj != undefined){
	            itemobj = [itemobj];
	        }
	        return itemobj;
	    },
	
	//  method: parseHTTP( url, options, callback )
	parseHTTP(url, options, callback) {
		let myopt = {};
		for (let key in options) {
			myopt[key] = options[key]; // copy object
		}
		if (!myopt.method) {
			if (typeof(myopt.postBody) == "undefined" &&
				typeof(myopt.postbody) == "undefined" &&
				typeof(myopt.parameters) == "undefined") {
				myopt.method = "get";
			} else {
				myopt.method = "post";
			}
		}
		if (callback) {
			myopt.asynchronous = true; // async-mode
			let __this = this;
			let __func = callback;
			let __save = myopt.onComplete;
			myopt.onComplete = function(trans) {
				let tree;
				if (trans && trans.responseXML && trans.responseXML.documentElement) {
					tree = __this.parseDOM(trans.responseXML.documentElement);
				}
				__func(tree, trans);
				if (__save) __save(trans);
			};
		} else {
			myopt.asynchronous = false; // sync-mode
		}
		let trans;
		if (typeof(HTTP) != "undefined" && HTTP.Request) {
			myopt.uri = url;
			let req = new HTTP.Request(myopt); // JSAN
			if (req) trans = req.transport;
		} else if (typeof(Ajax) != "undefined" && Ajax.Request) {
			let req = new Ajax.Request(url, myopt); // ptorotype.js
			if (req) trans = req.transport;
		}
		if (callback) return trans;
		if (trans && trans.responseXML && trans.responseXML.documentElement) {
			return this.parseDOM(trans.responseXML.documentElement);
		}
	},
	
	//  method: parseDOM( documentroot )
	parseDOM(root) {
		if (!root) return;
		
		this.__force_array = {};
		if (this.force_array) {
			for (let i = 0; i < this.force_array.length; i++) {
				this.__force_array[this.force_array[i]] = 1;
			}
		}
	
		let json = this.parseElement(root); // parse root node
		if (this.__force_array[root.nodeName]) {
			json = [json];
		}
		if (root.nodeType != 11) { // DOCUMENT_FRAGMENT_NODE
			let tmp = {};
			tmp[root.nodeName] = json; // root nodeName
			json = tmp;
		}
		return json;
	},
	
	//  method: parseElement( element )
	parseElement(elem) {
		//  COMMENT_NODE
		if (elem.nodeType == 7) {
			return;
		}
	
		//  TEXT_NODE CDATA_SECTION_NODE
		if (elem.nodeType == 3 || elem.nodeType == 4) {
			let bool = elem.nodeValue.match(/[^\x00-\x20]/);
			if (bool == null) return; // ignore white spaces
			return elem.nodeValue;
		}
	
		let retval;
		let cnt = {};
	
		//  parse attributes
		if (elem.attributes && elem.attributes.length) {
			retval = {};
			for (let i = 0; i < elem.attributes.length; i++) {
				let key = elem.attributes[i].nodeName;
				if (typeof(key) != "string") continue;
				let val = elem.attributes[i].nodeValue;
				if (!val) continue;
				key = this.attr_prefix + key;
				if (typeof(cnt[key]) == "undefined") cnt[key] = 0;
				cnt[key]++;
				this.addNode(retval, key, cnt[key], val);
			}
		}
		//  parse child nodes (recursive)
		if (elem.childNodes && elem.childNodes.length) {
			let textonly = true;
			if (retval) textonly = false; // some attributes exists
			for (let i = 0; i < elem.childNodes.length && textonly; i++) {
				let ntype = elem.childNodes[i].nodeType;
				if (ntype == 3 || ntype == 4) continue;
				textonly = false;
			}
			if (textonly) {
				if (!retval) retval = "";
				for (let i = 0; i < elem.childNodes.length; i++) {
					retval += elem.childNodes[i].nodeValue;
				}
			} else {
				if (!retval) retval = {};
				for (let i = 0; i < elem.childNodes.length; i++) {
					let key = elem.childNodes[i].nodeName;
					if (typeof(key) != "string") continue;
					let val = this.parseElement(elem.childNodes[i]);
					if (!val) continue;
					if (typeof(cnt[key]) == "undefined") cnt[key] = 0;
					cnt[key]++;
					this.addNode(retval, key, cnt[key], val);
				}
			}
		}
		return retval;
	},
	
	//  method: addNode( hash, key, count, value )
	addNode(hash, key, cnts, val) {
		if (this.__force_array[key]) {
			if (cnts == 1) hash[key] = [];
			hash[key][hash[key].length] = val; // push
		} else if (cnts == 1) { // 1st sibling
			hash[key] = val;
		} else if (cnts == 2) { // 2nd sibling
			hash[key] = [hash[key], val];
		} else { // 3rd sibling and more
			hash[key][hash[key].length] = val;
		}
	},
	
	//  method: writeXML( tree )
	writeXML(tree) {
		let xml = this.hash_to_xml(null, tree);
		return this.xmlDecl + xml;
	},
	
	//  method: hash_to_xml( tagName, tree )
	hash_to_xml(name, tree) {
		let elem = [];
		let attr = [];
		for (let key in tree) {
			if (!tree.hasOwnProperty(key)) continue;
			let val = tree[key];
			if (key.charAt(0) != this.attr_prefix) {
				if (typeof(val) == "undefined" || val == null) {
					elem[elem.length] = "<" + key + " />";
				} else if (typeof(val) == "object" && val.constructor == Array) {
					elem[elem.length] = this.array_to_xml(key, val);
				} else if (typeof(val) == "object") {
					elem[elem.length] = this.hash_to_xml(key, val);
				} else {
					elem[elem.length] = this.scalar_to_xml(key, val);
				}
			} else {
				attr[attr.length] = " " + (key.substring(1)) + '="' + (this.xml_escape(val)) + '"';
			}
		}
		let jattr = attr.join("");
		let jelem = elem.join("");
		if (typeof(name) == "undefined" || name == null) {
			// no tag
		} else if (elem.length > 0) {
			if (jelem.match(/\n/)) {
				jelem = "<" + name + jattr + ">\n" + jelem + "</" + name + ">\n";
			} else {
				jelem = "<" + name + jattr + ">" + jelem + "</" + name + ">\n";
			}
		} else {
			jelem = "<" + name + jattr + " />\n";
		}
		return jelem;
	},
	
	//  method: array_to_xml( tagName, array )
	array_to_xml(name, array) {
		let out = [];
		for (let i = 0; i < array.length; i++) {
			let val = array[i];
			if (typeof(val) == "undefined" || val == null) {
				out[out.length] = "<" + name + " />";
			} else if (typeof(val) == "object" && val.constructor == Array) {
				out[out.length] = this.array_to_xml(name, val);
			} else if (typeof(val) == "object") {
				out[out.length] = this.hash_to_xml(name, val);
			} else {
				out[out.length] = this.scalar_to_xml(name, val);
			}
		}
		return out.join("");
	},
	
	//  method: scalar_to_xml( tagName, text )
	scalar_to_xml(name, text) {
		if (name == "#text") {
			return this.xml_escape(text);
		} else {
			return "<" + name + ">" + this.xml_escape(text) + "</" + name + ">\n";
		}
	},
	
	//  method: xml_escape( text )
	xml_escape(text) {
		return text&&text.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
	},
}

export default BWU;