import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

export default new Router({
	// base: process.env.BASE_URL,
	// mode: 'history',
	routes: [
		// 起始页
		{
			  path: '/',
			  name: 'index',
			  component: () => import('@/views/index/index.vue'),
			  children:[
			  	{ //首页
			  		path: '/main/:hid?/:tid?',
			  		name: 'main',
			  		component: () => import('@/views/main/main.vue')
			  	},
			  	//录像
			  	{ 
			  		path: '/lx-video/:hid?/:tid?',
			  		name: 'lx-video',
			  		component: () => import('@/views/video/lx-video.vue')
			  	},
				// 录像播放页面
				{
					path: '/lx-VideoPlayback/:hid?/:tid?',
					name: 'lx-VideoPlayback',
					component: () => import('@/views/video/lx-VideoPlayback.vue')
				},
				//视频
				{ 
					path: '/sp-video/:hid?/:tid?',
					name: 'sp-video',
					component: () => import('@/views/video/sp-video.vue')
				},
				//新闻
				{ 
					path: '/news/:hid?/:tid?',
					name: 'news',
					component: () => import('@/views/news/news.vue')
				},
				//电视
				{ 
					path: '/tv/:hid?/:tid?',
					name: 'tv',
					component: () => import('@/views/tv/tv.vue')
				},
				// 电视-地方频道
				,{
					path: '/localTv/:hid?/:tid?',
					name: 'localTv',
					component: () => import('@/views/tv/localTv.vue')
				},
				//电视
				{ 
					path: '/tvDetails/:hid?/:tid?',
					name: 'tvDetails',
					component: () => import('@/views/tv/tvDetails.vue')
				},
				//数据
				{ 
					path: '/datas/:hid?/:tid?',
					name: 'datas',
					component: () => import('@/views/datas/datas.vue')
				},
				//下载
				{ 
					path: '/download/:hid?/:tid?',
					name: 'download',
					component: () => import('@/views/download/download.vue')
				},
				// 新闻详情
				,{ 
					path: '/nDetail/:hid?/:tid?',
					name: 'nDetail',
					component: () => import('@/views/news/nDetail.vue')
				},
				// 比赛直播室
				{ 
					path: '/liveRoom/:hid?/:tid?/:lid?',
					name: 'liveRoom',
					component: () => import('@/views/video/live-room.vue')
				}
				// 视频详情
				,{ 
					path: '/spDetail/:hid?/:tid?',
					name: 'spDetail',
					component: () => import('@/views/video/spDetail.vue')
				},
				// 播放器
				{ 
					path: '/playerVideo/:hid?/:tid?',
					name: 'playerVideo',
					component: () => import('@/views/video/player-video.vue')
				},
				// 导航二级分类
				{ 
					path: '/navPage/:hid?/:tid?',
					name: 'navPage',
					component: () => import('@/views/main/navPage.vue')
				},
				// 录像详情
				{ 
					path: '/lxDetails/:hid?/:sid?',
					name: 'lxDetails',
					component: () => import('@/views/video/lx-details.vue')
				},
				// 搜索详情
				{ 
					path: '/searchDetails/:hid?/:sid?',
					name: 'searchDetails',
					component: () => import('@/views/main/search-details.vue')
				},
			],
			redirect: '/main/1/:tid?'	
		},
	],
	/*跳转页面默认最顶部*/
	scrollBehavior (to, from, savedPosition) {
		return { x: 0, y: 0}
	}

})
