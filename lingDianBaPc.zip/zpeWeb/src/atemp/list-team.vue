<template>
	<div class="list-team">
		<div class="list-team-head list-atemp-head">
			<div class="list-atemp-tip">
				<span class="tip-text">{{ teamName }}-相关直播</span>
			</div>
			<div><span class="list-more pointer" @click="toMore">更多 >></span></div>
		</div>
		<div class="list-team-body" v-if="teamList.length">
			<div class="list-team-maindiv" v-for="(items, indexs) in teamList" :key="items.dateString">
				<div
					class="list-team-view poinbut"
					v-if="items.sportMatchVOS[index].matchLiveSourceDOS.length"
					v-for="(item, index) in items.sportMatchVOS"
					:key="index"
					:style="{ height: lineHeight + 'px' }"
					@click="changePlayer(item)"
				>
					<div class="team-top">
						<span>{{ items.dateString }}</span>
						<span></span>
					</div>
					<div class="team-content">
						<div class="team-content-left">{{ item.eventName }}</div>
						<div class="team-content-right" v-if="item.homeTeamName != '' && item.homeTeamName != null && item.guestTeamName != '' && item.guestTeamName != null">
							<span class="team-zd">{{ item.homeTeamName }}</span>
							<span class="team-vs">VS</span>
							<span class="team-zd">{{ item.guestTeamName }}</span>
						</div>
						<div class="team-content-right" v-else>{{ item | getCombinationTitle }}</div>
					</div>
				</div>
			</div>
		</div>
		<nodata fontSize="1rem" color="#666666" height="auto" v-if="!teamList.length"></nodata>
	</div>
</template>

<script>
export default {
	name: 'list-team',
	props: {
		// teamList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		pageType: {
			//头部页面id
			type: Number | String,
			default: 1
		},
		lineHeight: {
			type: Number,
			default: 75
		},
		teamName: {
			type: String,
			default: ''
		},
		teamId: {
			type: String | Number,
			default: 0
		},
		nodataTitle: {
			type: String,
			default: '暂无数据'
		},
		teamList: Object | Array,
		default: function() {
			return {
				list: []
			};
		}
	},
	created() {
		this.$nextTick(() => {
			console.log(this.teamList, '子组件');
		});
	},
	methods: {
		toMore() {
			this.BR.navTo('/', {
				hid: this.pageType,
				teamId: this.teamId
			});
		},
		changePlayer(item) {
			this.$emit('changePlayer', { matchId: item.matchId });
		}
	},
	filters: {
		// 获取组合标题
		getCombinationTitle: function(item) {
			let date, title, topLine, bottomLine;
			// 日期
			/* let time = item.matchBeginTime.trim().split(/\s+|:|-/g);
				date = time[1] + '-' + time[2]; */
			if (item.homeTeamName != '' && item.homeTeamName != null && item.guestTeamName != '' && item.guestTeamName != null) {
				// 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题
				if (item.eventTypeName == '' || item.eventTypeName == null) {
					title = item.specialName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle;
				} else if (item.eventTypeName == '其他') {
					title = item.eventName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle;
				} else {
					title = item.eventTypeName + item.matchTitle;
				}
				// topLine = "<div class='typeName'>"+ date + '&emsp;' + title +"</div>"
				/* topLine = "<div class='typeName'>"+ title +"</div>"
					bottomLine = "<div class='matchTitle'>"+ item.homeTeamName + ' - ' + item.guestTeamName +"</div>" */
				bottomLine = item.homeTeamName + ' - ' + item.guestTeamName;
			} else {
				title = item.eventTypeName == '' || item.eventTypeName == null ? item.specialName : item.eventTypeName == '其他' ? item.eventName : item.eventTypeName;
				/* topLine = "<div class='typeName'>"+ title +"</div>"
					bottomLine = "<div class='matchTitle'>"+ item.matchTitle +"</div>" */
				bottomLine = title + ' ' + item.matchTitle;
			}
			// js空格符：'\xa0'
			// return topLine + bottomLine
			return bottomLine;
		}
	}
};
</script>

<style lang="scss" scoped>
.list-team {
	flex: 1;
	overflow: hidden;
	text-align: left;

	.list-team-body {
		background: #fff;
		// min-height: 1.25rem;
		.list-team-maindiv {
			.list-team-view {
				padding: 0 0.625rem;
				display: flex;
				flex-direction: column;
				align-items: flex-start;
				justify-content: flex-start;
				border-bottom: 0.0625rem solid rgba(0, 0, 0, 0.3);
				flex: 1;
				font-size: 0.875rem;
				font-weight: 500;
				color: $color-heise;
				// &:last-child{border:0}
				> div {
					display: flex;
					flex: 1;
					width: 100%;
				}
				.team-top {
					align-items: center;
					span {
						color: $bg-span;
					}
				}
				.team-content {
					align-items: flex-start;
					flex: 1;
					.team-content-left {
						flex: 1;
					}
					.team-content-right {
						display: flex;
						flex: 3;
						justify-content: center;
						align-items: center;
						> span {
							text-align: center;
						}
						> span:first-child {
							text-align: right;
						}
						> span:last-child {
							text-align: left;
							color: $color-huise;
						}
						.team-zd {
							flex: 3;
							white-space: nowrap;
						}
						.team-vs {
							flex: 1;
						}
						.team-kd {
							flex: 3;
						}
					}
				}
			}
		}
	}
}
</style>
