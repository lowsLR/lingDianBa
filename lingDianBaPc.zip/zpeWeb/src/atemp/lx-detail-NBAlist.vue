<template>
	<div class="lxvideo-layout">
		<div class="list-atemp-head">
			<div class="list-atemp-tip">
				<span class="tip-text">{{ ftitle }}</span>
			</div>
			<div><span class="list-more pointer" @click="newNavTo">更多 >></span></div>
		</div>
		<hr style="width: 100%height:0.125rem;background:rgba(27,27,48,1);" />
		<div class="main-list-div ">
			<div class="main-list-big bgw mb15">
				<div v-for="(i, indexs) in livelist" :key="indexs" class="flex main-list-small" :class="[indexs == 1 ? 'bg-dan' : '']">
					<template v-if="i.homeTeamName">
						<div class="small-left">
							<div class="matchEndTime">{{ i.matchBeginTime | timeFilters }}</div>
							<div class="eventName">{{ i.eventName }}</div>
						</div>
						<div class="small-type">{{ i.matchTitle }}</div>
						<div class="small-content">
							<div class="flex-cc">
								<span>{{ i.homeTeamName }}</span>
								<span>VS</span>
								<span>{{ i.guestTeamName }}</span>
							</div>
						</div>
						<div class="small-right flex-cc"><div class="right-but poinbut" @click="topage(i)">观看录像</div></div>
					</template>
					<template v-else>
						<div class="small-left">
							<div class="matchEndTime">{{ i.matchBeginTime | timeFilters }}</div>
							<div class="eventName">{{ i.eventName }}</div>
						</div>
						<div class="small-type"></div>
						<div class="small-type-event">
							<span>{{ i.eventTypeName == '其他' ? '' : i.eventTypeName }}</span>
							<span>{{ i.matchTitle }}</span>
						</div>
						<div class="small-right flex-cc"><div class="right-but poinbut" @click="topage(i)">观看录像</div></div>
					</template>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
let that;
const { log } = console;
export default {
	name: 'lx-detail-NBAlist',
	props: {
		ftitle: {
			type: String,
			default: 'NBA录像'
		},
		flag: {
			type: String,
			default: 'true'
		},
		livelist: {
			type: Array,
			default: () => {
				return [];
			}
		},
		navItem: {
			type: Object,
			default: () => {
				return {
					id: '', // 标签id
					type: 5, // 标签类型 3热门 4完结 5全部
					name: '全部' // 标签名称
				};
			}
		}
	},
	data() {
		return {};
	},

	created: function() {
		that = this;
		// console.log('获取vuex', that.$store.state);
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
		// console.log('live-list的', that.$route.params);
	},

	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${M}-${D} ${h}:${m}`;
			}
		}
	},
	methods: {
		topage(item) {
			this.BR.navTo('/liveRoom', {
				hid: 1,
				matchId: item.matchId,
				activeName: 'lx',
				isLx: 'islx'
			});
		},
		newNavTo() {
			this.BR.navTo('/lx-video', {
				hid: 2
			});
		}
	}
};
</script>

<style lang="scss" scoped>
ul,
li {
	list-style: disc inside !important;
}
.lxvideo-layout {
	// border: 1px solid red;
	width: 66.5rem;
}
.list-atemp-tip {
	.tip-text {
		font-size: 1.375rem !important;
		font-family: Microsoft YaHei;
		font-weight: bold;
		color: rgba(27, 27, 48, 1);
		display: flex;
		align-items: center;
		margin-bottom: 0.9375rem;

		&::before {
			content: '';
			width: 0.375rem;
			height: 1.625rem;
			background: rgba(27, 27, 48, 1);
			margin-right: 0.875rem;
		}
	}
}
.main-list-div {
	.main-list-big {
		.live-title {
			padding-left: 0.625rem;
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(255, 83, 55, 1);
			line-height: 1.75rem;
			background: rgba(255, 83, 55, 0.13);
		}
		.main-list-small {
			height: 5.5rem;
			border-bottom: 0.0625rem dashed rgba(153, 153, 153, 1);
			cursor: pointer;
			// display: flex;
			// justify-content: space-between;

			&:last-child {
				border-bottom: 0;
			}
			.small-left,
			.small-type {
				display: flex;
				justify-content: center;
				align-items: center;
				flex-direction: column;
				padding: 1.4375rem;
				font-size: 1rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				line-height: 1.75rem;
				// border: 1px solid red;

				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
			}
			.small-left {
				// width: 5.9375rem;
				.matchEndTime {
					width: 5.9375rem;
					color: rgba(255, 83, 55, 1);
				}
				.eventName {
					color: rgba(102, 102, 102, 1);
				}
			}
			.small-type {
				// width: 290px;
				width: 18.125rem;
				color: rgba(0, 0, 0, 1);
			}
			.small-content {
				padding: 1.4375rem;
				flex: 1;
				display: flex;
				align-items: center;
				.flex-cc {
					flex: 1;
					// border: 1px solid red;
				}

				span {
					padding: 0 1.875rem;
					// width: 33%;
					// border: 1px solid red;

					&:nth-child(1),
					&:nth-child(3) {
						width: 40%;
						// border: 1px solid red;
					}

					&:nth-child(2) {
						width: 20%;
						// border: 1px solid red;
					}
				}
				img {
					width: 2.1875rem;
					height: 2.625rem;
					border-radius: 50%;
				}
			}
			.small-right {
				// width: 320px;
				padding: 0 1.5rem;
				display: flex;
				justify-content: center;
				align-items: center;
				position: relative;

				// border: 1px solid red;
				.right-but {
					width: 6.125rem;
					height: 1.75rem;
					background: rgba(255, 83, 55, 1);
					border-radius: 0.875rem;

					font-size: 1rem;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: rgba(255, 255, 255, 1);
					line-height: 1.75rem;
				}
				.right-span {
					display: flex;
					// flex-wrap: wrap;
					flex-direction: column;
					align-items: center;
					justify-content: flex-start;
					// padding-right: 24px;
					// position: absolute;
					// right: 0;
					span {
						// padding: 5px;
						font-size: 1rem;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: rgba(51, 51, 51, 1);
						line-height: 1.75rem;
					}
				}
			}
		}
	}
}

.bg-dan {
	background: rgba(255, 83, 55, 0.06);
}

.small-type-event {
	display: flex;
	align-items: center;
	justify-content: center;
	// border: 1px solid red;
	flex: 1;

	span:nth-child(1) {
		margin-right: 0.625rem;
	}
}
</style>
