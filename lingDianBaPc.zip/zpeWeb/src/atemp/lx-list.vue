<template>
	<div class="lx-details-layout">
		<div class="lx-container" v-for="(item, index) in livelist" :key="index">
			<div class="lx-detailds-list">
				<div class="lx-date">{{ item.matchBeginTime | timeFilters }}</div>
				<div class="lx-match-title">
					{{
						item.guestTeamId && item.homeTeamId
							? item.eventTypeName
								? item.eventTypeName == '其他'
									? item.eventName + (item.matchTitle ? ' ' : '') + item.matchTitle
									: item.eventTypeName + item.matchTitle
								: item.specialName + (item.matchTitle ? ' ' : '') + item.matchTitle
							: item.eventTypeName
							? item.eventTypeName == '其他'
								? item.eventName
								: item.eventTypeName
							: item.specialName
					}}
				</div>

				<div class="lx-match-tea">
					<template v-if="item.guestTeamId && item.homeTeamId">
						<div class="homeTeamName">{{ item.homeTeamName }}</div>
						<div class="vs">VS</div>
						<div class="guestTeamName">{{ item.guestTeamName }}</div>
					</template>
					<template v-else>
						<span>{{ item.matchTitle }}</span>
					</template>
				</div>

				<button class="videotape poinbut" @click="toDetails(item)" v-if="item.matchStartState == 0 && item.isClick == 'true'">正在直播</button>
				<button class="videotape active-no poinbut" @click="toDetails(item)" v-if="item.matchStartState == 1">未开赛</button>
				<button class="videotape poinbut" @click="toDetails(item)" v-if="item.matchStartState == 2" :class="{ active: item.isClick == 'false' }">观看录像</button>
				<button class="videotape poinbut" @click="toDetails(item)" v-if="videotapeFlag">观看录像</button>
			</div>
			<!-- 广告位置 -->
			<template v-if="livelist.length >= advlistIndex && index == advlistIndex && viedeoType == 'lx'">
				<AdSlot :AdName="'LXLB-1'" locationPosition="1" locationType="1" :adWidth="65" :adHeight="5.625" adStr="lx" @advIndex="advIndex"></AdSlot>
			</template>
		</div>
	</div>
</template>

<script>
let that;
const { log } = console;
export default {
	name: 'lx-list',
	props: {
		livelist: {
			type: Array,
			value: []
		},
		// 录像查询
		videotapeFlag: {
			type: Boolean,
			default: () => {
				return false;
			}
		},
		//面包屑
		navItem: {
			type: Object,
			default: () => {
				return {
					id: '', // 标签id
					type: 5, // 标签类型 3热门 4完结 5全部
					name: '全部' // 标签名称
				};
			}
		},
		viedeoType: {
			type: String,
			default: 'lx'
		}
	},
	data() {
		return {
			// livelist:test1,
			advlistIndex: ''
		};
	},
	created() {
		that = this;
		this.$nextTick(() => {
			// console.log(this.livelist,"===>livelist")
		}, 1000);
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${Y}-${M}-${D} ${h}:${m}`;
			}
		}
	},
	methods: {
		advIndex(i) {
			this.advlistIndex = i;
		},
		// 页面跳转到录像
		navtoLxDetail(matchId) {
			this.BR.navTo('/liveRoom', {
				hid: 1,
				matchId: matchId,
				activeName: 'lx',
				isLx: 'islx'
			});
		},
		// 页面跳转到视频
		navtoSpDetail(id) {
			this.BR.navTo('/liveRoom', {
				hid: 1,
				matchId: id
			});
		},

		toDetails(item, items) {
			let current = this.$store.state.currentRoute;
			if (item.matchStartState == 0) {
				that.navtoSpDetail(item.matchId);
			} else if (item.matchStartState == 2 && item.isClick == 'true') {
				that.navtoLxDetail(item.matchId);
			} else if (this.videotapeFlag) {
				that.navtoLxDetail(item.matchId);
			}
		}
	}
};
</script>

<style lang="scss" scoped>
ul,
li {
	list-style: disc inside !important;
}

.bg-dan {
	background: rgba(255, 83, 55, 0.06);
}

.lx-details-layout {
	width: 66.5rem;
	background: rgba(255, 255, 255, 1);
	padding: 0 0.8125rem;

	.lx-container {
		font-size: 1rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(0, 0, 0, 1);
		line-height: 1.75rem;
		// border-bottom: 1px dashed rgba(153, 153, 153, 1);
		&:last-child .lx-detailds-list {
			border-bottom: 0;
		}
	}
	.lx-detailds-list {
		display: flex;
		flex-direction: row;
		align-items: center;
		line-height: 5.4375rem;
		padding: 0 0.8125rem;
		// border-bottom: 0.03125rem dashed rgba(153, 153, 153, 1);
		border-bottom: 0.0625rem dashed #b3b3b3;
	}

	.lx-date {
		width: 9.375rem;
		text-align: left;
		// border: 1px solid red;
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		word-break: break-all;
	}

	/* 赛事类型 */
	.lx-match-title {
		width: 14rem;
		text-align: center;
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		word-break: break-all;
		// border: 1px solid blue;
	}
	/* 赛事标题 */
	.lx-match-tea {
		flex: 1;
		display: flex;
		align-items: center;
		flex-direction: row;
		justify-content: center;
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		word-break: break-all;
		// border: 1px solid red;
		span {
			width: 100%;
			white-space: nowrap;
			text-overflow: ellipsis;
			overflow: hidden;
			// word-break: break-all;
			// border: 1px solid red;
		}
		.homeTeamName,
		.guestTeamName {
			flex: 1;
		}
		.vs {
			width: 2.5rem;
			font-weight: bold;
		}
	}

	.lx-type {
		display: flex;
		align-items: center;
		flex: 1;
		// justify-content: center;

		.eventTypeName {
			margin-right: 0.9375rem;
		}
	}

	.videotape {
		// width: 98px;
		// height: 28px;
		width: 6.125rem;
		height: 1.75rem;
		background: rgba(255, 83, 55, 1);
		border-radius: 0.875rem;
		color: rgba(255, 255, 255, 1);
		text-align: center;
		line-height: 1.75rem;
		margin: 0;
		padding: 0;
		border: 0.0625rem solid transparent; //自定义边框
		outline: none;
	}
	.videotape.active-no,
	.videotape.active {
		background: rgba(230, 230, 230, 1) !important;
		color: rgba(153, 153, 153, 1) !important;
	}

	.lx-match-title-have {
		flex: 1;
		// border: 1px solid red;
		// text-align: left;
		text-align: center;
	}
}

.advertisingSpace {
	// width: 66.5rem;
	height: 5.625rem;
	display: flex;
	align-items: center;
	justify-content: center;
	// border: 1px solid red;
	background: #f5f5f5;
	margin-top: -0.0625rem;
}
</style>
