<template>
	<div>
		<div
			class="list-one"
			:style="{
				listStyle
			}"
		>
			<div class="list-one-head">
				<div class="list-atemp-tip">
					<img
						src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAUCAYAAAB4d5a9AAABQUlEQVQ4jdXVr0tDYRTG8c+mw6CuCeJdsqxuGAXBf0A0qM2/wKBB1gwaBBEULCaDCGrSZDGL4A+GcSBY7l8gboJlBrfgvHdu7Cr4lAPvc3i+HHjf86aCoKChWaxiAoN+VhUP2A3D8kW7xnSjbuMcUx0CNPqmcJ7LFbd/gsxgrcPgOK3lcsWZdpCVHgFNxeakgqDwguEEIK9xOekoo1RaVqlcK5WWu4EMxRmpICjUWw+fn29lMhnVak0+P9kNKNWoC9hCgMt0VOfBwZFa7c3h4Uk3gCZkA6cYxwDmIifpQWdYbD2MnKQHfQP8BiRS/xJy/BeQJazjy2VKGlLHJubxhHdcJLlWqmJefRr3CQDgLs7oxx6mE4DshWE50ujLZkcrPj+grpZUi3bCsLwfZ/Zls6NwhUeMYQSZDoJruMFKOwB8AO6NRD2kWD62AAAAAElFTkSuQmCC"
						alt=""
					/>
					<span class="tip-text">{{ ftitle }}</span>
				</div>
				<div><span class="list-more pointer" @click="toMore" v-if="isMore">更多 >></span></div>
			</div>
			<div class="list-one-body">
				<div v-for="(item, index) in oneList.list" class="list-one-item" :key="index" v-if="oneList.list">
					<div class="item-left">
						<div class="pointer" @click="navTo(item)" v-if="item.homeTeamName">{{ item.homeTeamName }} - {{ item.guestTeamName }}</div>
						<div class="pointer" @click="navTo(item)" v-if="!item.homeTeamName">{{ item.eventTypeName == '其他' ? '' : item.eventTypeName }} {{ item.matchTitle }}</div>
					</div>
					<div class="item-right" v-if="isTime">{{ item.matchEndTime | timeFilters }}</div>
				</div>
				<nodata fontSize="1rem" color="#666666" v-if="!oneList.list" height="16.875rem"></nodata>
			</div>
		</div>
	</div>
</template>

<script>
let that;
export default {
	name: 'lx-video-hot-list',
	props: {
		// oneList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		isTime: {
			type: Boolean,
			default: false
		},
		pageType: {
			//头部页面id
			type: Number | String,
			default: 1
		},
		ftitle: {
			type: String,
			default: '数据'
		},
		oneList: Object,
		default: function() {
			return {
				num: 5,
				title: '热门视频',
				list: []
			};
		},
		isMore: {
			type: Boolean,
			value: true
		}
	},
	created() {
		that = this;
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${M}-${D}`;
			}
		}
	},
	methods: {
		toMore() {
			this.BR.navTo('/lx-video', { hid: 2 });
		},
		navTo(item) {
			this.BR.navTo('/liveRoom', {
				matchId: item.matchId,
				activeName: 'lx',
				isLx: 'islx',
				hid: 1
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.list-one {
	flex: 1;
	overflow: hidden;
	text-align: left;
	.list-one-body {
		width: 100%;
		padding: 0.9375rem;
		// max-height: 50rem;
		background: rgba(255, 255, 255, 1);
		// border: 1px solid red;
		.list-one-item {
			display: flex;
			align-items: center;
			justify-content: space-between;
			font-size: 0.875rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			line-height: 1.625rem;
			height: 1.625rem;
			margin-bottom: 0.375rem;
			// border: 1px solid red;
			&:last-child {
				margin-bottom: 0;
			}

			&::before {
				content: '·';
				display: inline-block;
				position: absolute;
				font-size: 1.875rem;
				// border: 1px solid red;
				// margin-right: 0;
			}
			.item-left {
				flex: 1;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				// border:1px solid red;
			}
			span {
				font-size: 0.875rem;
			}
			div {
				margin-left: 0.75rem;
				line-height: 2.125rem;
				overflow: hidden;
				text-overflow: ellipsis;
			}
		}
	}

	.list-atemp-tip {
		display: flex;
		align-items: center;
		border-bottom: 0.125rem solid #1b1b30;
		padding-bottom: 0.5625rem;
		// border: 1px solid red;
		img {
			width: 1.5625rem;
			height: 1.25rem;
			display: inline-block;
		}

		.tip-text {
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: bold;
			color: rgba(27, 27, 48, 1);
			line-height: 28px;
			margin-left: 0.625rem;
		}
	}
}

.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
