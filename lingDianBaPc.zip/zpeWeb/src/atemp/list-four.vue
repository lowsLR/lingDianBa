<template>
	<div>
		<div class="list-four" >
			<ul class="list-four-body">
				<li class="li-mian" v-for="(item,index) in fourList.list" :key="index">
					<span>[2020年1月1日]  - </span>
					<span>{{item.stype}}</span>
					<span>{{item.title}}</span>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'list-four',
		props: {
			// fourList: Array,
			listStyle: { //样式
				type: String,
				default: ''
			},
			nodataTitle: { //无数据显示
				type: String,
				default: '暂无数据'
			},
			fourList: Object,
			default: function() {
				return {
					num: 5,
					title: '热门视频',
					list: [],
				}
			}
		}
	}
</script>

<style lang="scss">
	.list-four {
		flex: 1;
		overflow: hidden;
		text-align: left;
	}

	.list-four-tip {
		display: inline-block;
		width: 9.375rem;
		height: 2.1875rem;
		color: $bg-main;
	}

	.tip-text {
		font-size: 1rem;
		font-family: Microsoft YaHei;
		font-weight: 600;
		color: $bg-main;
		display: flex;
		padding-left: 0.3125rem;
	}
	.list-more {
		font-size: 0.75rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(102, 102, 102, 1);
	}
	.li-mian{
		box-sizing: border-box;
		border-bottom:0.0625rem solid rgba(225,225,225,1);
		display: flex;
		justify-content: center;
		align-items: center;
		
		font-size:1.0625rem;
		font-family:Microsoft YaHei;
		font-weight:400;
		color:rgba(51,51,51,1);
		line-height:2.875rem;
	}
	.li-mian:last-child{
		border: none;
	}
	.list-four .list-four-head {
		height: 2.1875rem;
		line-height: 2.1875rem;
		font-size: 1.125rem;
		font-weight: 600;
		display: flex;
		justify-content: space-between;
	}

	.list-four .list-four-body {
		background: #fff;
		padding: 0.3125rem;
	}

	.list-four .list-four-body li {
		height: 4rem;
		line-height: 4rem;
		display: block;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.list-four ul {
		width: 100%
	}

</style>
