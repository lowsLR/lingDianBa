<template>
	<div>
		<div
			class="list-two"
			:style="{
				listStyle
			}"
		>
			<div class="list-two-head list-atemp-head">
				<div class="list-atemp-tip">
					<img src="../static/main/lx.png" />
					<span class="tip-text">{{ ftitle }}</span>
				</div>
				<div><span class="list-more pointer" @click="toMore">更多 >></span></div>
			</div>
			<div class="list-two-view">
				<div class="">
					<ul class="list-two-body" v-if="oneList.length">
						<li v-for="(item, index) in oneList" class="list-two-item" :key="'b' + index">
							<span class="pointer" target="_blank" @click="toDetails(item)">{{ item.homeTeamName }} - {{ item.guestTeamName }}</span>
						</li>
					</ul>
					<nodata fontSize="1rem" color="#666666" height="10.625rem" v-if="!oneList.length"></nodata>
				</div>
				<div class="bbd">
					<ul class="list-two-body pt10" v-if="twoList.length">
						<li v-for="(item, index) in twoList" class="list-two-item" :key="'z' + index">
							<span class="pointer" target="_blank" @click="toDetails(item)">{{ item.homeTeamName }} - {{ item.guestTeamName }}</span>
						</li>
					</ul>
					<nodata fontSize="1rem" color="#666666" height="10.625rem" v-if="!twoList.length"></nodata>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'list-two',
	props: {
		// twoList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		pageType: {
			//头部页面id
			type: Number | String,
			default: 1
		},
		nodataTitle: {
			type: String,
			default: '暂无数据'
		},
		ftitle: {
			//头部页面id
			type: String,
			default: ''
		},
		twoList: Array,
		default: function() {
			return [];
		},
		oneList: {
			type: Array,
			default: function() {
				return [];
			}
		}
	},
	data() {
		return {
			navItem: {
				id: '', // 标签id
				type: 5, // 标签类型 3热门 4完结 5全部
				name: '全部' // 标签名称
			}
		};
	},
	methods: {
		toMore() {
			// this.BW.navTo({ type: this.pageType });
			this.BR.navTo('/lx-video', { hid: 2 });
		},
		navTo(item) {
			this.$router.push({
				path: '/nDetail',
				query: {
					hid: 5,
					nid: item.id
				}
			});
		},

		toDetails(item) {
			this.BR.navTo('/liveRoom', {
				matchId: item.matchId,
				activeName: 'lx',
				hid: 1
			});
		},

		// 查询有录像比赛的详情
		getQueryMatchByVideoDetial(matchId) {
			return new Promise((resolve, reject) => {
				// ... some code
				let datas = {
					matchDate: '',
					matchId: matchId,
					sourceType: 1,
					offset: 1,
					limit: 4
				};
				this.$newsReq
					.queryMatchByVideo(datas)
					.then(res => {
						if (res.status === 200 && res.data.resultCode === 1) {
							let list = res.data.data.list[0],
								sourceList = [],
								obj = {};
							// console.log("list: ",list);
							list.matchLiveSourceDOS.forEach(item => {
								sourceList.push(item);
							});
							obj = {
								matchId: list.matchId,
								sourceId: sourceList[0].sourceId
							};
							console.log(obj);

							resolve(obj);
						}
					})
					.catch(err => {
						// console.log('错误的err：', err);
					});
			});
		}
	}
};
</script>

<style lang="scss">
.bbd {
	border-top: 0.0625rem dotted rgba(153, 153, 153, 1);
}
.pt10 {
	padding-top: 0.625rem;
}
.list-two-view {
	height: 21.25rem;
	padding: 0.625rem;
	background: #fff;
	& > div {
		height: 50%;
		// height: 10.5rem;
		width: 100%;
		// .list-two-body:first-child{
		// 	height: 100%;
		// }
		.list-two-body {
			width: 100%;
			display: flex;
			// justify-content: flex-start;
			// align-items: flex-start;
			justify-content: flex-start;
			// justify-content: space-between;
			// align-items: flex-end;

			align-content: flex-start;

			flex-wrap: wrap;
			// list-style: none;
			// counter-reset: count;
			height: 100%;
			// padding-left: 0.625rem;

			.list-two-item {
				display: flex;
				width: 50%;
				// padding: 0.625rem;
				// flex: 1;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				position: relative;
				align-items: center;
				font-size: 0.875rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(102, 102, 102, 1);

				// line-height:1.75rem;

				&::before {
					content: '·';
					display: inline-block;
					position: absolute;
					font-size: 1.875rem;
				}
				span {
					font-size: 0.875rem;
					padding-right: 0.75rem;
					margin-left: 0.75rem;
					overflow: hidden;
					text-overflow: ellipsis;
					font-weight: 400;
					color: rgba(102, 102, 102, 1);
					line-height: 1.88rem;
				}
				&:nth-child(even) {
					padding-left: 0.625rem;
				}
			}
		}
	}
}
.list-two {
	flex: 1;
	overflow: hidden;
	text-align: left;
}
</style>
