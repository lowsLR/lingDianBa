<template>
	<div>
		<div class="tem-div">
			<div class="flex flex-jc-sb flex-ai-c">
				<div class="s-header iscolor" v-if="other">
					<span>相关</span>
					<span style="color:#FF5337;">频道</span>
				</div>
				<div class="s-header" v-if="!other">
					<span>{{ title }}</span>
				</div>
				<div class="more-div pointer" @click="toMore" v-if="isFlag">更多 >></div>
			</div>
			<div class="flex-worp " v-if="clist.length">
				<div @click="navToTvDetails(item.id)" class="pointer channel-item more-hidden1" v-for="(item, index) in clist" :key="index">
					<span v-if="index < showTvNum">{{ item.tvName }}</span>
				</div>
			</div>
			<div class="flex-worp" v-if="!clist.length"><nodata height="12.5rem" title="暂无数据" fontSize="1rem"></nodata></div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'channel',
	props: {
		pageType: {
			//头部页面id
			type: Number | String,
			default: 4
		},
		isNoNavto: {
			type: Boolean,
			default: false
		},
		isFlag: {
			type: Boolean,
			default: true
		},
		clist: {
			type: Array,
			default: () => {
				return [];
			}
		},
		showTvNum: {
			type: Number | String,
			default: 18
		},
		noData: {
			type: Boolean,
			default: false
		},
		title: {
			type: String,
			default: '其他体育频道'
		},
		other: {
			type: Boolean,
			default: true
		}
	},
	data() {
		return {};
	},
	created() {},
	methods: {
		toMore() {
			// this.BW.navTo({ type: this.pageType });
			this.BR.navTo('/tv', {
				hid: 4
			});
		},
		toTv() {},

		navToTvDetails(id) {
			console.log(id, '===>电视频道id');
			this.BR.navTo('/tvDetails', {
				hid: 4,
				tid: id
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.channel-div {
	width: 19.875rem;
	background: rgba(255, 255, 255, 1);
}

.s-header {
	font-size: 1rem;
	font-family: Microsoft YaHei;
	line-height: 1.75rem;
	border-bottom: 0.125rem solid #1b1b2f;
	width: 100%;
	text-align: left;
	background: #f5f5f5;
	font-weight: 400;
	color: rgba(27, 27, 47, 1);
	&::before {
		border-left: 0.375rem solid #1b1b2f;
	}
}
.iscolor {
	font-weight: 400 !important;
	&::before {
		border-left: 0.375rem solid #ff5337;
	}
}
.flex-worp {
	display: flex;
	// justify-content: space-around;
	align-items: flex-start;
	flex-wrap: wrap;
	// padding-bottom: 0.3125rem;
	// padding-top: .5625rem;
	// padding-left: 0.3125rem;
	// padding: 0.625rem;
	background: #ffffff;
	padding: 0 0.625rem;
	justify-content: space-between;
	// border: 1px solid red;
	div {
		// width: 32%;
		width: 5.625rem;
		text-align: left;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		// border: 1px solid red;
		box-sizing: border-box;
		padding: 0 0.3125rem;
		// &:nth-child(3n-1) {
		// 	margin: 0 5px;
		// }
	}
}
.channel-item {
	font-size: 0.875rem;
	font-weight: 400;
	color: rgba(102, 102, 102, 1);
	line-height: 2.45rem;
}
</style>
