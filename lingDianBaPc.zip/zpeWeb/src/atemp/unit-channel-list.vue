<template>
	<div class="tvList">
		<div class="tvItem" v-for="(citem, cindex) in urbanDistrictList" :key="cindex" @click="navTo(citem)">
			<img @error="errorImg($event, defaultImg)" :src="citem.imgLog ? citem.imgLog : require('../static/image/default_img.png')" />
			<p class="name pointer">{{ citem.tvName }}</p>
		</div>
	</div>
</template>

<script>
let that;
export default {
	name: 'unit-channel-list',
	props: {
		urbanDistrictList: {
			type: Array,
			value: []
		}
	},
	data() {
		return {
			defaultImg: require('../static/image/default_img.png') // 默认图片
		};
	},
	created: function() {
		that = this;
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
	},
	methods: {
		navTo(item) {
			// console.log(item, '===>vid');
			this.BR.navTo('/tvDetails', {
				hid: 4,
				tid: item.id,
				sid: 3,
				tvBrief: item.tvBrief
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.tvList {
	display: flex;
	flex-wrap: wrap;
	// justify-content: space-between;
	overflow: hidden;
	background-color: #ffffff;
}
.tvItem {
	width: 9.375rem;
	height: auto;
	// 左右间距计算(列数：5)：1064 - (150 * 5) / (5 * 2) = 31.4
	margin: 1.125rem 1.9375rem;
	// background-color: peachpuff;

	img {
		width: auto;
		max-width: 7.625rem;
		height: 3.25rem;
		margin: 0 auto;
		display: block;
	}
	p {
		font-size: 0.875rem;
		color: #333333;
		margin-top: 0.875rem;

		/* 超出宽度后就隐藏 */
		overflow: hidden;
		/* 规定段落中的文本不换行 */
		white-space: nowrap;
		/* 当文本内容溢出时显示省略标记 */
		text-overflow: ellipsis;
	}
}
</style>
