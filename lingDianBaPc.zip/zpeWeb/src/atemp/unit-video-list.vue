<template>
	<!-- 视频列表 (外层定义宽度) -->
	<div class="video-list" :style="{ width: videoListWidth }">
		<ul class="vBox" v-if="videoList.length">
			<li class="vItem" v-for="(item, index) in videoList" :key="item.id" @click="navTo(item)">
				<div class="coverPic"><img :src="item.imgHref ? item.imgHref : '../static/image/default_img.png'" class="userHead" alt="" /></div>
				<div class="vTitle">{{ item.liveTitle }}</div>
			</li>
			<!-- 占位div -->
			<div class="list" v-for="(item, index) in row - (videoList.length % row)" :key="index" v-if="videoList.length % row > 0"></div>
		</ul>

		<nodata v-else :height="'270px'" :fontSize="'1rem'"></nodata>
	</div>
</template>

<script>
let that;
export default {
	name: 'unit-video-list',
	props: {
		// 是否跳转页面
		isSwitchPages: {
			type: Boolean,
			default: true
		},
		//搜索页面新打开窗口
		searchVideo: {
			type: Boolean,
			default: false
		},
		// 视频id（视频详情页 需传递）
		videoId: {
			type: Number | String
		},
		// 数据列表
		videoList: {
			type: Array,
			// type: Object,
			default: function() {
				return [];
				/* return {
						list: [
							{num: 1, title: '热门视频'},
						],
					} */
			}
		},
		// 列数（控制列表布局）
		row: {
			type: Number,
			default: 4
			// default: 3
		},
		// 标签对象
		tagObj: {
			type: Object,
			default: function() {
				return {
					id: '',
					type: 5,
					name: '全部'
				};
			}
		},
		videoListWidth: {
			type: String,
			default: '100%'
		}
	},
	data() {
		return {};
	},
	created: function() {
		that = this;
		// console.log("获取vuex",that.$store.state)
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
	},
	methods: {
		navTo(item) {
			this.BR.navTo('/spDetail', {
				hid: 3,
				sid: 1,
				vid: item.id,
				tagObj: JSON.stringify(that.tagObj)
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.video-list {
	height: 100%;
	padding: 0.875rem 1.75rem;
	background-color: #ffffff;
	text-align: left;

	.vTitle {
		&:hover {
			color: #ff5337 !important;
		}
	}

	.vBox {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;

		// 加上after伪类，解决最后一排数量不够两端分布的情况(只适合每列有3个的分布情况)
		// &:after {
		// 	content: "";
		// 	width: 312px;
		// }
	}
	.vItem {
		width: 19.5rem;
		height: 15.25rem;
		margin: 0.625rem 0;
		border-radius: 0.625rem;
		overflow: hidden;
		box-shadow: 0 0 0.625rem rgba(0, 0, 0, 0.2);
		display: block;
		cursor: pointer;

		img {
			// width: 100%;
			height: 11.4375rem;
			display: block;
			margin: 0 auto;
		}
		.coverPic {
			position: relative;
			background-color: rgba(0, 0, 0, 1);
		}
		.coverPic:after {
			// content: url(../static/image/playButton.png);
			content: '';
			width: 4rem;
			height: 4rem;
			background: url(../static/image/playButton.png) no-repeat;
			background-size: cover;
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			z-index: 10;
		}

		.vTitle {
			height: 3.8125rem;
			line-height: 1.5rem;
			padding: 0.625rem;
			font-size: 1rem;
			color: #333333;
		}
	}

	.list {
		content: '';
		width: 19.5rem;
		overflow: hidden;
	}
}
</style>
