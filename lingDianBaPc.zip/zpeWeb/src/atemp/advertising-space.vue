<template>
	<div class="advertising-layout" :style="{width:width,height:height,color:color,fontWeight:fontWeight,background:background,fontSize:fontSize,margin:margin}">
		<img :src="img" alt="" v-if="img">
		<div class="textContent" v-if="textContent">{{textContent}}</div>
	</div>
</template>

<script>
export default {
	name: 'advertising-space',
	props: {
		textContent: {
			type: String,
			default: 'DS-1'
		},
		img: {
			type: String,
			default: ''
		},
		width:{
			type: String,
			default: '19.875rem',
		},
		height:{
			type: String,
			default: '10.625rem',
		},
		color:{
			type: String,
			default: '#ffffff',
		},
		fontWeight:{
			type: String,
			default: 'bold',
		},	
		background:{
			type: String,
			default: '#000000',
		},
		fontSize:{
			type: String,
			default: '4.5rem',
		},
		margin:{
			type: String,
			default: '0.625rem 0',
		},
	}
};
</script>

<style lang="scss" scoped>
	.advertising-layout{
		display: flex;
		align-items: center;
		justify-content: center;
		// width:;
	}
</style>
