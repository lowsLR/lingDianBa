<template>
	<!-- 相关新闻 -->
	<div class="types">
		<div class="headTag">
			<!-- <div>{{ eventTypeName == "" || eventTypeName ==null?eventName:(eventTypeName =='其他'?eventName:eventTypeName) }}</div> -->

			<span>{{ title }}</span>
			<span class="more pointer" @click="moreNews" v-if="isMore">更多 >></span>
		</div>
		<div class="newsItem">
			<template v-if="newsList.length > 0">
				<div class="frontNews" v-for="(item, index) in newsList" v-if="index == 0" :key="item.id" @click="navTo(item)">
					<!-- <img :src="item.imgUrl ? 'https://images.weserv.nl/?url=' + item.imgUrl : require('../static/image/default_img.png')" alt="" /> -->
					<img @error="errorImg($event, defaultImg)" :src="item.imgUrl ? item.imgUrl : require('../static/image/default_img.png')" />
					<div class="info">
						<p>{{ item.newsTitle }}</p>
						<span class="margin-text">{{ item.eventName }}</span>
						<span>{{ item.eventTypeName }}</span>
					</div>
				</div>
				<div class="frontNews front" v-for="(item, index) in newsList" v-if="index == 1" :key="item.id" @click="navTo(item)">
					<!-- <img :src="item.imgUrl ? 'https://images.weserv.nl/?url=' + item.imgUrl : require('../static/image/default_img.png')" alt="" /> -->
					<img @error="errorImg($event, defaultImg)" :src="item.imgUrl ? item.imgUrl : require('../static/image/default_img.png')" />
					<div class="info">
						<p>{{ item.newsTitle }}</p>
						<span class="margin-text">{{ item.eventName }}</span>
						<span>{{ item.eventTypeName }}</span>
					</div>
				</div>
				<li v-for="(item, index) in newsList" v-if="index >= 2" :key="item.id" @click="navTo(item)">{{ item.newsTitle }}</li>
			</template>
			<template v-else>
				<div class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
			</template>
		</div>
	</div>
</template>

<script>
let that;
export default {
	name: 'lx-detail-NBA-news',
	props: {
		// 数据列表
		newsList: {
			type: Array,
			// type: Object,
			default: function() {
				return [];
				/* return {
						list: [
							{num: 1, title: '热门视频'},
						],
					} */
			}
		},
		// 列数
		newsNum: {
			type: Number,
			default: 12
		},
		title: {
			type: String,
			default: ''
		},

		isnavto: {
			type: Boolean,
			default: true
		},
		eventTypeName: {
			type: String,
			default: ''
		},
		eventName: {
			type: String,
			default: ''
		},

		navItem: {
			type: Object,
			default: () => {
				return {
					id: '', // 标签id
					type: 5, // 标签类型 3热门 4完结 5全部
					name: '全部' // 标签名称
				};
			}
		},
		isMore: {
			type: Boolean,
			value: true
		}
	},
	data() {
		return {
			defaultImg: require('../static/image/default_img.png') // 默认图片
		};
	},
	created: function() {
		that = this;
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
	},
	methods: {
		navTo(item) {
			this.BR.navTo('/nDetail', {
				hid: 5,
				tid: 1,
				nid: item.id,
				eventTypeName: item.eventTypeName,
				navItem: JSON.stringify(this.navItem),
				sid: 3
			});
		},
		moreNews() {
			this.BR.navTo('/news', {
				hid: 5,
				tid: 1
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.types {
	width: 19.875rem;
	height: auto;
	overflow: hidden;
	margin-bottom: 1.5rem;
	color: #666666;
	cursor: default;

	li,
	p,
	span.more {
		&:hover {
			color: #ff5337 !important;
		}
	}

	.headTag {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 2.25rem;
		box-sizing: border-box;
		border-bottom: 0.125rem solid #1b1b30;

		span:nth-child(1) {
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: bold;
			color: rgba(27, 27, 48, 1);
			line-height: 1.75rem;

			&::before {
				content: '';
				background: #f5f5f5
					url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWCAYAAADEtGw7AAAA1UlEQVQ4jdXVMU4DMRCF4c8ryght77QIyqVLepQzcYIVlyEHQPTQURJEmwOgQB+KtQiyVmiF4yKvm2fNL3tm5AkxdnCBO9zg3DTt8IhbvOeHIcbuEs9oJwJzfWCBt99mg74AKuX2udkYnl+q1Rh4ak3/0mwMXEVnubHdvkxKnM+vx+x7aUpCjN2+6GoHBeylKalRihZ9rRqvaoFnx27ej2o0DxXn+PTAp9m83RGgX3ncGNZLqR7yOMTYXeFJ2WpaYuPwCS2bZCywxuc/wC1eDSVdJ9bmGzb1LujgVTQFAAAAAElFTkSuQmCC)
					no-repeat;
				background-size: cover;
				// width: 22px;
				width: 1.375rem;
				height: 1.375rem;
				display: inline-block;
				margin-right: 0.625rem;
				vertical-align: middle;
				margin-top: -0.25rem;
				// border: 3px solid red;
			}
		}
		span:nth-child(2) {
			font-size: 0.75rem;
			// cursor: pointer;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			line-height: 1.75rem;
		}
	}

	.newsItem {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 0.75rem 0.625rem;
		background-color: #ffffff;
		font-size: 0.875rem;

		li,
		p,
		span {
			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space: nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
		}
		.front {
			margin: 0.6875rem 0;
		}
		.frontNews {
			// height: 4.875rem;
			// margin-bottom: 0.75rem;
			// border-radius: 0.5rem;
			// box-shadow: 0 0 0.625rem rgba(0, 0, 0, 0.1);
			width: 18.625rem;
			height: 4.875rem;
			background: rgba(255, 255, 255, 1);
			box-shadow: 0px 0px 0.375rem 0px rgba(0, 0, 0, 0.3);
			border-radius: 0.5rem;
			overflow: hidden;
			display: flex;
			align-items: center;
			// border: 1px solid red;
			img {
				// height: 4.875rem;
				display: block;
				// min-width:6.125rem;
				// max-height:4.875rem;
				width: 6.125rem;
				height: 4.875rem;
				// height: auto;
				// border: 1px solid red;
				border-radius: 0.5rem 0px 0px 0.5rem;
			}

			.info {
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				overflow: hidden;
				// width: 100%;
				// margin: 0.625rem 0 0.625rem 0.625rem;
				text-align: left;
				cursor: pointer;

				// border: 1px solid red;

				width: 11.5625rem;
				// height:3.375rem;
				font-size: 0.875rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				line-height: 1.25rem;
				margin-left: 0.625rem;

				.margin-text {
					margin: 0.3125rem 0;
				}
			}

			p {
				color: #333333;
			}
			span {
				color: #656565;
			}
		}

		li {
			line-height: 1.75rem;
			cursor: pointer;
			// border: 1px solid red;
			text-align: left;
		}

		li:before {
			content: '';
			width: 0.25rem;
			height: 0.25rem;
			border-radius: 50%;
			background: #666666;
			display: inline-block;
			margin-right: 0.625rem;
			vertical-align: middle;
			margin-top: -0.1875rem;
		}
	}
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
