<template>
	<div>
		<div
			class="list-one"
			:style="{
				listStyle
			}"
		>
			<div class="list-one-head list-atemp-head">
				<div class="list-atemp-tip">
					<img src="@/static/main/lx.png" />
					<span class="tip-text">{{ ftitle }}</span>
				</div>
				<div><span class="list-more pointer" @click="toMore">更多 >></span></div>
			</div>
			<div class="list-one-body">
				<div v-for="(item, index) in list" class="list-one-item" :key="index">
					<div class="item-left">
						<span class="pointer ff-MY c666" @click="toDetails(item)">{{ item.homeTeamName + ' ' }}VS{{ ' ' + item.guestTeamName }}</span>
					</div>
					<div class="item-right" v-if="isTime">{{ item.matchBeginTimeStr }}</div>
				</div>
				<div v-if="!list.length" class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'list-one',
	props: {
		// oneList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		isTime: {
			type: Boolean,
			default: false
		},
		pageType: {
			//头部页面id
			type: Number | String,
			default: 1
		},
		ftitle: {
			type: String,
			default: '数据'
		},
		list: Array,
		default() {
			return [];
		}
	},
	methods: {
		toMore() {
			// this.BW.navTo({ type: this.pageType });
			this.BR.navTo('/lx-video', {
				hid: 2
			});
		},
		navTo(item) {
			this.$router.push({
				path: '/nDetail',
				query: {
					hid: 5,
					nid: item.id
				}
				// params: {hid: nid} -> 如何接收值
			});
			// window.open(rd.href, '_blank');
			//test
		},
		toDetails(item) {
			this.BR.navTo('/liveRoom', {
				matchId: item.matchId,
				activeName: 'lx',
				hid: 1
			});
		}
	}
};
</script>

<style lang="scss">
.list-one {
	flex: 1;
	overflow: hidden;
	text-align: left;
	.list-one-body {
		width: 100%;
		background: #fff;
		padding: 0.625rem;
		text-align: left;
		.list-one-item {
			display: flex;
			align-items: center;

			justify-content: space-between;

			font-size: 0.875rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			// height:1.625rem;
			line-height: 1.95rem;
			&::before {
				content: '·';
				display: inline-block;
				position: absolute;
				font-size: 1.875rem;
			}
			.item-left {
				flex: 1;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				span {
					font-size: 0.875rem;
					padding-right: 1.125rem;
					margin-left: 0.75rem;
					overflow: hidden;
					text-overflow: ellipsis;
					font-weight: 400;
					color: rgba(102, 102, 102, 1);
					// line-height:1.88rem;
				}
			}

			// div {
			// 	margin-left:0.75rem;
			// 	line-height: 2.125rem;
			// 	overflow: hidden;
			// 	text-overflow: ellipsis;
			// }
		}
	}
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
