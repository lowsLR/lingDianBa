<template>
	<div class="" v-if="total > pageSize">
		<el-pagination
			background
			layout="prev, pager, next"
			:total="total"
			:current-page="currentPage"
			:page-size="pageSize"
			@size-change="sizeChange"
			@current-change="currentChange"
			@prev-click="prevClick"
			@next-click="nextClick"
		>
		</el-pagination>
	</div>
</template>

<script>
	export default {
		name: 'list-three',
		props: {
			// 当前页码
			currentPage: {
				type: Number,
				default: 1
			},
			// 每页显示条数
			pageSize: {
				type: Number,
				default: 10
			},
			// 数据总条数
			total: {
				type: Number,
				default: 100
			},
		},
		data() {
			return {

			}
		},
		methods: {
			sizeChange(e) {
				// console.log("每页条数",e)
			},
			currentChange(e) {
				// console.log("当前页",e)
				this.$emit('changePage', e);
			},
			prevClick(e) {
				// console.log("上一页",e)
			},
			nextClick(e) {
				// console.log("下一页",e)
			},
		}

	}
</script>

<style lang="scss">

</style>
