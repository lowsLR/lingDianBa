<template>
	<div>
		<div class="list-atemp-head">
			<div class="list-atemp-tip"><span class="tip-text">{{ftitle}}</span> </div>
			<div><span class="list-more">更多 >></span></div>
		</div>
		<hr style="width: 100%height:0.125rem;background:rgba(27,27,48,1);" />
		<div class="main-list-div ">
			<div class="main-list-big bgw mb15">
				<div class="text-l live-title"><ul><li>
				12月27日 星期五
				</li></ul></div>
				<div v-for="(i,indexs) in 6" 
				:key="i"
				class="flex main-list-small"
				:class="[i == 1?'bg-dan':'']">
					<div class="small-left">
						<div>09:30</div>
						<div>篮球</div>
					</div>
					<div class="small-type">足协杯第3轮</div>
					<div class="small-content">
						<div class="flex-cc">
							<span>梅县铁汉生态</span>
							<span>VS</span>
							 <span>拜仁慕尼黑1860</span>
						</div>
					</div>
					<div class="small-right flex-cc">
						<div class="right-but" @click="topage">
								观看录像
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script >
	import {test1} from '../views/testdata.js';
	let that;
	export default {
		name: 'lx-list-detail',
		props: {
			ftitle:{
				type: String,
				default: 'NBA'
			},
		},
		data() {
			return {
				livelist:test1,
			}
		},
		
		created: function () {
		  that = this;
			console.log("获取vuex",that.$store.state)
			that.tabIndex = that.$store.state.routurl
			that.routerUrl = that.$route.path;
			// that.id = that.$route.params;
			// console.log(that.$route.path)
		 },
		methods: {
			topage(url,data){
				
			},
		}	
		
	}
</script>

<style lang="scss" scoped>
	ul, li{ list-style:disc inside !important;}
	.list-atemp-tip{
		.tip-text {
			font-size:1.375rem !important;
		}
	}
	.main-list-div{
		.main-list-big{
			.live-title{
				padding-left: 0.625rem;
				font-size:1rem;
				font-family:Microsoft YaHei;
				font-weight:400;
				color:rgba(255,83,55,1);
				line-height:1.75rem;
				background:rgba(255,83,55,0.13);
			}
			.main-list-small{
				height: 5.5rem;
				border-bottom: 0.0625rem dashed rgba(153,153,153,1);
				display: flex;
				justify-content: space-between;
				.small-left,.small-type{
					display: flex;
					justify-content: center;
					align-items: center;
					flex-direction: column;
					padding: 1.4375rem;
				}
				.small-content{
					display: flex;
					justify-content: center;
					align-items: center;
					flex-direction: column;
					padding: 1.4375rem;
					span{
						padding: 0 1.875rem;
					}
					img{
						width:2.1875rem;
						height:2.625rem;
						border-radius:50%;
					}
				}
				.small-right{
					width: 20rem;
					padding: 0 1.5rem;
					display: flex;
					justify-content: center;
					align-items: center;
					position: relative;
					.right-but{
						
						width:6.125rem;
						height:1.75rem;
						background:rgba(255,83,55,1);
						border-radius:0.875rem;
						
						font-size:1rem;
						font-family:Microsoft YaHei;
						font-weight:400;
						color:rgba(255,255,255,1);
						line-height:1.75rem;
					}
					.right-span{
						display: flex;
						// flex-wrap: wrap;
						flex-direction: column ;
						align-items: center;
						justify-content: flex-start;
						// padding-right: 24px;
						// position: absolute;
						// right: 0;
						span{
							// padding: 5px;
							font-size:1rem;
							font-family:Microsoft YaHei;
							font-weight:400;
							color:rgba(51,51,51,1);
							line-height:1.75rem;
						}
					}
				}
				
			}
		}
		
		
	}
	
	.bg-dan{
		background:rgba(255,83,55,0.06);
	}
</style>
