<template>
	<!-- 最近直播 -->
	<div class="live">
		<div class="liveTag">
			<div>最近直播</div>
			<span>更多 >></span>
		</div>
		<li class="liveItem" v-for="(item,index) in 6" :key="index" @click="navTo(index)">
			<span>NBA常规赛</span>
			<div class="matchInfo">
				<span>新韩银行大鸟女篮</span>
				<p>VS</p>
				<span>雷霆</span>
			</div>
			<span>01-18  09:00</span>
		</li>
	</div>
</template>

<script>
	let that;
	export default {
		name: 'unit-related-live',
		data() {
			return {
				activeName: '东部',
				tableData: [
					{rank: 1, name: '雄鹿'},
				]
			}
		},
		created: function () {
			that = this;
			that.tabIndex = that.$store.state.routurl
			that.routerUrl = that.$route.path;
		},
		methods: {
			navTo(vid){
				that.$router.push({
					path: '/lx-video',
					query: {
						hid: 2,
						tid: vid
					}
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.live {
		width: 19.875rem;
		height: auto;
			
		.liveTag {
			display: flex;
			justify-content: space-between;
			align-items: center;
			width: 100%;
			height: 2.25rem;
			box-sizing: border-box;
			border-bottom: 0.125rem solid #1B1B30;
			
			div {
				width: auto;
				height: 2.125rem;
				line-height: 2.125rem;
				font-size: 1rem;
				font-weight: bold;
				color: #1B1B30;
			}
			div:before{
				content: '';
				width: 0.375rem;
				height: 1.625rem;
				background: #1B1B30;
				display: inline-block;
				margin-right: 0.75rem;
				vertical-align: middle;
				margin-top: -0.25rem;
			}
			
			span {
				font-size: 0.75rem;
				color: #666666;
			}
		}
		
		.liveItem {
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			overflow: hidden;
			width: 100%;
			height: 5.5rem;
			padding: 0.5rem 0;
			border-bottom: 0.0625rem solid #EAEAEA;
			background-color: #FFFFFF;
			
			span {
				font-size: 0.75rem;
				color: #999999;
			}
		}
		
		.matchInfo {
			display: flex;
			align-items: center;
			
			p {
				font-size: 1rem;
				color: #666666;
				margin-top: 0.125rem;
			}
			
			span {
				flex: 1;
				font-size: 0.8125rem;
				/* font-size: 14
				
				; */
				color: #666666;
				margin: 0 0.6875rem;
				overflow: hidden;
				white-space: nowrap;
				text-overflow: ellipsis;
			}
		}
	}
</style>
