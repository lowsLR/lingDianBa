<template>
	<div>
		<div class="main-list-div ">
			<!-- <div class="main-list-big" @click="topage({matchId:8850})"> 测试</div> -->
			<div class="main-list-big bgw mb15" v-for="(item, index) in liveEventList" :key="index">
				<div class="text-l live-title">
					<ul>
						<li>{{ item.dateString }}</li>
					</ul>
				</div>
				<div v-for="(items, indexs) in item.sportMatchVOS" :key="items.eventName + index + indexs">
					<div class="flex main-list-small" :class="[items.isHot == 0 ? 'bg-dan' : '', indexs == item.sportMatchVOS.length - 1 ? 'bbottom' : '']">
						<div class="small-left">
							<div class="c-cs">{{ items.matchBeginTime | replaceTime }}</div>
							<div>{{ items.eventName }}</div>
						</div>
						<div class="small-content">
							<div class="matchTitle">
								<!-- {{items.eventTypeName+' - '+items.matchTitle}} -->
								{{
									items.eventTypeName == '' || items.eventTypeName == null
										? items.specialName + (items.matchTitle == '' || items.matchTitle == null ? '' : ' ') + items.matchTitle
										: items.eventTypeName == '其他'
										? items.eventName + (items.matchTitle == '' || items.matchTitle == null ? '' : ' ') + items.matchTitle
										: items.eventTypeName + items.matchTitle
								}}
							</div>

							<div class="flex-cc" v-if="null != items.guestTeamId && null != items.homeTeamId">
								<div>
									<span class="teamView">{{ items.homeTeamName }}</span>
									<img
										@error="errorImg($event, homeTeam)"
										class="LogoPath"
										:src="
											items.homeTeamLogoPath != null && items.homeTeamLogoPath != ''
												? 'https://images.weserv.nl/?url=' + items.homeTeamLogoPath
												: require('../static/image/nodata/homeTeam.png')
										"
									/>
									<span v-if="items.homeTeamScore != 0 && items.guestTeamName != 0">{{ items.homeTeamScore }}</span>
								</div>
								<div>VS</div>
								<div>
									<span v-if="items.homeTeamScore != 0 && items.guestTeamName != 0">{{ items.guestTeamSocre }}</span>
									<img
										@error="errorImg($event, guestTeam)"
										class="LogoPath"
										:src="
											items.guestTeamLogoPath != null && items.guestTeamLogoPath != ''
												? 'https://images.weserv.nl/?url=' + items.guestTeamLogoPath
												: require('../static/image/nodata/guestTeam.png')
										"
									/>
									<span class="teamView">{{ items.guestTeamName }}</span>
								</div>
							</div>
							<div class="matchIntroduction" v-if="items.matchIntroduction">提醒:{{ items.matchIntroduction }}</div>
						</div>
						<div class="small-right flex-cc">
							<div v-if="items.matchStartState == 2 && !items.isLive" class="right-but but-over poinbut">已结束</div>
							<div v-if="items.matchStartState == 2 && items.isLive" class="right-but but-lx poinbut" @click="topage(items)">观看录像</div>
							<div v-if="items.matchStartState == 0 && items.matchLiveSourceDOS.length" class="right-but but-class poinbut" @click="topage(items)">观看直播</div>
							<div v-if="items.matchStartState == 0 && items.matchLiveSourceDOS.length == 0 && items.isLive != '0'" class="right-but but-nodata poinbut">
								暂无信号
							</div>
							<div
								v-if="items.matchStartState == 0 && items.matchLiveSourceDOS.length == 0 && items.isLive == '0'"
								class="right-but but-nodata poinbut"
								@click="topage(items, 'lx')"
							>
								观看录像
							</div>
							<div v-if="items.matchStartState == 1" class="right-but but-nobegin poinbut" @click="topage(items)">即将开始</div>
							<div class="right-span">
								<span v-if="items.isLive == '0'" @click="topage(items, 'lx')" class="pointer">比赛录像</span>
								<span v-if="items.isLive != '0' && items.isHighlights == '0'" @click="topage(items, 'jj')" class="pointer">比赛集锦</span>
								<span v-if="items.matchProspect" @click="topage(items, 'second')" class="pointer">比赛前瞻</span>
								<span v-if="items.matchTextLivePath" @click="topage(items, 'third')" class="pointer">文字直播</span>
								<span v-if="items.eventScorePath" class="pointer" @click="justPage(items.eventScorePath)">比分直播</span>
								<span
									v-if="!((items.isLive == '0' || items.isHighlights == '0') && items.matchProspect && items.matchTextLivePath && items.eventScorePath)"
									class="pointer"
									@click="justPage(adData.advertisementLinkAddress)"
								>
									{{ adData.advertisementText }}
								</span>
							</div>
						</div>
					</div>

					<AdSlot
						:AdName="'SYLB-1'"
						locationPosition="1"
						locationType="1"
						:adWidth="66.2"
						:adHeight="5.625"
						adStr="sy"
						v-if="adFlag && indexs == advertisementSort && liveEventList[0].dateString.substring(0, 10) == items.matchBeginTime.substring(0, 10)"
						@advIndex="advIndex"
					></AdSlot>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import { test1 } from '../views/testdata.js';
let that;
export default {
	name: 'live-list',
	props: {
		liveEventList: Array,
		default: function() {
			return [];
		},
		nodataTitle: {
			type: String,
			default: '暂无数据'
		},
		adFlag: {
			type: Boolean,
			default: () => {
				return true;
			}
		},
		adSlotType: {
			type: String,
			default: 'sy'
		}
	},
	data() {
		return {
			livelist: test1,
			homeTeam: require('../static/image/nodata/homeTeam.png'),
			guestTeam: require('../static/image/nodata/guestTeam.png'),
			advertisementSort: '', //广告排序,
			adData: {}
		};
	},
	created: function() {
		that = this;
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
		this.$newsReq
			.queryAdvertisement({
				locationKey: 'sy'
			})
			.then(res => {
				let resdata = res.data.data;
				let index = resdata.findIndex(item => item.advertisementName == '首页列表文字广告');
				if (index > -1) {
					resdata[index].advertisementText = resdata[index].advertisementText.substring(0, 5);
					this.adData = resdata[index];
				}
			});
	},
	filters: {
		replaceTime(v) {
			return that.BW.splitTime(v);
		}
	},
	methods: {
		//链接外网跳转
		justPage(item) {
			window.open(item, '_blank');
		},
		advIndex(i) {
			this.advertisementSort = i;
		},
		topage(item, pathName, url, data) {
			this.BR.navTo('/liveRoom', {
				hid: 1,
				matchId: item.matchId,
				activeName: pathName || ''
			});
		}
	}
};
</script>

<style lang="scss" scoped>
ul,
li {
	list-style: disc inside !important;
}
.main-list-div {
	.main-list-big {
		.live-title {
			padding-left: 0.625rem;
			font-size: 1rem;
			font-weight: 400;
			line-height: 1.75rem;
			background: rgba(255, 83, 55, 0.13);
			color: rgba(255, 83, 55, 1);
			line-height: 2.5rem;

			height: 2.5rem;
		}
		& > .main-list-small:last-child {
			border-bottom: 0;
		}
		.bbottom {
			// background: red;
			border-bottom: 0 !important;
		}
		.main-list-small {
			height: 8rem;
			border-bottom: 0.0625rem dashed rgba(153, 153, 153, 1);
			display: flex;
			justify-content: space-between;

			.small-left {
				display: flex;
				justify-content: center;
				align-items: center;
				flex-direction: column;
				// padding: 1.4375rem;
				width: 5.25rem;
				div {
					white-space: nowrap;
					line-height: 2.275rem;

					font-size: 0.875rem;
					font-weight: 400;
				}
			}
			.small-content {
				display: flex;
				justify-content: center;
				align-items: center;
				flex-direction: column;
				padding: 1.4375rem 0;
				width: 35.75rem;
				.matchTitle {
					font-size: 1rem;
					font-weight: 400;
					color: rgba(0, 0, 0, 1);
					line-height: 1.75rem;
				}
				.matchIntroduction {
					font-size: 0.8125rem;
					font-weight: 400;
					color: rgba(102, 102, 102, 1);
					line-height: 1.75rem;
				}
				.flex-cc {
					width: 100%;
					display: flex;
					flex: 1;
					div {
						display: flex;
						justify-content: center;
						align-items: center;
						white-space: nowrap;
						span {
							font-size: 1rem;
							font-weight: 400;
							color: rgba(0, 0, 0, 1);
							line-height: 1.375rem;
						}
					}
					div:nth-child(1) {
						flex: 2;
						// background-color: red;
						justify-content: flex-end;
						span {
							padding-right: 1.25rem;
						}
					}
					div:nth-child(2) {
						flex: 1;
						// background-color: yellow;
						font-size: 1.25rem;
						font-weight: 400;
						color: rgba(153, 153, 153, 1);
						line-height: 1.375rem;
					}
					div:nth-child(3) {
						flex: 2;
						// background-color: blue;
						justify-content: flex-start;
						span {
							padding-left: 1.875rem;
						}
					}
				}
				// span{
				// 	padding: 0 1.875rem;
				// 	white-space: nowrap;
				// }
				img {
					width: 2.625rem;
					height: 2.625rem;
					border-radius: 50%;
				}
			}
			.small-right {
				// width: 20rem;
				width: 15.25rem;
				// padding: 0 1.5rem;
				display: flex;
				justify-content: space-between;
				align-items: center;
				position: relative;
				// border: 1px solid red;
				.right-but {
					width: 6.125rem;
					height: 1.75rem;
					border-radius: 0.875rem;
					font-size: 1rem;
					font-family: Microsoft YaHei;
					font-weight: 400;
					line-height: 1.75rem;
					// border: 1px solid red;
				}
				.but-class {
					background: rgba(255, 83, 55, 1);
					color: rgba(255, 255, 255, 1);
				}
				.but-lx {
					background: rgba(230, 230, 230, 1);
					color: rgba(51, 51, 51, 1);
				}
				.but-over {
					background: rgba(230, 230, 230, 1);
					color: rgba(153, 153, 153, 1);
				}
				.but-nobegin {
					background: rgba(255, 83, 55, 0.4);
					color: rgba(255, 255, 255, 1);
				}
				.but-nodata {
					background: #666666;
					color: rgba(255, 255, 255, 1);
				}
				.right-span {
					display: flex;
					// flex-wrap: wrap;
					flex-direction: column;
					align-items: center;
					justify-content: flex-start;
					// width: 6.5625rem;
					width: 7.5rem;
					// margin-left: 1.9375rem;
					// border: 1px solid red;
					span {
						// font-size: 1rem;
						font-size: 0.875rem;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: rgba(51, 51, 51, 1);
						line-height: 1.875rem;
						// border: 1px solid red;
					}
				}
			}
		}
	}
}

.bg-dan {
	background: rgba(255, 83, 55, 0.06);
}
</style>
