<template>
	<div>
		<div class="list-five">
			<div class="list-atemp-top">
				<div class="list-atemp-top-left">
					<span class="tip-text">{{ ftitle }}</span>
				</div>
				<div><!-- <span class="list-more">更多>></span> --></div>
			</div>
			<div class="list-five-body">
				<div v-for="(item, index) in fiveList" :key="index" class="list-five-item">
					<span @click="toDetails(item)" class="pointer" href="#" target="_blank">{{ item.matchTitle }}</span>
					<div class="right-span">
						<span v-if="isTime">
							<!-- {{item.matchBeginTimeStr | timeFilters}} -->
							{{ item.matchEndTime | timeFilters }}
						</span>
					</div>
				</div>
				<div v-if="!fiveList.length" class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'list-five',
	props: {
		// fiveList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		isTime: {
			type: Boolean,
			default: false
		},
		nodataTitle: {
			type: String,
			default: '暂无数据'
		},
		ftitle: {
			type: String,
			default: ''
		},
		fiveList: Array,
		default: function() {
			return [];
		}
	},
	created() {
		
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${M}-${D}`;
			}
		}
	},
	methods: {
		toDetails(item) {
			this.BR.navTo('/liveRoom', {
				matchId: item.matchId,
				activeName: 'lx',
				isLx: 'islx',
				hid: 1
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.tip-text {
	font-size: 1rem;
	font-weight: 400;
	color: rgba(255, 83, 55, 1);
}
.list-five {
	flex: 1;
	overflow: hidden;
	text-align: left;
	// background-color: black;
	.list-five-body {
		width: 100%;
		background-color: #fff;
		padding: 0.625rem;
		// padding: 0.6rem 1.125rem;

		list-style: none;
		counter-reset: count;
		display: flex;
		flex-direction: column;
		.list-five-item {
			display: flex;
			white-space: nowrap;
			align-items: center;
			justify-content: space-between;
			line-height: 1.5625rem;
			height: 2.1875rem;
			&::before {
				content: '·';
				display: inline-block;
				position: absolute;
				font-size: 1.875rem;
			}
			.right-span {
				font-size: 0.875rem;
				color: #959595;
			}

			span {
				margin-left: 1.3rem;
				overflow: hidden;
				text-overflow: ellipsis;
				font-size: 0.875rem;
				font-weight: 400;
				color: rgba(102, 102, 102, 1);
				line-height: 2.1rem;
			}
		}
	}
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
