<template>
	<!-- 公共广告位置 -->
	<div
		class="ad-container pointer"
		:style="{
			width: adWidth * adData.advertisementWeight + 'rem',
			height: adNewHeight * adData.advertisementHeight + 'rem',
			fontSize: fontSize * adData.advertisementHeight + 'rem'
		}"
		v-if="ad"
	>
		<img
			v-if="adData.advertisementShowType == '0'"
			:src="
				adData.advertisementPath && adData.advertisementPath != 1
					? adData.advertisementPath
					: 'https://goss2.cfp.cn/creative/vcg/nowarter800/new/VCG211167562512.jpg?x-oss-process=image/format,webp'
			"
			style="width: 100%;height: 100%;display: block;"
			@click="adRouter(adData)"
		/>
		<div v-if="adData.advertisementShowType == '1'" class="advertisementText" @click="adRouter(adData)">{{ adData.advertisementText }}</div>
		<div v-if="adData.advertisementShowType == '2'" v-html="adData.advertisementCode" @click="adRouter(adData)"></div>
		<div class="close" @click="closeAd">
			<span>X</span>
			<span>关闭广告</span>
		</div>
	</div>
</template>

<script>
export default {
	name: 'ad-slot',
	props: {
		width: {
			// 宽度
			type: String,
			default: '100%'
		},
		height: {
			// 高度
			type: String,
			default: '5.625rem' // 90px
		},
		AdName: {
			// 广告名称
			type: String,
			default: '广告位'
		},
		fontSize: {
			type: Number,
			default: 4.25 //72px
		},
		//位置名称
		locationPosition: {
			type: String,
			default: '1'
		},
		//广告位置类型 0正常1列表；
		locationType: {
			type: String,
			default: '0'
		},
		adWidth: {
			type: Number,
			default: 87.5
		},
		adHeight: {
			type: Number,
			default: 3.75
		},
		advertisement: {
			type: Array,
			default: () => {
				return [];
			}
		},
		adStr: {
			type: String,
			default: 'sy'
		}
	},
	data() {
		return {
			test: 'test',
			ad: true,
			adData: {
				advertisementWeight: 1,
				advertisementHeight: 1,
				advertisementShowType: 0,
				advertisementText: '',
				advertisementLinkAddress: '',
				advertisementPath: 'https://goss2.cfp.cn/creative/vcg/nowarter800/new/VCG211167562512.jpg?x-oss-process=image/format,webp'
			},
			// adData: null
			adNewHeight: 3.75
		};
	},
	created() {
		// this.$nextTick(() => {
		// 	this.getQueryAdvertisement(this.adStr);
		// });
		// console.log(this.adData,"==>广告初始")
	},
	mounted() {
		this.getQueryAdvertisement(this.adStr);
	},
	methods: {
		// 广告接口
		getQueryAdvertisement(adStr) {
			this.$newsReq
				.queryAdvertisement({
					locationKey: adStr
				})
				.then(res => {
					let resdata = res.data.data;
					// console.log(resdata, '广告');
					let index = resdata.findIndex(item => item.locationType == this.locationType && item.locationPosition == this.locationPosition);
					// console.log(index, 'index???');
					if (index == -1) {
						this.ad = false;
					} else {
						this.adData = resdata[index];
						// this.adData.advertisementWeight = resdata[index].advertisementWeight > 2 ? 2 : resdata[index].advertisementWeight;
						// this.adData.advertisementHeight = resdata[index].advertisementHeight > 5 ? 5 : resdata[index].advertisementHeight;
						this.adData.advertisementHeight = resdata[index].advertisementHeight.toFixed(3);
						this.$emit('advIndex', this.adData.advertisementSort);
					}
				});
		},
		navTo() {
			this.$router.push({
				path: this.pageRouter
			});
		},
		closeAd() {
			this.ad = false;
		},
		adRouter(adData) {
			window.open(adData.advertisementLinkAddress, '_blank');
			// console.log("广告",adData.advertisementLinkAddress);
		}
	}
};
</script>

<style lang="scss" scoped>
.ad-container {
	display: flex;
	align-items: center;
	justify-content: center;
	flex-direction: column;
	// background-color: #1a1a1a;
	background-color: transparent;
	// font-size: 4.25rem;
	// font-weight: bold;
	// color: #ffffff;
	position: relative;
	padding: 0;
	overflow: hidden;
	border: 0;
}
.close {
	display: flex;
	align-items: center;
	justify-content: flex-end;
	// background: #000000;
	position: absolute;
	top: -0.125rem;
	right: -0.625rem;
	// right: 0;
	// border: 1px solid red;
	// width: 5.625rem;
	padding: 0 0.125rem;
	height: 1.5rem;
	font-weight: 400;
	font-family: Microsoft YaHei;
	cursor: pointer;
	font-size: 0.875rem !important;
	-webkit-transform: scale(0.8);
	color: #ffffff;
	background-color: #999999;
	opacity: 0.6;
	padding: 0 0.625rem;
	span:first-child {
		margin-right: 0.3rem;
		font-size: 0.75rem;
		-webkit-transform: scale(0.8);
	}
	// span{
	// 	-webkit-transform:scale(0.8);
	// }
}
.advertisementText {
	font-size: 0.875rem !important;
	color: #666666 !important;
}
.test {
	// 1064px==>66.5  90px==>5.625 200px==>12.5 318px==>19.875 1400px==>87.5
	// 60px==>3.75 944px==> 59 432px==>27 1022px==>63.875  360px==>22.5
	width: 22.5rem;
}
</style>
