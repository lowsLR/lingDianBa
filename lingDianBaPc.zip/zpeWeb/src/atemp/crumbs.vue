<template>
	<div class="breadcumb">
		<div class="breadcumb-list">
			<div class="breadcumb-link">您的位置：</div>
			<div class="breadcumb-link">
				<router-link class="pointer" :to="{ path: 'main', query: { hid: '1' }}">{{uname}}</router-link>
				<span class="right-label"> > </span>
			</div>
			<div v-for="(item, i) in breadcumb.list" :key="i" class="breadcumb-link" :class="{last: i == breadcumb.list.length -1}">
				<router-link class="pointer" v-if="item.path" :to="{path: item.path}">{{item.name||''}}</router-link>
				<span v-else>{{item.name||''}}</span>
				<span class="right-label" v-if="i < breadcumb.list.length - 1"> > </span>
			</div>
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				uname: this.$store.state.saveState.uname,
			}
		},
		props: {
			breadcumb: {
				type: Object
			}
		},
		methods: {
		},
	}
</script>
<style lang="scss" scoped>
	.breadcumb {
		height: 1.5rem;
		line-height: 1.5rem;
		padding: 0 0.5rem;
		margin: 0.625rem 0;
		display: flex;
		align-items: center;
		
		.breadcumb-list, .breadcumb-link {
			display: flex;
			align-items: center;
		}
		
		.right-label {
			padding: 0 0.375rem;
		}
		
		.breadcumb-link, a, span {
			font-size: 0.75rem; // 12px
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
		}
	}
</style>
