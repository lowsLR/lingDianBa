<template>
	<div>
		<VueAliplayer 
		:source="source" 
		:vid="vid" 
		:playauth="playauth" 
		ref="aliplayer"
		></VueAliplayer>
	</div>
</template>

<script>
	import VueAliplayer from "vue-aliplayer"
	export default {
		name: 'vue-aliplayer',
		components:{
			VueAliplayer
		},
		props: {
		  playStyle: {
		    type: String,
		    default: ""
		  },
		  aliplayerSdkPath: {
		    // Aliplayer 代码的路径
		    type: String,
		    default: "https://g.alicdn.com/de/prismplayer/2.8.1/aliplayer-min.js"
		  },
		  autoplay: {
		    type: Boolean,
		    default: false
		  },
		  isLive: {
		    type: Boolean,
		    default: false
		  },
		  playsinline: {
		    type: Boolean,
		    default: false
		  },
		  width: {
		    type: String,
		    default: "100%"
		  },
		  height: {
		    type: String,
		    default: "320px"
		  },
		  controlBarVisibility: {
		    type: String,
		    default: "always"
		  },
		  useH5Prism: {
		    type: Boolean,
		    default: false
		  },
		  useFlashPrism: {
		    type: Boolean,
		    default: true
		  },
		  vid: {
		    type: String,
		    default: ""
		  },
		  playauth: {
		    type: String,
		    default: ""
		  },
		  source: {
		    type: String,
		    default: ""
		  },
		  cover: {
		    type: String,
		    default: ""
		  },
		  format: {
		    type: String,
		    default: "m3u8"
		  },
		  skinLayout: {
		    type: Array,
		    default: function() {
		      return [];
		    }
		  },
		  x5_video_position: {
		    type: String,
		    default: "top"
		  },
		  x5_type: {
		    type: String,
		    default: "h5"
		  },
		  x5_fullscreen: {
		    type: Boolean,
		    default: false
		  },
		  x5_orientation: {
		    type: Number,
		    default: 2
		  },
		  autoPlayDelay: {
		    type: Number,
		    default: 0
		  },
		  autoPlayDelayDisplayText: {
		    type: String
		  }
		},
		data() {
			return {
				
			}
		}
	}
	
</script>

<style>
</style>
