<template>
	<div class="" style="height:'100%'">
		<div class="list-highlig">
			<template v-if="highligList.length">
				<div v-if="highligList[0].matchLiveSourceDOS.length == 1">
					<div class="eventView">
						<ckplayer
							v-if="videoPlayerType == 1"
							width="100%"
							height="40rem"
							:sourceUrl="iframeSrc"
							:videoMsg="videoMsg"
							:isPlaySource="isPlaySource"
							:isAutoplay="false"
							:isLive="false"
							ref="player"
						></ckplayer>
						<iframe v-if="videoPlayerType == 2" class="iframeClass" :src="iframeSrc" allowfullscreen="true"></iframe>

						<div v-if="videoPlayerType == 3" class="flex-cc w100 h100 bgc-black navBlankView">
							点击跳转：
							<a :href="ahref" target="_blank">{{ matchLiveSourceDOS[sourceIndex].liveSourceName }}</a>
						</div>

						<div class="flex-cc w100 h100 bgc-black guoduDiv" v-if="videoPlayerType == 10"><img src="../static/main/lod.gif" /></div>
					</div>
					<div class="sourceTitle">{{ highligList[0].matchLiveSourceDOS[0].liveSourceName }}</div>
				</div>

				<ul v-else class="list-highlig-body">
					<li class="li-mian pointer" v-for="(item, index) in highligList[0].matchLiveSourceDOS" :key="index" @click="navToSpPlayback(item)">
						<div class="li-mian-div">
							<div class="li-main-img"><img src="../static/image/default_img.png" /></div>
							<div class="li-main-text">
								<div class="" v-if="highligList[0].homeTeamName || highligList[0].guestTeamName">
									{{ highligList[0].homeTeamName }} {{ highligList[0].homeTeamName && highligList[0].guestTeamName ? ' - ' : '' }}
									{{ highligList[0].guestTeamName }}
								</div>
								<div class="" v-else>{{ highligList[0].matchTitle }}</div>
								<div class="">
									<span style="color: red;" v-if="item.matchSourcePathShortName">[{{ item.matchSourcePathShortName }}]</span>
									{{ item.liveSourceName }}
								</div>
							</div>
						</div>
					</li>
				</ul>
			</template>
			<div style="height: 100%;" v-else><nodata height="100%" :title="nodataTitle"></nodata></div>
		</div>
	</div>
</template>

<script>
import ckplayer from '../components/ckplayer.vue';
export default {
	name: 'list-highlig',
	components: {
		ckplayer
	},
	props: {
		// highligList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		nodataTitle: {
			type: String,
			default: '暂无数据'
		},
		highligList: Array,
		default: function() {
			return {
				list: []
			};
		}
	},
	data() {
		return {
			videoPlayerType: 10,
			source: '',
			autoplay: false, //是否自动播放
			videoMsg: '',
			resultMsg: '',
			analysisSourceNumber: 0, //解析次数
			timeOutAnalys: null, //延迟解析对象
			iframeSrc: '',
			ahref: '',
			isPlaySource: true,
			navItem:{
				id:'',
				type:5,
				name:'全部'
			}
		};
	},
	computed: {
		matchLiveSourceDOS: function() {
			if (this.highligList.length == 1) {
				return this.highligList[0].matchLiveSourceDOS;
			}
			return [];
		}
	},
	watch: {
		'matchLiveSourceDOS.length': function(newVal, oldVal) {
			if (newVal != 1) {
				return;
			}
			console.log('长度为1');
			let that = this,
				item = that.highligList[0].matchLiveSourceDOS[0];
			that.analysisSourceNumber = 0;
			let datas = {
				sourcePathId: item.sourceId
			};
			reqAnalysisMatchLiveSource(item, datas);
			function reqAnalysisMatchLiveSource(item, datas) {
				that.analysisSourceNumber++;
				that.$req
					.analysisMatchLiveSource(datas)
					.then(res => {
						// console.log('解析直播信息', res);
						if (res.data.resultCode == 1 && res.status == 200) {
							// 覆盖原数据，解析状态值'valid'为 → 0:已解析
							item = res.data.data;
							that.setSrc(item);
							if (that.iframeSrc == '' || that.iframeSrc == null) {
								that.videoPlayerType = 1;
								that.shibai();
								return;
							}
						} else if (res.data.resultCode != 1 && res.status == 200) {
							if (res.data.resultCode == -199) {
								if (that.analysisSourceNumber < 10) {
									// console.log('重新解析');
									that.timeOutAnalys = setTimeout(() => {
										reqAnalysisMatchLiveSource(item, datas);
									}, 1000);
								} else {
									that.shibai();
								}
							} else {
								that.shibai(res);
							}
						}
					})
					.catch(err => {
						uni.hideLoading();
						uni.showToast({
							icon: 'none',
							title: '请稍后再试'
						});
					});
			}
		}
	},
	methods: {
		shibai(res) {
			this.videoPlayerType = 1;
			this.isPlaySource = false;
			this.videoMsg = res.data.resultMsg || '暂未获取信号,请选择其他播放源观看';
			this.resultMsg = res.data.resultMsg || '暂未获取信号,请选择其他播放源观看';
		},
		/*初始化播放器*/
		beginVideo(res) {
			this.isPlaySource = true;
			this.$nextTick(() => {
				this.$refs.player.initVideo(res);
			});
		},
		setSrc(item) {
			let that = this;
			switch (item.isAnalysis) {
				case '0':
					that.videoPlayerType = 1;
					that.iframeSrc = item.analysisPlayPathPc;
					that.beginVideo(item);
					break;
				case '1':
					that.videoPlayerType = 2;
					that.iframeSrc = item.notAnalysisPlayPath;
					break;
				case '2':
					that.videoPlayerType = 1;
					that.iframeSrc = item.analysisPlayPathPc;
					that.beginVideo(item);
					break;
				case '3':
					that.videoPlayerType = 2;
					that.iframeSrc = item.notAnalysisPlayPath;
					break;
				default:
					break;
			}
		},
		/*跳转录像详情*/
		navToSpPlayback(item) {
			console.log(item, '==>跳转/lx-VideoPlayback');
			const { href } = this.$router.resolve({
				name: `lx-VideoPlayback`,
				query: {
					hid: 2,
					sourceId: item.sourceId,
					matchId: item.matchId,
					sid: 3,
					sourceType:2,
					data: JSON.stringify(this.navItem)
				}
			});
			window.open(href, '_blank');
		}
	}
};
</script>

<style lang="scss">
.sourceTitle {
	width: 100%;
	height: 5rem;
	font-size: 1.25rem;
	font-weight: 400;
	color: rgba(51, 51, 51, 1);
	line-height: 1.75rem;
	display: flex;
	justify-content: center;
	align-items: center;
}
.eventView {
	width: 100%;
	background-color: black;
	// height: 100%;
	height: 40rem;
}
.iframeClass {
	width: 100%;
	height: 40rem;
	scrolling: no;
}
.guoduDiv {
	img {
		height: 10rem;
		width: 10rem;
	}
}
.navBlankView {
	font-size: 1.8rem;
	color: #ffffff;
	a {
		font-size: 1.8rem;
		font-weight: 600;
		color: $bg-chengse;
		text-decoration: underline;
	}
}
.list-highlig {
	flex: 1;
	overflow: hidden;
	text-align: left;
	height: 100%;
}

.list-highlig-tip {
	display: inline-block;
	width: 9.375rem;
	height: 2.1875rem;
	color: $bg-main;
}

.tip-text {
	font-size: 1rem;
	font-family: Microsoft YaHei;
	font-weight: 600;
	color: $bg-main;
	display: flex;
	padding-left: 0.3125rem;
}

.list-more {
	font-size: 0.75rem;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: rgba(102, 102, 102, 1);
}

.li-mian {
	box-sizing: border-box;
	border-bottom: 0.0625rem solid rgba(225, 225, 225, 1);
}
.li-mian-div {
	width: 100%;
	height: 9.375rem;
	display: flex;
	justify-content: flex-start;
	align-items: center;
	padding: 1.4375rem 1.6875rem;
}
.li-main-img {
	width: 9.75rem;
	height: 100%;
	img {
		width: 100%;
		height: 100%;
	}
}
.li-main-text {
	padding-left: 1.6875rem;
	font-size: 1rem;
	font-weight: 400;
	color: rgba(51, 51, 51, 1);
	line-height: 1.75rem;
}
// .li-mian:last-child{
// 	border: none;
// }
.list-highlig .list-highlig-head {
	height: 2.1875rem;
	line-height: 2.1875rem;
	font-size: 1.125rem;
	font-weight: 600;
	display: flex;
	justify-content: space-between;
}

.list-highlig .list-highlig-body {
	background: #fff;
	// padding: 0.3125rem;
}

.list-highlig .list-highlig-body li {
	// height: 4rem;
	// line-height: 4rem;
	display: block;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.list-highlig ul {
	width: 100%;
}
</style>
