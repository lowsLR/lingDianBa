<template>
	<div>
		<div class="tem-div">
			<div class="flex flex-jc-sb flex-ai-c title-header">
				<div class="s-header">
					热门
					<span style="color:#FF5337;">频道</span>
				</div>
				<div class="more-div pointer" @click="toMore" v-if="isShow">更多 >></div>
			</div>
			<div class="flex-worp " v-if="clist.length">
				<div @click="navToTvDetails(item.id)" class="pointer channel-item more-hidden1" v-for="(item, index) in clist" :key="index">{{ item.tvName }}</div>
			</div>
			<div class="flex-worp" v-else><nodata height="12.5rem" title="暂无数据" fontSize="1rem" color="#666666"></nodata></div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'channel',
	props: {
		pageType: {
			//头部页面id
			type: Number | String,
			default: 1
		},
		isNoNavto: {
			type: Boolean,
			default: false
		},
		isShow: {
			type: Boolean,
			default: true
		}
	},
	data() {
		return {
			// sindex:0,
			clist: []
		};
	},
	created() {
		this.getTV();
	},
	methods: {
		toMore() {
			this.BR.navTo('/tv', {
				hid: 4
			});
		},
		toTv() {},

		navToTvDetails(id) {
			this.BR.navTo('/tvDetails', {
				hid: 4,
				tid: id,
				sid: 3
			});
		},

		getTV() {
			// 查询电视台信息
			let datas = {
				id: '',
				livePlatform: this.livePlatform,
				type: 1 //查询电视类型 1热门电视台 2电视台类型 3根据地区查询电视台
			};
			this.$newsReq.queryTvInfo(datas).then(res => {
				if (res.data.resultCode == 1) {
					this.clist = res.data.data;
				} else {
				}
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.channel-div {
	width: 19.875rem;
	background: rgba(255, 255, 255, 1);
}
.title-header {
	// border: 1px solid red;
}
.s-header {
	font-size: 1rem;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: rgba(27, 27, 48, 1);
	display: flex;
	align-items: center;
	// line-height: 1.75rem;
	// border: 1px solid red;
}
.more-div {
	font-size: 0.75rem;
	font-weight: 400;
	color: rgba(101, 101, 101, 1);
}
.flex-worp {
	display: flex;
	justify-content: space-between;
	align-items: flex-start;
	flex-wrap: wrap;
	// padding-bottom: 0.3125rem;
	// padding-top: .5625rem;
	// padding-left: 0.3125rem;
	padding: 0.625rem;
	padding-top: 0;
	// border: 1px solid red;
	div {
		// width: 30%;
		width: 5.625rem;
		// overflow: hidden;
		// border: 1px solid red;
		// display: flex;
		// justify-content: center;
		// align-items: center;
		text-align: left;

		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		padding: 0 0.375rem;
	}
}
.channel-item {
	font-size: 0.875rem;
	font-weight: 400;
	color: rgba(102, 102, 102, 1);
	line-height: 2.45rem;
}
</style>
