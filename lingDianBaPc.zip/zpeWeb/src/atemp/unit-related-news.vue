<template>
	<!-- 相关新闻 -->
	<div class="types">
		<div class="headTag">
			<div>{{ eventTypeName }}新闻</div>
			<span class="more" @click="navToNews">更多 >></span>
		</div>
		<div class="newsItem" v-if="newsList.length > 0">
			<div class="frontNews" v-for="(item, index) in newsList" v-if="index == 0" :key="item.id" @click="navTo(item)">
				<img :src="item.imgUrl ? 'https://images.weserv.nl/?url=' + item.imgUrl : require('../static/image/default_img.png')" alt="" />
				<div class="info">
					<p>{{ item.newsTitle }}</p>
					<span>{{ item.eventName }}</span>
					<span>{{ item.eventTypeName }}</span>
				</div>
			</div>
			<div class="frontNews" v-for="(item, index) in newsList" v-if="index == 1" :key="item.id" @click="navTo(item)">
				<img :src="item.imgUrl ? 'https://images.weserv.nl/?url=' + item.imgUrl : require('../static/image/default_img.png')" alt="" />
				<div class="info">
					<p>{{ item.newsTitle }}</p>
					<span>{{ item.eventName }}</span>
					<span>{{ item.eventTypeName }}</span>
				</div>
			</div>
			<li v-for="(item, index) in newsList" v-if="index >= 2" :key="item.id" @click="navTo(item)">{{ item.newsTitle }}</li>
		</div>
		<!-- 无数据 -->
		<!-- <div class="noMore" v-else>暂无相关新闻</div> -->
		<nodata v-else height="16.875rem" fontSize="1rem"></nodata>
	</div>
</template>

<script>
let that;
export default {
	name: 'unit-related-news',
	props: {
		// 数据列表
		newsList: {
			type: Array,
			// type: Object,
			default: function() {
				return [];
				/* return {
						list: [
							{num: 1, title: '热门视频'},
						],
					} */
			}
		},
		// 列数
		newsNum: {
			type: Number,
			default: 12
		},
		// 赛事类型名称
		eventTypeName: {
			type: String,
			default: '相关'
		}
	},
	data() {
		return {};
	},
	created: function() {
		that = this;
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
	},
	methods: {
		navTo(item) {
			this.BR.navTo('/nDetail', {
				hid: 5,
				tid: 1,
				nid: item.id
			});
		},
		navToNews() {
			this.BR.navTo('/news', {
				hid: 5
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.types {
	width: 19.875rem;
	height: auto;
	overflow: hidden;
	margin-bottom: 1.5rem;
	color: #666666;
	cursor: default;

	li,
	p,
	span.more {
		&:hover {
			color: #ff5337 !important;
		}
	}

	.headTag {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 2.25rem;
		box-sizing: border-box;
		border-bottom: 0.125rem solid #1b1b30;

		div {
			width: auto;
			height: 34px;
			line-height: 34px;
			font-size: 16px;
			font-weight: bold;
			color: #1b1b30;
		}
		div:before {
			content: '';
			background: #f5f5f5 url(../static/main/news.png) no-repeat;
			background-size: cover;
			/* 22px * 22px */
			width: 1.375rem;
			height: 1.375rem;
			display: inline-block;
			margin-right: 12px;
			vertical-align: middle;
			margin-top: -4px;
		}

		span {
			font-size: 12px;
			color: #666666;
			cursor: pointer;

			/* &::after {
					content: '';
					background-image: url(../static/main/more.png);
					background-size: cover;
					background-repeat: no-repeat;
					width: 12px;
					height: 12px;
					display: inline-block;
					vertical-align: middle;
					margin: -4px 6px 0 4px;
				} */
		}
	}

	.newsItem {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 0.75rem 0.625rem;
		background-color: #ffffff;
		font-size: 0.875rem;
		text-align: left;
		li,
		p,
		span {
			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space: nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
		}

		.frontNews {
			height: 4.875rem;
			margin-bottom: 0.75rem;
			border-radius: 0.5rem;
			box-shadow: 0 0 0.625rem rgba(0, 0, 0, 0.1);
			overflow: hidden;
			display: flex;

			img {
				min-width: 6.125rem;
				max-width: 6.125rem;
				height: 4.875rem;
				display: block;
			}

			.info {
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				overflow: hidden;
				width: 100%;
				margin: 0.625rem 0 0.625rem 0.625rem;
				text-align: left;
				cursor: pointer;
			}

			p {
				color: #343434;
			}
		}

		li {
			line-height: 1.75rem;
			cursor: pointer;
		}

		li:before {
			content: '';
			width: 0.25rem;
			height: 0.25rem;
			border-radius: 50%;
			background: #666666;
			display: inline-block;
			margin-right: 0.625rem;
			vertical-align: middle;
			margin-top: -0.1875rem;
		}
	}

	/* 无数据 */
	/* .noMore {
			width: 100%;
			height: 12.5rem;
			line-height: 12.5rem;
			background-color: #FFFFFF;
		} */
}
</style>
