<template>
	<div  class="search-main" >
			<div class="search-div">
				<!-- <el-dropdown trigger="click">
				  <span class="el-dropdown-link">
				    首页<i class="el-icon-arrow-down el-icon--right"></i>
				  </span>
				  <el-dropdown-menu slot="dropdown">
				    <el-dropdown-item v-for="item in selectList">{{item.title}}</el-dropdown-item>
				  </el-dropdown-menu>
				</el-dropdown> -->
				<el-select v-model="value" placeholder="请选择">
				    <el-option
				      v-for="item in selectList"
				      :key="item.title"
				      :label="item.title"
				      :value="item.title">
				    </el-option>
				  </el-select>
				
				<div class="search-input">
				<el-input
				  placeholder="请输入内容"
				  v-model="inputVal"
					@keyup.enter.native="toSearchDetail"
				  clearable>
				</el-input></div>
				<div class="search-but poinbut" @click="toSearchDetail">零点搜索</div>
			</div>
	</div>
</template>

<script>
	export default {
		name: 'list-three',
		props: {
			selectList:{
				type : Array,
				default () {
					return [
						{id:1,title:'直播'},
						{id:2,title:'录像'},
						{id:3,title:'新闻'},
						{id:4,title:'电视'},
						{id:5,title:'视频'},
					]
						
				}
			},
			listStyle: { //样式
				type: String,
				default: ''
			},
			threeList: Object,
			default: function() {
				return {
					num: 5,
					title: '热门视频',
					list: [],
				}
			}
		},
		created() {
			switch(this.selectList[0].title){
				case '直播':
				this.value = '直播';
				break;
				case '录像':
				this.value = '录像';
				break;
				case '新闻':
				this.value = '新闻';
				break;
				case '电视':
				this.value = '电视';
				break;
				case '视频':
				this.value = '视频';
				break;
			}
				// console.log(this.value,"===???")
		},
		 data() {
		      return {
		        value: '直播',
				inputVal:''
		      }
		    },
			methods:{
				toSearchDetail(){
					if(this.inputVal == ''){
						this.$notify({
							title: '警告',
							message: '搜索内容不能为空！',
							type: 'warning'
						});
						return;
					}
					this.$router.push({
						path:'/searchDetails',
						params:{val:this.value,inputVal:this.inputVal},
						query:{val:this.value,inputVal:this.inputVal},
					})
					
				}
			}	
		
	}
</script>

<style lang="scss">
	.search-main{
		flex: 1;
		.search-div{
			flex: 1;
			height: 2.125rem;
			display: flex;
			border:0.0625rem solid rgba(255,83,55,1);
			border-radius:1.0625rem;
			align-items: center;
			position: relative;
			.el-dropdown,{
				flex: 1;
			}
			.el-select{
				flex: 1;
				.el-input__icon{
					line-height: 1.3;
				}
				.el-input--suffix .el-input__inner {
					border: 0;
					background: transparent;
				}
			}
			
			
			.search-but{
				flex: 1;
				height: 2.125rem;
				background:rgba(255,83,55,1);;
				font-size:0.75rem;
				font-family:Microsoft YaHei;
				font-weight:400;
				color:rgba(255,255,255,1);
				line-height:1.75rem;
				display: flex;
				justify-content: center;
				align-items: center;
				border-top-right-radius: 1.0625rem;
				border-bottom-right-radius: 1.0625rem;
				white-space: nowrap;
			}
			.search-input{
				flex: 2 ;
				display: flex;
				align-items: center;
				input{
					height: 2.125rem !important;
					border:0 !important;
					background-color:transparent;
					width: 100%;
					padding: 0;
				}
			}
		}
		
		
		
		
	
	}
	
</style>
