<template>
	<div class="list-lx">
		<div class="list-lx-head list-atemp-head">
			<div class="list-atemp-tip">
				<span class="tip-text">{{ teamName }}-录像推荐</span>
			</div>
			<div><span class="list-more pointer" @click="toMore">更多 >></span></div>
		</div>
		<ul class="list-lx-body" v-if="lxList.length">
			<li class="li-mian poinbut" v-for="(item, index) in lxList" :key="index" @click="toDetails(item)">
				<span>[{{ item.matchBeginTime | filtTtme }}] -</span>
				<span>{{ item.eventTypeName ? (item.eventTypeName == '其他' ? item.eventName : item.eventTypeName) : item.eventName }}</span>
				<span v-if="item.homeTeamName && item.guestTeamName">{{ item.homeTeamName }}VS{{ item.guestTeamName }}</span>
			</li>
		</ul>
		<nodata fontSize="1rem" color="#666666" v-else></nodata>
	</div>
</template>

<script>
export default {
	name: 'list-lx',
	props: {
		// lxList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		pageType: {
			//头部页面id
			type: Number | String,
			default: 2
		},
		teamName: {
			type: String,
			default: ''
		},
		lineHeight: {
			type: Number,
			default: 60
		},
		nodataTitle: {
			type: String,
			default: '暂无数据'
		},
		lxList: Object | Array,
		default: function() {
			return {
				list: []
			};
		}
	},
	filters: {
		filtTtme: function(val) {
			let timearr = val
				.replace(' ', ':')
				.replace(/\:/g, '-')
				.split('-');
			return timearr[0] + '-' + timearr[1] + '-' + timearr[2];
		}
	},
	methods: {
		toMore() {
			this.BR.navTo('/lx-video', {
				hid: 2
			});
		},
		toDetails(item) {
			let str = `${item.guestTeamName} vs ${item.homeTeamName}`;
			let current = this.$store.state.currentRoute;
			this.BR.navTo('/liveRoom', {
				hid: 1,
				...current,
				lxid: 1,
				matchId: item.matchId,
				str: str
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.list-lx {
	flex: 1;
	overflow: hidden;
	text-align: left;
	.list-lx-body {
		background: #fff;
		width: 100%;
		.li-mian {
			padding: 0.3125rem;
			box-sizing: border-box;
			border-bottom: 0.0625rem solid rgba(225, 225, 225, 1);
			display: flex;
			justify-content: flex-start;
			align-items: center;
			flex: 1;
			font-size: 0.875rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			line-height: 1.75rem;

			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
			&:last-child {
				border: none;
			}
			span:nth-child(2) {
				margin-right: 0.625rem;
			}
		}
	}
}
</style>
