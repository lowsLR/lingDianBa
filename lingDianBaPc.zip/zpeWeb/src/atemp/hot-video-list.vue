<template>
	<!-- 热门视频 -->
	<div class="types">
		<div class="headTag">
			<div>{{ title }}</div>
			<span class="more" @click="moreNews" v-if="isMore">更多 >></span>
		</div>
		<div class="newsItem" v-if="hotVideos.length">
			<div class="frontNews" v-for="(item, index) in hotVideos" v-if="index == 0" :key="item.id" @click="navTo(item)">
				<img :src="item.imgHref ? item.imgHref : require('../static/image/default_img.png')" alt="" />
				<div class="msk">{{ item.label }}</div>
			</div>
			<div class="frontNews" v-for="(item, index) in hotVideos" v-if="index == 1" :key="item.id" @click="navTo(item)">
				<img :src="item.imgHref ? item.imgHref : require('../static/image/default_img.png')" alt="" />
				<div class="msk">{{ item.label }}</div>
			</div>
			<li v-for="(item, index) in hotVideos" v-if="index >= 2" :key="item.id" @click="navTo(item)">{{ item.liveTitle }}</li>
		</div>
		<div v-else class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
	</div>
</template>

<script>
let that;
export default {
	name: 'hot-video-list',
	props: {
		// 数据列表
		hotVideos: {
			type: Array,
			// type: Object,
			default: function() {
				return [];
			}
		},
		// 列数
		newsNum: {
			type: Number,
			default: 12
		},
		title: {
			type: String,
			default: '热门视频'
		},

		isnavto: {
			type: Boolean,
			default: true
		},
		isMore: {
			type: Boolean,
			default: true
		},
		tagObj: {
			type: Object,
			default: function() {
				return {
					id: '',
					type: 5,
					name: '相关'
				};
			}
		}
	},
	data() {
		return {};
	},
	created: function() {
		that = this;
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
	},
	methods: {
		navTo(item) {
			this.BR.navTo('/spDetail', {
				hid: 3,
				vid: item.id,
				tagObj: JSON.stringify(this.tagObj)
			});
		},
		moreNews() {
			this.BR.navTo('/sp-video', {
				hid: 3,
				tid: 1
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.types {
	width: 19.875rem;
	height: auto;
	overflow: hidden;
	margin-bottom: 1.5rem;
	color: #666666;
	cursor: default;

	li,
	p,
	span.more {
		&:hover {
			color: #ff5337 !important;
		}
	}

	.headTag {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 2.25rem;
		box-sizing: border-box;
		border-bottom: 0.125rem solid #1b1b30;

		div {
			width: auto;
			height: 2.125rem;
			line-height: 2.125rem;
			font-size: 1rem;
			font-weight: bold;
			color: #1b1b2f;
		}
		div:before {
			content: '';
			background: #f5f5f5 url(../static/main/sp.png) no-repeat;
			background-size: cover;
			// width: 22px;
			width: 1.625rem;
			height: 1.625rem;
			display: inline-block;
			margin-right: 0.75rem;
			vertical-align: middle;
			margin-top: -0.25rem;
		}

		span {
			font-size: 0.75rem;
			cursor: pointer;
		}
	}

	.newsItem {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 0.75rem 0.625rem;
		background-color: #ffffff;
		font-size: 0.875rem;

		li,
		p,
		span {
			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space: nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
		}

		.frontNews {
			width: 18.625rem;
			height: 11rem;
			margin-bottom: 0.75rem;
			border-radius: 0.5rem;
			// box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
			overflow: hidden;
			display: flex;
			flex-direction: column;
			// border: 1px solid red;
			position: relative;

			&::before {
				content: '';
				display: block;
				width: 18.625rem;
				height: 11rem;
				background: rgba(0, 0, 0, 1);
				// background: red;
				position: relative;
				z-index: 100;
				// border: 1px solid red;
				opacity: 0.3;
			}
			img {
				// min-width: 98px;
				// max-width: 98px;
				// width:18.625rem;
				// height:11rem;
				width: 100%;
				height: 100%;
				display: block;
				position: absolute;
				top: 0;
				left: 0;
				z-index: 1;
			}

			.msk {
				width: 18.625rem;
				height: 1.875rem;
				background: rgba(0, 0, 0, 1);
				box-shadow: 0px 0px 0.375rem 0rem rgba(0, 0, 0, 0.3);
				// opacity: 0.3;
				border-radius: 0.5rem;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: nowrap;
				z-index: 2;
				position: absolute;
				bottom: 0;
				color: #ffffff;
				padding: 0 0.625rem;
				line-height: 1.875rem;
			}

			.info {
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				overflow: hidden;
				width: 100%;
				margin: 0.625rem 0 0.625rem 0.625rem;
				text-align: left;
				cursor: pointer;
			}

			p {
				color: #343434;
			}
		}

		li {
			line-height: 1.75rem;
			cursor: pointer;
			// border: 1px solid red;
			text-align: left;
		}

		li:before {
			content: '';
			width: 0.25rem;
			height: 0.25rem;
			border-radius: 50%;
			background: #666666;
			display: inline-block;
			margin-right: 0.625rem;
			vertical-align: middle;
			margin-top: -0.1875rem;
		}
	}
}

.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
