<template>
	<!-- 最近直播 -->
	<div class="live">
		<div class="liveTag">
			<div>{{ title }}</div>
			<span class="pointer" v-if="isMore" @click="newNavTo">更多 >></span>
		</div>
		<ul v-for="(items, indexs) in hotMatchPlayer" :key="indexs">
			<!-- <li class="liveItem pointer" v-for="(item, index) in items.sportMatchVOS" :key="index" @click="navTo(item)" v-if="index < 3"> -->
			<li class="liveItem pointer" v-for="(item, index) in items.sportMatchVOS" :key="index" @click="navTo(item)">
				<template v-if="item.homeTeamName">
					<span>{{ item.matchTitle }}</span>
					<div class="matchInfo">
						<span class="pointer">{{ item.homeTeamName }}</span>
						<p class="pointer">VS</p>
						<span class="pointer">{{ item.guestTeamName }}</span>
					</div>
					<span>{{ item.matchEndTime | timeFilters }}</span>
				</template>
				<template v-else>
					<span class="eventTypeName pointer">{{ item.matchTitle }} {{ item.eventTypeName == '其他' ? '' : item.eventTypeName }}</span>
					<span>{{ item.matchEndTime | timeFilters }}</span>
				</template>
			</li>
		</ul>
		<div v-if="!hotMatchPlayer.length" class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
	</div>
</template>

<script>
let that;
export default {
	name: 'search-hot-match-player',
	props: {
		title: {
			type: String,
			default: '最近直播'
		},
		isMore: {
			type: Boolean,
			default: true
		},
		hotMatchPlayer: {
			type: Array,
			default: () => {
				return [];
			}
		}
	},
	data() {
		return {
			activeName: '东部',
			tableData: [{ rank: 1, name: '雄鹿' }]
		};
	},
	created: function() {
		that = this;
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${M}-${D} ${h}:${m}`;
			}
		}
	},
	methods: {
		navTo(vid, pathName) {
			this.BR.navTo('/liveRoom',{
				hid: 1,
				// tid: vid,
				matchId: vid.matchId,
				activeName: pathName || '',
				isLx: pathName ? 'islx' : ''
			})
		},
		newNavTo() {
			this.BR.navTo('/main',{
				hid: 1
			})
		}
	}
};
</script>

<style lang="scss" scoped>
.live {
	width: 19.875rem;
	height: auto;

	.liveTag {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 2.25rem;
		box-sizing: border-box;
		border-bottom: 0.125rem solid #1b1b30;
		font-family: Microsoft YaHei;
		div {
			// width: auto;
			height: 2.125rem;
			line-height: 1.75rem;
			font-size: 1rem;
			font-weight: bold;
			color: #1b1b2f;
		}
		div:before {
			content: '';
			width: 0.375rem;
			height: 1.625rem;
			background: #1b1b2f;
			display: inline-block;
			margin-right: 0.625rem;
			vertical-align: middle;
			margin-top: -0.25rem;
		}

		span {
			font-size: 0.75rem;
			color: #666666;
		}
	}
	ul {
		// border: 1px solid red;
		// width:;
	}
	.liveItem {
		display: flex;
		flex-direction: column;
		// justify-content: space-between;
		justify-content: center;
		overflow: hidden;
		width: 100%;
		height: 5.5rem;
		padding: 0.5rem 0;
		border-bottom: 0.0625rem solid #eaeaea;
		background-color: #ffffff;
		span {
			font-size: 0.75rem;
			color: #999999;
		}

		.eventTypeName {
			color: #656565;
			// border: 1px solid red;
			overflow: hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
			margin-bottom: 0.625rem;
			padding: 0 0.625rem;
		}
	}

	.matchInfo {
		display: flex;
		align-items: center;
		// border: 1px solid red;
		margin: 0.3125rem 0;
		p {
			font-size: 0.875rem;
			color: #656565;
			margin-top: 0.125rem;
		}

		span {
			flex: 1;
			font-size: 0.875rem;
			/* font-size: 14px; */
			color: #656565;
			margin: 0 0.6875rem;
			overflow: hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
		}
	}
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
