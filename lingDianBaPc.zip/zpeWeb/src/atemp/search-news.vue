<template>
	<div class="search-news-div">
		<div class="news-List ">
			<!-- 	<ul class="news-item" v-for="(item, index) in newsList" :key="index">
				<li>
					<a href="#">{{ item.type + item.title }}:{{ item.content }}</a>
					<span>{{ item.time }}</span>
				</li>
			</ul> -->
			<ul class="news-item" v-for="(item, index) in searchNewsList" :key="index">
				<li>
					<a href="#" @click="navToNews(item.id, item.eventTypeName)">{{ item.newsTitle }}</a>
					<span>{{ item.createdTime | timeFilters }}</span>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
let that;
const { log } = console;
export default {
	props: {
		searchNewsList: {
			type: Array,
			default() {
				return [];
			}
		}
	},
	data() {
		return {
			livelist: 1
		};
	},
	created() {
		that = this;
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${M}-${D} ${h}:${m}`;
			}
		}
	},
	methods: {
		toDetails() {
			let current = this.$store.state.currentRoute;
			this.$router.push({
				path: 'lxDetails',
				query: {
					...current,
					lxid: 1
				}
			});
		},
		navToNews(nid, eventTypeName) {
			this.BR.navTo('/nDetail', {
				hid: 5,
				tid: 1,
				nid: nid,
				eventTypeName: eventTypeName,
				sid: 3
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.search-news-div {
	background: rgba(255, 255, 255, 1);
	.news-List {
		padding: 0.3125rem 0.875rem;
		.news-item {
			flex: 1;

			li {
				display: flex;
				justify-content: space-between;
				align-items: center;
				// font-size:14px;
				font-size: 0.875rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(102, 102, 102, 1);
				// line-height:28px;
				line-height: 1.75rem;
				padding: 0.5625rem 0;
				// position: relative;

				&:hover a,
				&:hover span {
					color: #ff5337;
					// color: red;
					// border: 1px solid red;
				}

				a {
					// padding-left: 15px;
					display: flex;
					align-items: center;
					color: #666666;
					&:before {
						content: ' ';
						position: relative;
						width: 0.25rem;
						height: 0.25rem;
						background: rgba(102, 102, 102, 1);
						border-radius: 50%;
						margin-right: 0.6875rem;
					}
					// &:hover{
					// 	color: #333333;
					// 	// color: red;
					// }
				}

				span {
					color: rgba(153, 153, 153, 1);
				}
			}
		}
	}
}
</style>
