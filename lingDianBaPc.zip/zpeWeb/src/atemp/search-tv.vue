<template>
	<div class="search-tv-layout">
		<div class="search-tv-container">
			<div :class="tvlist" class="tv-list" v-for="(item, index) in searchTv" :key="index" @click="navToTvDetails(item.id)">
				<!-- <img :src="item.imgLog" :alt="item.tvName" /> -->
				<img @error="errorImg($event, defaultImg)" :src="item.imgLog ? item.imgLog : require('../static/image/default_img.png')" />
				<div class="tv-name pointer">{{ item.tvName }}</div>
			</div>
		</div>
	</div>
</template>

<script>
let that;
const { log } = console;
export default {
	name: 'search-tv',
	props: {
		searchTv: {
			type: Array,
			default: () => {
				return [];
			}
		},
		// 一排显示多少个
		tvlistnNum: {
			type: Number,
			default: () => {
				return 1;
			}
		}
	},
	data() {
		return {
			defaultImg: require('../static/image/default_img.png') // 默认图片
		};
	},

	created() {
		that = this;
		this.tvlist = this.tvlistnNum == 1 ? 'tv-list-4' : 'tv-list-3';
	},
	methods: {
		navToTvDetails(id) {
			this.BR.navTo('/tvDetails', {
				hid: 4,
				tid: id,
				sid: 3
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.search-tv-layout {
	width: 66.5rem;
	background: rgba(255, 255, 255, 1);

	.search-tv-container {
		width: 100%;
		// border: 1px solid red;
		padding: 1.3125rem 0 2.3125rem 0;

		&::after {
			content: '';
			display: block;
			clear: both;
		}
	}

	.tv-list-3 {
		width: 33.3%;
		&:nth-child(1),
		&:nth-child(2),
		&:nth-child(3) {
			margin-top: 0;
		}
	}

	.tv-list-4 {
		width: 25%;
		&:nth-child(1),
		&:nth-child(2),
		&:nth-child(3),
		&:nth-child(4) {
			margin-top: 0;
		}
	}
	.tv-list {
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		// border: 1px solid red;
		box-sizing: border-box;
		float: left;
		margin-top: 2.4375rem;

		img {
			width: 5.1875rem;
			height: 3.25rem;
			display: block;
		}
		.tv-name {
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
			line-height: 1.75rem;
			margin-top: 0.625rem;
		}
	}
}
</style>
