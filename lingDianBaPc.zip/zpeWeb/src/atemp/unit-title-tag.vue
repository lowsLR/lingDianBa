<template>
	<!-- 公共头部标签 -->
	<div class="headTag" :style="tagStyle" :class="tagType === 0 ? 'main-tag' : ''">
		<div>{{ title }}</div>
		<span v-if="isMore" @click="navTo">{{ moreText }} >></span>
	</div>
</template>

<script>
export default {
	name: 'unit-title-tag',
	props: {
		tagType: {
			// 标签类型(0：主标签、1：栏目标签、2：右组件标签)
			type: Number,
			default: 1
		},
		tagStyle: {
			// 样式
			type: Object,
			default: function() {
				return {
					// width: ''+ w +'px',
					// position: 'absolute',
				};
			}
		},
		title: {
			// 标题
			type: String,
			default: '全部'
		},
		isMore: {
			// 是否开启更多
			type: Boolean,
			default: false
		},
		moreText: {
			// 更多
			type: String,
			default: '更多'
		},
		pageRouter: {
			// 跳转路由
			type: String,
			default: ''
		}
	},
	data() {
		return {
			test: 'test'
		};
	},
	created() {
		// console.log(this.test)
	},
	methods: {
		navTo() {
			let hid;
			if (this.pageRouter == '/sp-video') {
				hid = 3;
			} else {
				hid = 1;
			}
			this.BR.navTo(this.pageRouter, { hid: hid });
		}
	}
};
</script>

<style lang="scss" scoped>
.main-tag {
	margin-bottom: 0.5rem;
	/* margin-top: 0 !important; */
	border: 0 !important;
}

.headTag {
	/* margin-top: 24px; */
	display: flex;
	justify-content: space-between;
	align-items: center;
	width: 100%;
	// height: 2.25rem; // 36px
	padding: 0.75rem 0;
	box-sizing: border-box;
	border-bottom: 0.125rem solid #1b1b30;
	cursor: default;

	div {
		width: auto;
		// height: 34px;
		line-height: 1.75rem;
		font-size: 1.375rem;
		font-weight: bold;
		color: #1b1b30;
	}
	div:before {
		content: '';
		width: 0.375rem;
		height: 1.625rem;
		background: #1b1b30;
		display: inline-block;
		margin-right: 0.75rem;
		vertical-align: middle;
		margin-top: -0.25rem;
	}

	span {
		font-size: 1.125rem;
		color: #666666;
		cursor: pointer;

		&:hover {
			color: #ff5337 !important;
		}
	}
}
</style>
