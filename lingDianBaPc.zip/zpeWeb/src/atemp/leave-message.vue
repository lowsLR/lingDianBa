<template>
	<div class="leave-mian">
		<!-- 文本框 -->
		<div class="leave-input">
			<textarea
				@input="MonitorIn"
				@keydown="keyBoardEventListener($event)"
				:class="replyStatus ? 'replyStyle' : ''"
				v-model="inputText"
				:placeholder="textPromptMsg"
				ref="textFocus"
				:disabled="disabled"
			></textarea>
			<div class="leave-but">
				<!-- <i class="el-icon-orange"></i> -->
				<el-popover placement="right" width="400" v-model="visible" trigger="click" v-if="loginState && isTouristSwitch">
					<!-- <emotion @emotion="handleEmotion" :height="200" ></emotion> -->
					<!-- 表情区域 -->
					<div class="browBox">
						<ul>
							<li v-for="(item, index) in faceList" :key="index" @click="handleEmoji(index)">{{ item }}</li>
						</ul>
					</div>

					<img slot="reference" src="../static/main/bq.png" class="poinbut" />
				</el-popover>

				<div class="sub-but flex-cc" @click="handleSubmit" :class="btnStatus ? 'active-submit' : ''">{{ replyStatus ? '回 复' : '发布评论' }}</div>
			</div>
		</div>
		<!-- 评论内容 -->
		<div class="leave-message">
			<div class="p11 flex flex-1 flex-jc-sb bb3">
				<div>全部评论&nbsp;{{ mainComment.total > 0 ? '(' + mainComment.total + ')' : '' }}</div>
				<div class="comment-sort" @click="sortTypeId = sortTypeId === 1 ? 2 : 1">
					{{ sortTypeId === 1 ? '最新评论' : '热门评论' }}
					<span></span>
				</div>
			</div>
			<!-- 评论列表 -->
			<div class="p11 comment-list">
				<div class="leave-message-main commentItem" v-for="(item, index) in mainComment.data" :key="index">
					<div class="leave-message-top p11">
						<div class="flex flex-jc-fs flex-ai-c">
							<div class="leave-headerimg">
								<img :src="item.imageUrl ? 'https://images.weserv.nl/?url=' + item.imageUrl : require('../static/image/nodata/user_default.png')" alt="" />
							</div>
							<div>{{ item.nickName }}</div>
						</div>
						<div>{{ item.createdTime | getInterceptTime }}</div>
					</div>
					<div class="leave-message-message">
						<div class="leave-message-content">
							<p>{{ item.content }}</p>
							<!-- <p class="bq-message-img" v-html="item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion)"></p> -->
							<div class="replyBox">
								<span @click="handleExpand(item)" v-if="item.isReply && !item.isExpand">查看回复</span>
								<span @click="handleExpand(item)" v-if="item.isReply && item.isExpand">收起评论</span>
								<span @click.stop="handleReply(item)">{{ replyStatus && mainCommentId == item.id ? '取消回复' : '回复' }}</span>
							</div>
						</div>

						<!-- 是否显示回复(子评论) -->
						<!-- <div v-if="item.isExpand"> -->
						<div :class="item.isExpand ? 'expand' : 'fold'">
							<!-- 二级评论（初始显示状态） Obj -->
							<div class="leave-message-main childComment" v-if="item.sportMatchCommentChildDO && !item.isShowReply">
								<div class="leave-message-top p11">
									<div class="flex flex-jc-fs flex-ai-c">
										<div class="leave-headerimg">
											<img
												:src="
													item.sportMatchCommentChildDO.imageUrl
														? 'https://images.weserv.nl/?url=' + item.sportMatchCommentChildDO.imageUrl
														: require('../static/image/nodata/user_default.png')
												"
												alt=""
											/>
										</div>
										<div>
											{{ item.sportMatchCommentChildDO.nickName }}&ensp;
											<span>回复</span>
											&ensp;{{ item.nickName }}
										</div>
									</div>
									<div class="time">{{ item.sportMatchCommentChildDO.createdTime | getInterceptTime }}</div>
								</div>
								<div class="leave-message-message ">
									<div class="leave-message-content bb3">
										<p>{{ item.sportMatchCommentChildDO.content }}</p>
										<!-- <p class="bq-message-img" v-html="item.sportMatchCommentChildDO.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion)"></p> -->
										<!-- <span>回复</span> -->
									</div>
								</div>
							</div>

							<!-- 二级评论 Arr -->
							<template v-if="item.isShowReply">
								<div class="leave-message-main childComment" v-for="(citem, cindex) in item.replyData.data" :key="item.id + cindex">
									<div class="leave-message-top p11">
										<div class="flex flex-jc-fs flex-ai-c">
											<div class="leave-headerimg">
												<img
													:src="citem.imageUrl ? 'https://images.weserv.nl/?url=' + citem.imageUrl : require('../static/image/nodata/user_default.png')"
													alt=""
												/>
											</div>
											<div>
												{{ citem.nickName }}&ensp;
												<span>回复</span>
												&ensp;{{ item.nickName }}
											</div>
										</div>
										<div class="time">{{ citem.createdTime | getInterceptTime }}</div>
									</div>
									<div class="leave-message-message ">
										<div class="leave-message-content bb3">
											<p>{{ citem.content }}</p>
											<!-- <p class="bq-message-img" v-html="citem.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion)"></p> -->
											<!-- <span>回复</span> -->
										</div>
									</div>
								</div>
							</template>

							<!-- 子评论(回复)列表分页状态 -->
							<div class="bTip noMoreReply" v-if="item.isReply && item.replyData.loadMoreStatus === 2">暂无更多回复</div>
							<div class="bTip read-more-reply" @click="readMoreReply(item)" v-if="item.isReply && item.replyData.loadMoreStatus === 0">查看更多回复</div>
						</div>
					</div>
				</div>

				<!-- 评论列表分页状态 -->
				<div class="bTip noMore" v-if="mainComment.isLastPage">没有更多了</div>
				<div class="bTip read-more" @click="readMore" v-else>查看更多</div>
			</div>
		</div>
	</div>
</template>

<script>
// import Emotion from '@/components/Emotion/index';

// 导入JSON格式的表情库 (emoticon)
const Emoji = require('@/assets/emojis.json');

let that;
export default {
	name: 'leave-message',
	components: {
		// Emotion
	},
	props: {
		// 赛事id
		matchId: {
			type: String | Number,
			default: 0
		}
	},
	data() {
		return {
			disabled: false,
			isTouristState: true, //是否开启游客发留言权限
			isTouristSwitch: true, //是否开发留言板
			inputText: '',
			mainComment: {
				total: 0, // 数据总条数
				pageSize: 10, // 每页显示条数
				currentPage: 1, // 当前页码
				loadMoreStatus: 0, // 加载更多 0加载前，1加载中，2没有更多了
				isLastPage: false, // 末页状态
				data: []
			},
			sortTypeId: 1, // 排序类型 1：(最新)根据时间排序，2：(热门)点赞排序
			btnStatus: false, // (提交)按钮状态
			replyStatus: false, // 是否为回复状态
			textPromptMsg: '说点什么...', // 文本提示信息
			mainCommentId: 0, // 主评论id
			faceList: [], // 表情列表
			visible: false // 是否显示表情列表
		};
	},
	created: function() {
		that = this;

		// 生成表情列表
		for (let i in Emoji) {
			that.faceList.push(Emoji[i].char);
		}
		// console.log('表情列表：', that.faceList);

		that.loadCommentList('add');
		that.switchInfo();
	},
	watch: {
		sortTypeId(newValue, oldValue) {
			console.log(newValue, oldValue);
		},
		loginState(val) {
			if (this.isTouristState) {
				if (val) {
					this.disabled = false;
					this.textPromptMsg = '说点什么...';
					this.btnStatus = true;
					this.isTouristSwitch = true;
				} else {
					this.disabled = true;
					this.textPromptMsg = '请登录后留言';
					this.btnStatus = false;
					this.isTouristSwitch = false;
				}
			}
			this.inputText = '';
			this.replyStatus = false;
		}
	},
	computed: {
		loginState() {
			return this.$store.state.hasLogin;
		}
	},
	methods: {
		//判断用户是否可以留言
		switchInfo() {
			this.$newsReq.switchInfo().then(res => {
				if (!res.data.data.leaveTouristSwitch) {
					this.disabled = true;
					this.isTouristState = false;
					this.isTouristSwitch = false;
					this.textPromptMsg = '留言暂时不可用';
				} else {
					if (!this.loginState) {
						this.disabled = true;
						// this.isTouristState = true;
						// this.isTouristSwitch = true;
						this.textPromptMsg = '请登录后留言';
					}
				}
			});
		},
		// 查询一级评论列表数据
		loadCommentList(type) {
			let tabItem = that.mainComment;
			// console.log('type=>', type);
			//type：add加载更多、refresh下拉刷新
			if (type === 'add') {
				if (tabItem.loadMoreStatus === 2 || tabItem.isLastPage) {
					// console.log("末页状态：",tabItem.isLastPage)
					return;
				}
				if (tabItem.data && tabItem.data.length > 0) {
					tabItem.currentPage++;
				}
				tabItem.loadMoreStatus = 1;
				// console.log('--------------------- 加载 ---------------------');
			}
			if (type === 'refresh') {
				tabItem.data = []; //刷新前清空数组
				tabItem.currentPage = 1;
				tabItem.loadMoreStatus = 1;
				// console.log('--------------------- 刷新 ---------------------');
			}

			let datas = {
				id: ~~that.matchId, // 赛事id (~~：取整(不四舍五入))
				limit: tabItem.pageSize,
				offset: tabItem.currentPage,
				sortTypeId: 1, // 排序类型：1根据时间排序、2点赞排序
				// "sortTypeId": that.sortTypeId,
				typeId: 3 // 赛事类型：1新闻、2视频、3赛事
			};
			// console.log('请求参数-->',datas);
			that.$reqc
				.queryMainComment(datas)
				.then(res => {
					// console.log("返回结果-->",res)
					let list = res.data.data;
					// 更新总条数、分页状态
					tabItem.total = list.total;
					tabItem.isLastPage = list.isLastPage;

					list.list.forEach((item, index) => {
						// 是否有回复消息、与(默认展开)展开状态
						if (item.sportMatchCommentChildDO) {
							item.isShowReply = false; // *是否以数组形式显示子评论
							item.isReply = true; // *是否有回复(子评论)
							item.isExpand = true; // *展开状态
							/* 子评论数据对象 */
							item.replyData = {
								total: 0,
								pageSize: 5,
								currentPage: 1,
								isLastPage: false,
								loadMoreStatus: 0,
								data: []
							};
						} else {
							item.isReply = false;
							item.isExpand = false;
						}
						tabItem.data.push(item);
					});
					// 上滑加载、下拉刷新 处理状态 (返回数据长度小于零/数据长度与总数据量相等 → '没有更多数据了')
					if (type === 'add' || type === 'refresh') {
						// tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2 : 0;
						// console.log('是否为末页：',tabItem.isLastPage);
						tabItem.loadMoreStatus = tabItem.isLastPage ? 2 : 0;
					}
					// console.log("全部数据：",tabItem.data);
					// 二维数组，开启强制渲染
					this.$forceUpdate();
				})
				.catch(err => {
					// console.log(err);
				});
		},

		// 主评论查看更多
		readMore() {
			that.loadCommentList('add');
		},

		// 子评论(回复)查看更多
		readMoreReply: function(item) {
			// console.log(item);
			let rds = item.replyData;
			if (rds.loadMoreStatus === 2 || rds.isLastPage) {
				that.$message.info('没有更多数据了');
				return;
			}
			// 判断是否为首次加载评论
			if (rds.data && rds.data.length > 0) {
				rds.currentPage++;
			}
			// rds.loadMoreStatus = 1;
			let datas = {
				commentId: item.id, // 主评论id
				limit: rds.pageSize,
				offset: rds.currentPage,
				matchType: 3, // 评论类型：1新闻、2视频、3赛事
				sortTypeId: 1 // 排序类型：1根据时间排序、2点赞排序
			};
			// console.log('子评论请求参数-->',datas);
			that.$reqc.queryCommentChild(datas).then(res => {
				// console.log("子评论返回结果-->",res)
				// 更新子评论末页状态
				rds.isLastPage = res.data.data.isLastPage;
				// 更新子评论加载状态
				rds.loadMoreStatus = rds.isLastPage ? 2 : 0;
				// 插入子评论数据
				let list = res.data.data.list;
				list.forEach((item, index) => {
					rds.data.push(item);
				});

				if (!item.isShowReply) {
					item.isShowReply = true;
				}
			});
		},

		// 处理子评论收起与展开
		handleExpand: function(item) {
			// let tabItem = that.mainComment.data;

			item.isExpand = !item.isExpand;
			that.$forceUpdate();
		},

		// 监听键盘回车事件
		keyBoardEventListener: function(event) {
			if (event.keyCode === 13 && event.ctrlKey) {
				// that.inputText += "\n"; //换行
			} else if (event.keyCode === 13) {
				that.handleSubmit(); //提交的执行函数
				event.preventDefault(); // 阻止浏览器默认换行操作
				return false;
			}
		},

		// 发布评论/回复
		handleSubmit() {
			let val = this.inputText.replace(/(^\s*)|(\s*$)/g, '');
			if (val == '' || val == null) {
				that.$message.warning('请输入评论内容');
				return;
			}
			let datas, request;
			// 回复
			if (that.replyStatus) {
				datas = {
					commentContent: val,
					mainCommentId: that.mainCommentId,
					matchType: '3',
					livePlatform: '0'
				};
				request = that.$reqc.createCommentChi(datas);
			}
			// 评论
			else {
				datas = {
					commentContent: val,
					id: ~~that.matchId,
					matchType: '3',
					livePlatform: '0'
				};
				request = that.$reqc.createMainComment(datas);
			}

			request
				.then(res => {
					// console.log(res);
					if (res.status === 200 && res.data.resultCode === 1) {
						// 接口调用后返回提示内容
						this.$message.success(res.data.resultMsg);
						// 回复状态下 -> 取消回复
						if (that.replyStatus) {
							that.replyStatus = false;
							that.mainCommentId = '';
							that.textPromptMsg = '说点什么...';
						}
						// 清空输入内容 并修改按钮状态
						that.inputText = '';
						that.btnStatus = false;
						// 更新评论列表数据
						that.loadCommentList('refresh');
					} else {
						if (res.data.code == '1003') {
							this.$message.error('请重新登录');
							/* 全局事件触发 - 打开登录模态框 */
							that.eventBus.$emit('openLoginDialog', { dialogState: true, formType: 1 });
							return;
						}
						this.$message.error(res.data.resultMsg);
					}
				})
				.catch(err => {
					// console.log(err);
				});
		},

		// 修改回复状态
		handleReply(item) {
			// 回复状态下 -> 取消回复
			if (!this.isTouristState) return;
			if (!this.loginState) return;
			if (that.replyStatus) {
				that.replyStatus = false;
				that.mainCommentId = '';
				that.textPromptMsg = '说点什么...';
			}
			// 进入回复状态
			else {
				that.replyStatus = true;
				that.mainCommentId = item.id;
				that.textPromptMsg = '回复 ' + item.nickName;
			}
		},

		// 输入监听
		MonitorIn: function(e) {
			let val = this.inputText.replace(/(^\s*)|(\s*$)/g, '');
			if (val != '' && val != null) {
				that.btnStatus = true;
			} else {
				that.btnStatus = false;
			}
		},

		// 获取用户点击之后的标签，存放到输入框内
		handleEmoji(i) {
			that.inputText += that.faceList[i];
			that.btnStatus = true;
			// 隐藏表情框
			that.visible = !that.visible;
			// 点击表情后 获取文本框焦点
			this.$refs.textFocus.focus();
		}

		/* 输入/发送 表情 */
		/* handleEmotion (i) {
				this.inputText += i
				that.visible = !that.visible;
				// 点击表情后 获取文本框焦点
				this.$refs.textFocus.focus()
			},
			// 将匹配结果替换表情图片
			emotion (res) {
			  let word = res.replace(/\#|\;/gi,'')
			  const list = ['微笑', '撇嘴', '色', '发呆', '得意', '流泪', '害羞', '闭嘴', '睡', '大哭', '尴尬', '发怒', '调皮', '呲牙', '惊讶', '难过', '酷', '冷汗', '抓狂', '吐', '偷笑', '可爱', '白眼', '傲慢', '饥饿', '困', '惊恐', '流汗', '憨笑', '大兵', '奋斗', '咒骂', '疑问', '嘘', '晕', '折磨', '衰', '骷髅', '敲打', '再见', '擦汗', '抠鼻', '鼓掌', '糗大了', '坏笑', '左哼哼', '右哼哼', '哈欠', '鄙视', '委屈', '快哭了', '阴险', '亲亲', '吓', '可怜', '菜刀', '西瓜', '啤酒', '篮球', '乒乓', '咖啡', '饭', '猪头', '玫瑰', '凋谢', '示爱', '爱心', '心碎', '蛋糕', '闪电', '炸弹', '刀', '足球', '瓢虫', '便便', '月亮', '太阳', '礼物', '拥抱', '强', '弱', '握手', '胜利', '抱拳', '勾引', '拳头', '差劲', '爱你', 'NO', 'OK', '爱情', '飞吻', '跳跳', '发抖', '怄火', '转圈', '磕头', '回头', '跳绳', '挥手', '激动', '街舞', '献吻', '左太极', '右太极']
			  let index = list.indexOf(word)
			  return `<img src="https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/${index}.gif" align="middle">`   
			}, */
	},
	filters: {
		// 截取指定时间(MM - DD)
		getInterceptTime: function(times) {
			if (typeof times == 'string') {
				let time = times.trim().split(/\s+|:|-/g);
				// console.log(time);
				// return time[1] + '月' + time[2] + '日';
				// return time[3] + ':' + time[4];
				return time[1] + '-' + time[2] + ' ' + time[3] + ':' + time[4];
			} else {
				return times;
			}
		}
	}
};
</script>

<style lang="scss" scoped="">
.leave-mian {
	display: flex;
	flex: 1;
	flex-direction: column;

	/* 文本框 */
	.leave-input {
		display: flex;
		flex-direction: column;
		height: 8.75rem;
		padding: 0.5rem;
		background-color: $bg-white;
		border: 0.0625rem solid #cccccc;

		input,
		textarea {
			border: 0;
		}
		textarea {
			height: 5.9375rem;
			box-sizing: border-box;
			/* 取消文本聚焦框 */
			outline: none;
			resize: none;
			padding-left: 0.3125rem;
			&::-webkit-input-placeholder {
				color: #cccccc;
			}
		}

		.replyStyle::-webkit-input-placeholder {
			color: rgba(0, 114, 188, 0.6);
		}

		.leave-but {
			height: 2.75rem;
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding-top: 0.5rem;
			border-top: 0.0625rem solid #cccccc;
			.sub-but {
				background-color: rgba(255, 83, 55, 0.6);
				width: 6.25rem;
				height: 1.75rem;
				line-height: 1.75rem;
				border-radius: 0.875rem;
				font-size: 0.875rem;
				color: #ffffff;
				cursor: pointer;

				/* &:hover {
						background-color: rgba(255,83,55,1);
					} */
			}

			.active-submit {
				background-color: rgba(255, 83, 55, 1);
			}
		}
	}

	/* 评论内容 */
	.leave-message {
		background-color: $bg-white;
		margin-top: 0.875rem;

		.comment-sort {
			display: flex;
			align-items: center;
			cursor: pointer;
			color: #999999;
			&:hover {
				color: #000000;
			}
			span {
				width: 1.25rem;
				height: 1.5rem;
				margin-left: 0.25rem;
				background-image: url(../static/image/sort.png);
				background-size: cover;
			}
		}

		/* 评论内容框 */
		.comment-list {
			max-height: 38.75rem; // 620px
			overflow: hidden;
			overflow-y: auto;

			/* 隐藏滚动条 */
			scrollbar-width: none; /* Firefox */
			-ms-overflow-style: none; /* IE 10+ */
			&::-webkit-scrollbar {
				widht: 0;
			}
			&::-webkit-scrollbar {
				display: none; /* Chrome Safari */
			}
		}

		/* 主评论项 */
		.commentItem {
			// border-top: 1px solid red;
			border-bottom: 1px solid #ebebeb;
			/* padding-bottom: 0.5rem; */
		}
		/* 子评论 */
		.childComment {
			border-top: 1px solid #ebebeb;
			/* margin-bottom: 1rem; */
		}

		.leave-message-main {
			flex: 1;

			.leave-message-top {
				display: flex;
				border: #111111;
				justify-content: space-between;
				color: #666666;

				.leave-headerimg {
					width: 1.875rem;
					height: 1.875rem;
					margin-right: 0.5rem;

					img {
						width: 1.875rem;
						height: 1.875rem;
						border-radius: 50%;
					}
				}
				div {
					font-size: 0.875rem;
				}
				span {
					color: #999999;
				}
				.time {
					white-space: nowrap;
				}
			}
			.leave-message-message {
				display: flex;
				flex-direction: column;
				padding-left: 1.875rem;

				.leave-message-content {
					flex: 1;
					padding: 0.5rem;
					p {
						flex: 1;
						text-align: left;
					}
					.replyBox {
						display: flex;
						justify-content: flex-end;
					}
					span {
						padding: 0 0.5rem;
						font-size: 0.8125rem;
						color: #0072bc;
						cursor: pointer;
					}
				}
			}
		}
	}

	.bb3 {
		/* border-bottom: 1px solid #EBEBEB; */
		border-bottom: 0;
	}

	/* 查看更多评论、子评论查看更多 */
	.bTip {
		background-color: #ffffff;
		font-size: 0.875rem;
		color: #666666;
		cursor: default;
	}
	/* 主评论 */
	.read-more,
	.noMore {
		height: 3.75rem;
		line-height: 3.75rem;
	}
	/* (回复)子评论 */
	.read-more-reply,
	.noMoreReply {
		height: 2.75rem;
		line-height: 2.75rem;
		border-top: 1px solid #ebebeb;
		/* margin-bottom: 1rem; */
	}
	.read-more,
	.read-more-reply {
		cursor: pointer;

		&:hover {
			color: rgba(255, 83, 55, 1);
			background-color: rgba(255, 83, 55, 0.1);
		}
	}

	/* 收起或展开评论 */
	.expand {
		max-height: 38.75rem; // 620px
		transition: max-height 0.8s ease;
		opacity: 1;
		/* overflow-y: auto 避免展开后主评论样式穿透 */
		overflow-y: auto;

		/* 隐藏滚动条 */
		scrollbar-width: none; /* Firefox */
		-ms-overflow-style: none; /* IE 10+ */
		&::-webkit-scrollbar {
			widht: 0;
		}
		&::-webkit-scrollbar {
			display: none; /* Chrome Safari */
		}
	}
	.fold {
		max-height: 0;
		overflow: hidden;
		transition: all 0.5s ease;
		// opacity: 0;
	}
}

/* 表情区域 */
.browBox {
	/* width: 100%; */
	height: 12.5rem;
	background: papayawhip;
	overflow: scroll;

	/* 隐藏滚动条 */
	scrollbar-width: none; /* Firefox */
	-ms-overflow-style: none; /* IE 10+ */
	&::-webkit-scrollbar {
		widht: 0;
	}
	&::-webkit-scrollbar {
		display: none; /* Chrome Safari */
	}

	ul {
		display: flex;
		flex-wrap: wrap;
		li {
			width: 12.5%;
			padding: 0.25rem 0;
			font-size: 26px;
			list-style: none;
			text-align: center;
			cursor: pointer;
		}
	}
}
</style>
