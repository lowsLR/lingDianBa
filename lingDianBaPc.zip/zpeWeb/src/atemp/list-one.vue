<template>
	<div>
		<div
			class="list-one"
			:style="{
				listStyle
			}"
		>
			<div class="list-one-head list-atemp-head">
				<div class="list-atemp-tip">
					<img src="../static/main/news.png" />
					<span class="tip-text">{{ ftitle }}</span>
				</div>
				<div><span class="list-more pointer" @click="toMore">更多 >></span></div>
			</div>
			<div class="list-one-body" v-if="oneList && oneList.list && oneList.list.length">
				<div v-for="(item, index) in oneList.list" class="list-one-item" :key="index">
					<div class="item-left">
						<span v-if="isTime"><!-- <a href="#">{{item.stype}}</a> --></span>
						<span class="pointer ff-MY c666" @click="navTo(item)">{{ item.title }}</span>
					</div>
					<div class="item-right" v-if="isTime">{{ item.time }}</div>
				</div>
			</div>
			<!-- <nodata v-else :title="nodataTitle"></nodata> -->
			<div v-else class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'list-one',
	props: {
		// oneList: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		isTime: {
			type: Boolean,
			default: false
		},
		pageType: {
			//头部页面id
			type: Number | String,
			default: 1
		},
		nodataTitle: {
			//无数据显示
			type: String,
			default: '暂无数据'
		},
		ftitle: {
			type: String,
			default: '数据'
		},
		oneList: Object,
		default: function() {
			return {
				num: 5,
				title: '热门视频',
				list: []
			};
		}
	},
	methods: {
		toMore() {
			// this.BW.navTo({type:this.pageType})
			this.BR.navTo('/news', {
				hid: 5
			});
		},
		navTo(item) {
			this.BR.navTo('/nDetail', {
				hid: 5,
				nid: item.id
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.list-one {
	flex: 1;
	overflow: hidden;
	text-align: left;
	.list-one-body {
		width: 100%;
		background: #fff;
		padding: 0.625rem;
		.list-one-item {
			display: flex;
			align-items: center;
			justify-content: space-between;
			font-size: 0.875rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			line-height: 1.625rem;
			height: 1.625rem;
			&::before {
				content: '·';
				display: inline-block;
				position: absolute;
				font-size: 1.875rem;
			}
			.item-left {
				flex: 1;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;

				span {
					font-size: 0.875rem;
					padding-right: 1.125rem;
					margin-left: 0.75rem;
					overflow: hidden;
					text-overflow: ellipsis;
					font-weight: 400;
					color: rgba(102, 102, 102, 1);
					line-height: 1.88rem;
				}
			}

			// div {
			// 	margin-left:0.75rem;
			// 	line-height: 2.125rem;
			// 	overflow: hidden;
			// 	text-overflow: ellipsis;
			// }
		}
	}
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
