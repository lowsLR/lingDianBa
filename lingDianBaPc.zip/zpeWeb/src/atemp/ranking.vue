<template>
	<div>
		<div class="tem-div" v-if="rankType.req != ''">
			<div class="flex flex-jc-sb flex-ai-c">
				<div class="s-header">{{rankType.name}}<span style="color:#FF5337;">积分排名</span></div>
				<!-- <div class="more-div">更多>></div> -->
			</div>
			<div>
				<!-- stretch="true" -->
				 <el-tabs v-if="rankType.req == 'queryFIFA'" 
				 v-model="activeName" 
				 :stretch="isStretch" 
				 type="card" 
				 @tab-click="handleClick">
				    <el-tab-pane label="男足" name="11"></el-tab-pane>
				    <el-tab-pane label="女足" name="12"></el-tab-pane>
				 </el-tabs>
				 <el-tabs v-if="rankType.req == 'queryBasketball'" 
				 v-model="activeName" :stretch="isStretch" type="card" 
				 @tab-click="handleClick">
					   <el-tab-pane 
						 v-for="(item,index) in nlist" 
						 :key="item.title+index"
						 :label="item.title" 
						 :name="item.title"
						 ></el-tab-pane>
				 </el-tabs>
				 <el-tabs v-if="rankType.req == 'queryIntegral'"
				 v-model="activeName" :stretch="isStretch" type="card" 
				 @tab-click="handleClick">
				 					   <el-tab-pane 
				 						 v-for="(item,index) in integralData" 
				 						 :key="item.title+index"
				 						 :label="item.title" 
				 						 :name="item.title"
				 						 ></el-tab-pane>
				 </el-tabs>
				  <div class="rank-list">
					  <el-table 
						key="queryFIFA"
						v-if="rankType.req == 'queryFIFA'" 
						:data="tableData" :show-header="isshow" style="width: 100%">
					      <el-table-column width="40">
								<template slot-scope="scope" >
									<div class="rank-color" :class="['bg-'+scope.row.ranking]">
										{{scope.row.ranking}}
									</div>
								</template>
					      </el-table-column>
					      <el-table-column
					        prop="countryRegion"
					        >
					      </el-table-column>
					      <el-table-column
					        prop="integralSituation"
					        >
					      </el-table-column>
					    </el-table>
					  <el-table 
						v-if="rankType.req == 'queryBasketball'" 
						key="queryBasketball"
						:data="nbcData" :show-header="isshow" style="width: 100%">
					      <el-table-column width="40">
					  		<template slot-scope="scope">
					  			<div class="rank-color" :class="['bg-'+scope.row.ranking]">
					  				{{scope.row.ranking}}
					  			</div>
					  		</template>
					      </el-table-column>
					      <el-table-column
					        prop="team"
					        >
					      </el-table-column>
					      <el-table-column >
									<template slot-scope="scope">
										<div>
											{{scope.row.win +'胜  '+ scope.row.negative+'负'}}
										</div>
									</template>
					      </el-table-column>
					      <el-table-column
					        prop="recentDevelopments"
					        >
					      </el-table-column>
					    </el-table>
							
							<el-table v-if="rankType.req == 'queryIntegral'"
							key="queryIntegral"
							:data="integralList" :show-header="isshow" style="width: 100%">
							    <el-table-column width="40">
									<template slot-scope="scope">
										<div class="rank-color" :class="['bg-'+scope.row.ranking]">
											{{scope.row.ranking}}
										</div>
									</template>
							    </el-table-column>
							    <el-table-column
							      prop="team"
							      >
							    </el-table-column>
							    <el-table-column >
										<template slot-scope="scope">
											<div>
												{{scope.row.win +'胜  '+ scope.row.negative+'负'}}
											</div>
										</template>
							    </el-table-column>
							    <!-- <el-table-column
							      prop="recentDevelopments"
							      >
							    </el-table-column> -->
							  </el-table>
				  </div>
			</div>
		</div>
		
	</div>
</template>

<script>
	
	export default {
		name: 'ranking',
		props: {
			// rankType: {
			// 	type: Number,
			// 	default: 0
			// },
			rankType: Object,
			default: function() {
				return {
						req:'queryFIFA',
						index:0,
						name:'足球'
				}
			}
		},
		data() {
			return {
				isStretch:true,
				isshow:false,
				activeName:'11',
				tableData:[],
				integralData:[],//积分总数组
				integralList:[],//积分数据
				queryReq:{
					queryBasketball: () => {
						this.queryBasketball();
					},
					queryFIFA: () => {
						this.queryFIFA();
					},
					queryIntegral: () => {
						this.queryIntegral();
					},
				},
				typeId:11,//11男足 12女足
				nlist:[],//nba cba数组
				nbcData:[],
			}
		},
		computed:{
			newReq(){
				return this.rankType.req;
			},
			newindex(){
				return this.rankType.index;
			}
		},
		watch:{
			newReq(val){
				if(val != ''){
					this.queryReq[`${this.rankType.req}`].call(this);
				}
			},
			newindex(val){
				if(this.newReq != '' && val > 0){
					this.queryReq[`${this.rankType.req}`].call(this);
				}
			},
		},
		created() {
			// this.queryBasketball();
			if (this.rankType.req) {
				this.queryReq[`${this.rankType.req}`].call(this);
			}
		},
		methods: {
			handleClick(tab, event) {
				switch (this.rankType.req){
					case 'queryFIFA':
						this.typeId = ~~this.activeName;
						this.queryReq[`${this.rankType.req}`].call(this);
						break;
					case 'queryBasketball':
						let i = this.nlist.findIndex(item => item.title == this.activeName);
						this.nbcData = this.nlist[i].date;
						break;
					case 'queryIntegral':
						let q = this.integralData.findIndex(item => item.title == this.activeName);
						this.integralList = this.integralData[q].date;
						break;		
					default:
						break;
				}
				
			},
			
			// 查询nba、cba
			queryBasketball: function () {
				let datas = {
					 "limit": 15,
					 "offset": 1
				}
				this.$req.queryBasketball(datas).then( res => {
					// console.log("查询nba、cba：",res);
					if(res.status == 200 && res.data.length){
						let arr = res.data;
						arr.forEach((item,index) => {
							item.date = item.date.slice(0,15);
						})
						this.nlist = arr;
						this.nbcData = this.nlist[0].date;
						this.activeName = this.nlist[0].title;
						this.$forceUpdate();
					}
				})
			},
			
			// 查世界排名变化
			queryFIFA: function () {
				let datas = {
					 "limit": 15,
					 "offset": 1,
					 "typeId": this.typeId,
				}
				// this.tableData = [];
				this.$req.queryFIFA(datas).then( res => {
					// console.log("查世界排名变化：",res);
					if(res.status == 200 && res.data.resultCode == 1){
						let list = res.data.data.list;
						if(this.activeName != '11' && this.activeName != '12'){
							this.activeName = '11';
						}
						// this.tableData = list.slice(0,15);
						this.tableData = list;
						this.$forceUpdate();
					}
				})
			},
			// 查询积分排名变化
			queryIntegral: function () {
				let datas = {
					 "limit": 15,
					 "offset": 1,
					 "typeId": this.rankType.index,	//5 西甲 6 意甲 7 英超 8 德甲 9 欧冠 10 法甲
				}
				this.$req.queryIntegral(datas).then( res => {
					// console.log("查询积分排名变化：",res);
					if(res.status == 200 && res.data.length){
						let arr = res.data;
						arr.forEach((item,index) => {
							item.date = item.date.slice(0,15);
						})
						this.integralData = arr;
						this.integralList = arr[0].date;
						this.activeName = arr[0].title;
						this.$forceUpdate();
					}
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.rank-list{
		
	}
	.rank-color{
		width:1.125rem;
		height:1.125rem;
		background:rgba(230,230,230,1);
		border-radius:0.25rem;
		font-size:0.75rem;
		font-family:Microsoft YaHei;
		font-weight:400;
		color:rgba(51,51,51,1);
		line-height:1.125rem;
		display: flex;
		justify-content: center;
		align-items: center;
		white-space: nowrap;
	}
	// .rank-color:first-child{
	// 	
	// }
	.bg-1{
		background:rgba(255,83,55,1) !important;
		color:rgba(255,255,255,1) !important;
	}
	.bg-2{
		background:rgba(255,141,110,1) !important;
		color:rgba(255,255,255,1) !important;
	}
	.bg-3{
		background:rgba(255,188,148,1) !important;
		color:rgba(255,255,255,1) !important;
	}
</style>
