<template>
	<div class="team-layout">
		<!-- 标题 -->
		<div class="title-header">
			<div class="title">
				<span></span>
				<span>球队筛选</span>
			</div>
		</div>
		<div class="team-content">
			<div class="ranks">
				<div class="ranks-list">
					<template v-if="ranksList.length">
						<div class="pic-name" v-for="(item, index) in ranksList" :key="index">
							<img @error="errorImg($event, homeTeam)" :src="item.teamLogoPath ? item.teamLogoPath : require('../static/image/default_match_img.png')" />
							<div class="name pointer">{{ item.teamName }}</div>
						</div>
					</template>
					<template v-else>
						<nodata fontSize="1rem" color="#666666" height="16.875rem"></nodata>
					</template>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
let that;
const { log } = console;
export default {
	name: 'team-selection',
	props: {
		ranksList: {
			type: Array,
			default: () => {
				return [];
			}
		}
	},
	data() {
		return {
			homeTeam: require('../static/image/nodata/homeTeam.png')
		};
	},
	created() {},
	methods: {}
};
</script>

<style lang="scss" scoped>
.team-layout {
	width: 19.875rem;
	// border: 1px solid red;
	.title-header {
		width: 100%;
		border-bottom: 0.125rem solid #1b1b30;

		// border: 1px solid red;
		.title {
			display: flex;
			align-items: center;
			padding-bottom: 0.3125rem;
			span:first-child {
				width: 0.375rem;
				height: 1.625rem;
				background: rgba(27, 27, 48, 1);
				margin-right: 0.625rem;
			}
			span:last-child {
				font-size: 1rem;
				font-family: Microsoft YaHei;
				font-weight: bold;
				color: rgba(27, 27, 48, 1);
				// line-height:1.75rem;
			}
		}
	}
	.team-content {
		width: 100%;
		background: rgba(255, 255, 255, 1);
		padding: 0.9375rem 0.9375rem 0 0.9375rem;
	}

	.ranks {
		margin-bottom: 1.9375rem;

		.team-title {
			width: 100%;
			text-align: center;
			height: 1.0625rem;
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(51, 51, 51, 1);
			line-height: 1.75rem;
			margin-bottom: 1.25rem;
		}

		.ranks-list {
			display: flex;
			align-items: center;
			flex-direction: row;
			flex-wrap: wrap;
			// justify-content: space-between;
			// padding: 0 0.625rem;
			// border: 1px solid red;
		}

		.pic-name {
			width: 33.33%;
			border: 0.0625rem solid #ffffff;
			// border: 1px solid red;
			display: flex;
			align-items: center;
			margin-bottom: 0.875rem;
			img {
				width: 1.875rem;
				height: 1.875rem;
				display: block;
				// margin-right: 0.625rem;
				flex-shrink: 0;
			}

			// &:nth-child(3n-1) {
			// 	margin: 0;
			// }

			.name {
				font-size: 0.875rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(102, 102, 102, 1);
				line-height: 1.75rem;
				border: 1px solid #ffffff;
				width: 100%;
				white-space: nowrap;
				text-overflow: ellipsis;
				overflow: hidden;
				word-break: break-all;
				// border: 1px solid red;
				text-align: left;
				margin-left: 0.3125rem;
			}
		}
	}
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
</style>
