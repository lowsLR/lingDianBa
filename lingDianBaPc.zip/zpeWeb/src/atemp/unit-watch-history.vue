<template>
	<!-- 相关新闻 -->
	<div class="types">
		<div class="headTag"><div>观看记录</div></div>
		<div class="newsItem" v-if="historyArr.length">
			<li class="pointer" v-for="(item, index) in historyArr" :key="index" @click="navTo(item.id)">
				<p class="title">{{ item.tvName }}</p>
				<p class="time">{{ item.time }}</p>
			</li>
		</div>
		<div class="noMore" v-else>暂无数据</div>
	</div>
</template>

<script>
let that;
export default {
	name: 'unit-watch-history',
	props: {
		// 数据列表
		historyArr: {
			type: Array,
			default: function() {
				return [];
			}
		}
	},
	data() {
		return {
			activeName: '东部',
			tableData: [{ rank: 1, name: '雄鹿' }]
		};
	},
	created: function() {
		that = this;
		// console.log("获取vuex",that.$store.state)
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
		// that.id = that.$route.params;
		// console.log(that.$route.path)
		// console.log("live-list的",that.$route.params )
	},
	methods: {
		navTo(id) {
			// console.log(id);
			this.BR.navTo('/tvDetails', {
				hid: 4,
				tid: id
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.types {
	// width: 19.875rem;
	width: 20.5rem;
	height: 8.625rem;
	overflow: hidden;
	margin-top: 1.5rem;
	color: #666666;
	// border: 1px solid red;
	.headTag {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 2.25rem;
		box-sizing: border-box;
		border-bottom: 0.125rem solid #1b1b30;

		div {
			width: auto;
			height: 2.125rem;
			line-height: 2.125rem;
			font-size: 1rem;
			font-weight: bold;
			color: #1b1b30;
		}
		div:before {
			content: '';
			width: 0.375rem;
			height: 1.625rem;
			background: #1b1b30;
			display: inline-block;
			margin-right: 0.75rem;
			vertical-align: middle;
			margin-top: -0.25rem;
		}
	}

	.newsItem {
		height: calc(100% - 2.25rem);
		box-sizing: border-box;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		padding: 0 0.5rem;
		background-color: #ffffff;
		font-size: 0.75rem;
		text-align: left;
		padding-bottom: 0.3125rem;
		li,
		p,
		span {
			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space: nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
		}

		li {
			width: 47%;
			height: 25%;
			display: flex;
			align-items: center;
		}

		.title {
			flex: 1;
		}
		.time {
			min-width: 2.25rem;
			max-width: 2.25rem;
		}

		li:before {
			content: '';
			min-width: 0.25rem;
			height: 0.25rem;
			border-radius: 50%;
			background: #666666;
			display: inline-block;
			margin-right: 0.375rem;
			vertical-align: middle;
		}
	}

	.noMore {
		height: calc(100% - 2.25rem);
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #ffffff;
	}
}
</style>
