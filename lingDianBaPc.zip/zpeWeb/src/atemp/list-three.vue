<template>
	<div class="" style="height:'100%'">
		<div class="list-three">
			<ul class="list-three-body" v-if="threeList.length">
				<li class="li-mian pointer" v-for="(item, index) in threeList[0].matchLiveSourceDOS" :key="index" @click="navToSpPlayback(item)">
					<span>[{{ item.createdTime | timeFilters }}]</span>
					<!-- <span>{{' '+threeList[0].matchTitle}}</span> -->
					<span v-if="threeList[0].homeTeamName && threeList[0].guestTeamName" style="margin-left: 0.625rem;">
						{{ ' ' + threeList[0].homeTeamName }} - {{ threeList[0].guestTeamName + '' }}
					</span>
					<span v-else style="margin-left: 0.625rem;">{{ ' ' + threeList[0].eventTypeName }} {{ threeList[0].matchTitle + '' }}</span>
					<span v-if="item.matchSourcePathShortName" style="color: #FF5337;margin:0 0.3125rem 0 0.625rem">[{{ item.matchSourcePathShortName }}]</span>
					<span style="font-weight: bold;">{{ ' ' + item.liveSourceName }}</span>
				</li>
			</ul>
			<div style="height: 100%;" v-else><nodata height="100%" :title="nodataTitle"></nodata></div>
		</div>
	</div>
</template>

<script>
export default {
	name: 'list-three',
	props: {
		listStyle: {
			//样式
			type: String,
			default: ''
		},
		nodataTitle: {
			type: String,
			default: '暂无数据'
		},
		threeList: Array,
		default: function() {
			return {
				list: []
			};
		}
	},
	data() {
		return {
			navItem: {
				id: '',
				type: 5,
				name: '全部',
				secondName: ''
			}
		};
	},
	methods: {
		// 跳转录像详情
		navToSpPlayback(item) {
			this.navItem.secondName = this.getCombinationTitle(this.threeList[0]);
			const { href } = this.$router.resolve({
				name: `lx-VideoPlayback`,
				query: {
					hid: Number(2),
					sourceId: item.sourceId,
					matchId: item.matchId,
					sid: 3,
					data: JSON.stringify(this.navItem)
				}
			});
			window.open(href, '_blank');
		},

		// 获取组合标题
		getCombinationTitle: function(item) {
			let date, title, topLine, bottomLine;
			// 日期
			/* let time = item.matchBeginTime.trim().split(/\s+|:|-/g);
				date = time[1] + '-' + time[2]; */
			if (item.homeTeamName != '' && item.homeTeamName != null && item.guestTeamName != '' && item.guestTeamName != null) {
				// 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题
				if (item.eventTypeName == '' || item.eventTypeName == null) {
					title = item.specialName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle;
				} else if (item.eventTypeName == '其他') {
					title = item.eventName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle;
				} else {
					title = item.eventTypeName + item.matchTitle;
				}
				bottomLine = item.homeTeamName + ' - ' + item.guestTeamName;
			} else {
				title = item.eventTypeName == '' || item.eventTypeName == null ? item.specialName : item.eventTypeName == '其他' ? item.eventName : item.eventTypeName;
				bottomLine = title + ' ' + item.matchTitle;
			}
			// js空格符：'\xa0'
			// return topLine + bottomLine
			return bottomLine;
		}
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${Y}年${M}月${D}日`;
			}
		}
	}
};
</script>

<style lang="scss">
.list-three {
	flex: 1;
	overflow: hidden;
	text-align: left;
	height: 100%;
}

.list-three-tip {
	display: inline-block;
	width: 9.375rem;
	height: 2.1875rem;
	color: $bg-main;
}

.tip-text {
	font-size: 1rem;
	font-family: Microsoft YaHei;
	font-weight: 600;
	color: $bg-main;
	display: flex;
	padding-left: 0.3125rem;
}

.list-more {
	font-size: 0.75rem;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: rgba(102, 102, 102, 1);
}
.li-mian {
	box-sizing: border-box;
	border-bottom: 0.0625rem solid rgba(225, 225, 225, 1);
	display: flex;
	justify-content: center;
	align-items: center;

	font-size: 1.0625rem;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: rgba(51, 51, 51, 1);
	line-height: 2.875rem;
}
// .li-mian:last-child{
// 	border: none;
// }
.list-three .list-three-head {
	height: 2.1875rem;
	line-height: 2.1875rem;
	font-size: 1.125rem;
	font-weight: 600;
	display: flex;
	justify-content: space-between;
}

.list-three .list-three-body {
	background: #fff;
	padding: 0.3125rem;
}

.list-three .list-three-body li {
	height: 4rem;
	line-height: 4rem;
	display: block;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}

.list-three ul {
	width: 100%;
}
</style>
