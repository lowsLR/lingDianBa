<template>
	<div class="container">
		<!-- Form -->
		<el-dialog :title="formType === 3 ? '重置密码' : '零点八登录'" :visible.sync="dialogFormVisible" :before-close="handleClose">
			<!-- 登录表单 -->
			<el-form :model="loginForm" v-if="formType === 1">
				<el-input v-model="loginForm.phone" placeholder="请输入手机号" maxlength="11" clearable></el-input>
				<el-input v-model="loginForm.password" placeholder="请输入密码" maxlength="16" show-password></el-input>
				<el-button type="primary" @click.stop="handleLoginOrRegister(formType)" class="confirmBtn">登 录</el-button>
				<div class="bottomOption">
					<span class="switchForm" @click.stop="changeFormType(3)">忘记密码</span>
					<div>
						<span>没有账号？</span>
						<span class="switchForm" @click.stop="changeFormType(2)">立即注册</span>
					</div>
				</div>
			</el-form>

			<!-- 注册表单 -->
			<el-form :model="registForm" v-if="formType === 2">
				<el-input v-model="registForm.phone" placeholder="请输入手机号" maxlength="11" clearable></el-input>
				<div class="imgCodeBox" v-if="registFormShow">
					<el-input placeholder="请输入图片验证码" v-model="registVerifyCode" maxlength="4"></el-input>
					<img id="registImg" :src="getRegistCodeUrl" @click.stop="handleGetImgCode" class="imgCodeBtn" alt="" />
				</div>
				<el-input placeholder="请输入验证码" v-model="registForm.code" maxlength="6">
					<el-button @click.stop="handleGetCode" slot="append" class="codeBtn">{{ count }}</el-button>
				</el-input>
				<el-input v-model="registForm.password" placeholder="请输入密码" maxlength="16" show-password></el-input>
				<el-input v-model="registForm.invitationCode" type="text" placeholder="请填写6位邀请码（选填）" maxlength="6" clearable></el-input>
				<el-button type="primary" @click.stop="handleLoginOrRegister(formType)" class="confirmBtn">注 册</el-button>
				<span>
					<span>已有账号？</span>
					<span class="switchForm" @click.stop="changeFormType(1)">前往登录</span>
				</span>
			</el-form>

			<!-- 重置密码 -->
			<el-form :model="resetPw" v-if="formType === 3">
				<el-input v-model="resetPw.phone" placeholder="请输入手机号" maxlength="11" clearable></el-input>
				<div class="imgCodeBox" v-if="resetPwShow">
					<el-input placeholder="请输入图片验证码" v-model="resetPwVerifyCode" maxlength="4"></el-input>
					<img id="resetPwImg" :src="getResetPwCodeUrl" @click.stop="handleGetImgCode" class="imgCodeBtn" alt="" />
				</div>
				<el-input placeholder="请输入验证码" v-model="resetPw.code">
					<el-button @click.stop="handleGetCode" slot="append" class="codeBtn">{{ count }}</el-button>
				</el-input>
				<el-input v-model="resetPw.password" placeholder="请输入密码" maxlength="16" show-password></el-input>
				<el-input v-model="resetPw.confirmPwd" placeholder="请再次输入密码" maxlength="16" show-password></el-input>
				<el-button type="primary" @click.stop="handleLoginOrRegister(formType)" class="confirmBtn">提 交</el-button>
			</el-form>

			<!-- <div class="otherWays" v-if="formType === 1">
				<div class="title">其它方式登录</div>
				<div class="mode">
					<div class="item weixin"></div>
					<div class="item qq"></div>
					<div class="item weibo"></div>
				</div>
			</div> -->

			<!-- <div slot="footer" class="dialog-footer">
				<el-button @click="changeLoginDialog">取 消</el-button>
				<el-button type="primary">确 定</el-button>
			</div> -->
		</el-dialog>
	</div>
</template>

<script>
import BWU from '@/bw/js/bw-util.js';
import base from '../request/api/base.js'; // 导入接口域名列表

import { mapState, mapMutations } from 'vuex';
import { login, register, sendSMS, resetPW } from '@/utils/special/user.js';

let that, timer;
export default {
	name: 'loginDialog',
	props: {
		// 模态框显示隐藏
		dialogFormVisible: {
			type: Boolean,
			default: false
		},
		// 表单类型 1：登录，2：注册，3：重置(修改)密码
		formType: {
			type: Number,
			default: 1
		}
	},
	data() {
		return {
			registFormShow: false, //注册显示验证码
			resetPwShow: false, //修改密码显示验证码
			loginForm: {
				phone: '',
				password: ''
			},
			registForm: {
				phone: '', // 手机号
				password: '', // 密码
				code: '', // 短信验证码
				invitationCode: '', // 邀请码
				smsType: 1 // 短信类型（固定）
			},
			resetPw: {
				phone: '',
				password: '',
				confirmPwd: '',
				code: '',
				smsType: 1
			},
			count: '发送验证码',
			isgetCode: true, // 短信验证码获取状态

			registVerifyCode: '', // 图片验证码（注册）
			resetPwVerifyCode: '', // 图片验证码（重置密码）
			getRegistCodeUrl: '', // 图片验证码地址（注册）
			getResetPwCodeUrl: '', // 图片验证码地址（重置密码）
			getCodeUrl: `${base.bd}/app/login/userAccount/getVerify`, // 图片验证码地址
			isClickCodeUrl: false // 是否已点击获取图片验证码
		};
	},
	created: function() {
		that = this;
	},
	destroyed() {
		// 离开页面清除定时器
		that.$once('hook:beforeDestroy', () => {
			clearInterval(timer);
		});
	},
	watch: {
		'registForm.phone'(newValue, oldValue) {
			if (BWU.phone_validation(newValue)) {
				that.registFormShow = true;
				that.handleGetImgCode();
			} else {
				that.registFormShow = false;
				that.registVerifyCode = '';
			}
		},
		'resetPw.phone'(newValue, oldValue) {
			if (BWU.phone_validation(newValue)) {
				that.resetPwShow = true;
				that.handleGetImgCode();
			} else {
				that.resetPwShow = false;
				that.resetPwVerifyCode = '';
			}
		},
		formType(newValue, oldValue) {
			// 切换页面清除定时器
			clearInterval(timer);
			that.count = '发送验证码';
			that.isgetCode = true;
		}
	},
	methods: {
		// 映射成 this.login()，this.logout()
		...mapMutations(['login', 'logout']),

		// before-close 仅当用户通过点击关闭图标或遮罩关闭 Dialog 时起效
		handleClose(done) {
			// 关闭模态框时，清空 所有 表单数据
			this.loginForm = this.$utils.resetObject(this.loginForm);
			this.registForm = this.$utils.resetObject(this.registForm);
			this.resetPw = this.$utils.resetObject(this.resetPw);
			
			this.$emit('update:dialogFormVisible', false);
			
			
		},

		// 获取图片验证码
		handleGetImgCode() {
			if (that.isClickCodeUrl) return;
			// console.log(that.isShow,"==>isShow")
			that.isClickCodeUrl = true;

			let img, phone;
			if (that.formType == 2) {
				img = document.getElementById('registImg');
				phone = that.registForm.phone;
				// that.resetPwShow = false;
			} else {
				img = document.getElementById('resetPwImg');
				phone = that.resetPw.phone;
				// that.registFormShow = false;
			}
			// var url = this.getCodeUrl;
			var request = new XMLHttpRequest();
			request.responseType = 'blob';
			request.open('get', this.getCodeUrl + '?key=' + phone, true);
			// request.setRequestHeader('token', this.$store.state.userInfo.token);
			this.$nextTick(() => {
				request.onreadystatechange = e => {
					// console.log(e, '===>e');
					if (request.readyState == XMLHttpRequest.DONE && request.status == 200) {
						if (!img) {
							that.isClickCodeUrl = false;
							that.handleGetImgCode();
						} else {
							img.src = URL.createObjectURL(request.response);
							img.onload = () => {
								URL.revokeObjectURL(img.src);
							};
						}
					}
				};
				request.send(null);
			});

			setTimeout(function() {
				that.isClickCodeUrl = false;
			}, 1000);
		},

		/**
		 * @Description: 处理登录或注册的函数
		 * reqType(请求类型)：1：登录，2：注册，3：重置(修改)密码
		 */
		async handleLoginOrRegister(reqType) {
			let datas, res;
			// 登录
			if (reqType == 1) {
				if (!this.$utils.paramsValidate(this.loginForm)) return;
				if (!this.$utils.isMobilePhone(this.loginForm.phone)) return;
				datas = {
					clientId: 0.1,
					password: this.loginForm.password,
					phone: this.loginForm.phone,
					systemtype: '',
					verify: ''
				};
				// 同步处理异步请求
				res = await login(datas);
			}
			// 注册
			if (reqType == 2) {
				this.registForm.smsType = 1; // 短信类型 1：注册，2：重置密码
				if (!this.$utils.paramsValidate(this.registForm)) return;
				if (!this.$utils.isMobilePhone(this.registForm.phone)) return;
				datas = this.registForm;
				res = await register(datas);
			}
			// 重置密码
			if (reqType == 3) {
				this.resetPw.smsType = 2; // 短信类型 1：注册，2：重置密码
				if (!this.$utils.paramsValidate(this.resetPw)) return;
				if (!this.$utils.isMobilePhone(this.resetPw.phone)) return;
				datas = this.resetPw;
				res = await resetPW(datas);
			}
			// 请求状态码为200、接口返回状态码为1，表示登录或注册成功，
			if (res.status === 200 && res.data.resultCode === 1) {
				// 请求成功后，清空对应表单数据
				switch (reqType) {
					case 1:
						this.loginForm = this.$utils.resetObject(this.loginForm);
						break;
					case 2:
						this.registForm = this.$utils.resetObject(this.registForm);
						break;
					case 3:
						this.resetPw = this.$utils.resetObject(this.resetPw);
						break;
					default:
						break;
				}

				// 重置密码后需重新登录
				if (reqType === 3) {
					// 清除本地存储
					this.$ls.remove('userInfo');
					this.$ls.remove('token');

					// 更新Vuex数据（清空 登录状态、用户数据）
					this.logout();

					// 关闭登录模态框
					this.$emit('update:dialogFormVisible', false);

					this.$message.success(res.data.resultMsg + '，请重新登录');
					console.log('user info was cleared successfully');
					return;
				}

				// 接口调用后返回提示内容
				this.$message.success(res.data.resultMsg);

				// 设置本地存储(用户信息)
				let val = {
					userId: res.data.data.userId,
					nickName: res.data.data.nickName,
					imageUrl: res.data.data.imageUrl,
					userIntegral: res.data.data.userIntegral,
					invitationCode: res.data.data.invitationCode,
					token: res.data.data.token,
					registeIp: res.data.data.registeIp
					// deviceType: that.deviceType || '',
				};
				try {
					// 设置本地存储
					this.$ls.set('userInfo', val);
					this.$ls.set('token', res.data.data.token);

					// 更新Vuex数据（登录状态、用户数据）
					this.login(val);
				} catch (e) {
					// error
					console.log(e);
				}
				// this.$ls.clear(); // 清空所有本地缓存
				// console.log(this.$ls.get('userInfo'));
				// console.log(this.$ls.get('token'));

				// 关闭登录模态框
				this.$emit('update:dialogFormVisible', false);

				// 修改登录状态
				// this.$emit('modifyLoginStatus');
			} else {
				if (res.data.resultCode === -118) {
					this.$message.error('手机号或密码不正确');
					return;
				}
				this.$message.error(res.data.resultMsg);
			}
		},

		// 登录注册切换
		changeFormType: function(type) {
			// that.formType = type
			/**
			 * 在父组件中 直接在需要传递的属性后面加上.sync
			 * 在子组件中 监听你使用update事件来更新formType,而在父组件不需要调用该函数
			 */
			this.$emit('update:formType', type);

			if (type == 2 && BWU.phone_validation(that.registForm.phone)) {
				// 表单切换 更新图片验证码
				setTimeout(function() {
					that.handleGetImgCode();
				}, 10);
			}
		},

		/**
		 * 获取短信验证码
		 * @Description: 使用工具函数的节流方法，让执行事件时产生间隔
		 */
		handleGetCode: _.throttle(async () => {
			// 获取指定操作对应的手机号
			let phone = that.formType === 2 ? that.registForm.phone : that.resetPw.phone;
			if (!that.$utils.isMobilePhone(phone)) return;
			// 获取指定操作对应的图片验证码
			let verifyCode = that.formType === 2 ? that.registVerifyCode : that.resetPwVerifyCode;
			if (!verifyCode) {
				that.$message.warning('请输入图片验证码');
				return;
			}
			// 指定发送的短信类型
			let smsType = that.formType === 2 ? 1 : 2;

			if (that.isgetCode === false) return;

			console.log('执行sendSms');
			let res = await sendSMS({
				phone: phone,
				smsType: smsType, // 短信类型 1：注册，2：重置密码
				verify: verifyCode
			});
			console.log(res);
			if (res.status == 200 && res.data.resultCode == 1) {
				that.$message.success(res.data.resultMsg);

				that.isgetCode = false;
				that.count = 59;
				timer = setInterval(() => {
					that.count--;
					// console.log(that.count, 'timer')
					// 边界值处理
					if (that.count === 0) {
						that.count = '发送验证码';
						that.isgetCode = true;
						// 到0清除定时器
						clearInterval(timer);
					}
				}, 1000);
			} else if (res.status == 200 && res.data.resultCode != 1) {
				that.$message.warning(res.data.resultMsg);
			}
		}, 5000)
	}
};
</script>

<style lang="scss" scoped>
.container {
	width: 100%;
}

/deep/.el-dialog {
	width: 27.625rem;
}

/deep/.el-dialog__header {
	padding: 0.8125rem 0;
	background: rgba(27, 27, 48, 1);
	display: flex;
	align-items: center;
	justify-content: center;

	/* 标题 */
	.el-dialog__title {
		font-size: 1.0625rem;
		color: #ffffff;
	}

	/* 关闭图标 */
	.el-dialog__headerbtn {
		top: 1.125rem;
	}
	.el-dialog__headerbtn .el-dialog__close {
		color: rgba(255, 255, 255, 1);
	}
}

/* 登录表单 */
.el-form {
	display: flex;
	flex-direction: column;
	align-items: center;

	/deep/.el-input {
		width: 80%;
		overflow: hidden;
		margin-bottom: 1rem;
		border-radius: 1.5625rem;
		border: 0.0625rem solid rgba(204, 204, 204, 1);

		input {
			height: auto !important;
			text-align: center;
			line-height: 2.1875rem;
		}
		input::placeholder {
			color: rgba(102, 102, 102, 1);
		}

		.el-button {
			border: 0px;
			border-radius: 0 1.5625rem 1.5625rem 0;
			padding: 0.75rem 1.25rem;
			margin: -0.625rem -1.375rem;
			color: #ffffff;
			background-color: rgba(27, 27, 48, 1);
		}

		.codeBtn {
			width: 6.875rem;
			font-size: 1rem;
			display: flex;
			align-items: center;
			justify-content: center;
		}
	}

	.imgCodeBox {
		width: 80%;
		height: 2.3125rem;
		display: flex;
		align-items: center;
		margin-bottom: 1rem;
		border: 0.0625rem solid rgba(204, 204, 204, 1);
		border-radius: 1.5625rem;
		overflow: hidden;

		.el-input {
			border: 0;
			margin: 0;
		}

		/* 图片验证码按钮 */
		.imgCodeBtn {
			min-width: 6.875rem;
			max-width: 6.875rem;
			height: 2.3125rem;
			display: block;
			background-color: rgba(0, 0, 0, 0.1);
		}
	}
	
	.bottomOption {
		display: flex;
		justify-content: space-between;
		width: 80%;
	}

	span {
		font-size: 0.5625rem;
		color: #666666;

		&.switchForm {
			color: #409eff;
			cursor: pointer;
		}
	}

	.confirmBtn {
		width: 80%;
		height: 2.1875rem;
		line-height: 2.1875rem;
		padding: 0;
		margin-bottom: 0.5rem;
		border: 0;
		background-color: rgba(27, 27, 48, 0.8);
		border-radius: 1.5625rem;

		&:hover {
			background-color: rgba(27, 27, 48, 1);
		}
	}
}

/* 第三方登录 */
.otherWays {
	margin-top: 1.125rem;
	.title {
		display: flex;
		align-items: center;
		justify-content: center;
		margin-bottom: 0.5rem;
		font-size: 0.5625rem;
		color: #999999;

		&::after,
		&::before {
			content: '';
			width: 20%;
			height: 0.0625rem;
			margin: 0 0.625rem;
			border-bottom: 0.0625rem solid #cccccc;
		}
	}

	.mode {
		display: flex;
		justify-content: space-around;
		.item {
			width: 2.8125rem;
			height: 3.125rem;
			font-size: 0.625rem;
			color: #999999;
			position: relative;

			background-size: 2.25rem;
			background-repeat: no-repeat;
			/* background-color: red; */
			background-position: top center;

			&::after {
				width: 2.8125rem;
				height: 0;
				position: absolute;
				top: 1.25rem;
				left: 0;
			}
		}
		.weixin {
			background-image: url(../static/image/weixin.png);
			&::after {
				content: '微信登录';
			}
		}
		.qq {
			background-image: url(../static/image/QQ.png);
			&::after {
				content: 'QQ登录';
			}
		}
		.weibo {
			background-image: url(../static/image/weibo.png);
			&::after {
				content: '微博登录';
			}
		}
	}
}
</style>
