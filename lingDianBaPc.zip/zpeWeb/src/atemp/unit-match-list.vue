<template>
	<!-- 相关录像 -->
	<div class="types">
		<div class="headTag">
			<div>{{ eventTypeName }}录像</div>
			<span @click="navToLx">更多 >></span>
		</div>
		<div class="newsItem" v-if="lxList.length > 0">
			<li v-for="(item, index) in lxList" :key="index" @click="navTo(item)">
				<p class="title">{{ item | getCombinationTitle }}</p>
				<p class="time">{{ item.matchBeginTime | getInterceptTime }}</p>
			</li>
		</div>
		<!-- 无数据 -->
		<nodata v-else :height="'270px'" :fontSize="'1rem'"></nodata>
	</div>
</template>

<script>
let that;
export default {
	name: 'unit-match-list',
	props: {
		// 数据列表
		lxList: {
			type: Array,
			// type: Object,
			default: function() {
				return [];
			}
		},
		// 赛事类型名称
		eventTypeName: {
			type: String,
			default: '相关'
		}
	},
	data() {
		return {};
	},
	created: function() {
		that = this;
		that.tabIndex = that.$store.state.routurl;
		that.routerUrl = that.$route.path;
	},
	methods: {
		navTo(item) {
			this.BR.navTo('/liveRoom', {
				matchId: item.matchId,
				activeName: 'lx',
				isLx: 'islx'
			});
		},
		navToLx() {
			this.BR.navTo('/lx-video', {
				hid: 2
			});
		}
	},
	filters: {
		// 获取组合标题
		getCombinationTitle: function(item) {
			let date, title, topLine, bottomLine;
			// 日期
			/* let time = item.matchBeginTime.trim().split(/\s+|:|-/g);
				date = time[1] + '-' + time[2]; */
			if (item.homeTeamName != '' && item.homeTeamName != null && item.guestTeamName != '' && item.guestTeamName != null) {
				// 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题
				if (item.eventTypeName == '' || item.eventTypeName == null) {
					title = item.specialName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle;
				} else if (item.eventTypeName == '其他') {
					title = item.eventName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle;
				} else {
					title = item.eventTypeName + item.matchTitle;
				}
				
				bottomLine = item.homeTeamName + ' - ' + item.guestTeamName;
			} else {
				title = item.eventTypeName == '' || item.eventTypeName == null ? item.specialName : item.eventTypeName == '其他' ? item.eventName : item.eventTypeName;
			
				bottomLine = title + ' ' + item.matchTitle;
			}
			// js空格符：'\xa0'
			// return topLine + bottomLine
			return bottomLine;
		},

		// 截取指定时间(MM - DD)
		getInterceptTime: function(times) {
			if (typeof times == 'string') {
				let time = times.trim().split(/\s+|:|-/g);
				return time[1] + '月' + time[2] + '日';
				// return time[1] + '-' + time[2];
			} else {
				return times;
			}
		}
	}
};
</script>

<style lang="scss" scoped>
.types {
	width: 318px;
	height: auto;
	overflow: hidden;
	margin-bottom: 24px;
	color: #666666;
	cursor: default;

	li,
	span {
		&:hover {
			color: #ff5337 !important;
		}
	}

	.headTag {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 100%;
		height: 2.25rem;
		box-sizing: border-box;
		border-bottom: 0.125rem solid #1b1b30;

		div {
			width: auto;
			height: 34px;
			line-height: 34px;
			font-size: 16px;
			font-weight: bold;
			color: #1b1b30;
		}
		div:before {
			content: '';
			background: #f5f5f5 url(../static/main/lx.png) no-repeat;
			background-size: cover;
			/* 25px * 20px */
			width: 1.5625rem;
			height: 1.25rem;
			display: inline-block;
			margin-right: 12px;
			vertical-align: middle;
			margin-top: -4px;
		}

		span {
			font-size: 12px;
			color: #666666;
			cursor: pointer;

			/* &::after {
					content: '';
					background-image: url(../static/main/more.png);
					background-size: cover;
					background-repeat: no-repeat;
					width: 12px;
					height: 12px;
					display: inline-block;
					vertical-align: middle;
					margin: -4px 6px 0 4px;
				} */
		}
	}

	.newsItem {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding: 12px 10px;
		background-color: #ffffff;
		font-size: 14px;
		text-align: left;

		li,
		p,
		span {
			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space: nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
		}

		.title {
			flex: 1;
		}
		.time {
			min-width: 72px;
			text-align: right;
		}

		li {
			display: flex;
			align-items: center;
			line-height: 28px;
			cursor: pointer;
		}

		li:before {
			content: '';
			min-width: 4px;
			height: 4px;
			border-radius: 50%;
			background: #666666;
			display: inline-block;
			margin-right: 10px;
			vertical-align: middle;
			// margin-top: -3px;
		}
	}

	/* 无数据 */
	/* .noMore {
			width: 100%;
			height: 12.5rem;
			line-height: 12.5rem;
			background-color: #FFFFFF;
		} */
}
</style>
