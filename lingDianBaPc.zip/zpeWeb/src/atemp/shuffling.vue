<template>
	<div class="Imgroll">
		<!-- height="22.875rem" -->
		<el-carousel type="point">
			<el-carousel-item v-for="(item, index) in spList" :key="index">
				<div class="ban-div">
					<!-- <img class="ban-divImg h100" ref='img' :src="item.imgHref" @click="navTo(item)"/>
						 <img class="ban-divImg h100" ref='img' :src="item.originalLog" @click="navTo(item)"/> -->
					<img
						class="ban-divImg h100"
						ref="img"
						@error="errorImg($event, defaultImg)"
						:src="item.originalLog ? item.originalLog : require('../static/image/default_img.png')"
						@click="navTo(item)"
					/>
					<div class="ban-span text-l">
						<div class="ban-text more-hidden1">{{ item.liveTitle }}</div>
					</div>
				</div>
			</el-carousel-item>
		</el-carousel>
	</div>
</template>

<script>
export default {
	name: 'shuffling',
	props: {
		dataimg: Array,
		listStyle: {
			//样式
			type: String,
			default: ''
		}
	},
	data() {
		return {
			spList: [],
			defaultImg: require('../static/image/default_img.png') // 默认图片
		};
	},
	created() {
		this.queryLiveTitle();
	},
	methods: {
		queryLiveTitle: function() {
			let datas = {
				id:'',
				limit: 5,
				offset: 1,
				type: 5,
				"livePlatform": 0,
			};
			this.$reqc.queryLiveTitle(datas).then(res => {
				this.spList = res.data.data.list;
			});
		},
		navTo(item) {
			this.BR.navTo('/spDetail', {
				hid: 3,
				vid: item.id,
				tagObj: JSON.stringify({
					id: '',
					type: 5,
					name: '相关'
				})
			});
		}
	}
};
</script>

<style lang="scss">
.Imgroll {
	height: 100%;
	margin-left: 0.9375rem;
}
.ban-div {
	width: 100%;
	height: 100%;
	position: relative;
	background-color: $bg-main;
}
.el-carousel__button {
	width: 0.5rem !important;
	height: 0.5rem !important;
}
.ban-divImg {
}
.ban-div .ban-span {
	width: 100%;
	height: 2.5rem;
	background: rgba(0, 0, 0, 0.3);
	position: absolute;
	left: 0;
	bottom: 0;
}
.ban-text {
	width: 70%;
	font-size: 1rem;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
	/* background:rgba(0,0,0,.3); */
	line-height: 2.5;

	padding-left: 1.25rem;
	display: flex;
	justify-content: flex-start;
	align-items: center;
}
.el-carousel,
.el-carousel__container {
	height: 100%;
}

.el-carousel__button {
	display: block;
	opacity: 0.48;
	width: 0.625rem;
	height: 0.625rem;
	border-radius: 50%;
	background-color: #fff;
	border: none;
	outline: 0;
	padding: 0;
	margin: 0;
	cursor: pointer;
	transition: 0.3s;
}
.el-carousel__indicators--horizontal {
	bottom: 0;
	left: auto;
	right: 0 !important;
	transform: translateX(-50%);
	/* padding: 0px 4px !important; */
}
</style>
