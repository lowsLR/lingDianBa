/**
 * 新闻模块接口列表
 */

import axios from '../http';
import base from './base'; // 导入接口域名列表

const $newsReq = {
	// //查询新闻标题列表
	queryNewsTitle(data) {
		return axios.post(`${base.bd}/web/news/queryNewsTitle`, data);
	},
	//查询新闻内容
	queryNewsContent(data) {
		return axios.get(`${base.bd}/web/news/queryNewsContent?newsId=${data.newsId}`, data);
	},
	// 查询导航配置列表
	queryNavigationList(data) {
		return axios.post(`${base.bd}/app/matchs/queryNavigationList`, data);
	},
	// 查询电视台信息
	queryTvInfo(data) {
		return axios.post(`${base.bd}/web/tv/queryTvInfo`, data);
	},
	// 查询电视台类容信息
	queryTvConten(data) {
		return axios.post(`${base.bd}/web/tv/queryTvConten`, data);
	},
	// 查询省区
	queryTvProvincen() {
		return axios.get(`${base.bd}/web/tv/queryTvProvince`);
	},
	// 查询分类
	queryTvType(data) {
		return axios.get(`${base.bd}/web/tv/queryTvType`, data);
	},
	// 综合搜索
	searchAll(data) {
		return axios.post(`${base.bd}/web/search/searchAll`, data);
	},
	// 解析电视台播放地址
	analysisTv(data) {
		return axios.post(`${base.bd}/web/tv/analysisTv`, data);
	},
	// 搜索有录像的赛事
	searchMatchListByVideo(data) {
		return axios.post(`${base.bd}/web/search/searchMatchListByVideo`, data);
	},
	//模糊查询电视台
	queryLikeTvName(data) {
		return axios.post(`${base.bd}/web/tv/queryLikeTvName`, data);
	},
	// 解析直播源和录像
	analysisMatchLiveSource(data) {
		return axios.post(`${base.bd}/web/index/analysisMatchLiveSource`, data);
	},
	//录像接口
	queryMatchByVideo(data) {
		return axios.post(`${base.bd}/web/index/queryMatchByVideo`, data);
	},
	//根据赛事类型查询相关球队
	queryTeamByEvent(data) {
		return axios.post(`${base.bd}/web/match/queryTeamByEvent`, data);
	},
	//新闻接口
	queryAdvertisement(data) {
		return axios.post(`${base.bd}/web/advertisement/queryAdvertisement`, data);
	},
	// 创建反馈内容
	createFeedback(data) {
		return axios.post(`${base.bd}/web/feedback/createFeedback`, data);
	},
	//web开关配置信息-聊天室
	switchInfo(data) {
		return axios.post(`${base.bd}/web/switch/info`);
	},
	//底部信息
	webFootInfo(data) {
		return axios.post(`${base.bd}/web/index/webFootInfo`);
	},
	//下载apk
	queryDownloadInfo(data) {
		return axios.post(`${base.bd}/web/user/info/queryDownloadInfo`);
	},
}

export default $newsReq;
