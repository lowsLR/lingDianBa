/**
 * req模块接口列表
 */
import axios from '../http';
import base from './base'; // 导入接口域名列表

const req = {    
	//获取验证码
	codeOne(data){
		return axios.post(`${base.bd}/auth/codeOne`,data);
	},
	//登录
	login(data){
		return axios.post(`${base.bd}/auth/login`,data);  
	},
	//注册
	regist(data){
		return axios.post(`${base.bd}/auth/regist`,data);  
	},
	
	//查询友情链接
	friendlyLinkList(data){
		return axios.post(`${base.bd}/web/index/friendlyLinkList`,data);  
	},
	
	//根据key查询配置数据
	queryConfigByKey(data){
		return axios.post(`${base.bd}/web/index/queryConfigByKey`,data);  
	},
	
	//查询所有赛事
	queryAllMatchList(data){
		return axios.post(`${base.bd}/web/index/queryAllMatchList`,data);  
	},
	
	//搜索赛事
	searchMatch(data){
		return axios.post(`${base.bd}/web/search/searchMatch`,data);  
	},
	//搜索视频
	searchLiveTitle(data){
		return axios.post(`${base.bd}/web/search/searchLiveTitle`,data);  
	},
	//搜索有录像的赛事
	searchMatchListByVideo(data){
		return axios.post(`${base.bd}/web/search/searchMatchListByVideo`,data);  
	},
	//搜索新闻列表
	searchNewsTitle(data){
		return axios.post(`${base.bd}/web/search/searchNewsTitle`,data);  
	},
	//模糊查询电视台
	queryLikeTvName(data){
		return axios.post(`${base.bd}/web/search/queryLikeTvName`,data);  
	},
	
	//查询单个赛事
	queryMatchById(data){
		return axios.post(`${base.bd}/web/index/queryMatchById`,data);  
	},
	
	//查询新闻标题列表
	queryNewsTitle(data){
		return axios.post(`${base.bd}/app/match/news/queryNewsTitle`,data);  
	},
	
	//查询录像数据
	queryMatchByVideo(data){
		return axios.post(`${base.bd}/web/index/queryMatchByVideo`,data);  
	},
	
	//解析直播源
	analysisMatchLiveSource(data){
		return axios.post(`${base.bd}/web/index/analysisMatchLiveSource`,data);  
	},
	
	//查询nba、cba
	queryBasketball(data){
		return axios.post(`${base.bd}/web/ranking/queryBasketball`,data);  
	},
	
	//查世界排名变化
	queryFIFA(data){
		return axios.post(`${base.bd}/web/ranking/queryFIFA`,data);  
	},
	
	//查询积分排名变化
	queryIntegral(data){
		return axios.post(`${base.bd}/web/ranking/queryIntegral`,data);  
	},
	
	//获取进入聊天室信息
	addChatRoom(data){
		return axios.post(`${base.bd}/web/chatRoom/addChatRoom`,data);  
	},
	
	//获取历史消息
	getHistory(data){
		//?count=${data.count}&stanzaId=${data.stanzaId}
		return axios.get(`${data.url}`,data);  
	},
	
	//查询项目/赛事类型/专题/球队简介
	queryIntroduce(data){
		//?count=${data.count}&stanzaId=${data.stanzaId}
		return axios.post(`${base.bd}/web/match/queryIntroduce`,data);  
	},
	
	//天下功夫 赛事分类为搏击有录像的比赛 只显示标题
	tianxiagongfu(data){
		return axios.post(`${base.bd}/web/index/tianxiagongfu`,data);  
	},
	
	//专家看球 项目为节目的有录像的比赛
	zhuanjiakanqiu(data){
		return axios.post(`${base.bd}/web/index/zhuanjiakanqiu`,data);  
	},
	
	//查询新闻内容
	queryNewsContent(data) {
		return axios.get(`${base.bd}/web/news/queryNewsContent?newsId=${data.newsId}`, data);
	},
}

export default req;