// @author
/**
 * 接口域名的管理
 */
const base = {
	bd: 'http://8.129.19.0:8087',
}
export default base;
