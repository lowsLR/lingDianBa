/**
 * reqc模块接口列表
 */
import axios from '../http';
import base from './base'; // 导入接口域名列表

const reqc = {
	/**
	 * 用户登陆
	 */
	login(data) {
		// return axios.post(`${base.bd}/app/login/userAccount/login`, data);
		return axios.post(`${base.bd}/web/login/userAccount/login`, data);
	},


	// 获取图片验证码
	getVerify(data) {
		return axios.get(`${base.bd}/web/login/userAccount/getVerify`);
	},

	// 查询录像数据
	queryMatchByVideo(data) {
		return axios.request({
			url: `${base.bd}/web/index/queryMatchByVideo`,
			method: 'post',
			data: data
		})
	},

	// 查询视频列表
	queryLiveTitle(data) {
		return axios.request({
			// url: `${base.bd}/app/match/Live/queryLiveTitle`,
			url: `${base.bd}/web/live/queryLiveTitle`,
			method: 'post',
			data: data
		})
	},

	// 查询视频内容
	queryLiveContent(data) {
		// return axios.get(`${base.bd}/app/match/Live/queryLiveContent?liveId=${data.vid}`, data);
		return axios.request({
			// url: `${base.bd}/app/match/Live/queryLiveContent?liveId=${data.liveId}`,
			url: `${base.bd}/web/live/queryLiveContent`,
			method: 'post',
			data: data
		})
	},

	// 查询新闻列表
	queryNewsTitle(data) {
		return axios.request({
			// url: `${base.bd}/app/match/news/queryNewsTitle`,
			url: `${base.bd}/web/news/queryNewsTitle`,
			method: 'post',
			data: data
		})
	},

	// pc首页查询录像
	webQueryMatchListByVideo(data) {
		return axios.request({
			url: `${base.bd}/web/index/webQueryMatchListByVideo`,
			method: 'post',
			data: data
		})
	},



	/**
	 *  web积分排行接口
	 */
	// (数据页) 查询nba、cba
	queryBasketball(data) {
		return axios.post(`${base.bd}/web/ranking/queryBasketball`, data);
	},
	// (数据页) 查询世界排名变化
	queryFIFA(data) {
		return axios.post(`${base.bd}/web/ranking/queryFIFA`, data);
	},
	// (数据页) 查询积分排名变化
	queryIntegral(data) {
		return axios.post(`${base.bd}/web/ranking/queryIntegral`, data);
	},


	/**
	 * 评论
	 */
	/**
	 * 创建评论一级列表
	 * @param {string}	commentContent (评论内容)
	 * @param {number}	id (新闻id/视频id/赛事id)
	 * @param {string}	matchType (评论类型 1新闻 2视频 3赛事)
	 */
	createMainComment(data) {
		return axios.post(`${base.bd}/web/publish/comment/createMainComment`, data);
	},
	/**
	 * 创建评论二级列表
	 * @param {string}	commentContent (评论内容)
	 * @param {number}	mainCommentId (一级评论表id)
	 * @param {string}	matchType (评论类型 1新闻 2视频 3赛事)
	 */
	createCommentChi(data) {
		return axios.post(`${base.bd}/web/publish/comment/createCommentChi`, data);
	},
	// 查询评论一级列表
	queryMainComment(data) {
		return axios.post(`${base.bd}/web/match/comment/queryMainComment`, data);
	},
	// 查询评论二级列表
	queryCommentChild(data) {
		return axios.post(`${base.bd}/web/match/comment/queryCommentChild`, data);
	},

}

export default reqc;
