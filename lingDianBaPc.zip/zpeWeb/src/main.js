import Vue from 'vue'
import App from './App.vue'

import axios from 'axios'
import VueAxios from 'vue-axios'
Vue.use(VueAxios, axios)

import VueQriously from 'vue-qriously'
Vue.use(VueQriously)

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import '@/static/css/global.css'
// import "@/static/css/color.scss"; 
Vue.use(ElementUI);
import '@/static/css/bw.css'
// 解决 'Passive Event Listeners' 提示
import 'default-passive-events';
/*vueVideoPlayer配置*/
// import VueVideoPlayer from 'vue-video-player'
// import 'video.js/dist/video-js.css'
// import 'vue-video-player/src/custom-theme.css'
// import 'videojs-flash'
// Vue.use(VueVideoPlayer);
// import hls from 'videojs-contrib-hls'
// Vue.use(hls)
// import './plugins/video';// 引入视频播放插件 
import '@/plugins/video'; // 引入视频播放插件 


/*面包屑*/
import crumbs from '@/atemp/crumbs.vue';
Vue.component('crumbs', crumbs);

/*暂无数据*/
import nodata from '@/components/bw-nodate.vue';
Vue.component('nodata', nodata);

/*测试用的假数据*/
import {
	test1,
	testteam,
	testlx,
	testfive,
	List10,
	newsList,
	explain
} from './views/testdata.js'
Vue.prototype.test1 = test1;
Vue.prototype.testteam = testteam;
Vue.prototype.testlx = testlx;
Vue.prototype.testfive = testfive;
Vue.prototype.List10 = List10;
Vue.prototype.newsList = newsList;
Vue.prototype.explain = explain; // 数据页说明数据
Vue.prototype.livePlatform = '0';

Vue.prototype.errorImg = function(e, u) {
	// console.log("监听img错误:",e)
	// e.currentTarget.src = require(u);
	if (u) {
		e.currentTarget.src = u;
	}
};

import router from './router'; //路由
import store from './store' //vuex

Vue.config.productionTip = false

import params from './params.js'
Vue.prototype.$params = params;
import BW from './utils/bw/bw-util.js'
Vue.prototype.BW = BW;
import BR from './utils/bw/bw-resolve.js'
Vue.prototype.BR = BR;

import req from './request/api/req.js'; //接口
Vue.prototype.$req = req;

import reqc from './request/api/reqc.js'; //接口
Vue.prototype.$reqc = reqc;

import newsReq from './request/api/news_req.js'; //新闻接口
Vue.prototype.$newsReq = newsReq;


Vue.prototype.navTo = function(url, data) {
	router.push({
		path: url,
		params: data
	})
}



/**
 *		→ 接口、组件 与 公共函数文件 ←
 */

// 引入lodash工具函数库(https://www.html.cn/doc/lodash/)，安装：`npm i lodash -S`
import lodash from 'lodash';
Vue.prototype.$_ = lodash;

import utils from './utils/special/common.js';
Vue.prototype.$utils = utils;

/* 本地存储	调用：this.$ls.xxx() */
import ls from './utils/special/localstorage.js';
Vue.prototype.$ls = ls;

/* 登录Dialog */
import loginDialog from '@/atemp/loginDialog.vue';
Vue.component('loginDialog', loginDialog);

/* 注册全局事件对象 */
import bus from '@/utils/special/bus.js';
Vue.prototype.eventBus = bus;

/* 引入广告位组件 */
import AdSlot from '@/atemp/ad-slot.vue';
Vue.component('AdSlot', AdSlot);

// END

//广告位置
import advertisingSpace from '@/atemp/advertising-space.vue';
Vue.component('advertisingSpace', advertisingSpace);

new Vue({
	store,
	router,
	render: h => h(App),
}).$mount('#app')
