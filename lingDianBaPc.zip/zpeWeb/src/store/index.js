import Vue from 'vue'
import Vuex from 'vuex'

//引入之后，对vuex进行引用
Vue.use(Vuex);

const routurl = sessionStorage.getItem('routurl') ? JSON.parse(sessionStorage.getItem('routurl')) : 1

const saveState = sessionStorage.getItem('store') ? JSON.parse(sessionStorage.getItem('store')) : {
	accToken: '', //接口token
	routurl: 1,
	navid: 0,
	currentRoute: {
		hid: 1,
		sid: 0,
		htitle: '首页',
		stitle: '所有赛事'
	},
	uname: '零点八直播',
	
}

export default new Vuex.Store({
	state: {
		saveState: saveState,
		newsTar: {},
		
		
		forcedLogin: false, // 是否需要强制登录
		hasLogin: false,	// 是否已登录(登录状态)
		/**
		 * 用户信息（属性）
		 * userId			用户id
		 * nickName			昵称
		 * imageUrl			用户头像
		 * invitationCode	邀请码
		 * token			token
		 */
		userInfo: {},
		
		isShowFriendLink: false, // 是否显示友情链接
	},
	// state: saveState,
	mutations: {
		setFriendLink(state, val) {
			state.isShowFriendLink = val
		},
		setAccToken(state, val) {
			state.saveState.accToken = val || ''
		},
		setRouturl(state, val) {
			state.saveState.routurl = val || 0
		},
		setNavid(state, val) {
			state.saveState.navid = val || 0
		},
		setCurrentRoute(state, val) {
			state.saveState.currentRoute = val;
		},
		
		
		
		/**
		 * --提交（opt：更新的数据）
		 * this.$store.commit('changeLoginStatus', opt);
		 * --更新 修改state数据
		 * changeLoginStatus: (state, msg) => {state.loginStatus = msg},
		 * --获取 state数据
		 * console.log(this.$store.state.loginStatus)
		 */
		// 登录
		/**
		 * 登录处理逻辑，与登录模态框调用 参考文件：header.vue、loginDialog.vue、leave-message.vue
		 */
		login(state, msg) {
			state.userInfo = msg;
			state.hasLogin = true;
		},
		// 退出登录
		logout(state) {
			state.userInfo = {};
			state.hasLogin = false;
		}
		
		// END
		
	}
});
