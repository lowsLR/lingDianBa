<template>
	<div class="content">
	    <div class="mainView">
			首页
		</div>
	</div>
</template>

<script>
	export default {
	  name: 'z-mian', 
	}
</script>

<style>
	/* @import "../static/css/55-59.css"; */
	/* @import "../static/css/app-2.css"; */
	.mainView{
		width: 100%;
		min-height: 32em;
	}
</style>
