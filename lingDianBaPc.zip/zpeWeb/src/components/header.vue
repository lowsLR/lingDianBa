<template>
	<div class="header">
		<div class="mh">
			<div class="mw header-top">
				<a href="" class="logo"></a>
				<ul class="menu">
					<router-link v-for="(item, index) in hlist" :key="item.title + item.index" :to="{ path: item.url, query: { hid: item.id } }">
						<li class="menuNav" :class="[tabIndex == item.id ? 'active-li' : '']" c="c0">{{ item.title }}</li>
					</router-link>
				</ul>

				<!-- 用户信息 -->
				<!-- trigger="hover" -->
				<el-popover v-if="hasLogin" placement="bottom" width="300" trigger="click" v-model="popoverVisible">
					<div class="popoverBox">
						<div class="info">
							<img
								:src="userInfo.imageUrl ? 'https://images.weserv.nl/?url=' + userInfo.imageUrl : require('../static/image/nodata/user_default.png')"
								class="userHead"
								mode="aspectFill"
								alt=""
							/>
							<div class="right">
								<!-- 显示的昵称 -->
								<div class="userName" v-if="!modal6">
									<div class="nickName">{{ userInfo.nickName || '新用户' }}</div>
									<div class="modify" @click="modal6 = !modal6"></div>
								</div>
								<!-- 修改昵称输入框 -->
								<div class="modifyInput" v-if="modal6">
									<el-input type="text" @input="_input" :value="userName" placeholder="输入昵称" maxlength="12"></el-input>
									<el-button-group>
										<el-button @click="modifyUserName" type="success" icon="el-icon-check"></el-button>
										<el-button
											@click="
												modal6 = !modal6;
												userName = '';
											"
											type="danger"
											icon="el-icon-close"
										></el-button>
									</el-button-group>
								</div>
								<div>当前积分：{{ userInfo.userIntegral }}</div>
							</div>
						</div>
						<div class="handleBtn">
							<el-button plain @click.stop="bindLogout">退出登录</el-button>
							<el-button
								plain
								@click="
									dialogState = true;
									formType = 3;
								"
							>
								修改密码
							</el-button>
						</div>
					</div>

					<!-- 触发模块 (使用 require 引入图片) -->
					<!-- xxx != null && xxx != '' ? xxx : xxx -->
					<div slot="reference" class="triggerBox">
						<img
							:src="userInfo.imageUrl ? 'https://images.weserv.nl/?url=' + userInfo.imageUrl : require('../static/image/nodata/user_default.png')"
							class="userHead"
							mode="aspectFill"
							alt=""
						/>
						<div class="nickName">{{ userInfo.nickName ? userInfo.nickName : '新用户' }}</div>
					</div>
				</el-popover>

				<!-- 登录注册入口 -->
				<div class="loginBox" v-if="!hasLogin">
					<span
						@click="
							dialogState = true;
							formType = 1;
						"
					>
						登录
					</span>
					<span
						@click="
							dialogState = true;
							formType = 2;
						"
					>
						注册
					</span>
				</div>

				<div class="app poinbut" @click="toDown">APP下载</div>
			</div>
		</div>

		<!-- 登录、注册、重置密码 模态框 -->
		<login-dialog :dialogFormVisible.sync="dialogState" :formType.sync="formType"></login-dialog>

		<div class="sh navDiv-view" v-if="nlist.length">
			<div class="mwTag">
				<div class="header-nav-view c0 cur">
					<div
						v-for="(items, indexs) in nlist"
						v-if="indexs <= 12"
						:key="items.SN"
						class="nav-view-item pointer"
						:class="[itemSN == items.SN ? 'is-item-acvtion' : '']"
						@click="toNavPath(items)"
					>
						{{ items.name }}
					</div>
					<div class="unfold" v-if="zlist.length" @click="tagExpand">{{ iszk ? '收起' : '展开' }}</div>
				</div>
				<div v-if="zlist.length" class="zk-view" :class="[iszk ? 'iszkDivShow' : 'iszkDivHide']">
					<div class="zk-view-div">
						<div
							v-for="(items, indexs) in zlist"
							:key="items.SN + indexs"
							class="zview-item pointer"
							:class="[itemSN == items.SN ? 'is-item-acvtion' : '']"
							@click="toNavPath(items)"
						>
							{{ items.name }}
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
let that;
import { mapState, mapMutations } from 'vuex';
import { updateUserName } from '@/utils/special/user.js';
export default {
	name: 'z-hader',
	computed: {
		...mapState(['hasLogin', 'forcedLogin', 'userInfo'])
	},
	data() {
		return {
			screenWidth: document.body.clientWidth, // 屏幕宽
			offsetNum: 0, //偏移位置
			screeHeight: document.body.clientHeight, // 屏幕高
			dialogState: false, // 登录模态框可见状态
			formType: 1, // 模态框显示 表单类型 1：登录，2：注册，3：重置密码
			popoverVisible: false, // Popover弹出框 可见状态

			modal6: false, // 是否修改昵称
			userName: '', //用户名

			iszk: false,
			tabIndex: 1,
			id: 0,
			itemSN: '1',
			routerUrl: '',
			nlist: [],
			zlist: [],
			hlist: [
				{
					id: 1,
					title: '首页',
					url: '/main'
				},
				{
					id: 2,
					title: '录像',
					url: '/lx-video'
				},
				{
					id: 3,
					title: '视频',
					url: '/sp-video'
				},
				{
					id: 4,
					title: '电视',
					url: '/tv'
				},
				{
					id: 5,
					title: '新闻',
					url: '/news'
				},
				{
					id: 6,
					title: '数据',
					url: '/datas'
				}
				// {
				// 	id:7,
				// 	title:'下载',
				// 	url:'/download',
				// }
			]
		};
	},
	watch: {
		$route: {
			handler() {
				let rout = that.$route;
				let sid = rout.query.sid || 2,
					hid = rout.query.hid || 1,
					st = '';
				if (sid != 1) {
					// st = (that.zlist.length && that.zlist[that.zlist.findIndex(item => item.SN == sid)].title) || '';
				}
				let current = {
					hid: hid,
					sid: sid,
					htitle: that.hlist[hid - 1].title,
					stitle: st || ''
				};
				this.$store.commit('setCurrentRoute', current);
				that.id = sid;
				that.itemSN = sid;
				that.routerUrl = rout.fullPath;
				if (that.tabIndex == hid) {
					return;
				}
				that.tabIndex = hid;
				if (that.tabIndex < 7) {
					that.getQueryConfigByKey(~~(that.tabIndex - 1));
				}
			},
			deep: true
		}
	},
	created: function() {
		that = this;
		let current = that.$store.state.saveState.currentRoute;
		let query = that.$route.query;
		current = query.hid ? query : current;
		that.tabIndex = current.hid;
		that.id = current.sid;
		that.routerUrl = that.$route.path;
		if (that.screenWidth > 1400) {
			that.offsetNum = that.screenWidth - 1400;
		}

		/* 全局事件监听 - 打开登录模态框 */
		this.eventBus.$on('openLoginDialog', res => {
			that.dialogState = res.dialogState;
			that.formType = res.formType;
		});

		if (query && query.hid == 7) {
			that.tabIndex = query.hid;
			return;
		}
		that.getQueryConfigByKey(~~(that.tabIndex - 1));
	},
	methods: {
		...mapMutations(['login', 'logout']),

		// 退出登录
		bindLogout: function() {
			// 清除本地存储
			this.$ls.remove('userInfo');
			this.$ls.remove('token');

			// 更新Vuex数据（登录状态、用户数据）
			this.logout();

			// 隐藏popover弹出框
			this.popoverVisible = false;
		},

		/*跳转下载页*/
		toDown() {
			let routeUrl = this.$router.resolve({
				path: '/download',
				query: { hid: 7 }
			});
			window.open(routeUrl.href, '_blank');
		},

		/* 点击展开标签 */
		tagExpand: function() {
			that.iszk = !that.iszk;
		},

		//根据key查询配置数据
		getQueryConfigByKey(index) {
			if (index == 5) {
				that.nlist = [];
				that.zlist = [];
				return;
			}
			if (index == 3) {
				that.nlist = [];
				that.zlist = [];

				that.$newsReq.queryTvType().then(res => {
					if (res.status == 200 && res.data.resultCode == 1) {
						let resdata = res.data.data || [];
						if (resdata.length) {
							resdata.forEach(item => {
								item['SN'] = item.sn;
								item['name'] = item.typeName;
							});
						}
						resdata.unshift({
							id: '',
							name: '地区电视台',
							SN: '2',
							typeName: '地区电视台'
						});
						if (resdata.length > 13) {
							that.nlist = resdata.slice(0, 13);
							that.zlist = resdata.slice(13, resdata.length - 1);
						} else {
							that.nlist = resdata;
							that.zlist = [];
						}
						// that.nlist = resdata;
					}
				});
				return;
			}

			that.$req
				.queryConfigByKey({
					configKey: that.$params.configKey[index]
				})
				.then(res => {
					if (res.status == 200 && res.data.resultCode == 1) {
						let list = [];
						if (that.hid == 6) {
							let arr = res.data.data.list;
							arr.forEach((item, index) => {
								let ob = {
									SN: '',
									id: '',
									name: '',
									sort: 1,
									type: 2
								};
							});
							return;
						} else {
							let arr = res.data.data || [];
							let ob = {
								SN: '2',
								id: '',
								name: '',
								sort: 1,
								type: 5
							};
							switch (index) {
								case 1:
								case 2:
								case 4:
									ob.name = '全部';
									break;
								default:
									break;
							}
							if (index != 0) {
								arr.unshift(ob);
							}
							list = arr;
						}
						that.nlist = list;
						if (list.length > 13) {
							that.nlist = list.slice(0, 13);
							that.zlist = list.slice(13, list.length - 1);
						} else {
							that.nlist = list;
							that.zlist = [];
						}
					} else {
						that.nlist = [];
						that.zlist = [];
					}
				});
		},

		zhankai() {
			that.iszk = !that.iszk;
		},
		navTo(url, data) {
			if (that.routerUrl == url && that.id == undefined) {
				return;
			}
			that.$router.push({
				path: url,
				params: data,
				query: data
			});
		},
		toNavPath(item) {
			// let hitem = that.hlist[that.hlist.findIndex(item => item.id == that.tabIndex)]
			if (that.itemSN == item.SN) {
				return;
			}
			let sid = that.itemSN;
			if (that.tabIndex == 1) {
				if (sid == 0) {
					this.$router.push({
						path: '/main',
						query: {
							hid: that.tabIndex,
							sid: item.SN,
							title: item.title,
							data: JSON.stringify(item)
						}
					});
				} else {
					/**/
					this.$router.push({
						path: '/navPage',
						query: {
							hid: that.tabIndex,
							sid: item.SN,
							title: item.title,
							data: JSON.stringify(item)
						}
					});
				}
			} else {
				let query = {
					hid: that.tabIndex,
					sid: item.SN,
					title: item.title,
					data: JSON.stringify(item)
				};
				// that.itemSN = item.SN;
				this.$router.push({
					path: this.BW.pageJson[that.tabIndex].url,
					query: query
				});
			}
		},
		toPath(item) {
			// let query = Object.assign({id: id}, this.$route.query )
			// this.$router.push({ query})
			let sid = item.id;
			that.itemSN = item.SN;
			switch (that.tabIndex) {
				case 1:
					if (sid == 0) {
						this.$router.push({
							path: '/main',
							query: {
								hid: that.tabIndex,
								sid: sid,
								title: item.title
							}
						});
					} else {
						if (that.id != sid) {
							this.$router.push({
								path: '/navPage',
								query: {
									hid: that.tabIndex,
									sid: sid,
									title: item.title
								}
							});
						} else {
							return;
							let query = {
								hid: that.tabIndex,
								sid: sid,
								title: item.title
							};
							this.$router.push({
								query
							});
						}
					}

					break;
				case 2:
					if (that.id != sid) {
						that.id = sid;
						let query = {
							hid: that.tabIndex,
							sid: sid,
							stitle: item
						};
						this.$router.push({
							query: query
						});
					}
					break;
				case 3:
					if (that.id != sid) {
						that.id = sid;
						let query = {
							hid: that.tabIndex,
							sid: sid,
							stitle: item.title
						};
						this.$router.push({
							path: '/lx-video',
							query: query
						});
					}
					break;
				case 4:
					if (that.id != sid) {
						that.id = sid;
						let query = {
							hid: that.tabIndex,
							sid: sid,
							stitle: item.title
						};
						this.$router.push({
							path: '/sp-video',
							query: query
						});
					}
					break;

				case 5:
					if (that.id != sid) {
						that.id = sid;
						let query = {
							hid: that.tabIndex,
							sid: sid,
							stitle: item.title
						};
						this.$router.push({
							path: '/news',
							query: query
						});
					}
					break;
				case 6:
					if (that.id != sid) {
						that.id = sid;
						let query = {
							hid: that.tabIndex,
							sid: sid,
							stitle: item.title
						};
						this.$router.push({
							path: '/datas',
							query: query
						});
					}
					break;
				default:
					break;
			}
		},

		// 修改用户名
		async modifyUserName() {
			if (that.userName == '') {
				that.$message.warning('昵称不能为空');
				return;
			}
			let datas = {
				nickName: that.userName
			};
			// 同步处理异步请求
			let res = await updateUserName(datas);
			// 请求状态码为200、接口返回状态码为1，表示登录或注册成功
			if (res.status === 200 && res.data.resultCode === 1) {
				let msg = that.$ls.get('userInfo');
				if (msg) {
					msg.nickName = res.data.data.nickName;
					// 更新本地存储
					that.$ls.set('userInfo', msg);
					// 更新Vuex数据（登录状态、用户数据）
					that.login(msg);

					that.$message.success('昵称修改成功');
				}
			} else {
				that.$message.error(res.data.resultMsg || res.data.msg);
			}
			that.userName = '';
			that.modal6 = false;
		},

		// 用户名输入
		_input(e) {
			this.userName = e;
		}
	}
};
</script>

<style lang="scss" scoped>
// @import "../static/css/55-59.css";
.test {
	text-align: center;
}
.menu {
	height: 4.875rem;
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
}
.menu .menuNav {
	text-align: center;
	// width:7.5rem;
	width: 7.5rem;
	// height: 4.875rem;
	line-height: 4.875rem;

	font-size: 1.125rem;
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
	line-height: 1.75rem;
}

.active-li {
	width: 7.5rem;
	height: 3.625rem;
	background: rgba(255, 255, 255, 1);
	border-radius: 0.625rem;

	font-size: 1.125rem;
	font-weight: 500;
	color: rgba(27, 27, 48, 1) !important;
	line-height: 1.75rem;
	display: flex;
	justify-content: center;
	align-items: center;
}

.pl200 {
	padding-left: 12.5rem;
}

.mw {
	width: 100%;
	text-align: center;
	display: flex;
	justify-content: center;
	position: relative;
}
.mwTag {
	width: 100%;
	height: 3.5rem;
	text-align: center;
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	// background-color: pink;
	position: relative;
}

.header-nav-view {
	width: 87.5rem;
	// background-color: red;
	flex: 1;
	display: flex;
	justify-content: flex-start;
	align-items: center;
	font-size: 0.875rem;
	font-weight: 400;
	color: rgba(27, 27, 48, 1);
	line-height: 1.75rem;
	.nav-view-item {
		width: 6.25rem;
		// border-bottom: 1px solid rgba(255, 83, 55, 0);
		&:hover {
			// border-bottom: 1px solid rgba(255, 83, 55, 1);
		}
	}
}

.mh {
	background-color: $bg-main;
}
.is-item-acvtion {
	color: $bg-chengse;
	// margin-left: 24px;
}

/* 展开 */
.unfold {
	min-width: 5rem;
	cursor: pointer;
	color: #ff5337;
}

/* 个人中心信息 */
.popoverBox {
	.info {
		display: flex;
		align-items: center;
		img {
			min-width: 60px;
			max-width: 60px;
			height: 60px;
			border-radius: 50%;
			border: 1px solid #e6e6e6;
		}
		.right {
			display: flex;
			flex-direction: column;
			justify-content: space-around;
			width: 100%;
			height: 60px;
			margin: 0 0 0 1rem;
			padding: 2px 0;

			.userName {
				width: 100%;
				height: 24px;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.nickName {
					width: calc(100% - 22px);
					line-height: 1.5rem;
					font-size: 1rem;
				}
				.modify {
					width: 18px;
					height: 20px;
					background-size: cover;
					background-image: url(../static/image/modify.png);
				}
			}

			.modifyInput {
				display: flex;
				align-items: center;

				.el-input {
					width: calc(100% - 70px);
					/* 每个半径的四个值的顺序是：左上角，右上角，右下角，左下角 */
					border-radius: 4px 0 0 4px;
					border: 1px solid #67c23a;
					border-right: 0px;
					height: 30px;

					&__inner {
						padding: 0 10px;
					}
				}

				.el-button-group {
					display: flex;

					.el-button {
						width: 35px;
						line-height: 30px;
						padding: 0;
						border: 0;
						font-size: 15px;

						&:first-child {
							border-radius: 0;
						}
					}
				}

				input,
				button {
					// height: 30px;
				}

				input {
					width: auto;
					padding: 0;
					margin: 0;
					padding-left: 10px;
					font-size: 13px;
				}
			}
		}
	}
	.handleBtn {
		display: flex;
		justify-content: space-between;
		border-top: 1px solid #cccccc;
		margin-top: 20px;
		padding-top: 20px;

		.el-button {
			height: 30px;
			padding: 0px 30px;
			border-radius: 25px;
		}
	}
}

.header-top {
	width: 87.5rem;
	position: relative;

	/* 用户信息 */
	.triggerBox {
		display: flex;
		align-items: center;
		position: absolute;
		top: 50%;
		right: 140px;
		transform: translateY(-50%);
		cursor: default;

		img {
			width: 35px;
			height: 35px;
			border-radius: 50%;
			border: 1px solid #e6e6e6;
		}

		.nickName {
			color: #ffffff;
			margin: 0 15px 0 10px;
		}
	}

	/* 登录按钮 */
	.loginBox {
		position: absolute;
		right: 10rem;
		width: 6.25rem;
		height: 1.875rem;
		line-height: 1.875rem;
		border-radius: 0.1875rem;
		color: #ffffff;

		span {
			display: inline-block;
			width: 50%;
			cursor: pointer;
		}
	}

	.app {
		position: absolute;
		right: 0;
		font-size: 0.875rem;
		color: #fff;
		border: solid 0.0625rem #fff;
		border-radius: 1.125rem;
		line-height: 1.875rem;
		padding: 0 1.875rem;
	}

	.logo {
		position: absolute;
		left: 0;
		width: 11.875rem;
		height: 4.25rem;
		line-height: 4.25rem;
		display: inline-block;
		background: url(../static/logo/logo.png) no-repeat center center;
		background-position: 0px;
		background-size: 100% 100%;
	}
}

.navDiv-view {
	position: relative;
	height: 3.5rem;
}

.zk-view {
	position: absolute;
	top: 3.125rem;
	width: 100%;

	/* height: auto;
	min-height: 3.5rem;
	transition: all 0.3s ease-out;
	overflow: hidden; */

	display: flex;
	justify-content: center;
	align-items: flex-start;
	flex-wrap: wrap;
	font-size: 1rem;
	color: #000;
	background-color: $bg-white;
	z-index: 2500;

	.zk-view-div {
		width: 87.5rem;
		display: flex;
		justify-content: flex-start;
		align-items: flex-start;
		flex-wrap: wrap;

		.zview-item {
			width: 6.25rem;
			height: 3.5rem;
			line-height: 3.5rem;
			font-size: 0.875rem;
		}
	}
}

/* 二级分类收起与展开 */
.iszkDivShow {
	max-height: 3.5rem;
	transition: all 0.5s ease;
	overflow-y: auto;

	/* 隐藏滚动条 */
	scrollbar-width: none; /* Firefox */
	-ms-overflow-style: none; /* IE 10+ */
	&::-webkit-scrollbar {
		widht: 0;
	}
	&::-webkit-scrollbar {
		display: none; /* Chrome Safari */
	}
}
.iszkDivHide {
	max-height: 0;
	overflow: hidden;
	transition: all 0.5s ease;
	// opacity: 0;
}

/* 展开下拉框 */
.unfoldBox {
	left: 50% !important;
	transform: translateX(-50%) !important;

	/deep/.popper__arrow {
		border: 0;

		&::after {
			margin-left: -1.5rem;
		}
	}
}
</style>
