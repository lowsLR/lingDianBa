<template>
	<div class="nodataClass" 
	:style="{'width':width,'height':height,'background-color':bgColor,'font-size':fontSize,color:color}">
		{{title}}
	</div>
</template>

<script>
	var _self;
	export default {
	  name: 'bw-nodate',
		props:{
			title:{
				type:String | Number,
				default:'暂无数据'
			},
			width:{
				type:String,
				default:'100%'
			},
			height:{
				type:String,
				default:'auto'
			},
			bgColor:{
				type:String,
				default:'#FFFFFF'
			},
			fontSize:{
				type:String,
				default:'2.125rem'
			},
			color:{
				type:String,
				default:'#666666'
			},
			
		},
		data() {
			return {
				
			}
		},
		created() {
		},
		methods:{
			
		} 
	}
</script>

<style>
	.nodataClass{
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
</style>
