<template>
	<div class="footer">
		<div class="foot-main">
			<div class="flex flex-jc-sa">
				<div class="foot-left" v-if="isShowFriendLink">
					<div class="links">
						<h5 style="padding-bottom: 0.625rem;">友情链接</h5>
						<a v-for="(item, index) in friendlyLinkList" :key="index" :href="'http://' + item.friendlyLinkPath" target="_blank">{{ item.friendlyLinkName }}</a>
					</div>
				</div>
				<div class="foot-right">
					<div class="links">
						<div style="padding-bottom: 0.625rem;">
							<!-- <div style="margin-right: 2.5rem; color: #FFFFFF;font-size: 1.5rem;">
								联系我们
							</div> -->
							<dialog-feedback dialogColor="#fff"></dialog-feedback>
						</div>
						<!-- <h5 style="padding-bottom: 0.625rem;">联系我们</h5> -->
						<div>{{ contact }}</div>
						<div>合作和友情链接请联系 {{ contact }}（权重小于4的勿扰）</div>
					</div>
				</div>
			</div>

			<div class="notice">
				本站所有直播信号和视频录像均由用户收集或从搜索引擎搜索整理获得，如有侵犯您的权益请通知我们，我们会第一时间处理，谢谢！
				<!-- <p><a href="contact.html" ref="nofollow">点此联系我们</a> <a href="sitemap.html">网站地图</a></p> -->
			</div>
			<div class="cp">{{ keepRecord }}</div>
		</div>
	</div>
</template>

<script>
import dialogFeedback from '../a-ellery/dialog-feedback.vue';
import { mapState } from 'vuex';
var _self;
export default {
	name: 'z-footer',
	components: {
		dialogFeedback
	},
	computed: {
		...mapState(['isShowFriendLink'])
	},
	data() {
		return {
			friendlyLinkList: [],
			contact: '', //联系方式
			keepRecord: '', //版权
			statistics: '' //统计代码
		};
	},
	created() {
		_self = this;
		_self.getFriendlyLinkList();
		_self.webFootInfo();
	},
	methods: {
		//底部信息
		webFootInfo() {
			this.$newsReq.webFootInfo().then(res => {
				let resData = res.data.data;
				this.contact = resData.contact;
				this.keepRecord = resData.keepRecord;
				this.statistics = resData.statistics;
				// 创建script标签，引入外部文件
				let script = document.createElement('script');
				script.type = 'text/javascript';
				script.src = this.statistics;
				document.getElementsByTagName('body')[0].appendChild(script);
			});
		},
		/*查看友情链接*/
		getFriendlyLinkList() {
			_self.$req
				.friendlyLinkList({
					limit: 10,
					offset: 1
				})
				.then(res => {
					// console.log(res);
					let list = res.data.data.list;
					_self.friendlyLinkList = list;
				});
		}
	}
};
</script>

<style>
@import '../static/css/55-59.css';
.foot-main {
	display: flex;
	flex-direction: column;
	flex: 1;
	/* padding-top: 1.875rem; */
}
.foot-left,
.foot-right {
	text-align: left;
	width: 31.25rem;
}
.footer {
	width: 100%;
	min-width: 90.5rem;
	background: #212224;
	height: 20rem;
	/* margin-top:80px; */
}
.footer .links {
	padding: 2.5rem 0px;
}

.footer .links a,
.footer .links div {
	/* color:#8D93A1; */
	/* display:inline-block; */
	/* padding:2px 0; */
	/* margin-right:20px */
	font-size: 1.125rem;
	font-weight: 400;
	color: rgba(153, 153, 153, 1);
	line-height: 1.9375rem;
}
.footer .links a:hover {
	color: #ff4d4d;
}
.footer .links a:active {
	color: #b93131;
}
.footer .links h5 {
	font-size: 1.5rem;
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
	line-height: 1.75rem;
}
.footer .notice {
	margin-top: 1.25rem;
	text-align: center;
}
.footer .notice a {
	color: #8d93a1;
	font-size: 12px;
	line-height: 30px;
	margin: 0 5px;
}
.footer .cp {
	padding: 10px 0 50px 0;
	text-align: center;
}
.footer .notice,
.footer .cp {
	font-size: 1.125rem;
	font-weight: 400;
	color: rgba(153, 153, 153, 1);
	line-height: 1.75rem;
}
</style>
