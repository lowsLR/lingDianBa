<template>
	<!--  -->
	<div :style="{width:width,height:height}">
		<!--  -->
		<video-player  class="video-player vjs-custom-skin"
		  ref="videoPlayer" 
		  :playsinline="true" 
			crossOrigin="anonymous"
		  :options="playerOptions"
			@play="onPlayerPlay($event)"
			@pause="onPlayerPause($event)"
			@ended="onPlayerEnded($event)"
			@waiting="onPlayerWaiting($event)"
			@playing="onPlayerPlaying($event)"
			@loadeddata="onPlayerLoadeddata($event)"
			@timeupdate="onPlayerTimeupdate($event)"
			@canplay="onPlayerCanplay($event)"
			@canplaythrough="onPlayerCanplaythrough($event)"
			@statechanged="playerStateChanged($event)"
			@error="onPlayerError"
			@ready="playerReadied"  
		></video-player>
		
	</div>
</template>

<script>
	import videojs from 'video.js'
	import {videoPlayer} from 'vue-video-player'
	import 'videojs-flash'
	var _this;
	var playVideo,
	setStartTime;//设置剩余开始时间;
	export default {
	  name:'bwVideoPlayer',
	  props:{
	  	isLiveType:{
	  		type: Number,
	  		default: 2
	  	},
	  	isBeginAnalys:{
	  		type: Boolean,
	  		default: false
	  	},
	  	width: {
	  	  type: String,
	  	  default: "100%"
	  	},
	  	height: {
	  	  type: String,
	  	  default: "320px"
	  	},
	  	videoMsg:{//提示
	  		type: String,
	  		default: ''
	  	},
	  	isPlaySource:{//是否有播放资源
	  		type: Boolean,
	  		default: false
	  	},
	  	isLive:{//是否是直播
	  		type: Boolean,
	  		default: true
	  	},
	  	sourceUrl:{//播放路径
	  		type: String,
	  		default: ''
	  	},
	  	poster:{//封面图路径
	  		type: String,
	  		default: ''
	  	},
	  	isAutoplay:{//是否自动播放
	  		type: Boolean,
	  		default: false
	  	},
	  	videoType:{//是否自动播放
	  		type: String,
	  		default: 'application/x-mpegURL'
	  	},
	  	bgc:{//背景色
	  		type: String,
	  		default: '#000000'
	  	},
	  },
		data() {
			return {
				isPlayPause:false,
				dtime:'',
				t:0,
				istime:false,
				playerOptions : {
						techOrder: ['html5','flash'], // 兼容顺序
						// techOrder: ['flash', 'html5'], // 兼容顺序
						live: this.isLive,
						autoplay: this.isAutoplay || true, // 如果true，浏览器准备好时开始播放
						muted: false, // 默认情况下将会消除任何音频
						loop: false, // 是否视频一结束就重新开始
						preload: 'auto', // 建议浏览器在<video>加载元素后是否应该开始下载视频数据。auto浏览器选择最佳行为,立即开始加载视频（如果浏览器支持）
						language: 'zh-CN',
						aspectRatio: '16:9', // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
						fluid: true, // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
						hls:true,
						flash: {
						  hls: {
						    withCredentials: false
						  },
						  swf: 'videojs-swf/dist/video-js.swf'
						},
						html5: { hls: { withCredentials: false } },
						sources: [
						  {
						    // withCredentials: false,
						    type: 'application/x-mpegURL',
						    src: this.sourceUrl || '',
						    type: this.videoType || 'video/mp4',
						  }//设置路径和 类型
						],
						
						poster: this.poster,//封面
						// width:this.windowWidth,
						width:this.width,
						height:this.height,
						notSupportedMessage: '此视频暂无法播放，请稍后再试', // 允许覆盖Video.js无法播放媒体源时显示的默认信息。
						controlBar: {
						  timeDivider: false,
						  durationDisplay: false,
						  remainingTimeDisplay: false,
						  currentTimeDisplay: false, // 当前时间
						  volumeControl: false, // 声音控制键
						  playToggle: true, // 暂停和播放键
							
							currentTimeDisplay: !this.isLive, // 当前时间
							// timeDivider: this.isLive?false:true, // 时间分割线
							durationDisplay: !this.isLive, // 总时间
						  progressControl: !this.isLive, // 进度条
							
							// currentTimeDisplay: false, // 当前时间
							// durationDisplay: false, // 总时间
							// progressControl: false, // 进度条
						  fullscreenToggle: true // 全屏按钮
						},
						
						// techOrder: [ 'flash','html5',], // 兼容顺序
					  // techOrder: [ 'flash'], // 兼容顺序
						
						
				},
				beginAnalysNum:0,
				
				newsourceUrl:'',
				isCorsError:false,
			};
		},
		filters: {
		  filtersVideoMsg: function (value) {
		    return value.replace(/\,/g,"\n");
		  }
		},
		computed: {
		    player() {
		      return this.$refs.videoPlayer.player
		    },
		},
		created() {
			_this = this;
			
		},
		methods:{
			initNum(){
				this.beginAnalysNum = 0;
			},
			/*错误*/
			onPlayerError(err){
				console.log("播放错误:")
				if(err.error_ && err.error_.code == 4){
					if(!this.isCorsError){
						// this.$emit("corsError",{code:err.error_.code})
						// let reg = new RegExp("^(?=^.{3,255}$)(http(s)?:\/\/)?(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+\.\w+)*$");
						// let reg = "/[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\.?/"
						// this.newsourceUrl = this.sourceUrl.replace(/^(?=^.{3,255}$)(http(s)?:\/\/)?(www\.)?[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+(:\d+)*(\/\w+\.\w+)*$/,'')
						this.newsourceUrl = this.sourceUrl.replace("http://cctvalih5ca.v.myalicdn.com",'')
						console.log("新字符串",this.newsourceUrl)
						this.isCorsError = true;
						this.switchPlayerVideo(this.newsourceUrl)
					}
					return;
				}
				if(this.isLiveType == 1){
					this.beginAnalysNum++;
						if(this.beginAnalysNum < 2){
							console.log("第一次报错")
							try{
								if(this.isBeginAnalys){
									console.log("重新解析")
									this.$emit("beginAnalysisSource")
								}
							}catch(e){
								//TODO handle the exception
							}
						}else{
							console.log("第二次报错")
							try{
								this.$emit("errorVideo")
							}catch(e){
								//TODO handle the exception
							}
							
						}
				}
				
			},
			/*播放*/
			onPlayerPlay(p){
				console.log("开始播放:",p)
			},
			/*暂停*/
			onPlayerPause(p){
				console.log('暂停:',p)
			},
			/*视频播放完*/
			onPlayerEnded(p){
				console.log('视频播放完:',p)
			},
			/*元素readyState更改导致播放停止*/
			onPlayerWaiting(p){
				console.log('元素readyState更改导致播放停止:',p)
				// p.error_.message = '无法加载媒体，可能是由于服务器或网络故障，也可能是由于不支持该格式。';
			},
			/*已开始播放*/
			onPlayerPlaying(p){
				console.log('已开始播放:',p)
			},
			/*当播放器在当前播放位置下载数据时触发*/
			onPlayerLoadeddata(p){
				console.log('当播放器在当前播放位置下载数据时:',p)
				// console.log(this.$refs.videoPlayer)
			},
			/* 当前播放位置发生变化时触发*/
			onPlayerTimeupdate(p){
				// console.log('当前播放位置发生变化时触发',p)
			},
			/*媒体的readyState为HAVE_FUTURE_DATA或更高*/
			onPlayerCanplay(p) {
			  // console.log('player Canplay!', p)
			},
			/*媒体的readyState为HAVE_ENOUGH_DATA或更高。这意味着可以在不缓冲的情况下播放整个媒体文件。*/
			onPlayerCanplaythrough(p) {
			  // console.log('player Canplaythrough!', p)
			},
			/*播放状态改变回调*/
			playerStateChanged(p){
				// console.log('播放状态改变',p)
			},
			/*将侦听器绑定到组件的就绪状态。与事件监听器的不同之处在于，如果ready事件已经发生，它将立即触发该函数*/
			playerReadied(p){
				console.log('加载完成，准备播放',p)
				// this.$refs.videoPlayer.player;
				let _this = this
				var hls = p.tech({ IWillNotUseThisInPlugins: true }).hls
				p.tech_.hls.xhr.beforeRequest = function (options) {
					// console.log(options)
					// let userInfo = localStorage.getItem('userInfo')
					// let token = JSON.parse(userInfo).accessToken
					options.headers = {
					// options.header = {
						'Accept': 'application/json, text/plain, */*',
						"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
						'Content-Type': 'application/json;charset=UTF-8',
						"Access-Control-Allow-Headers":"Origin, X-Requested-With, Content-Type, Accept, Range",
						"Access-Control-Allow-Origin":"*",
						"ttttttt":'test',
						// // 'Accept-Language': 'zh-CN,zh;q=0.9,hy;q=0.8,mn;q=0.7',
						// "Accept-Language":" zh-CN,zh;q=0.9",
						// "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",
						// "Host": "cctvalih5ca.v.myalicdn.com",
						// "Access-Control-Allow-Credentials":"true",
						// "Access-Control-Allow-Origin":"*",
						// "Access-Control-Request-Headers":"content-type",
						// // "Access-Control-Allow-Origin":"http://localhost:8080",
						// "Access-Control-Allow-Methods": "POST, GET, OPTIONS,DELETE,PUT",
						// "Accept": "*/*",
						// "Accept-Encoding": "gzip, deflate,sdch",
						// "Accept-Language": "zh-CN,zh;q=0.9",
						// "Connection": "keep-alive",
						// "Host": "cctvalih5ca.v.myalicdn.com",
						// "If-Modified-Since": "Mon, 25 May 2020 07:14:45 GMT",
						// "If-None-Match": "9C4263C804BECE6CBEED87768ED9FEA0",
						// "Origin": "http://localhost:8080",
						// "Referer": "http://localhost:8080/",
						// "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36",
						
						// 'Authorization': 'Bearer ' + token
					}
					return options
				}
				
				// this.player;
				
				// try{
				// 	this.$emit('calculationNum');
				// }catch(e){
				// 	//TODO handle the exception
				// }
			},
			getVideoData(){
				this.istime = false;
				console.log("isPlaySource是否有播放源",this.isPlaySource);
				console.log("是否有倒计时",this.istime);
				console.log("提示",this.videoMsg);
				// that.$forceUpdate();
			},
			
			timeup() {
				uni.showToast({
					title: '时间到'
				})
			},
			/*清空倒计时*/
			clearStartTime(){
				return new Promise((res,rel) => {
					if(setStartTime){
						clearInterval(setStartTime);
						setStartTime = null; 
						this.dtime = '';
					}
					res();
				})
				
			},
			 formatSeconds(t) {
				let mi = 60,hh = mi*60,dd = hh*24;
				// let d = this.formatBit( Math.floor(t/dd)),
				// 		h = this.formatBit( Math.floor((t - d*dd)/hh)),
				// 		m = this.formatBit( Math.floor((t - d*dd - h*hh)/mi)),
				// 		s = this.formatBit( Math.floor((t - d*dd - h*hh - m*mi)));
				let h = this.formatBit( Math.floor(t/hh)),
						m = this.formatBit( Math.floor((t - h*hh)/mi)),
						s = this.formatBit( Math.floor((t - h*hh - m*mi)));		
				// let tstr = d+'天'+h+'小时'+m+"分"+s+'秒';
				let tstr = '倒计时:'+ h+'小时'+m+"分"+s+'秒';
				return tstr;
				
				// let min = Math.floor(t % 3600);
				// let h = this.formatBit(Math.floor(t / 3600)),
				// 		m = this.formatBit(Math.floor(min/60)),
				// 		s = this.formatBit( Math.floor(t%60));
				// let tstr = h+':'+m+":"+s;
				// return tstr;
			},
			setDataTime(time){
				this.clearStartTime().then( res => {
					this.istime = true;
					this.t = Math.floor(time/1000);
					console.log(this.t);
					setStartTime = setInterval(() => {
						this.t--;
						// console.log(this.t)
						this.dtime = this.formatSeconds(this.t)
						if (this.t <= 0) {
							clearInterval(setStartTime)
							// setTimeout(function() {this.istime = false;},1000);
							// 倒计时结束 重新开始解析
							this.$emit('beginAnalysisSource');
						}
					}, 1000)
				})
			},
			formatBit(v){
				v = +v
				return v > 9 ? v : '0' + v
			},
			setPlay(){
				console.log("进入设置")
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
			},
			switchPlayerVideo(url){
				 if (url) {
				            this.playerOptions.sources = [
				              {
												type: this.videoType || 'video/mp4',
				                autoplay: true,
				                src: url // 本地资源地址，注意：本地资源存放在 static 文件夹中，本文视频资源路径 static/topicMaterial/1.mp4
				              }
				            ]; 
				          } else {
				            this.playerOptions.sources = [];
				          }
			},
			
			/*初始化播放器*/
			initVideo(pdata) {
				console.log('初始化',pdata)
				let _self = this;
				_self.pdata = pdata;
				_self.playerOptions['sources'][0]['src'] = '';
				// _self.beginAnalysNum = 0;
				/*匹配路径以什么结尾*/
				let url = pdata.url,
						index = url.lastIndexOf("\."),
						str = url.substring((index+1),url.url),
						str2 = url.match('[^.]+(?!.*.)')[0];
				_self.playerOptions.poster = pdata.poster || '';
				_self.playerOptions.autoplay = pdata.isAutoplay||true;
				_self.playerOptions.live = pdata.isLive||true;
				if(pdata.isLive){
					_self.playerOptions.controlBar.currentTimeDisplay = false
					_self.playerOptions.controlBar.durationDisplay = false
					_self.playerOptions.controlBar.progressControl = false
				}
				switch (str2){
					case 'm3u8':
						_self.playerOptions['sources'][0]['type'] = 'application/x-mpegURL';
						break;
					case 'mp4':
						_self.playerOptions['sources'][0]['type'] = 'video/mp4';
						break;	
					default:
						_self.playerOptions['sources'][0]['type'] = 'application/x-mpegURL';
						break;
				}
				 _self.playerOptions['sources'][0]['src'] =pdata.url;
			
				console.log('初始化结束',)
			},
			/*切换路径*/
			switchPath(){
				 _self.playerOptions['sources'][0]['src'] = this.sourceUrl;
			},
			/*销毁后重建*/
			videoDisposeRebuild(){
				this.videoDispose().then( res => {
							this.initVideo(pdata)
				})
			},
			/*销毁播放器*/
			videoDispose() {
				return new Promise( (res,rel) => {
					// if(playVideo){
						// playVideo.dispose();
						this.clearStartTime();
					// }
					res();
				})
			},
			play(){
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'pause'){
						playVideo.play();
					}
				}
			},
			pause(){
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'playing'){
						playVideo.pause();
					}
				}
			}	,
			/*切换播放暂停*/
			playPause (){
				if(playVideo){
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
				}
			},
		} 
	}
</script>

<style >
	
	.video-player{
		width: 100%;
		height: 100%;
	}
	/* .video-js{
		width: 100% !important;
		height: 100% !important;
	} */
	
	.video-js.vjs-fluid{
		/* height: 550px; */
		height: 100%;
		padding-top: 0;
	}
	.video-js .vjs-big-play-button{
	     /*
	      播放按钮换成圆形
	     */
	    height: 2em;
	    width: 2em;
	    line-height: 2em;
	    border-radius: 1em;
	  }
</style>
