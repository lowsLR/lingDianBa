<template>
    <div>
        <div class="box text edit" :contenteditable="isLiveEdit" v-html="innerText" @input="changeTxt"   placeholder="说的什么.."></div>
        <span class="text-num trsY">{{textNum}}</span>
        <div class="facebox" v-show="faceBoxFlag">
            <img @click="addFace(`${i}.gif`)" :src="`${gifBaseUrl+i}.gif`" alt="" class="pointer faceItem" v-for="i in 131">
        </div>
    </div>
</template>

<script>
	 export default {
	        name:'mContenteditable',
	        props:{
	            commentsValue:{
	                type:String,
	                default:''
	            },
	            faceBoxFlag:{
	                type: Boolean,
	                default: false
	            }
	        },
	        data:function(){
	            return {
	                innerText:this.commentsValue,
	                gifBaseUrl:'http://******/Public/Home/face/', //表情包地址
	                textNum:0,//剩余可编辑字数
	                textNumConfig:200,//字数限制定义
	                isLiveEdit:true
	            }
	        },
	        mounted(){
	            this.textNum = this.textNumConfig - this.innerText.length;
	        },
	        methods:{
	            changeTxt:function(e){
	                let self = this;
	                this.textNum = this.textNumConfig - this.innerText.length;
	                this.innerText = e.currentTarget.innerText;
	                this.$emit('input',this.innerText);//解决父子组件数据双向绑定
	                if (this.textNum<1){
	                    this.textNum = 0;
	                    //this.Message({type:'error',content:'字数超出限制'});
	                    this.innerText = this.innerText.substring(0,this.textNumConfig);
	                }
	                setTimeout(()=>{
	                    self.keepLastIndex(e.target)
	                },5)
	 
	            },
	            //光标定位
	            keepLastIndex(obj) {
	                if (window.getSelection) { //ie11 10 9 ff safari
	                    obj.focus(); //解决ff不获取焦点无法定位问题
	                    var range = window.getSelection(); //创建range
	                    range.selectAllChildren(obj); //range 选择obj下所有子内容
	                    range.collapseToEnd(); //光标移至最后
	                } else if (document.selection) { //ie10 9 8 7 6 5
	                    var range = document.selection.createRange(); //创建选择对象
	                    range.moveToElementText(obj); //range定位到obj
	                    range.collapse(false); //光标移至最后
	                    range.select();
	                }
	            },
	            //插入表情
	            addFace(str){
	                let Img = `<img class='text-emoji' name='${str}' src='${this.gifBaseUrl+str}'/>`;  // img是要插入的图片表情
	                let txt = this.innerText;
	                this.innerText = txt + Img ;
	                this.$emit('input',this.innerText);//解决父子组件数据双向绑定
	            },
	 
	            //发送成功 清空输入框 
	            clearData(){
	                this.innerText = '' ;
	                this.$emit('input',this.innerText);//解决父子组件数据双向绑定
	            }
	        },
	    }
</script>

<style>
	.text:empty:before{content: attr(placeholder);color:#bbb;}
	.text:focus{content:none;}
	 
	.edit,
	.edit * {
	    -webkit-user-select: auto;
	    -webkit-user-modify: read-write;
	}
</style>
