<template>
	<div>
		<div v-if="isPlaySource" id="video" :style="{ width: width, height: height }"></div>
		<div v-else class="bgc-black flex-cc fs30 fw600" :style="{ width: width, height: height }">
			<!-- 	{{ videoMsg }} -->
			<span v-if="!istime">{{ videoMsg }}</span>
			<span>{{ dtime || '' }}</span>
		</div>
	</div>
</template>
<script>
// window.errorHandler = function(e){
// 	 console.log("监听播放器错误:",e)
// 	 console.log("当前Vue",window.that)
// }
window.loadedHandler = function() {
	console.log('播放器加载完成');
	window.player.addListener('error', errorHandler);
};

function errorHandler(e) {
	// console.log('监听播放器错误:', e);
	try {
		window.that.$emit('playerError', e);
	} catch (e) {
		//e
	}
}
window.errorHandler = errorHandler;
// var player;
let setStartTime; //设置剩余开始时间;
export default {
	name: 'ckplayer',
	props: {
		isLiveType: {
			type: Number,
			default: 2
		},
		isBeginAnalys: {
			type: Boolean,
			default: false
		},
		width: {
			type: String,
			default: '100%'
		},
		height: {
			type: String,
			default: '320px'
		},
		videoMsg: {
			//提示
			type: String,
			default: ''
		},
		isPlaySource: {
			//是否有播放资源
			type: Boolean,
			default: false
		},
		isLive: {
			//是否是直播
			type: Boolean,
			default: true
		},
		sourceUrl: {
			//播放路径
			type: String,
			default: ''
		},
		poster: {
			//封面图路径
			type: String,
			default: ''
		},
		isAutoplay: {
			//是否自动播放
			type: Boolean,
			default: true
		},
		videoType: {
			//播放类型
			type: String,
			default: 'application/x-mpegURL'
		},
		bgc: {
			//背景色
			type: String,
			default: '#000000'
		}
	},
	data() {
		return {
			dtime: '',
			t: 0,
			istime: false
		};
	},
	created() {
		// new ckplayer(videoObject);
		// var localJs = document.createElement("script");
		// 		localJs.setAttribute("src","../../static/video/ckplayer/ckplayer.js");
		// document.head.appendChild(localJs);
	},
	mounted() {
		// 定义一个对象
		window.that = this;
	},
	destroyed() {
		window.that = null;
		try {
			window.player.V = null;
		} catch (e) {
			//TODO handle the exception
		}
		try {
			window.player.removeChild();
		} catch (e) {
			//TODO handle the exception
		}
		window.player = null;
	},
	methods: {
		getVideoData() {
			this.istime = false;
			console.log('isPlaySource是否有播放源', this.isPlaySource);
			console.log('是否有倒计时', this.istime);
			console.log('提示', this.videoMsg);
			// that.$forceUpdate();
		},
		/*清空倒计时*/
		clearStartTime() {
			return new Promise((res, rel) => {
				if (setStartTime) {
					clearInterval(setStartTime);
					setStartTime = null;
					this.dtime = '';
				}
				res();
			});
		},
		formatSeconds(t) {
			let mi = 60,
				hh = mi * 60,
				dd = hh * 24;
			// let d = this.formatBit( Math.floor(t/dd)),
			// 		h = this.formatBit( Math.floor((t - d*dd)/hh)),
			// 		m = this.formatBit( Math.floor((t - d*dd - h*hh)/mi)),
			// 		s = this.formatBit( Math.floor((t - d*dd - h*hh - m*mi)));
			let h = this.formatBit(Math.floor(t / hh)),
				m = this.formatBit(Math.floor((t - h * hh) / mi)),
				s = this.formatBit(Math.floor(t - h * hh - m * mi));
			// let tstr = d+'天'+h+'小时'+m+"分"+s+'秒';
			let tstr = '倒计时:' + h + '小时' + m + '分' + s + '秒';
			return tstr;

			// let min = Math.floor(t % 3600);
			// let h = this.formatBit(Math.floor(t / 3600)),
			// 		m = this.formatBit(Math.floor(min/60)),
			// 		s = this.formatBit( Math.floor(t%60));
			// let tstr = h+':'+m+":"+s;
			// return tstr;
		},
		setDataTime(time) {
			this.clearStartTime().then(res => {
				this.istime = true;
				this.t = Math.floor(time / 1000);
				console.log(this.t);
				setStartTime = setInterval(() => {
					this.t--;
					// console.log(this.t)
					this.dtime = this.formatSeconds(this.t);
					if (this.t <= 0) {
						clearInterval(setStartTime);
						// setTimeout(function() {this.istime = false;},1000);
						// 倒计时结束 重新开始解析
						this.$emit('beginAnalysisSource');
					}
				}, 1000);
			});
		},
		/*销毁播放器*/
		videoDispose() {
			return new Promise((res, rel) => {
				// #ifdef H5
				// if(playVideo){
				// playVideo.dispose();
				this.clearStartTime();
				// }
				// #endif
				res();
			});
		},
		formatBit(v) {
			v = +v;
			return v > 9 ? v : '0' + v;
		},
		// 清除
		playrerClear() {
			window.player.removeChild();
			window.player = null;
		},
		initVideo(res) {
			// console.log(res,"==>ck")
			if (res) {
				this.showVideo(res);
			}
			// this.showVideo(res);
		},
		hasPlayer() {
			return !!window.player;
		},
		showVideo(res) {
			if (res) {
				// console.log('showVideores', res);
				var videoObject = {
					container: '#video', //“#”代表容器的ID，“.”或“”代表容器的class
					variable: 'player', //该属性必需设置，值等于下面的new chplayer()的对象
					// autoplay: res.hasOwnProperty('ap') ? res.ap ? true : false : this.isAutoplay,//自动播放
					autoplay: res.hasOwnProperty('hm') ? (res.hm ? false : this.isAutoplay) : this.isAutoplay, //自动播放
					live: res.hasOwnProperty('l') ? (res.l ? true : false) : this.isLive,
					html5m3u8: res.hasOwnProperty('hm') ? (res.hm ? true : false) : false,
					// html5m3u8:true,
					flashplayer: res.hasOwnProperty('fp') ? (res.fp ? true : false) : false,
					video: res.hasOwnProperty('url') ? res.url : this.sourceUrl, //视频地址
					loaded: 'loadedHandler' //当播放器加载后执行的函数
				};
				// console.log('videoObject', videoObject);
				// 定义一个对象
				window.player = new ckplayer(videoObject);
				// player = new ckplayer();
				// player.embed(videoObject);
			}
		},
		changeVideo(res) {
			if (!window.player) {
				if (res) {
					this.initVideo(res);
					return;
				}
				// this.initVideo(res);
				// return;
			}
			console.log('changeVideo', res);
			let newVideoObject = {
				container: '#video', //容器的ID
				variable: 'player',
				autoplay: this.isAutoplay, //自动播放
				live: res.hasOwnProperty('l') ? (res.l ? true : false) : this.isLive,
				html5m3u8: res.hasOwnProperty('hm') ? (res.hm ? true : false) : false,
				// html5m3u8:true,
				flashplayer: res.hasOwnProperty('fp') ? (res.fp ? true : false) : false,
				video: res.hasOwnProperty('url') ? res.url : this.sourceUrl, //视频地址
				loaded: 'loadedHandler' //当播放器加载后执行的函数
			};
			//判断是需要重新加载播放器还是直接换新地址

			if (window.player.playerType == 'html5video') {
				// if(player.getFileExt(res.url) == '.flv' || player.getFileExt(res.url) == '.m3u8' || player.getFileExt(res.url) == '.f4v' || res.url.substr(0, 4) == 'rtmp') {
				// 	player.removeChild();
				// 	player = null;
				// 	player = new ckplayer();
				// 	player.embed(newVideoObject);
				// } else {
				// 	player.newVideo(newVideoObject);
				// }
				window.player.removeChild();
				window.player = null;
				window.player = new ckplayer();
				window.player.embed(newVideoObject);
			} else {
				// if(player.getFileExt(res.url) == '.mp4' || player.getFileExt(res.url) == '.webm' || player.getFileExt(res.url) == '.ogg') {
				// 	player = null;
				// 	player = new ckplayer();
				// 	player.embed(newVideoObject);
				// } else {
				// 	player.newVideo(newVideoObject);
				// }
				window.player = null;
				window.player = new ckplayer();
				window.player.embed(newVideoObject);
			}
		}
	}
};
</script>

<style scoped>
#video {
	width: 37.5rem;
	height: 25rem;
	margin: 0rem auto;
}
</style>
