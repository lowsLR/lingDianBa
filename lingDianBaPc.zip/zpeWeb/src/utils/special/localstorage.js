/**
 * 使用本地存储
 */
'use strict'

const ls = window.localStorage

export default {
	
	// 存储变量名为key，值为val的变量
	set(key, val) {
		if (ls) {
			ls.setItem(key, JSON.stringify(val))
		} else {
			alert('This browser does NOT support localStorage');
		}
	},
	
	// 获取存储的变量key的值
	get(key) {
		try {
			return JSON.parse(ls.getItem(key))
		} catch (err) {
			return '';
			// return null
		}
	},
	
	// 删除变量名为key的存储变量
	remove(key) {
		ls.removeItem(key)
	},
	
	// 清空localStorage
	clear() {
		ls.clear()
	},
	
	keys() {
		return ls.keys()
	},
	
}
