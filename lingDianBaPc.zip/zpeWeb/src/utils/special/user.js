/**
 * 用户相关api
 */
'use strict'

import axios from '../../request/http.js';
import base from '@/request/api/base.js'; // 导入接口域名列表

// 用户登录
export function login(data) {
	// return axios.post(`${base.bd}/app/login/userAccount/login`, data);
	return axios.request({
		url: `${base.bd}/web/login/userAccount/login`,
		method: 'post',
		data: data
	})
}


// 用户注册
export function register(data) {
	return axios.request({
		// url: `${base.bd}/app/login/userAccount/regist`,
		url: `${base.bd}/web/login/userAccount/regist`,
		method: 'post',
		data: data
	})
}


// 发送短信（短信类型 1：注册，2：重置密码）
export function sendSMS({
	phone,
	smsType,
	verify
}) {
	return axios.request({
		// url: `${base.bd}/app/login/userAccount/sendSms`,
		url: `${base.bd}/web/login/userAccount/sendSms`,
		method: 'post',
		data: {
			phone: phone,
			smsType: smsType,
			verify: verify
		}
	})
}


// 重置密码
export function resetPW(data) {
	return axios.request({
		// url: `${base.bd}/app/login/userAccount/retrieve`,
		url: `${base.bd}/web/login/userAccount/retrieve`,
		method: 'post',
		data: data
	})
}


// 修改用户名
export function updateUserName(data) {
	return axios.request({
		// url: `${base.bd}/app/user/info/updateUserInfoName`,
		url: `${base.bd}/web/user/info/updateUserInfoName`,
		method: 'post',
		data: data
	})
}
