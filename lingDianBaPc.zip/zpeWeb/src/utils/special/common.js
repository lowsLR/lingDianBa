'use strict'
/**
 * public function
 */

import ElementUI from 'element-ui';

export default {
	/**
	 * 请求参数验证
	 * params 的所有属性值都不能为空
	 * 参数验证
	 * if(!this.paramsValidate(params)) return;
	 */
	paramsValidate: function(params) {
		let flag = true;

		// 判断对象是否存在某个字段：obj.hasOwnProperty("key")
		if (params.hasOwnProperty('invitationCode')) {
			// 删除对象指定属性(键)，避免参数验证
			delete params.invitationCode
		}
		// console.log(params);

		for (let key in params) {

			if (params[key] != '0' && !params[key]) {
				ElementUI.Message({
					message: '警告哦，请完善数据!',
					type: 'warning'
					// type: 'error'
				});
				return false; // 终止程序
			}
		}
		return flag;
	},
	
	/**
	 * 匹配手机号
	 */
	isMobilePhone: function (str) {
		// if(str==null||str=="") return false;
		let result=str.match(/^((\(\d{2,3}\))|(\d{3}\-))?((13\d{9})|(15\d{9})|(18\d{9}))$/);
		if (result == null) {
			ElementUI.Message.warning('请输入有效手机号')
			return false;
		}
		return true;
	},
	
	/**
	 * 清空对象的值(value)
	 * @param {Object} obj
	 */
	resetObject(obj) {
		for(let key in obj){
			obj[key] = ''
		}
		// {'key1':'','key2':''}
		return obj;
	},
	
	/**
	 * 获取当前日期
	 * @param {String} str -> 'YYYY-MM-DD  hh:mm:ss  we'
	 */
	getCurrentDate(str) {
		let now = new Date(),
			year = now.getFullYear(), //得到年份
			month = now.getMonth(), //得到月份
			date = now.getDate(), //得到日期
			day = now.getDay(), //得到周几
			hour = now.getHours(), //得到小时
			minu = now.getMinutes(), //得到分钟
			sec = now.getSeconds(), //得到秒
			MS = now.getMilliseconds(), //获取毫秒
			week;
		month = month + 1;
		if (month < 10) month = "0" + month;
		if (date < 10) date = "0" + date;
		if (hour < 10) hour = "0" + hour;
		if (minu < 10) minu = "0" + minu;
		if (sec < 10) sec = "0" + sec;
		if (MS < 100) MS = "0" + MS;
		let arr_week = new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六");
		week = arr_week[day];
		let time = "";
		let dj = {
			'YYYY': year,
			'MM': month,
			'DD': date,
			'hh': hour,
			'mm': minu,
			'ss': sec,
			'we': week,
		}
		if (str) {
			time = str.replace('YYYY', dj['YYYY'])
				.replace('MM', dj['MM'])
				.replace('DD', dj['DD'])
				.replace('hh', dj['hh'])
				.replace('mm', dj['mm'])
				.replace('ss', dj['ss'])
				.replace('we', dj['we']);
		} else {
			// time = year + "年" + month + "月" + date + "日" + " " + hour + ":" + minu + ":" + sec + " " + week;
			// time = year + "年" + month + "月" + date + "日"
			
			// 'YYYY-MM-DD'
			time = year + '-' + month + '-' + date;
		}
		return time;

	},
	
	/**
	 * 获取当前年月日 (固定返回数据)
	 */
	getCurrentYMD: function() {
		let date = new Date();
		let year = date.getFullYear();
		let month = date.getMonth() + 1 < 10 ? ('0' + (date.getMonth() + 1)) : (date.getMonth() + 1);
		let day = date.getDate() < 10 ? ('0' + date.getDate()) : date.getDate();
		// 'YYYY-MM-DD'
		let time = year + '-' + month + '-' + day;
	
		return time;
	},
	
	/**
	 * 时间戳转时间
	 * @param {String} timestamp 
	 * timestamp：时间戳为10位需*1000，时间戳为13位不需乘1000
	 */
	timesToTime(timestamp) {
		let date = new Date(timestamp);
		let Y = date.getFullYear() + '年';
		let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '月';
		let D = date.getDate() + '日 ';
		let h = date.getHours() + ':';
		let m = date.getMinutes() < 10 ? '0' + date.getMinutes() + ':' : date.getMinutes() + ':';
		let s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
		return Y + M + D + h + m + s;
	},

}
