import Vue from 'vue'
import router from '../../router/index.js'; //路由
const TypePage = {
	NEW_PAGE: 1, //打开新的窗口
	OLD_PAGE: 2 //原页面跳转
};
const BR = {
	navTo(path, queryObj, type = TypePage.NEW_PAGE) {
		// console.log("点击了")
		if (type == TypePage.NEW_PAGE) {
			let {
				href
			} = router.resolve({
				path: path,
				query: queryObj
			});
			window.open(href, '_blank');
		} else {
			///
			router.push({
				path: path,
				query: queryObj
			})
		}

	}
}
export default BR;
