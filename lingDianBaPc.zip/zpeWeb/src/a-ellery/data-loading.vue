<template>
	<div v-if="!list.length">
		<div class="lod" v-if="isLod" :style="{ height: height }">
			<img src="../static/main/lod.gif" alt="" />
			<div class="txt" :style="{ fontSize: fontSize }">加载中…</div>
		</div>
		<nodata v-if="!isLod" :height="height" title="暂无数据" fontSize='1.25rem'></nodata>
	</div>
</template>

<script>
export default {
	name: 'dataLoading',
	props: {
		list: {
			type: Array,
			default: () => {
				return [];
			}
		},
		height: {
			type: String,
			default: () => {
				return '100%';
			}
		},
		fontSize: {
			type: String,
			default: () => {
				return '1.25rem';
			}
		}
	},
	data() {
		return {
			isLod: true
		};
	},
	watch: {
		list(newValue, oldValue) {
			if (!newValue.length) {
				setTimeout(() => {
					this.isLod = false;
					if (this.list.length) {
						this.isLod = true;
					}
				}, 300);
			}
		}
	}
};
</script>

<style scoped lang="scss">
.lod {
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
	/* height: 35rem; */
	position: relative;
	overflow: hidden;
	img {
		width: 25rem;
		height: 25rem;
		position: absolute;
	}
	.txt {
		color: #333333;
		// font-size: 1.25rem;
		position: absolute;
		z-index: 10;
	}
}
</style>
