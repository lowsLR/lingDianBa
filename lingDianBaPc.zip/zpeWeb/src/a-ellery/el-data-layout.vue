<template>
	<div class="el-data-css">
		<el-date-picker
			prefix-icon="datePickerImage"
			:editable="false"
			@change="formatTime"
			v-model="timevalue"
			value-format="yyyy-MM-dd"
			align="center"
			type="date"
			placeholder="选择日期"
			:picker-options="pickerOptions"
			:clearable="false"
		></el-date-picker>
	</div>
</template>

<script>
export default {
	name: 'el-data-layout',
	data() {
		return {
			timevalue:'',
			//日期选项
			pickerOptions: {
				disabledDate(time) {
					return time.getTime() > Date.now();
				},
				shortcuts: [
					{
						text: '今天',
						onClick(picker) {
							picker.$emit('pick', new Date());
						}
					},
					{
						text: '昨天',
						onClick(picker) {
							const date = new Date();
							date.setTime(date.getTime() - 3600 * 1000 * 24);
							picker.$emit('pick', date);
						}
					},
				]
			},
		};
	},
	created() {
		
	},
	computed: {
		name() {
			return this.data 
		}
	},
	methods: {
		//日期选择
		formatTime(e) {
			this.$emit('formatTime', e);
		},
		clearboth(){
			this.timevalue= '';
		}
	}
};
</script>

<style lang="scss">
.el-data-css {
	height: 2.125rem;
	// border: 1px solid red;
	// width: 50px;
	.el-date-editor.el-input,
	.el-date-editor.el-input__inner {
		height: 100%;
		display: flex;
		align-items: center;
		// width: 300px;
		// border:1px solid red;
		background: rgba(27, 27, 48, 1);
		border-radius: 1.0625rem;
		width: auto;
		
		font-size: 0.9375rem;
		input {
			min-width: 7.875rem !important;
			// width: 0 !important;
			max-width: 8.99rem !important;
			// width: auto !important;
			margin-left: -0.25rem;
			padding-left: 1.375rem;
			background: rgba(27, 27, 48, 1);
			color: rgba(255, 255, 255, 1);
			border-radius: 1.6875rem;
			height: 100%;
			padding-right: 2px;
		}
	}
	.el-input--prefix .el-input__inner {
		// padding-left: 5px;
	}
	.el-input--suffix .el-input__inner {
		// padding-left: 10px;
	}
	.el-input__suffix-inner .el-input__icon{
		// border: 1px solid red;
		display: none;
	}
	.el-input__inner {
		cursor: pointer;
		// font-size: 0.625rem !important;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		// width: 8.4375rem;
		// border: 1px solid red;
		text-align: center;

		&::placeholder {
			font-size: 1rem;
			// font-size: 8px !important;
			color: rgba(255, 255, 255, 1) !important;
		}

		&::-webkit-input-placeholder {
			/* WebKit browsers 适配谷歌 */
			font-size: 1rem;
			color: rgba(255, 255, 255, 1);
		}

		&:-moz-placeholder {
			/* Mozilla Firefox 4 to 18 适配火狐 */
			font-size: 1rem;
			color: rgba(255, 255, 255, 1);
		}
		&:-moz-input-placeholder {
			/* Mozilla Firefox 4 to 18 适配火狐 */
			font-size: 1rem;
			color: rgba(255, 255, 255, 1);
		}
		&:-ms-input-placeholder {
			/* Internet Explorer 10+  适配ie*/
			font-size: 1rem;
			color: rgba(255, 255, 255, 1);
		}
	}
	input {
		// width: auto;
		// padding-left: 1.5625rem;
		background: rgba(27, 27, 48, 1);
		color: rgba(255, 255, 255, 1);
		border-radius: 1.6875rem;
		height: 100%;
		// border: 2px solid red;
	}
}
.el-data-css .el-date-editor.el-input, .el-data-css .el-date-editor.el-input__inner{
	    background: transparent;
}
</style>
