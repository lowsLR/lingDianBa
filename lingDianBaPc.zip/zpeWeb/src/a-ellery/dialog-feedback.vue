<template>
	<div>
		<el-button type="text" @click="dialogVisibleFun" :style="{ color: dialogColor }" v-if="!dialogVisible">
			<span style="font-size: 1.5rem;">联系我们</span>
			<span style="font-size: 1.2rem;">(点击给我们留言)</span>
		</el-button>

		<el-dialog class="feedBackDialog" :title="title" :visible.sync="dialogVisible" width=" 66.375rem" :before-close="handleClose">
			<el-form ref="form" :model="form" label-width="80px" :rules="rules">
				<el-form-item label="反馈名称:">
					<el-radio-group v-model="form.resource1">
						<el-radio v-for="(item, index) in feedbackName" :key="index" :label="item.label" @change="feedbackFun(item.label)" fill="#1B1B2F"></el-radio>
					</el-radio-group>
				</el-form-item>
				<el-form-item label="联系方式:">
					<el-radio-group v-model="form.resource2">
						<el-radio v-for="(item, index) in contact" :key="index" :label="item.con" @change="contactFun(item.id)" fill="#1B1B2F"></el-radio>
					</el-radio-group>
				</el-form-item>
				<!-- 校验 -->
				<el-form-item prop="email" v-if="inspect == 'email'">
					<el-input v-model="form.email" placeholder="请留下您的联系方式" clearable :disabled="disabled"></el-input>
				</el-form-item>
				<el-form-item prop="phone" v-if="inspect == 'phones'">
					<el-input v-model.number="form.phone" placeholder="请留下您的联系方式" clearable :disabled="disabled"></el-input>
				</el-form-item>
				<el-form-item prop="reg" v-if="inspect == 'qq'">
					<el-input v-model.number="form.reg" placeholder="请留下您的联系方式" clearable :disabled="disabled"></el-input>
				</el-form-item>
				<el-form-item prop="other" v-if="inspect == 'other'">
					<el-input v-model="form.other" placeholder="请留下您的联系方式" clearable :disabled="disabled"></el-input>
				</el-form-item>
				<!-- 验证码 -->
				<el-form-item prop="verificationCode" v-if="verificationShow">
					<el-input v-model="form.verificationCode" placeholder="请输入验证码"></el-input>
					<!-- <img :src="getCodeUrl" @click.stop="handleGetImgCode" class="imgCodeBtn" alt="" crossorigin="anonymous" :authsrc="getColePic" id="img" /> -->
					<img :src="getCodeUrl" @click.stop="handleGetImgCode" class="imgCodeBtn" alt="" id="img" />
				</el-form-item>
				<el-form-item label="反馈内容:" prop="desc" class="textareaprop">
					<el-input type="textarea" v-model="form.desc" :placeholder="placeholder" resize="none"></el-input>
				</el-form-item>
				<el-form-item><el-button type="primary" @click="onSubmit">提交</el-button></el-form-item>
			</el-form>
			<!-- 提示框 -->
			<el-dialog width="30%" :title="innerVisibleTitle" :visible.sync="innerVisible" append-to-body :center="true" :show-close="false" top="30vh"></el-dialog>
		</el-dialog>

		<!-- 登录提示框 -->
		<el-button type="text" @click="open"></el-button>
		<!-- 打开登录界面 -->
		<login-dialog :dialogFormVisible.sync="dialogState" :formType.sync="formType"></login-dialog>
	</div>
</template>

<script>
// Object.defineProperty(Image.prototype, 'authsrc', {
// 	writable: true,
// 	enumerable: true,
// 	configurable: true
// });
import base from '../request/api/base.js'; // 导入接口域名列表
export default {
	name: 'dialog-feedback',
	props: {
		// elRadio: {
		// 	type: String,
		// 	default: ''
		// },
		dialogColor: {
			type: String,
			default: ''
		}
	},
	data() {
		let phone = (rule, value, callback) => {
			// console.log(value, '===>value');
			var myreg = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(18[0-9]{1})|(19[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
			if (!myreg.test(value)) {
				callback(new Error('请输入正确的手机号码'));
			} else {
				callback();
			}
		};
		let reg = (rule, value, callback) => {
			let qq = /^[1-9][0-9]{4,9}$/gim;
			if (!qq.test(value)) {
				callback(new Error('请输入正确的QQ号码格式'));
			} else {
				callback();
			}
		};
		return {
			formType: 1,
			dialogState: false,
			disabled: true,
			dialogVisible: false,
			form: {
				name: '',
				region: '',
				date1: '',
				date2: '',
				delivery: false,
				type: [],
				resource1: '',
				resource2: '',
				email: '',
				desc: '',
				phone: '',
				reg: '',
				other: '',
				verificationCode: ''
			},
			feedbackName: [
				{
					label: '广告联系',
					id: 'gg'
				},
				{
					label: '友情链接',
					id: 'yq'
				},
				{
					label: '频道报错',
					id: 'pd'
				},
				{
					label: '录像失效',
					id: 'lx'
				},
				{
					label: '版权反馈',
					id: 'bq'
				},
				{
					label: '意见建议',
					id: 'yj'
				}
			],
			contact: [
				{
					con: 'QQ',
					id: 'qq'
				},
				{
					con: '微信',
					id: 'wechat'
				},
				{
					con: '邮箱',
					id: 'email'
				},
				{
					con: '手机',
					id: 'phones'
				},
				{
					con: '其他',
					id: 'other'
				}
			],
			placeholder: '请简单描述侵权的内容以及页面并留下联系方法，以便我们快速处理',
			title: '意见反馈', //标题
			inspect: 'other',
			rules: {
				desc: [{ required: true, message: '请输入内容', trigger: 'blur' }, { min: 10, message: '请留言内容超过10字', trigger: 'blur' }],
				email: [{ required: true, message: '请输入邮箱地址', trigger: 'blur' }, { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] }],
				phone: [{ validator: phone, trigger: 'blur' }],
				reg: [{ validator: reg, trigger: 'blur' }],
				other: [{ required: true, message: '请留下您的联系方式', trigger: 'blur' }],
				verificationCode: [{ required: true, message: '请输入正确的验证码', trigger: 'blur' }]
			},
			feedbackType: '', //反馈名称类型
			contactType: '', //联系类型:
			innerVisible: false, //提示框
			innerVisibleTitle: '', //提示文字
			getCodeUrl: '', // 图片验证码地址
			getColePic: `${base.bd}/app/login/userAccount/getFeedbackVerify`,
			isClickCodeUrl: false, // 是否已点击获取图片验证码
			verificationShow: false, // 验证码框默认隐藏
			dialogName: '',
			elRadio: '广告联系',
			isReg: true //检验qq时不频繁请求验证码接口
		};
	},
	created() {
		this.$nextTick(() => {
			if (this.elRadio) {
				this.form.resource1 = this.elRadio;
				this.feedbackFun(this.elRadio);
				// this.handleGetImgCode();
			} else {
				this.form.resource1 = '';
			}
		});
	},
	methods: {
		//提示框
		open() {
			this.$confirm('对不起,请登录后再留言', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: ''
				// center: true 居中布局
			})
				.then(() => {
					this.dialogState = true;
					this.formType = 1;
				})
				.catch(() => {});
		},
		//反馈框
		dialogVisibleFun() {
			if (!this.$store.state.hasLogin) {
				this.open();
			} else {
				this.dialogVisible = true;
				// console.log('子页获取数据foot', this.$route);
				this.dialogName = this.$route.name;
				switch (this.dialogName) {
					case 'lx-VideoPlayback':
						this.elRadio = this.feedbackName[3].label;
						break;
					case 'tvDetails':
						this.elRadio = this.feedbackName[2].label;
						break;
					// case 'main':
					// this.elRadio = this.feedbackName[0].label;
					// break;
					// case 'main':
					// this.elRadio = this.feedbackName[0].label;
					// break;
				}
				this.form.resource1 = this.elRadio;
				this.feedbackFun(this.elRadio);
			}
		},
		handleClose(done) {
			this.dialogVisible = false;
		},
		// 提交
		onSubmit() {
			if (!this.contactType) {
				this.innerVisible = true;
				this.innerVisibleTitle = '请选择联系方式';
			} else {
				this.$refs.form.validate(valid => {
					console.log(valid, '==>valid');
					if (valid) {
						switch (this.contactType) {
							case '1':
								if (this.testQQ(this.form.reg)) {
									this.contactNumber = this.form.reg;
								}
								break;
							case '2':
								if (this.form.other) {
									this.contactNumber = this.form.other;
								}
								break;
							case '3':
								if (this.testEmail(this.form.email)) {
									this.contactNumber = this.form.email;
								}
								break;
							case '4':
								if (this.testPhone(this.form.phone)) {
									this.contactNumber = this.form.phone;
								}
								break;
							case '5':
								if (this.form.other) {
									this.contactNumber = this.form.other;
								}
								break;
						}
						let obj = {
							feedbackContact: this.contactNumber, //联系方式
							feedbackContactInformation: this.contactType, //联系方式类型  1 qq  2微信 3 邮箱 4 手机  5 其
							feedbackContent: this.form.desc, //反馈内容
							feedbackPlatform: '0', //反馈所属平台 0:pc、1:安卓、2:苹果、3:h5
							feedbackTitle: this.form.resource1, //反馈标题
							feedbackType: this.feedbackType, //1广告联系 2友情链接 3频道报错 4录像失效 5 版权反馈 6 意见建议
							verify: this.form.verificationCode
						};
						this.createFeedback(obj);
					}
				});
			}
		},
		// 调用接口
		createFeedback(obj) {
			this.$newsReq.createFeedback(obj).then(res => {
				if (res.data.code == '1003') {
					this.$message.error('请重新登录');
					/* 全局事件触发 - 打开登录模态框 */
					this.eventBus.$emit('openLoginDialog', { dialogState: true, formType: 1 });
					this.handleClose();
					return;
				}
				if (res.data.resultCode == -1 && res.data.resultMsg == '请输入正确的验证码') {
					this.innerVisible = true;
					this.innerVisibleTitle = res.data.resultMsg;
					this.handleGetImgCode();
				}
				if (res.data.resultCode == 1) {
					this.form.resource2 = '';
					this.innerVisible = true;
					this.innerVisibleTitle = '反馈提交成功';
					setTimeout(() => {
						this.$refs.form.resetFields();
						this.dialogVisible = false;
						this.innerVisible = false;
					}, 500);
				}
			});
		},
		feedbackFun(title) {
			if (title == '版权反馈') {
				this.title = title;
			} else {
				this.title = title + '反馈';
			}
			switch (title) {
				case '广告联系':
					this.placeholder = '请简单描述你的合作方式，以及合作内容，并留下联系方式';
					this.feedbackType = '1';
					break;
				case '友情链接':
					this.placeholder = '请留下贵站的域名以及联系方式';
					this.feedbackType = '2';
					break;
				case '频道报错':
					this.placeholder = '请描述详细原因：如无法播放，内容不符等';
					this.feedbackType = '3';
					break;
				case '录像失效':
					this.placeholder = '请描述详细原因：如无法播放，内容不符视频内容不完整等';
					this.feedbackType = '4';
					break;
				case '版权反馈':
					this.placeholder = '请简单的描述侵权的内容以及页面并留下联系方式，以便我们快速的处理';
					this.feedbackType = '5';
					break;
				case '意见建议':
					this.placeholder = '请简单的描述侵权的内容以及页面并留下联系方式，以便我们快速的处理';
					this.feedbackType = '6';
					break;
			}
		},
		contactFun(type) {
			this.inspect = '';
			this.form.email = '';
			this.form.phone = '';
			this.form.reg = '';
			this.form.other = '';
			this.verificationShow = false;
			this.form.verificationCode = '';
			this.$refs.form.clearValidate();
			console.log(type, '===>contactFun');
			if (type == 'other' || type == 'wechat') {
				this.inspect = 'other';
			} else {
				this.inspect = type;
			}
			switch (type) {
				case 'qq':
					this.contactType = '1';
					break;
				case 'wechat':
					this.contactType = '2';
					break;
				case 'email':
					this.contactType = '3';
					break;
				case 'phones':
					this.contactType = '4';
					break;
				case 'other':
					this.contactType = '5';
					break;
			}
		},
		//验证手机
		testPhone(value) {
			var myreg = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(18[0-9]{1})|(19[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
			if (!myreg.test(value)) {
				return false;
			} else {
				return true;
			}
		},
		//验证邮箱
		testEmail(value) {
			let reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
			if (!reg.test(value)) {
				return false;
			} else {
				return true;
			}
		},
		//验证qq
		testQQ(value) {
			let qq = /^[1-9][0-9]{4,9}$/gim;
			if (!qq.test(value)) {
				return false;
			} else {
				return true;
			}
		},
		//文本框字体
		testTextarea(value) {
			if (value.length >= 10) {
				return true;
			} else {
				return false;
			}
		},
		//验证吗获取
		handleGetImgCode() {
			setTimeout(() => {
				var img = document.getElementById('img');
				// var url = this.getColePic;
				var request = new XMLHttpRequest();
				request.responseType = 'blob';
				request.open('get', this.getColePic + '?key=' + this.$store.state.userInfo.userId, true);
				request.onreadystatechange = e => {
					// console.log(e,"===>e")
					if (request.readyState == XMLHttpRequest.DONE && request.status == 200) {
						console.log(img, '===>img');
						img.src = URL.createObjectURL(request.response);

						img.onload = () => {
							URL.revokeObjectURL(img.src);
						};
					}
				};
				request.send(null);
			});
		}
	},
	watch: {
		'form.resource2'(newValue, oldValue) {
			if (newValue) {
				this.disabled = false;
			} else {
				this.disabled = true;
			}
		},
		'form.email'(newValue, oldValue) {
			if (this.testEmail(newValue)) {
				this.verificationShow = true;
				this.handleGetImgCode();
			} else {
				this.verificationShow = false;
				this.form.verificationCode = '';
			}
		},
		'form.phone'(newValue, oldValue) {
			if (this.testPhone(newValue)) {
				this.verificationShow = true;
				this.handleGetImgCode();
			} else {
				this.verificationShow = false;
				this.form.verificationCode = '';
			}
		},
		'form.reg'(newValue, oldValue) {
			if (this.testQQ(newValue)) {
				this.verificationShow = true;
				if (this.isReg) {
					this.handleGetImgCode();
					this.isReg = false;
				}
			} else {
				this.verificationShow = false;
				this.form.verificationCode = '';
			}
		},
		'form.other'(newValue, oldValue) {
			if (newValue) {
				this.verificationShow = true;
				if (this.isReg) {
					this.handleGetImgCode();
					this.isReg = false;
				}
			} else {
				this.verificationShow = false;
				this.form.verificationCode = '';
			}
		},
		isReg(newValue, oldValue) {
			if (newValue != oldValue) {
				setTimeout(() => {
					this.isReg = true;
				}, 2000);
			}
		}
	}
};
</script>

<style lang="scss" scoped>
/* /deep/.el-dialog__wrapper { */
/deep/.feedBackDialog {
	.el-dialog .el-dialog__header {
		height: 4.875rem;
		background: rgba(27, 27, 48, 1) !important;
		font-size: 1.625rem;
		.el-dialog__title {
			color: rgba(255, 255, 255, 1);
		}
		button {
			i {
				color: rgba(255, 255, 255, 1);
				display: flex;
				align-items: center;
				&::before {
					content: '';
					// width: 0.0625rem;
					height: 2.6rem;
					display: block;
					border: 0.03125rem solid rgba(255, 255, 255, 1);
					opacity: 0.3;
				}
				&::after {
					content: '\E6DB';
					font-size: 1.875rem;
					display: block;
					margin-left: 1.2rem;
				}
			}
		}
	}
	.el-dialog__body {
		// border: 1px solid red;
		padding-left: 3.4375rem;

		.el-form {
			.el-form-item {
				// border: 1px solid red;
				display: flex;
				align-items: center;
				&:first-child {
					margin-bottom: 2.5rem;
				}
				&:nth-last-child(2) {
					// border: 1px solid red;
					display: flex;
					align-items: flex-start;
					margin-bottom: 2.25rem;
					.el-form-item__label {
						// border: 1px solid red;
						margin-top: 0.9375rem;
						margin-left: -0.9375rem;
					}
				}
				&:last-child {
					// border: 1px solid red;
					justify-content: center;
					button {
						// border: 1px solid red;
						width: 28.25rem;
						height: 3rem;
						background: rgba(27, 27, 48, 1);
						opacity: 0.7;
						border-radius: 1.5rem;
						border: 0;
						// &:hover{
						// 	border: 0;
						// }
						span {
							color: rgba(255, 254, 254, 1);
							font-size: 1.25rem;
						}
					}
				}
				.el-form-item__label {
					width: auto !important;
					height: 1.4375rem;
					font-size: 1.375rem;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: rgba(51, 51, 51, 1);
					line-height: 1.125rem;
					// border: 1px solid red;
				}
				.el-form-item__content {
					// border: 1px solid red;
					// flex: 1;
					margin-left: 0.625rem !important;
					display: flex;
					align-items: flex-start;
					img {
						width: 6.25rem;
						height: 2.875rem;
						border: 0.0625rem solid #1b1b30;
						box-sizing: border-box;
						margin-left: 1.25rem;
					}
					.el-radio-group {
						// border: 1px solid red;
						display: flex;
						align-items: center;
						box-sizing: border-box;
						.el-radio {
							// border: 1px solid red;
							width: auto;
							height: 3.125rem;
							display: flex;
							align-items: center;
							.el-radio__input {
								border: 0.0625rem solid #414550;
								box-sizing: border-box;
								width: 1.825rem;
								height: 1.825rem;
								// overflow: hidden;
							}
							.el-radio__inner {
								// width: 1.625rem;
								// height: 1.625rem;
								// box-sizing: border-box;
								// border: 1px solid red;
								width: 1.625rem;
								height: 1.625rem;
								border-radius: 0;
								background: rgba(255, 255, 255, 1);
								// overflow: hidden;
								border: 0;
								&::after {
									margin: 0;
									padding: 0;
									// width: 1.625rem !important;
									// height: 1.625rem !important;
									width: 100%;
									height: 100%;
									border-radius: 0;
									background-color: rgba(27, 27, 48, 1);
									content: '\2713';
									position: absolute;
									left: 50%;
									top: 50%;
									color: white;
									// border: 0;
									// transform: translate(-50%, -50%) scale(1);
									// transition: transform 0.15s ease-in;
									display: flex;
									align-items: center;
									justify-content: center;
									border: 1px solid rgba(27, 27, 48, 1);
								}
							}

							.el-radio__label {
								// border: 1px solid red;
								font-size: 1.25rem;
								color: #666666;
							}
						}
					}

					.el-textarea {
						position: relative;
						.el-textarea__inner {
							width: 49.375rem;
							height: 10rem;
							background: rgba(255, 255, 255, 1);
							border-radius: 0;

							&::-webkit-input-placeholder {
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								line-height: 1.125rem;
								padding: 0.625rem 0;
							}
							&::-moz-placeholder {
								/* Mozilla Firefox 19+ */
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								line-height: 1.125rem;
								padding: 0.625rem 0;
							}
							&:-moz-placeholder {
								/* Mozilla Firefox 4 to 18 */
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								line-height: 1.125rem;
								padding: 0.625rem 0;
							}
							&:-ms-input-placeholder {
								/* Internet Explorer 10-11 */
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								line-height: 1.125rem;
								padding: 0.625rem 0;
							}
						}
					}

					.el-input {
						// border: 1px solid red;
						position: relative;
						width: 17.375rem;
						height: 3rem;
						background: rgba(255, 255, 255, 1);
						border: 0.0625rem solid rgba(179, 179, 179, 1);
						// margin-left: 6.5625rem;
						margin: 0px 0 1.25rem 6.5625rem;
						.el-input__inner {
							// border: 1px solid red;
							min-height: 1.125rem;
							&::-webkit-input-placeholder {
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								// line-height: 1.125rem;
								// padding: 0.625rem 0;
							}
							&::-moz-placeholder {
								/* Mozilla Firefox 19+ */
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								// line-height: 1.125rem;
								// padding: 0.625rem 0;
							}
							&:-moz-placeholder {
								/* Mozilla Firefox 4 to 18 */
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								// line-height: 1.125rem;
								// padding: 0.625rem 0;
							}
							&:-ms-input-placeholder {
								/* Internet Explorer 10-11 */
								font-size: 1.25rem;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: rgba(128, 128, 128, 1);
								// line-height: 1.125rem;
								// padding: 0.625rem 0;
							}
						}
					}

					.el-form-item__error {
						// border: 1px solid red;
						position: absolute;
						height: 1.875rem;
						margin-left: 6.5625rem;
						margin-top: -0.9375rem;
						color: red;
						font-size: 12px !important;
					}
				}
			}
		}
	}
	.textareaprop {
		.el-form-item__content {
			position: relative;
			.el-form-item__error {
				// border: 1px solid yellow !important;
				position: absolute;
				top: 11.25rem;
				left: -6.875rem;
			}
		}
	}
}
</style>
