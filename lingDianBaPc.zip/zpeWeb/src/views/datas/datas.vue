<template>
	<div class="container">
		<div class="main">
			<div class="match-type">
				<div class="items"
				v-for="(item, index) in eventTypeList" :key="index"
				:class="tabCurrentIndex === index ? 'active' : ''"
				@click="queryEventData(index)"
				>
					<div class="item-name">{{item.name}}</div>
					<div class="item-icon">
						<!-- 使用 require 引入图片， xxx != null && xxx != '' ? xxx : xxx -->
						<img :src="item.img ? ('https://images.weserv.nl/?url='+item.img) : require('../../static/image/404.png')" alt="">
					</div>
				</div>
			</div>
			<div class="match-data">
				<el-tabs class="el-tab-header" v-model="activeName" @tab-click="handleClick" :stretch="isStretch">
					
					<!-- <el-tab-pane label="赛程" name="schedule">
						暂无赛程数据
					</el-tab-pane> -->
					
					<!-- <el-tab-pane label="排名" name="ranking"> -->
					<el-tab-pane :label="eventTypeList[tabCurrentIndex].name + '\xa0排名'" name="ranking" disabled>
						<!-- Layout 布局 通过基础的 24 分栏，迅速简便地创建布局 -->
						<el-row>
							<!-- 篮球所属模块 -->
							<template v-if="eventTypeList[tabCurrentIndex].id === 1 || eventTypeList[tabCurrentIndex].id === 2">
								<el-col :span="3"><div class="title">排名</div></el-col>
								<el-col :span="6"><div class="title">球队</div></el-col>
								<el-col :span="3"><div class="title">胜</div></el-col>
								<el-col :span="3"><div class="title">负</div></el-col>
								<el-col :span="3"><div class="title">胜率</div></el-col>
								<el-col :span="3"><div class="title">胜差</div></el-col>
								<el-col :span="3"><div class="title">近况</div></el-col>
							</template>
							<!-- 欧冠所属模块 -->
							<template v-if="eventTypeList[tabCurrentIndex].id >= 5 && eventTypeList[tabCurrentIndex].id <= 10">
								<el-col :span="3"><div class="title">排名</div></el-col>
								<el-col :span="6"><div class="title">球队</div></el-col>
								<el-col :span="3"><div class="title">胜</div></el-col>
								<el-col :span="3"><div class="title">平</div></el-col>
								<el-col :span="3"><div class="title">负</div></el-col>
								<el-col :span="3"><div class="title">进/失球</div></el-col>
								<el-col :span="3"><div class="title">积分</div></el-col>
							</template>
							<!-- FIFA所属模块 -->
							<template v-if="eventTypeList[tabCurrentIndex].id === 11 || eventTypeList[tabCurrentIndex].id === 12">
								<el-col :span="4"><div class="title">世界排名</div></el-col>
								<el-col :span="5"><div class="title">国家/地区</div></el-col>
								<el-col :span="5"><div class="title">排名变化</div></el-col>
								<el-col :span="5"><div class="title">积分情况</div></el-col>
								<el-col :span="5"><div class="title">积分变化</div></el-col>
							</template>
						</el-row>
						
						<!-- 篮球、欧冠所属数据列表 -->
						<div v-for="(tabItem, cindex) in eventTypeList[tabCurrentIndex].data" :key="cindex" v-if="eventTypeList[tabCurrentIndex].data.length > 0 && (eventTypeList[tabCurrentIndex].id >= 1 && eventTypeList[tabCurrentIndex].id <= 10)">
							<div class="classify">{{tabItem.title}}</div>
							<el-row class="line" v-for="(item, index) in tabItem.date" :key="index">
								<!-- 排名 -->
								<el-col :span="3">{{item.ranking}}</el-col>
								<!-- 球队 -->
								<el-col :span="6">
									<div class="team">
										<el-col class="teamLog" :span="12"><img :src="item.imageUrl ? ('https://images.weserv.nl/?url='+item.imageUrl) : require('../../static/image/404.png')" alt=""></el-col>
										<el-col class="teamName" :span="12"><span>{{item.team}}</span></el-col>
									</div>
								</el-col>
								<el-col :span="3"><div class="">{{item.win}}</div></el-col>
								<!-- 篮球所属模块 -->
								<template v-if="eventTypeList[tabCurrentIndex].id === 1 || eventTypeList[tabCurrentIndex].id === 2">
									<el-col :span="3"><div class="">{{item.negative}}</div></el-col>
									<el-col :span="3"><div class="">{{item.winningProbability}}</div></el-col>
									<el-col :span="3"><div class="">-</div></el-col>
									<el-col :span="3"><div class="">{{item.recentDevelopments}}</div></el-col>
								</template>
								
								<!-- 欧冠所属模块 -->
								<template v-if="eventTypeList[tabCurrentIndex].id >= 5 && eventTypeList[tabCurrentIndex].id <= 10">
									<el-col :span="3"><div class="">{{item.flat}}</div></el-col>
									<el-col :span="3"><div class="">{{item.negative}}</div></el-col>
									<el-col :span="3"><div class="">{{item.goal}}/{{item.fumble}}</div></el-col>
									<el-col :span="3"><div class="">{{item.integral}}</div></el-col>
								</template>
							</el-row>
						</div>
						
						<!-- FIFA所属数据列表 -->
						<div v-if="eventTypeList[tabCurrentIndex].data.length > 0 && (eventTypeList[tabCurrentIndex].id === 11 || eventTypeList[tabCurrentIndex].id === 12)">
							<el-row class="line" v-for="(item, index) in eventTypeList[tabCurrentIndex].data" :key="index">
								<el-col :span="4">{{item.ranking}}</el-col>
								<el-col :span="5">
									<div class="team">
										<el-col class="teamLog" :span="12"><img :src="item.imageUrl ? ('https://images.weserv.nl/?url='+item.imageUrl) : require('../../static/image/404.png')" alt=""></el-col>
										<el-col class="teamName" :span="12"><span>{{item.countryRegion}}</span></el-col>
									</div>
								</el-col>
								<el-col :span="5"><div class="">{{item.rankingChange}}</div></el-col>
								<el-col :span="5"><div class="">{{item.integralSituation}}</div></el-col>
								<el-col :span="5"><div class="">{{item.integralChange}}</div></el-col>
							</el-row>
						</div>
						
						<div v-if="eventTypeList[tabCurrentIndex].data.length <= 0 && (eventTypeList[tabCurrentIndex].id >= 1 && eventTypeList[tabCurrentIndex].id <= 12)">暂无排名数据</div>
						
						<!-- FIFA 分页 -->
						<paging
						class="paging"
						v-if="eventTypeList[tabCurrentIndex].data.length > 0 && (eventTypeList[tabCurrentIndex].id === 11 || eventTypeList[tabCurrentIndex].id === 12)"
						:total="eventTypeList[tabCurrentIndex].total"
						:current-page="eventTypeList[tabCurrentIndex].currentPage"
						:page-size="eventTypeList[tabCurrentIndex].pageSize"
						@changePage="changePage"></paging>
						
					</el-tab-pane>
					
					<!-- <el-tab-pane label="球员榜" name="playerList">
						暂无球员榜数据
					</el-tab-pane> -->
					<!-- <el-tab-pane label="球队榜" name="teamList">
						暂无球队榜数据
					</el-tab-pane> -->
					<!-- <el-tab-pane label="交易" name="trade">
						暂无交易数据
					</el-tab-pane> -->
					<!-- <el-tab-pane label="新秀" name="rookie">
						暂无新秀数据
					</el-tab-pane> -->
					<!-- <el-tab-pane label="伤病" name="injury">
						暂无伤病数据
					</el-tab-pane> -->
					<!-- <el-tab-pane label="季后赛" name="playoff">
						暂无季后赛数据
					</el-tab-pane> -->
					<!-- 禁用赛事数据库 -->
					<!-- <el-tab-pane label="NBA数据库" name="database" disabled>
						暂无数据
					</el-tab-pane> -->
				</el-tabs>
				
				<div class="explain">
					<p v-for="(item,index) in explain" :key="'e'+index">{{item.content}}</p>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import unitWatchHistory from '../../atemp/unit-watch-history.vue'
	import paging from '../../atemp/paging.vue'
	let that;
	export default {
		components: {
			unitWatchHistory,
			paging
		},
		data() {
			return {
				tabCurrentIndex: 0,
				eventTypeList: [
					{id: 1, name: 'NBA', img: 'http://data.zhibo8.cc/pc_main_data/images/nba.png', data: []},
					{id: 2, name: 'CBA', img: 'http://data.zhibo8.cc/html/img/cba.png', data: []},
					{id: 5, name: '西甲', img: 'http://duihui.duoduocdn.com/zuqiu/xijia1.png', data: []},
					{id: 6, name: '意甲', img: 'http://duihui.duoduocdn.com/zuqiu/yijia1.png', data: []},
					{id: 7, name: '英超', img: 'http://data.zhibo8.cc/application/public/football/match/league/8.png', data: []},
					{id: 8, name: '德甲', img: 'http://data.zhibo8.cc/application/public/football/match/league/9.png', data: []},
					{id: 9, name: '欧冠', img: 'http://data.zhibo8.cc/application/public/football/match/league/10.png', data: []},
					{id: 10, name: '法甲', img: 'http://data.zhibo8.cc/application/public/football/match/league/16.png', data: []},
					{id: 11, name: 'FIFA(男足)', img: 'http://bbsimg.zhibo8.cc/bbsimg/2018-06-20/20180620100438_7775.png', total: 0, currentPage: 1, pageSize: 15, data: []},
					{id: 12, name: 'FIFA(女足)', img: 'http://bbsimg.zhibo8.cc/bbsimg/2018-06-20/20180620100438_7775.png', total: 0, currentPage: 1, pageSize: 15, data: []},
				],
				
				activeName: 'ranking', // el-tabs 切换标签名
				isStretch: true,
				
				initStatus: true, // (避免重复发起请求)是否初始化
				
				id: '',
				routerUrl: ''
			}
		},
		created: function() {
			that = this;
			that.routerUrl = that.$route.path;
			that.id = that.$route.params.id;
			// console.log(that.$route.path)
			// console.log(that.$route.query)
			
			this.queryEventData(that.tabCurrentIndex)
		},
		mounted:function(){
			
		},
		methods: {
			// 查看赛事类型数据
			queryEventData: function (index) {
				if (that.tabCurrentIndex === index && !that.initStatus) {
					that.$message.warning('已选中当前赛事')
					return;
				}
				if (that.initStatus) that.initStatus = false;
				// 更新选中标签
				that.tabCurrentIndex = index;
				
				let request,
					datas,
					tabItem = that.eventTypeList[that.tabCurrentIndex];
				
				switch (tabItem.id){
					case 1:
					case 2:
						datas = {
							"limit": 100,
							"offset": 1,
							"typeId": tabItem.id,
						}
						request = that.$reqc.queryBasketball(datas)
						break;
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					case 10:
						datas = {
							"limit": 100,
							"offset": 1,
							"typeId": tabItem.id,
						}
						request = that.$reqc.queryIntegral(datas)
						break;
					case 11:
					case 12:
						datas = {
							"limit": tabItem.pageSize,
							"offset": tabItem.currentPage,
							"typeId": tabItem.id,
						}
						request = that.$reqc.queryFIFA(datas)
						break;
					default:
						return;
						break;
				}
				// console.log('数据列表 请求参数：', datas);
				request.then(res => {
					// FIFA数据
					if (tabItem.id === 11 || tabItem.id === 12) {
						tabItem.total = res.data.data.total;
						tabItem.data = res.data.data.list || [];
					} else {
						tabItem.data = res.data || [];
					}
					
				}).catch(err => {
					console.log(err);
				})
			},
			
			// 选择分页
			changePage(e){
				// console.log("页面改变",e)
				that.initStatus = true; // 修改页面请求状态
				that.eventTypeList[that.tabCurrentIndex].currentPage = e;
				that.queryEventData(that.tabCurrentIndex);
			},
			
			// 切换tab标签
			handleClick(tab, event) {
				// console.log(tab.name, tab, event);
			},
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 1400px;
		height: auto;
		margin: 0 auto;
		margin-top: 10px;
		background-color: #F5F5F5;
		display: flex;
		flex-direction: column;
	}

	.main {
		color: #333333;
	}

	.match-type {
		display: flex;
		flex-wrap: wrap;
		padding: 6px 4px;
		background-color: #FFFFFF;
		font-size: 16px;

		.items {
			margin: 4px 4px;
			width: 108px;
			height: 100px;
			overflow: hidden;
			border: 1px solid #CCCCCC;
			cursor: pointer;
		}

		.active {
			border: 1px solid #FF5337;

			.item-name {
				color: #FFFFFF;
				background-color: #FF5337;
				border-bottom: 1px solid #FF5337;
			}
		}

		.item-name {
			height: 30px;
			line-height: 30px;
			border-bottom: 1px solid #CCCCCC;
		}

		.item-icon {
			height: 68px;
			display: flex;
			align-items: center;
			justify-content: center;

			img {
				min-width: 58px;
				height: 58px;
				display: block;
			}
		}
	}
	
	.match-data {
		padding: 0 18px 18px 18px;
		background-color: #FFFFFF;
		margin: 0 auto;
	}
	
	
	/deep/.el-tab-header {
		/* 标签项 */
		.el-tabs__item {
			background-color: rgba(245, 245, 245, 1);
		}
		.is-active {
		    color: rgba(52, 52, 52, 1);
			background-color: rgba(255, 255, 255, 1);
		}
		/* 底部选中条 */
		.el-tabs__active-bar {
			background-color: rgba(52, 52, 52, 1);
			display: none;
		}
	}
	
	
	.el-tab-pane {
		margin-top: 8px;
		border: 1px solid #CCCCCC;
	}
	
	.el-row {
		height: 34px;
		line-height: 34px;
		font-size: 12px;
		
		.title {
			color: #666666;
		}
		
		.team {
			display: flex;
			align-items: center;
			.teamLog {
				display: flex;
				justify-content: flex-end;
				padding-right: 0.5rem;
				
				img {
					min-width: 26px;
					max-width: 26px;
					height: 26px;
					display: block;
					border-radius: 50%;
				}
			}
			.teamName {
				display: flex;
				padding-left: 0.5rem;
				
				span {
					white-space: nowrap;
				}
			}
		}
	}
	.classify {
		font-size: 12px;
		padding: 10px 0;
	}
	
	.line {
		cursor: default;
		&:hover {
			background-color: rgba(255, 83, 55, .1);
		}
	}
	
	/* 分页 */
	.paging {
		margin: 2rem 0 1rem 0;
	}
	
	.explain {
		font-size: 14px;
		color: #999999;
		margin-top: 15px;
		text-align: left;
	}
	
	/* 赛事数据库 */
	/deep/#tab-database {
		background-color: rgba(255, 83, 55, 1);
		color: #FFFFFF;
		padding-left: 1.25rem !important;
		padding-right: 1.25rem !important;
	}
	/* 排名 */
	/deep/#tab-ranking {
		background-color: rgba(255, 83, 55, 1);
		color: #FFFFFF;
		padding-left: 1.25rem !important;
		padding-right: 1.25rem !important;
	}
	
</style>
