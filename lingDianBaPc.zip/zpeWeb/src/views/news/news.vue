<template>
	<div class="container">
		<AdSlot :AdName="'XW-1'" locationPosition="1" locationType="0" :adWidth="87.5" :adHeight="5.625" adStr="xw" style="margin:1rem 0"></AdSlot>
		<div class="news-layout">
			<div class="left">
				<crumbs :breadcumb="breadcumb"></crumbs>
				<unit-title-tag :tagType="0" :title="title"></unit-title-tag>
				<div class="main">
					<div class="column-left">
						<div class="tab-content">
							<ul class="newsList">
								<template v-if="!noData">
									<li v-for="(item, index) in tabData" :key="index">
										<div class="newlistContainer" @click="navTo(item)">
											<div class="left-content">
												<p class="title pointer">{{ item.newsTitle }}</p>
												<p class="content">{{ item.newsBrief }}</p>
												<p>{{ item.createdTime }}</p>
											</div>
											<img @error="errorImg($event, defaultImg)" :src="item.imgUrl ? item.imgUrl : require('../../static/image/default_img.png')" />
										</div>
										<!-- <AdSlot
											:AdName="'XWLB-1'"
											locationPosition="1"
											locationType="1"
											:adWidth="66.6875"
											:adHeight="3.75"
											adStr="xwlb"
											style="margin: 0.625rem 0"
										></AdSlot> -->
										<AdSlot
											v-if="index == advertisementSort"
											:AdName="'XWLB-1'"
											locationPosition="1"
											locationType="1"
											:adWidth="66.5"
											:adHeight="3.75"
											adStr="xw"
											style="margin: 0.625rem 0"
											@advIndex="advIndex"
										></AdSlot>
									</li>
								</template>
								<template v-if="noData">
									<div class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
								</template>
							</ul>
						</div>

						<template v-if="tabData.length">
							<div style="width: 100%;height:1.5rem"></div>
							<paging :total="total" @changePage="changePage" :pageSize="pageSize" :currentPage="currentIndex"></paging>
						</template>
					</div>
				</div>
			</div>
			<div class="right">
				<div class="column-right">
					<AdSlot :AdName="'XW-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="xw" style="margin:0 0 0.625rem 0"></AdSlot>
					<search-hot-match-player :hotMatchPlayer="hotMatchPlayer" title="最近直播" style="margin-top: 0.625rem;"></search-hot-match-player>
					<AdSlot :AdName="'XW-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="xw" style="margin: 0.625rem 0"></AdSlot>
				</div>
			</div>
		</div>
		<div class="footGG"></div>
	</div>
</template>

<script>
import unitTitleTag from '../../atemp/unit-title-tag.vue';
import unitRecentLive from '../../atemp/unit-recent-live.vue';
import paging from '../../atemp/paging.vue';

import searchHotMatchPlayer from '../../atemp/search-hot-match-player.vue';
const { log } = console;
let that;
export default {
	components: {
		unitTitleTag,
		unitRecentLive,
		paging,
		searchHotMatchPlayer
	},
	data() {
		return {
			defaultImg: require('../../static/image/default_img.png'), // 默认图片
			total: 10, //数据总条数
			tabCurrentIndex: 0, //默认选中第一个tab
			// tabData: ['NBA1016', '英超1016', '西甲1016', '法甲1016', '意甲1016', '德甲1016'],
			tabData: [],
			id: '',
			routerUrl: '',
			// 新闻标题列表
			newsIndex: {
				id: '', //对应的专题/赛事类型/项目id
				limit: 30, //加载条数
				offset: 1, //页数
				type: 5 //  1专题 2赛事类型 3热门 4完结 5全部
			},
			title: '全部',
			noData: false,

			breadcumb: {
				list: [{ name: '新闻', path: '' }, { name: '全部新闻', path: '' }]
			},
			tagObj: {
				id: '', // 标签id
				type: 5, // 标签类型 3热门 4完结 5全部
				name: '相关' // 标签名称
			},

			// 最近直播
			hotMatchPlayer: [],
			matchType: '',
			//传过来的名称
			cgname: '',
			//传过去的数据
			navItem: {},
			pageSize: 30, // 加载条数
			currentIndex: 1, // 当前页码
			advertisementSort: ''
		};
	},
	created: function(e) {
		that = this;
		that.routerUrl = that.$route.path;
		that.id = that.$route.params.id;
		let query = that.$route.query;
		let newsObj = JSON.parse(sessionStorage.getItem('newsObj'));
		if (newsObj) {
			that.navItem = newsObj;
		} else {
			if (query.data) {
				that.navItem = JSON.parse(query.data);
			} else {
				that.navItem = {
					id: '', // 标签id
					type: 5, // 标签类型 3热门 4完结 5全部
					name: '全部' // 标签名称
				};
			}
		}
		that.title = that.navItem.name;
		that.breadcumb.list[1].name = that.navItem.name + '新闻';
		that.newsIndex.id = that.navItem.id;
		that.newsIndex.type = that.navItem.type;
		that.newsIndex.limit = that.navItem.limit ? that.navItem.limit : 30;
		that.newsIndex.offset = that.navItem.offset ? that.navItem.offset : 1;
		that.currentIndex = that.navItem.currentIndex ? that.navItem.currentIndex : 1;
		that.queryNewsTitle(that.newsIndex);
		that.getHotMatchPlayer(); //最近直播
	},

	methods: {
		advIndex(i) {
			this.advertisementSort = i;
		},
		// 查询新闻标题列表
		queryNewsTitle(datas) {
			let newsObj = {
				currentIndex: that.currentIndex,
				name: that.title,
				id: that.newsIndex.id,
				limit: that.newsIndex.limit,
				offset: that.newsIndex.offset,
				type: that.newsIndex.type
			};
			sessionStorage.setItem('newsObj', JSON.stringify(newsObj));
			that.$newsReq.queryNewsTitle(datas).then(res => {
				// log(res.data, '===res查询新闻标题列表');
				let list = res.data.data.list;
				list.forEach(item => {
					item.newsBrief = item.newsContent.length > 10000 ? item.newsBrief : that.richTextFormat(item.newsContent, 50);
				});
				that.tabData = list;
				that.total = res.data.data.total;

				that.noData = list.length > 0 ? false : true;
			});
		},
		changePage(e) {
			// console.log('页面改变', e);
			that.currentIndex = e;
			that.newsIndex.offset = e;
			that.queryNewsTitle(that.newsIndex);
		},

		navTo(item) {
			let matchType = that.matchType;
			this.BR.navTo('/nDetail', {
				hid: 5,
				tid: 1,
				sid: 3,
				nid: item.id,
				navItem: JSON.stringify(that.navItem)
			});
		},
		//最近直播
		getHotMatchPlayer() {
			let date = new Date();
			let year = date.getFullYear(),
				month = date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1,
				today = date.getDate() < 10 ? `0${date.getDate()}` : date.getDate();
			let matchDate = `${year}-${month}-${today}`;
			that.$req
				.queryAllMatchList({
					date: matchDate, // 必须的
					id: '',
					limit: 9,
					livePlatform: '0',
					offset: 1,
					teamId: '',
					type: 5 //  0项目 1专题 2赛事类型 3热门 4完结 5全部 6球队
				})
				.then(res => {
					// log(res, '===>最近直播');
					that.hotMatchPlayer = res.data.data.list[0];
				});
		},
		// 正则过滤富文本
		richTextFormat(value, length = 50) {
			// value = value.replace(/<\/?[^>]*>/g,'')
			value = value.replace(/<\/?.+?>/g, '');
			value = value.replace(/\s+/g, '');
			if (value.length > 30) {
				return value.slice(0, length) + '...';
			}
			return value;
		}
	},
	watch: {
		$route: {
			handler() {
				let data,
					query = this.$route.query;

				if (query.data) {
					data = JSON.parse(this.$route.query.data);
				} else {
					data = {
						SN: '2',
						id: '',
						name: '全部',
						sort: 1,
						type: 5
					};
				}
				//改变一次就清除一次页面
				that.newsIndex.offset = 1;
				that.currentIndex = 1;
				that.navItem = data;

				that.newsIndex.id = that.navItem.id;
				that.newsIndex.type = that.navItem.type;
				that.title = that.navItem.name;
				that.breadcumb.list[1].name = that.navItem.name + '新闻';
				that.queryNewsTitle(that.newsIndex);
			},
			deep: true
		}
	},
	destroyed() {
		sessionStorage.removeItem('newsObj');
	}
};
</script>

<style lang="scss" scoped>
/* @import "../static/css/55-59.css"; */
/* @import "../static/css/app-2.css"; */
.container {
	// width: 1400px;
	width: 87.5rem;
	/* height: auto; */
	// min-height: 900px;
	min-height: 56.25rem;
	margin: 0 auto;
	background-color: #f5f5f5;
	display: flex;
	flex-direction: column;
}
.adv-crumbs {
	// border: 1px solid red;
	display: flex;
	justify-content: space-between;
	align-items: flex-start;
	.crumbs-unit {
		flex: 1;
	}
}
.main {
	display: flex;
	justify-content: space-between;
	// border: 1px solid red;
	// width:;
}

.column-left {
	// width: 1064px;
	width: 66.5rem;
	height: auto;

	.tab-content {
		height: auto;
		text-align: left;

		.newlistContainer {
			display: flex;
			justify-content: space-between;
			width: 100%;
			overflow: hidden;
			margin-bottom: 0.75rem;
			padding: 0.625rem;
			// font-size: 14px;
			font-size: 0.875rem;
			color: #999999;
			background-color: #ffffff;
			// box-shadow:0 0 10px rgba(0, 0, 0, .1);

			img {
				// min-width: 228px;
				// max-width: 228px;
				min-width: 14.25rem;
				max-width: 14.25rem;
				// height: 119px;
				height: 7.4375rem;
				border-radius: 0.375rem;
				display: block;
			}

			.title {
				// font-size: 18px;
				font-size: 1.1875rem;
				color: #333333;
				// /* 超出宽度后就隐藏 */
				// overflow: hidden;
				// /* 规定段落中的文本不换行 */
				// white-space:nowrap;
				// /* 当文本内容溢出时显示省略标记 */
				// text-overflow: ellipsis;
			}

			.content {
				// max-height: ;
				max-height: 2.375rem;
				overflow: hidden;
				font-size: 0.875rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(153, 153, 153, 1);
				line-height: 1.375rem;
				/* 规定段落中的文本不换行 */
				white-space: nowrap;
				/* 当文本内容溢出时显示省略标记 */
				text-overflow: ellipsis;
			}

			.left-content {
				width: calc(100% - 14.25rem);
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				// padding: 8px 26px 8px 8px;
				padding: 0.5rem 1.625rem 0.5rem 0.5rem;
				.title {
					font-weight: bold;
				}
				.content {
				}
			}
		}
	}

	/* .pageList {
			display: flex;
			justify-content: space-between;
			align-items: center;
			width: 392px;
			margin: 20px auto;
			font-size: 18px;
			color: #666666;
			
			li {
				width: 32px;
				height: 32px;
				line-height: 32px;
				border-radius: 50%;
				cursor: default;
			}
			li:hover:not(.active) {
				background-color: rgba(255, 83, 55, .3);
			}
			.active {
				color: #FFFFFF;
				background-color: #FF5337;
			}
		} */
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}

.news-layout {
	// border: 1px solid red;
	display: flex;
	flex-direction: row;
	justify-content: space-between;
	.left {
		width: 66.5rem;
	}
}
</style>
