<template>
	<div class="container">
		<div class="left">
			<AdSlot :AdName="'XWXQ-1'" locationPosition="1" locationType="0" :adWidth="66.5" :adHeight="3.75" adStr="xwxq" style="margin: 0.625rem 0 1rem"></AdSlot>
			<crumbs :breadcumb="breadcumb"></crumbs>
			<div class="content">
				<div class="column-left">
					<p class="title">{{ nDetail.newsTitle }}</p>
					<div class="attar">
						作者：零点八
						<span>{{ nDetail.createTime | timeFilters }}</span>
					</div>
					<div class="descBox" v-html="nDetail.newsContent"></div>
				</div>
			</div>
		</div>
		<div class="right">
			<AdSlot :AdName="'XWXQ-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="xwxq" style="margin: 0.625rem 0"></AdSlot>
			<!-- 相关新闻 -->
			<lx-detail-NBA-news :newsList="newsList" title="相关新闻" :isnavto="false" @isnavtolist="isnavtolist" :isMore="true"></lx-detail-NBA-news>
			<AdSlot :AdName="'XWXQ-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="xwxq" style="margin: 0.625rem 0"></AdSlot>
			<!-- 最近直播 -->
			<search-hot-match-player :hotMatchPlayer="hotMatchPlayer" title="最近直播"></search-hot-match-player>
		</div>
	</div>
</template>

<script>
import unitRelatedNews from '../../atemp/unit-related-news.vue';
import unitRecentLive from '../../atemp/unit-recent-live.vue';

import lxDetailNBANews from '../../atemp/lx-detail-NBA-news.vue';
import searchHotMatchPlayer from '../../atemp/search-hot-match-player.vue';
let that;
const { log } = console;
export default {
	components: {
		unitRelatedNews,
		unitRecentLive,
		lxDetailNBANews,
		searchHotMatchPlayer
	},
	data() {
		return {
			// desc: '<p>I believe I can fly</p><p>I believe I can fly</p>',
			desc: '',
			id: '',
			routerUrl: '',
			nDetail: {}, //新闻详情数据
			breadcumb: {
				list: [{ name: '新闻', path: '/news?hid=5' }, { name: '', path: '' }, { name: '', path: '' }]
			},
			newsList: [], // 新闻列表
			// 最近直播
			hotMatchPlayer: [],
			matchType: '',
			navItem: {}
		};
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		that.id = that.$route.params.nid;
		// console.log('*query*', that.$route.query);
		let query = that.$route.query;
		if (!query.navItem) {
			that.navItem = {
				id: '', // 标签id
				type: 5, // 标签类型 3热门 4完结 5全部
				name: '全部' // 标签名称
			};
		} else {
			that.navItem = JSON.parse(that.$route.query.navItem);
		}
		that.getQueryNewsContent(that.$route.query.nid);
		that.newsNBA(that.navItem.id, that.navItem.type);
		that.matchType = that.$route.query.matchType;
		that.getHotMatchPlayer();
		that.breadcumb.list[1] = {
			name: that.navItem.name,
			path: `/news?hid=5&sid=${that.navItem.SN}&data=${JSON.stringify(that.navItem)}`
		};
	},
	watch: {
		$route: {
			handler() {
				that.id = that.$route.query.id;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	methods: {
		getQueryNewsContent(newsId) {
			let datas = {
				newsId: newsId
			};
			// log(datas,"==>newsId")
			that.$newsReq.queryNewsContent(datas).then(res => {
				that.nDetail = res.data.data;

				that.breadcumb.list[2].name = that.nDetail.newsTitle;
			});
		},
		newsNBA(matchType, type) {
			that.$newsReq
				.queryNewsTitle({
					id: matchType,
					limit: 8,
					offset: 1,
					type: type
				})
				.then(res => {
					// log(res, '===>新闻');
					that.newsList = res.data.data.list;
				});
		},
		isnavtolist(obj) {
			that.getQueryNewsContent(obj.id);
			// that.breadcumb.list[1].name = obj.eventTypeName;
		},

		// 最近直播
		getHotMatchPlayer() {
			let date = new Date();
			let year = date.getFullYear(),
				month = date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1,
				today = date.getDate() < 10 ? `0${date.getDate()}` : date.getDate();
			let matchDate = `${year}-${month}-${today}`;
			// log(matchDate, '===>matchDate');
			that.$req
				.queryAllMatchList({
					date: matchDate, // 必须的
					id: '',
					limit: 9,
					livePlatform: '0',
					offset: 1,
					teamId: '',
					type: 5 //  0项目 1专题 2赛事类型 3热门 4完结 5全部 6球队
				})
				.then(res => {
					// log(res, '===>最近直播');
					that.hotMatchPlayer = res.data.data.list[0];
				});
		}
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${Y}-${M}-${D} ${h}:${m}`;
			}
		}
	}
};
</script>

<style lang="scss" scoped>
// .container {
// 	// width: 1400px;
// 	width: 87.5rem;
// 	/* min-height:900px; */
// 	height: auto;
// 	margin: 0 auto;
// 	margin-top: 10px;
// 	background-color: #f5f5f5;
// 	display: flex;
// 	justify-content: space-between;

// 	border: 1px solid red;
// }

.container {
	width: 87.5rem;
	display: flex;
	justify-content: space-between;
}

.content {
	width: 100%;
	display: flex;
	flex-direction: column;
	// justify-content: space-between;
}

.column-left {
	// width:;
	width: 66.5rem;
	/* height: auto; */
	height: 100%;
	background-color: #ffffff;
	// border: 1px solid red;
	// padding: 10px; //暂时添加
	padding: 1.375rem 2.3125rem;
	.title {
		// padding: 1.25rem 0 2.5rem 0; //暂时添加
		font-size: 1.625rem;
		font-family: Microsoft YaHei;
		font-weight: bold;
		color: rgba(51, 51, 51, 1);
		line-height: 1.75rem;
		padding: 1.375rem 0 1.25rem 0;
	}
	.attar {
		font-size: 0.875rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: #656565;
		line-height: 1.75rem;
		padding-bottom: 1.375rem;
		border-bottom: 0.0625rem solid #cccccc;
		margin-bottom: 2rem;
		span {
			margin-left: 0.625rem;
		}
	}
	.descBox {
		font-size: 0.875rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(102, 102, 102, 1);

		// line-height:40px;
		line-height: 2.5rem;

		text-align: left;

		text-indent: 2em;
	}
}
</style>
