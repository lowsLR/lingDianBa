<template>
	<div class="content">
		<div class="mainView">
			<img class="" src="../../static/main/phone.png" />

			<div class="dowView">
				<div class="dowImg"><img class="dowLogo" src="../../static/logo/logo.png" /></div>
				<div class="dowText">立即扫码安装APP 更多赛事尽在零点吧</div>
				<div class="dowMain">
					<div class="dowMainLeft">
						<div v-for="(item, index) in phoneVlist" :key="item.name" class="dowBut poinbut " @click="setPindex(index)" :class="index == pindex ? 'currentBut' : ''">
							{{ item.name }}
						</div>
					</div>
					<div class="dowMainRight"><qriously :value="qrcode" :size="200" /></div>
				</div>
				<div class="link">
					H5访问链接：
					<a :href="h5HomeUrl">{{ h5HomeUrl }}</a>
				</div>
			</div>
		</div>
		<div class="jc-bg">
			<div class="iso-tilp">
				<div class="tilp-l">
					<img src="../../static/image/ellery/sk.png" alt="" />
					<div class="tilp-contnet">
						<div class="tilp-title">IOS安装提示</div>
						<div class="tilp-text">安装后请按照以下教程添加信任</div>
					</div>
				</div>
				<div class="tilp-r">
					<div>关注公众号 更多精彩资讯</div>
					<img src="../../static/image/ellery/gzh.png" alt="" />
				</div>
			</div>
			<div class="instail-layout">
				<div class="up">
					<div>1. 点击ios下载，弹出如图 提示，点击[允许]</div>
					<div>2. 若出现如图提示，进入 第3步，否则进入第4步</div>
					<div>3. 打开[设置]，点击 [已下载描述文件]</div>
					<div>4. 一直点击[安装]按钮即可</div>
				</div>
				<div class="down">
					<img src="../../static/image/ellery/1.png" alt="" />
					<img src="../../static/image/ellery/2.png" alt="" />
					<img src="../../static/image/ellery/3.png" alt="" />
					<img src="../../static/image/ellery/4.png" alt="" />
				</div>
			</div>
		</div>
	</div>
</template>

<script>
let that;
export default {
	data() {
		return {
			h5HomeUrl: '', //h5跳转
			tabIndex: 1,
			id: '',
			routerUrl: '',
			phoneVlist: [{ name: 'iphone版', qrcode: '' }, { name: 'Android版', qrcode: '' }], //下载版本
			pindex: 1, //当前下标
			qrcode: 'http://8.129.19.0:8091/H5/index.html#/pages/mine/downloadApp'
			//'https://apps.apple.com/us/app/APP的包名/id+ID号?l=zh&ls=1' 	ios路径
		};
	},
	watch: {
		$route: {
			handler() {
				// console.log(this.$route.path);
				that.id = that.$route.query.id;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		//下载地址
		this.queryDownloadInfo();
	},
	methods: {
		setPindex(i) {
			if (that.pindex != i) {
				that.pindex = i;
				that.qrcode = that.phoneVlist[that.pindex].qrcode;
			}
		},
		queryDownloadInfo() {
			this.$newsReq.queryDownloadInfo().then(res => {
				console.log(res.data.data, '==>queryDownloadInfo');
				// h5DownloadUrl,//安卓下载
				// h5HomeUrl//h5跳转
				let data = res.data.data;
				this.h5HomeUrl = data.h5HomeUrl;
				this.qrcode = data.h5DownloadUrl;
				// 目前只有安卓，这里待修改
				this.phoneVlist.forEach(item => {
					item.qrcode = data.h5DownloadUrl;
				});
			});
		}
	}
};
</script>
<!-- <style>
	.footer{
		margin-top: 0 !important;
	}
</style> -->
<style lang="scss" scoped>
/* @import "../static/css/55-59.css"; */
/* @import "../static/css/app-2.css"; */
// /deep/.footer{
// 	margin-top: 0 !important;
// }
.content {
	width: 100%;
	min-height: 50rem;
	background: url(../../static/main/dowImg.png) no-repeat;
	background-size: 100%;
	/* 	background-size: cover;
		-webkit-background-size: cover;
		-o-background-size: cover; */
	// border: 1px solid red;
}

.mainView {
	/* width: 100%; */
	// min-height: 32em;
	height: 100%;
	position: relative;
	display: flex;
	justify-content: center;
	// border: 1px solid red;
	padding-top: 3.0625rem; //可能有变动
}
.dowView {
	// width: 100%;
	min-height: 30rem;
	// height: 32.1875rem;
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
	margin-left: 10.4375rem;
	/* background-color: #FFFFFF; */
}
.dowLogo {
	width: 21.3125rem;
	height: 6.6875rem;
}
.dowText {
	margin-top: 3.9375rem;
	margin-bottom: 1.4375rem;
	// margin-top: 1.875rem;
	font-size: 1.125rem;
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
	line-height: 1.5625rem;
}
.dowMain {
	// margin-top: 2.5625rem;
	width: 25rem;
	// height:18.75rem;
	// background-color: yellow;
	display: flex;
	align-items: center;
	justify-content: center;
}
.dowMainLeft {
	margin-right: 1.5625rem;
}
.dowBut {
	width: 10.375rem;
	height: 3.0625rem;
	border: 0.0625rem solid rgba(255, 255, 255, 1);
	border-radius: 1.5rem;
	display: flex;
	justify-content: center;
	align-items: center;
	font-size: 1.1875rem;
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
	line-height: 1.5rem;
}
.dowBut:nth-child(n + 2) {
	margin-top: 2.5rem;
}
.currentBut {
	background: rgba(255, 255, 255, 1);
	border: 0;
	color: rgba(51, 51, 51, 1) !important;
}

.mt40 {
	margin-top: 2.5rem;
}

.dowMainRight {
	margin-left: 1.5rem;
	width: 12.5rem;
	height: 12.5rem;
	background-color: #ffffff;
}
.link {
	min-width: 40rem;
	height: 3.125rem;
	border: 0.0625rem solid rgba(255, 255, 255, 1);
	border-radius: 1.5625rem;
	font-size: 1.25rem;
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
	line-height: 1.5625rem;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 4rem;
	display: flex;
	align-items: center;
	a {
		font-size: 1.25rem;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		line-height: 1.5625rem;
		color: #fff;
	}
}

.jc-bg {
	width: 100%;
	background: url(../../static/image/ellery/bg.png) no-repeat;
	background-size: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	flex-direction: column;
	// border: 1px solid red;
	// height: 61.25rem;
	margin-top: 1.875rem;
}
.iso-tilp {
	// width: 75.4375rem;//
	width: 87.5rem;
	// border: 1px solid red;
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-top: 7.875rem;
	.tilp-l {
		display: flex;
		img {
			width: 1.5rem;
			height: 4.875rem;
			margin-right: 1.5rem;
			// border: 1xp solid red;
			margin-top: -1.4375rem;
		}
		.tilp-contnet {
			// border: 1px solid red;
			text-align: left;
			.tilp-title {
				font-size: 2.25rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(0, 0, 0, 1);
				line-height: 1.5625rem;
				margin-bottom: 5.0625rem;
			}
			.tilp-text {
				font-size: 1.625rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(0, 0, 0, 1);
				line-height: 1.5625rem;
			}
		}
	}
	.tilp-r {
		div {
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(0, 0, 0, 1);
			line-height: 1.5625rem;
			margin-bottom: 0.625rem;
		}
		img {
			width: 8.875rem;
			height: 8.875rem;
		}
	}
}
.instail-layout {
	// width: 75.4375rem;//
	// border: 1px solid red;
	width: 81.5rem;
	display: flex;
	flex-direction: column;
	margin-top: 30px;
	padding-bottom: 40px;
	.up {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		div {
			width: 17.6875rem;
			font-size: 1.5rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			line-height: 2.1875rem;
			text-align: left;
			margin-bottom: 1.8125rem;
		}
	}
	.down {
		display: flex;
		align-items: center;
		justify-content: space-between;
		img {
			width: 17.6875rem;
			height: 31.375rem;
		}
	}
}
</style>
