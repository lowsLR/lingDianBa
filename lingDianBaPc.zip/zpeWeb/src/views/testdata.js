const test1 = [
	{
		time:"12月27日",
		week:'星期五',
		type:'直播节目表',
		listdata:[
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐']
			},
		]
	},
	{
		time:"12月27日",
		week:'星期五',
		type:'直播节目表',
		listdata:[
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
		]
	},
	{
		time:"12月27日",
		week:'星期五',
		type:'直播节目表',
		listdata:[
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
		]
	},
	{
		time:"12月27日",
		week:'星期五',
		type:'直播节目表',
		listdata:[
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
			{
				title:'足协杯第三轮',
				time:'03:30',
				ltype:'足球',
				lt:'陕西大秦之水',
				ln:0,
				li:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				rt:'新疆雪豹',
				rn:1,
				ri:'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1583143765506&di=d7f9d9e5fa47649a37e8931931902278&imgtype=0&src=http%3A%2F%2Fpic3.16pic.com%2F00%2F55%2F82%2F16pic_5582213_b.jpg',
				blist:['比分直播','文字直播','微信推荐','动画直播']
			},
		]
	}
	
	
]

const testteam = {
	title:'莫斯科迪纳摩队',
	list:[
		{id:1,type:'足球杯',time:'2020-12-12 03:30',zd:'陕西大秦之水',kd:'莫斯科迪纳摩队'},
		{id:2,type:'足球杯',time:'2020-12-12 03:30',zd:'莫斯科迪纳摩队',kd:'陕西大秦之水'},
		{id:3,type:'足球杯',time:'2020-12-12 03:30',zd:'陕西大秦之水',kd:'莫斯科迪纳摩队'},
		{id:4,type:'足球杯',time:'2020-12-12 03:30',zd:'莫斯科迪纳摩队',kd:'陕西大秦之水'},
		{id:5,type:'足球杯',time:'2020-12-12 03:30',zd:'陕西大秦之水',kd:'莫斯科迪纳摩队'},
	]
}
const testlx = {
	title:'莫斯科迪纳摩队',
	list:[
		{id:1,type:'足球杯',time:'2020-12-12 03:30',zd:'陕西大秦之水',kd:'莫斯科迪纳摩队'},
		{id:2,type:'足球杯',time:'2020-12-12 03:30',zd:'莫斯科迪纳摩队',kd:'陕西大秦之水'},
		{id:3,type:'足球杯',time:'2020-12-12 03:30',zd:'陕西大秦之水',kd:'莫斯科迪纳摩队'},
		{id:4,type:'足球杯',time:'2020-12-12 03:30',zd:'莫斯科迪纳摩队',kd:'陕西大秦之水'},
		{id:5,type:'足球杯',time:'2020-12-12 03:30',zd:'陕西大秦之水',kd:'莫斯科迪纳摩队'},
	]
}

const testfive = {
	title:'天下功夫',
	list:[
		{id:1,title:'WWE SmackDown 第1070期 天下足球 天下',time:'02-23'},
		{id:2,title:'WWE SmackDown 第1070期',time:'02-23'},
		{id:3,title:'WWE SmackDown 第1070期',time:'02-23'},
		{id:4,title:'WWE SmackDown 第1070期',time:'02-23'},
		{id:5,title:'WWE SmackDown 第1070期',time:'02-23'},
		{id:6,title:'WWE SmackDown 第1070期 天下足球-哈兰德：横空出世',time:'02-23'},
	]
	
}

const List10 = {
					num: 10,
					title: '热门新闻',
					list: [{
							id: 1,
							type: '1',
							time:'02-23',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 2,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 3,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 4,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 5,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 6,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 7,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 8,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 9,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
						{
							id: 10,
							time:'02-23',
							type: '1',
							stype: 'NBA',
							title: '02月24日凯尔特人vs湖人 录像集锦'
						},
					]
				}

const newsList = [
	{id:1,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容激发必杀技 哈登威少欲率队复仇',type:'NBA',time:'02-20 17:15'},
	{id:2,title:'常规赛视频直播',content:'火箭VS勇士 哈登威少欲率队复仇',type:'NBA',time:'02-20 17:15'},
	{id:3,title:'全明星直播',content:'詹姆斯队VS字母哥队 星光军团重磅来势',type:'NBA',time:'02-20 17:15'},
	{id:4,title:'全明星直播',content:'技巧三分＆扣篮大赛 视觉盛宴即将呈现',type:'NBA',time:'02-20 17:15'},
	{id:5,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容',type:'NBA',time:'02-20 17:15'},
	{id:6,title:'全明星新秀挑战赛直播',content:'世界联队VS美国联队 风云战再起',type:'NBA',time:'02-20 17:15'},
	{id:7,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容激发必杀技',type:'NBA',time:'02-20 17:15'},
	{id:8,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容激发必杀技 哈登威少欲率队复仇',type:'NBA',time:'02-20 17:15'},
	{id:9,title:'常规赛视频直播',content:'火箭VS勇士 哈登威少欲率队复仇',type:'NBA',time:'02-20 17:15'},
	{id:10,title:'全明星直播',content:'詹姆斯队VS字母哥队 星光军团重磅来势',type:'NBA',time:'02-20 17:15'},
	{id:11,title:'全明星直播',content:'技巧三分＆扣篮大赛 视觉盛宴即将呈现',type:'NBA',time:'02-20 17:15'},
	{id:12,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容',type:'NBA',time:'02-20 17:15'},
	{id:13,title:'全明星新秀挑战赛直播',content:'世界联队VS美国联队 风云战再起',type:'NBA',time:'02-20 17:15'},
	{id:14,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容激发必杀技',type:'NBA',time:'02-20 17:15'},
	{id:15,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容激发必杀技 哈登威少欲率队复仇',type:'NBA',time:'02-20 17:15'},
	{id:16,title:'常规赛视频直播',content:'火箭VS勇士 哈登威少欲率队复仇',type:'NBA',time:'02-20 17:15'},
	{id:17,title:'全明星直播',content:'詹姆斯队VS字母哥队 星光军团重磅来势',type:'NBA',time:'02-20 17:15'},
	{id:15,title:'全明星直播',content:'技巧三分＆扣篮大赛 视觉盛宴即将呈现',type:'NBA',time:'02-20 17:15'},
	{id:19,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容',type:'NBA',time:'02-20 17:15'},
	{id:20,title:'全明星新秀挑战赛直播',content:'世界联队VS美国联队 风云战再起',type:'NBA',time:'02-20 17:15'},
	{id:21,title:'常规赛直播',content:'火箭VS勇士 哈登威少携五小阵容激发必杀技',type:'NBA',time:'02-20 17:15'},
]


const explain = [
	{content:'* - 锁定季后赛   o - 无缘季后赛'},
	{content:'NBA排名规则'},
	{content:'球队在各自东西部联盟的名次将按照球队常规赛胜率由高向低依次排列。当两支或多支球队战绩相同时 ，将使用平分判定准则进行比较，具体规则如下：'},
	{content:'（一）. 当两支球队战绩相同时：'},
	{content:'1、 相互战绩；'},
	{content:'2、 分区冠军排在非分区冠军之前；'},
	{content:'3、 分区内战绩 (仅限两支球队在同一分区)；'},
	{content:'4、 本联盟内战绩；'},
	{content:'5、 对本联盟内季后赛球队的胜率 (包括战绩相同竞争季后赛席位的球队)；'},
	{content:'6、 对另一联盟内季后赛球队的胜率 (包括战绩相同竞争季后赛席位的球队)；'},
	{content:'7、 赛季总净胜分；'},
	{content:'8、 抽签决定。'},
	{content:'（二）. 当多支球队（3支以上）战绩相同时：'},
	{content:'1、 分区冠军排在非分区冠军之前；'},
	{content:'2、 涉及球队相互战绩；'},
	{content:'3、 分区内战绩 (仅限多支球队在同一分区)；'},
	{content:'4、 本联盟内战绩；'},
	{content:'5、 对本联盟内季后赛球队的胜率 (包括战绩相同竞争季后赛席位的球队)；'},
	{content:'6、 对另一联盟内季后赛球队的胜率 (包括战绩相同竞争季后赛席位的球队)；'},
	{content:'7、 赛季总净胜分；'},
	{content:'8、 抽签决定。'},
	{content:'确定好名次后东西部联盟各自前八名的球队进入季后赛，各联盟内第一名对阵第八名、第二名对阵第七名、依此类推。 季后赛（包括总决赛）对阵双方的主场优势由球队胜率来定，如果两支球队胜率相同，将按照 tie-break 中的 A 规则对两支球队进行比较，排名在前的获得主场优势。'},
]

export {
	test1,
	testteam,
	testlx,
	testfive,
	List10,
	newsList,
	explain
}