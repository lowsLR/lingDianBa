<template>
	<div class="main-body mt15">
		<div class="mainView">
			<!-- <div class="ggview"></div> -->
			<!-- 广告位 -->
			<AdSlot :AdName="'SY-1'" locationPosition="1" locationType="0" :adWidth="87.5" :adHeight="5.625" adStr="sy"></AdSlot>
			<div style="width: 100%;height: 1.5rem;"></div>
			<div class="mainView-content">
				<div class="column-left">
					<div class="main-top flex">
						<div class="main-top-left">
							<twoList pageType="2" ftitle="最新录像" :oneList="lxList1" :twoList="lxList2"></twoList>
						</div>
						<div class="main-top-right"><shuffling></shuffling></div>
					</div>

					<div style="width: 100%;height: 1.125rem;"></div>
					<!-- <div class="ggview"></div> -->
					<!-- 广告位 -->
					<AdSlot :AdName="'SY-2'" locationPosition="2" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="sy"></AdSlot>

					<div class="main-wrap">
						<div class="wrap-body">
							<div class="category main main-wrap-top">
								<div class="main-wrap-head"><span class="main-wrap-head-text">赛事直播列表</span></div>
								<div class="main-nav" style="flex: 1;">
									<div
										v-for="(item, index) in navList"
										:key="item.name + item.id + index"
										@click="setNav(item)"
										class="pointer"
										:class="[navIndex == item.id ? 'select-nav-div' : '']"
									>
										{{ item.name }}
									</div>
								</div>
								<div class="select-div">
									<el-dropdown trigger="click">
										<div class="el-dropdown-link pointer main-shaixuan">筛选</div>
										<el-dropdown-menu slot="dropdown">
											<div class="select-main-view">
												<div class="select-main-div flex flex-jc-fs" v-for="(item, index) in selectList" :key="index" v-if="item.list.length">
													<div class="select-item-left">{{ item.typeName }}：</div>
													<div class="select-item-right flex-1">
														<el-dropdown-item
															v-for="(items, indexs) in item.list"
															:key="items.SN + item.type + indexs"
															class="pointer"
															:class="[itemSN == items.SN ? 'is-acvtion' : '']"
															@click.native="setvalue(item.type, items)"
														>
															{{ items.name }}
														</el-dropdown-item>
													</div>
												</div>
											</div>
										</el-dropdown-menu>
									</el-dropdown>
								</div>
							</div>
							<!-- 首页赛事列表数据 -->
							<div v-if="liveEventList && liveEventList.length">
								<div class="bgw" style="width: 100%;height: 0.625rem;"></div>
								<liveList :liveEventList="liveEventList" :adFlag="adFlag"></liveList>
								<!-- 列表状态 -->
								<div class="prompt" v-if="has_log == 0">
									<!-- 滚动加载更多 -->
									<!-- <div class="loadMore"></div> -->
									<!-- 点击加载更多 -->
									<div class="loadMore" @click="handleLoadMore"></div>
								</div>
								<div class="prompt" v-if="has_log == 1">
									<!-- 正在加载... -->
									<div class="loading"></div>
								</div>
								<div class="prompt" v-if="has_log == 2">
									<!-- 没有更多数据了 -->
									<div class="noMoreData">没有更多数据了</div>
								</div>

								<!-- <paging :currentPage="offset" :total="total" @changePage="changePage"></paging> -->
							</div>
							<dataLoading :list="liveEventList" height="35rem"></dataLoading>
						</div>
					</div>
				</div>
				<div class="column-right">
					<!-- 首页十条数据  -->
					<onelist :pageType="5" :oneList="newsData" ftitle="热点新闻" :isTime="false"></onelist>

					<div style="width: 100%;height: 1.5rem;"></div>

					<!-- 搜索框 -->
					<searchView></searchView>

					<div style="width: 100%;height: 1.125rem;"></div>
					<!-- <div class="ggview"></div> -->
					<!-- 广告位 -->
					<AdSlot :AdName="'SY-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="16.25" adStr="sy"></AdSlot>

					<div style="width: 100%;height: 0.9375rem;"></div>
					<!-- 热门频道 -->
					<channel pageType="4"></channel>

					<div style="width: 100%;height: 0.9375rem;"></div>
					<!-- 天下功夫 -->
					<fiveList :fiveList="txgfList" ftitle="天下功夫"></fiveList>
					<div style="width: 100%;height: 0.9375rem;"></div>
					<!-- 广告位 -->
					<AdSlot :AdName="'SY-4'" locationPosition="4" locationType="0" :adWidth="19.875" :adHeight="5.625" adStr="sy"></AdSlot>
					<div style="width: 100%;height: 0.9375rem;"></div>
					<fiveList :fiveList="zjkqList" ftitle="专家看球" :isTime="true"></fiveList>
					<!-- 篮球积分排行 -->
					<!-- <ranking></ranking> -->
					<div style="width: 100%;height: 1.125rem;"></div>
					<!-- <div class="ggview"></div> -->
				</div>
			</div>
			<div class="footGG"></div>
		</div>
		<!-- 回到顶部 -->
		<div class="backToTop" v-if="showRocket" @click="handleToTop"></div>
	</div>
</template>

<script>
import onelist from '../../atemp/list-one.vue';
import shuffling from '../../atemp/shuffling.vue';
import channel from '../../atemp/channel.vue';
import ranking from '../../atemp/ranking.vue';
import liveList from '../../atemp/live-list.vue';
import twoList from '../../atemp/list-two.vue';
import fiveList from '../../atemp/list-five.vue';
import searchView from '../../atemp/search.vue';
import paging from '../../atemp/paging.vue';
import dataLoading from '../../a-ellery/data-loading.vue'
let that;
export default {
	components: {
		onelist,
		shuffling,
		channel,
		ranking,
		liveList,
		twoList,
		fiveList,
		searchView,
		paging,
		dataLoading
	},
	data() {
		return {
			// isLod: true, //加载中。。。
			itemSN: '',
			newsData: {}, //新闻数据
			navIndex: 1,
			isStretch: true,
			isshow: false,
			activeName: '东部',
			tabIndex: 1,
			id: '',
			routerUrl: '',
			selectList: [], //首页筛选
			lxList1: [], //最新足球录像
			lxList2: [], //最新篮球录像
			txgfList: [], //天下功夫
			zjkqList: [], //专家看球
			oneList: {
				num: 5,
				title: '最新录像',
				list: []
			},
			dataimg: [
				{
					src: require('../../static/image/222.jpg'),
					txt: '同仇敌忾！克洛普力挺瓜帅怒批圣诞赛程'
				},
				{
					src: require('../../static/image/222.jpg'),
					txt: '同仇敌忾！克洛普力挺瓜帅怒批圣诞赛程'
				},
				{
					src: require('../../static/image/222.jpg'),
					txt: '同仇敌忾！克洛普力挺瓜帅怒批圣诞赛程'
				}
			],
			navList: [
				{ id: 1, name: '全部', type: 5 },
				{ id: 5, name: '热门', type: 3 },
				{ id: 2, name: '足球', type: 0, eid: '3' },
				{ id: 3, name: '篮球', type: 0, eid: '4' },
				{ id: 4, name: '其他', type: 7 }
			],

			matchType: 5,
			matchDate: '2020-03-01',
			matchId: '',
			teamId: 0,
			eid: '',

			liveEventList: [], // 直播列表数据
			limit: 20, // 每次请求条数
			offset: 1, // 请求页数
			total: 10, //总条数

			has_log: 0, // 0加载前 1加载中 2没有更多数据了
			showRocket: false, // 显示火箭
			adFlag: true //首页广告记录是否显示
		};
	},
	watch: {
		$route: {
			handler() {
				that.id = that.$route.query.id || 0;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		let query = that.$route.query;
		that.teamId = query.teamId || 0;
		// 是否显示友情链接
		that.$store.commit('setFriendLink', true);

		// 获取首页左上角最新录像
		that.getQueryMatchByVideo();

		that.getQueryConfigByKey(6);
		that.queryNewsTitle();
		that.tianxiagongfu();
		that.zhuanjiakanqiu();

		that.$nextTick(() => {
			that.getQueryAllMatchList();
		});

		// 监听页面（手动）刷新
		window.addEventListener('beforeunload', that.refreshToTop);

		// 监听（绑定）滚轮滚动事件
		window.addEventListener('scroll', that.onScroll);
	},
	destroyed: () => {
		// 离开页面清除（移除）页面（手动）刷新事件
		window.removeEventListener('beforeunload', that.refreshToTop);

		// 离开页面清除（移除）滚轮滚动事件
		window.removeEventListener('scroll', that.onScroll);

		that.$store.commit('setFriendLink', false);
	},
	methods: {
		// 页面刷新返回顶部
		refreshToTop: function() {
			window.scrollTo(0, 0);
		},
		// 滚动加载分页
		onScroll: function() {
			// scrollTop 滚动条滚动时，距离顶部的距离
			let scrollTop = ~~(document.documentElement.scrollTop || document.body.scrollTop);
			// windowHeight 可视区的高度
			let windowHeight = ~~(document.documentElement.clientHeight || document.body.clientHeight);
			// scrollHeight 滚动条的总高度
			// let scrollHeight = ~~(document.documentElement.scrollHeight || document.body.scrollHeight);
			let scrollHeight = document.querySelector('#app').clientHeight;
			// console.log(scrollTop,windowHeight,scrollHeight);

			// 是否显示火箭
			that.showRocket = scrollTop > 1000 ? true : false;

			// 加载更多, 滚动条到底部的条件
			/* if (scrollTop + windowHeight >= scrollHeight - 200 && that.has_log == 0) {
				that.has_log = 1;
				// 加载数据
				that.offset++;
				// console.log('页数:',that.offset);
				that.getQueryAllMatchList();
			} */
		},

		// 点击加载更多
		handleLoadMore() {
			if (that.has_log == 0) {
				that.has_log = 1;
				// 加载数据
				that.offset++;
				// console.log('页数:',that.offset);
				that.getQueryAllMatchList();
			}
		},

		// 查看首页赛事
		getQueryAllMatchList() {
			let time = that.BW.returnNowTime('YYYY-MM-DD');
			let datas = {
				date: time,
				id: that.eid,
				limit: that.limit,
				livePlatform: that.livePlatform,
				offset: that.offset,
				teamId: that.teamId,
				type: that.matchType
			};
			that.BW.queryAllMatchList(datas)
				.then(res => {
					// console.log('查看首页赛事', res);
					that.total = res.total;
					let list = res.list[0] || [];
					// console.log(list,"===>list")
					// list[0].sportMatchVOS[1].isLive = "1";
					// list[0].sportMatchVOS[1].isHighlights = "0";
					// list[0].sportMatchVOS[1].matchTextLivePath = "www.baidu.com";
					// list[0].sportMatchVOS[1].matchProspect = 'xxxx';
					// list[0].sportMatchVOS[1].eventScorePath = 'xxxaaaaa';
					// 赛事日期相同的数据合并
					if (that.liveEventList.length > 0) {
						let TempArr = that.liveEventList[that.liveEventList.length - 1];
						// console.log(TempArr, that.liveEventList.length);
						let date = TempArr.dateString;
						list.forEach((item, index) => {
							if (item.dateString == date) {
								that.liveEventList[that.liveEventList.length - 1].sportMatchVOS = TempArr.sportMatchVOS.concat(list[index].sportMatchVOS);
								list.splice(index, 1);
								// console.log('相同日期数据:', that.liveEventList[that.liveEventList.length-1].sportMatchVOS);
							}
						});
						// console.log(list,"===>list")
					} else {
						// setTimeout(() => {
						// 	that.isLod = false;
						// 	if(that.liveEventList.length){
						// 		that.isLod = true;
						// 	}
						// }, 300);
						// console.log("zhixing========")
					}

					// 数据合并
					that.liveEventList.push.apply(that.liveEventList, list);
					// console.log(that.liveEventLis,"===>？？？？")
					// 请求状态修改(末页判断)
					that.has_log = res.isLastPage ? 2 : 0;
					// console.log(that.has_log);

					that.$forceUpdate();
				})
				.catch(err => {});
		},

		// 返回顶部
		handleToTop() {
			window.scrollTo(0, 0);

			// let timer = setInterval(function() {
			// 	let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
			// 	let ispeed = Math.floor(-scrollTop / 10);
			// 	// console.log(ispeed)
			// 	if (scrollTop == 0) {
			// 		clearInterval(timer);
			// 	}
			// 	document.documentElement.scrollTop = document.body.scrollTop = scrollTop + ispeed;
			// }, 15);
			// // 离开页面清除定时器
			// that.$once('hook:beforeDestroy', () => {
			// 	clearInterval(timer);
			// });
		},

		// 首页赛事列表分页
		changePage(e) {
			that.offset = e;
			that.getQueryAllMatchList();
		},

		setNav(item) {
			if (that.navIndex == item.id) {
				return;
			}
			// console.log(item,"===>>>setNav")
			that.adFlag = item.name == '全部' ? true : false;
			that.navIndex = item.id;
			that.matchType = item.type;
			that.eid = item.eid || '';
			that.itemSN = item.SN;
			that.offset = 1;
			that.$nextTick(() => {
				// 直播列表标签导航切换时，清空原赛事项目/专题/类型 的数据
				that.liveEventList = [];
				that.getQueryAllMatchList();
			});
		},
		setvalue(type, item) {
			// console.log(type, item);
			that.adFlag = item.name == '全部' ? true : false;
			that.navIndex = 1;
			that.matchType = 5;
			that.eid = '';
			that.itemSN = '';

			that.eid = item.id;
			that.matchType = type;
			that.matchId = item.matchId;
			that.itemSN = item.SN;
			that.$nextTick(() => {
				// 筛选切换时，清空原赛事项目/专题/类型 的数据
				that.liveEventList = [];
				that.getQueryAllMatchList();
			});
		},

		navTo(url, data) {
			that.$router.push({
				path: url,
				params: data,
				query: data
			});
		},
		handleClick(tab, event) {},

		//查看首页筛选数据
		getQueryConfigByKey(index) {
			that.$req
				.queryConfigByKey({
					configKey: that.$params.configKey[index]
				})
				.then(res => {
					// console.log("查看首页筛选数据",res);
					if (res.status == 200 && res.data.resultCode == 1) {
						let list = [];
						that.selectList = res.data.data;
					}
				});
		},

		// 获取最新录像
		getQueryMatchByVideo: function() {
			let datas = {
				limit: 10,
				offset: 1
			};
			that.$reqc
				.webQueryMatchListByVideo(datas)
				.then(res => {
					// console.log("查看最新录像",res);
					if (res.status == 200 && res.data.resultCode == 1) {
						// console.log(res.data.data);
						that.lxList1 = res.data.data.footBallVideoList;
						that.lxList2 = res.data.data.basketballVideoList;
					} else {
						// console.log(res.data.data);
					}
				})
				.catch(err => {
					console.log(err);
				});
		},

		// 查询新闻标题列表
		queryNewsTitle(datas) {
			that.$newsReq
				.queryNewsTitle({
					limit: 10,
					offset: 1
				})
				.then(res => {
					// console.log(res.data, '===res查询新闻标题列表');
					if (res.data.resultCode == 1) {
						let list = [],
							arr = res.data.data.list;
						arr.forEach((item, index) => {
							list.push({
								id: item.id,
								type: '5',
								time: item.createdTime,
								eventName: item.eventName,
								eventTypeName: item.eventTypeName,
								title: item.newsTitle
							});
						});

						that.newsData = {
							num: 10,
							type: 5,
							list: list
						};
						that.$forceUpdate();
					}
					// let list = res.data.data.list;
					// that.tabData = list;
					// that.total = res.data.data.total;

					// that.noData = list.length > 0 ? false : true;
				});
		},

		// 天下功夫
		tianxiagongfu() {
			let datas = {
				limit: 5,
				offset: 1
			};
			that.$req
				.tianxiagongfu(datas)
				.then(res => {
					// console.log("天下功夫数据",res)
					if (res.status == 200 && res.data.resultCode == 1) {
						let list = res.data.data.list || [];
						list.forEach(item => {
							item.matchBeginTimeStr = that.BW.splitTimeZH(item.matchBeginTime);
						});
						that.txgfList = list;
					}

					that.$forceUpdate();
				})
				.catch(err => {});
		},

		// 专家看球
		zhuanjiakanqiu() {
			let datas = {
				limit: 5,
				offset: 1
			};
			that.$req
				.zhuanjiakanqiu(datas)
				.then(res => {
					// console.log("专家看球数据",res)
					if (res.status == 200 && res.data.resultCode == 1) {
						// that.zjkqList = res.data.data.list;
						let list = res.data.data.list || [];
						list.forEach(item => {
							item.matchBeginTimeStr = that.BW.splitTimeZH(item.matchBeginTime);
						});
						that.zjkqList = list;
					}
					that.$forceUpdate();
				})
				.catch(err => {});
		}
	}
};
</script>

<style lang="scss" scoped>
// .lod {
// 	background: #ffffff;
// 	display: flex;
// 	align-items: center;
// 	justify-content: center;
// 	height: 35rem;
// 	position: relative;
// 	overflow: hidden;
// 	img {
// 		width: 30rem;
// 		height: 30rem;
// 	}
// 	.txt {
// 		color: #333333;
// 		font-size: 1.875rem;
// 		position: absolute;
// 		z-index: 10;
// 	}
// }
.main-shaixuan {
	font-size: 1.125rem;
	font-weight: 300;
	color: rgba(101, 101, 101, 1);
	line-height: 2.8125rem;
}
.mainView {
	/* width: 100%; */
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	flex-direction: column;
}
.mainView-content {
	flex: 1;
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	position: relative;
}
.height366 {
	height: 22.875rem;
}

.pl-wrap {
	text-align: left;
}

.hot-wrap {
	width: 100%;
}

.main-top-left {
	// width: 19.875rem;
	width: 25rem; // 400px
}

.main-top-right {
	flex: 1;
}

.main-wrap-top {
	display: flex;
	justify-content: space-between;
	align-items: center;
	border-bottom: 0.125rem solid rgba(27, 27, 48, 1);
}

.main-wrap-head {
	// width: 9.375rem;
	// height: 100%;
	// text-align: left;

	font-size: 1.375rem;
	// font-family:Microsoft YaHei;
	font-weight: bold;
	color: rgba(27, 27, 48, 1);
	line-height: 1.75rem;
}
.main-wrap-head-text {
	padding-left: 0.75rem;
}
.main-wrap-head::before {
	content: '';
	width: 0.375rem;
	height: 1.625rem;
	background: $bg-main;
	position: absolute;
}
.select-div {
	display: flex;
	align-items: center;
	// margin-right: 1.25rem;
	width: 6.25rem;
	justify-content: center;

	font-size: 1.125rem;
	font-weight: 400;
	color: rgba(102, 102, 102, 1);
	line-height: 1.75rem;

	margin-left: 6.25rem;
}
.select-div .el-dropdown {
	width: 5rem !important;
	height: 2.125rem;
	display: flex;
	align-items: center;
	justify-content: center;
}
.select-main-view {
	width: 40rem;
	ol,
	ul,
	li {
		display: inline-block;
		list-style: none;
		margin: 0;
	}
}
/* .select-main-div:not(:last-child) {
	border-bottom: 0.0625rem dashed rgba(153, 153, 153, 1);
	padding-bottom: 0.9375rem;
} */
.select-main-div {
	border-bottom: 0.0625rem dashed rgba(153, 153, 153, 1);
	padding: 0.5rem 0;

	&:last-child {
		border: 0;
		padding-bottom: 0;
	}
	&:first-child {
		padding-top: 0;
	}
}

.select-item-right {
	// display: flex;
	// justify-content: flex-start;
	// align-items: flex-start;
	// flex-direction: column;
}
.select-item-left {
	width: 5.75rem;
	text-align: center;
	line-height: 2.25rem;
	font-weight: bold;
	// color: rgba(51, 51, 51, 1);
	color: #000000;
	cursor: default;
}

.main-nav {
	flex: 1;
	display: flex;
	justify-content: center;
	align-items: center;
	margin-left: 2.2rem;
}
.main-nav > div {
	flex: 1;
	// height: 2.75rem;
	display: flex;
	justify-content: center;
	align-items: center;
	position: relative;

	font-size: 1.125rem;
	font-weight: 300;
	color: rgba(101, 101, 101, 1);
	line-height: 2.8125rem;
}
.select-nav-div {
	// color:$bg-chengse !important;
	color: $bg-main !important;
	font-weight: 600 !important;
}
// .select-nav-div::after{
// 	content: "";
// 	position: absolute;
// 	bottom: 0;
// 	left: 0;
// 	width: 100%;
// 	height: 0.3125rem;
// 	background-color: rgba(27, 27, 48, 1);
// }

/* 赛事列表底部提示 */
.prompt {
	display: flex;
	justify-content: center;
	align-items: center;
	width: 100%;
	height: 5rem;
	font-size: 1.25rem;
	color: #999999;
	cursor: default;
	/* background-color: rgba(255, 83, 55, .1); */

	/* 加载更多 */
	.loadMore {
		display: flex;
		width: 15rem; // 240px
		height: 3.125rem; // 50px
		background-image: url(../../static/image/load_more.png);
		background-size: 41.5px 22px;
		background-repeat: no-repeat;
		background-position: center bottom;

		&::before {
			content: '点击加载更多';
			width: 100%;
			height: 1.75rem; // 28px
			font-size: 1.125rem;
		}
	}

	/* 加载中 */
	.loading {
		width: 12.5rem; // 200px
		height: 1.125rem; // 18px
		background-size: cover;
		background-image: url(../../static/image/loading.gif);
	}

	/* 没有更多数据了 */
	.noMoreData {
		display: flex;
		align-items: center;
		&::before,
		&::after {
			content: '';
			width: 12.5rem;
			height: 1px;
			background-color: #999999;
			display: inline-block;
			margin: 0 1rem;
		}
	}
}

/* 火箭 */
.backToTop {
	position: fixed;
	bottom: 350px;
	right: 50px;
	width: 100px;
	height: 100px;
	background-image: url(../../static/image/backToTop_def.png);
	background-size: cover;

	&:hover {
		background-image: url(../../static/image/backToTop_active.png);
	}
}
</style>
