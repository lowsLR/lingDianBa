<template>
	<div class="mt15" style="margin: 0;">
		<div class="mainView">
			<AdSlot :AdName="'SS-1'" locationPosition="1" locationType="0" :adWidth="90" :adHeight="5.625" adStr="ss" style="margin: 0.625rem 0"></AdSlot>
			<div class="mainView-layout">
				<div class="nows">
					<div class="lx-div">
						<!-- 面包屑 -->
						<crumbs :breadcumb="breadcumb"></crumbs>
						<div class="search-detail-main">
							<div class="search-div">
								<el-select v-model="valueTitle" placeholder="请选择">
									<el-option v-for="item in selectList" :key="item.title" :label="item.title" :value="item.title"></el-option>
								</el-select>
								<div class="search-input"><el-input placeholder="请输入内容" v-model="inputVal" @keyup.enter.native="searchTap" clearable></el-input></div>
								<div class="search-but poinbut" @click="searchTap">零点搜索</div>
							</div>
						</div>
						<div class="totalView">系统搜索到相关{{ valueTitle }}{{ total }}个</div>
					</div>
					<div style="width: 100%;height: 1.375rem;"></div>
					<div class="mainView-content">
						<div class="column-left">
							<div class="lx-div">
								<div v-if="selectIndex == 0">
									<!-- 直播 -->
									<lx-list :livelist="livelist" v-if="isflag" viedeoType="zb"></lx-list>
									<div style="width: 100%;height:1.5rem"></div>
								</div>
								<div v-if="selectIndex == 1">
									<!-- 录像 -->
									<lx-list :livelist="livelist" :videotapeFlag="true" v-if="isflag"></lx-list>
									<div style="width: 100%;height:1.5rem"></div>
								</div>
								<div v-if="selectIndex == 2">
									<!-- 新闻 -->
									<searchNews :searchNewsList="searchNewsList" v-if="isflag"></searchNews>
									<div style="width: 100%;height:1.5rem"></div>
								</div>
								<div v-if="selectIndex == 3">
									<!-- 电台 -->
									<search-tv :searchTv="searchTv" :tvlistnNum="1" v-if="isflag"></search-tv>
									<div style="width: 100%;height:1.5rem"></div>
								</div>
								<div v-if="selectIndex == 4">
									<!-- 视频 -->
									<unit-video-list :videoList="videoList" v-if="isflag" :searchVideo="true"></unit-video-list>
									<div style="width: 100%;height:1.5rem"></div>
								</div>
								<div v-if="selectIndex == 5">
									<div class="noSearch">
										<div class="no-top">很抱歉，没有搜索到您想要的内容！</div>
										<div class="no-tip">您可以回到顶部重新发起搜索</div>
									</div>
								</div>
								<div class="" v-if="selectIndex !== 5">
									<paging :total="total" @changePage="changePage" :currentPage="currentPage" :pageSize="pageSize"></paging>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="column-right">
					<!-- <div v-if="selectIndex == 0"><unit-recent-live></unit-recent-live></div> -->
					<div v-if="selectIndex == 0">
						<AdSlot :AdName="'SS-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin:0 0 0.625rem 0"></AdSlot>
						<search-hot-match-player :hotMatchPlayer="hotMatchPlayer" title="热门赛事直播" :isMore="false" v-if="isflag"></search-hot-match-player>
						<AdSlot :AdName="'SS-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin: 0.625rem 0"></AdSlot>
					</div>

					<div v-if="selectIndex == 1">
						<AdSlot :AdName="'SS-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin:0 0 0.625rem 0"></AdSlot>
						<lx-video-hot-list ftitle="热门赛事录像" :oneList="oneList" :isTime="true" :isMore="false" v-if="isflag"></lx-video-hot-list>
						<AdSlot :AdName="'SS-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin: 0.625rem 0"></AdSlot>
					</div>

					<div v-if="selectIndex == 2">
						<AdSlot :AdName="'SS-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin:0 0 0.625rem 0"></AdSlot>
						<lx-detail-NBA-news :newsList="newsList" title="热点新闻" :isMore="false" v-if="isflag"></lx-detail-NBA-news>
						<AdSlot :AdName="'SS-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin: 0.625rem 0"></AdSlot>
					</div>
					<div v-if="selectIndex == 4">
						<AdSlot :AdName="'SS-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin:0 0 0.625rem 0"></AdSlot>
						<hot-video-list :isMore="false" :hotVideos="hotVideos" v-if="isflag"></hot-video-list>
						<AdSlot :AdName="'SS-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin: 0.625rem 0"></AdSlot>
					</div>

					<div v-if="selectIndex == 3">
						<AdSlot :AdName="'SS-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin:0 0 0.625rem 0"></AdSlot>
						<!-- 热门频道 -->
						<channel pageType="4" v-if="isflag"></channel>
						<div style="width: 100%;height: 1.5rem;"></div>
						<!-- 天下功夫 -->
						<fiveList :fiveList="txgfList" ftitle="天下功夫" v-if="isflag"></fiveList>
						<div style="width: 100%;height: 1.5rem;"></div>
						<!-- 专家看球 -->
						<fiveList :fiveList="zjkqList" ftitle="专家看球" :isTime="true" v-if="isflag"></fiveList>
						<AdSlot :AdName="'SS-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="11.8125" adStr="ss" style="margin: 0.625rem 0"></AdSlot>
					</div>

					<div style="width: 100%;height: 1.375rem;"></div>
					<!-- <div class="ggview"></div> -->
				</div>
			</div>
		</div>

		<div class="footGG"></div>
	</div>
</template>

<script>
import lxList from '../../atemp/lx-list.vue';
import onelist from '../../atemp/list-one.vue';
import paging from '../../atemp/paging.vue';
import unitRecentLive from '../../atemp/unit-recent-live.vue';
import unitRelatedNews from '../../atemp/unit-related-news.vue';
import searchNews from '../../atemp/search-news.vue';
import unitVideoList from '../../atemp/unit-video-list.vue';
import searchTv from '../../atemp/search-tv.vue';
import searchHotMatchPlayer from '../../atemp/search-hot-match-player.vue';
import lxVideoHotList from '../../atemp/lx-video-hot-list.vue';
import lxDetailNBANews from '../../atemp/lx-detail-NBA-news.vue';
import hotVideoList from '../../atemp/hot-video-list.vue';
import channel from '../../atemp/channel.vue';
import fiveList from '../../atemp/list-five.vue';
let that;
const { log } = console;
export default {
	components: {
		lxList,
		onelist,
		paging,
		unitRecentLive,
		unitRelatedNews,
		searchNews,
		unitVideoList,
		searchTv,
		searchHotMatchPlayer,
		lxVideoHotList,
		lxDetailNBANews,
		hotVideoList,
		channel,
		fiveList
	},
	data() {
		return {
			total: 100, //数据总条数
			breadcumb: {
				list: [{ name: '搜索', path: '' }]
			},
			stitle: '全部',
			timevalue: '',
			sindex: 0,
			id: '',
			routerUrl: '',
			slist: ['全部', 'NBA', '英超', '西甲', '法甲', '意甲', '欧洲杯', '中超', '欧冠杯', '欧罗巴杯', '亚洲预选', 'CBA', '澳洲杯', '韩K联'],
			value: 1,
			valueStr: '直播',
			inputVal: '',
			selectList: [{ id: 1, title: '直播' }, { id: 2, title: '录像' }, { id: 3, title: '新闻' }, { id: 4, title: '电视' }, { id: 5, title: '视频' }],
			selectIndex: 0,
			actions: {
				search_1: () => {
					that.searchMatch();
				},
				search_2: () => {
					that.searchMatchListByVideo();
				},
				search_3: () => {
					that.searchNewsTitle();
				},
				search_4: () => {
					that.queryLikeTvName();
				},
				search_5: () => {
					that.searchLiveTitle();
				},
				search_6: () => {
					that.searchMatch();
				}
			},
			// 赛事搜索数据
			livelist: [],

			valueTitle: '直播',

			// 视频数据
			videoList: [],

			// 当前页码
			currentPage: 1,

			//每页显示条数
			pageSize: 10,

			//搜索新闻数据
			searchNewsList: [],

			//搜索电台数据
			searchTv: [],

			// 热门赛事直播
			hotMatchPlayer: [],

			//热门赛事录像
			oneList: {},

			// 热点新闻
			newsList: [],

			//热门视频
			hotVideos: [],

			//天下功夫
			txgfList: [],

			//专家看球
			zjkqList: [],
			isflag: true
		};
	},
	watch: {
		$route: {
			handler() {
				// console.log(this.$route.path);
				// that.id = that.$route.query.id||0;
				// console.log('子页获取vuex数据', that.$store.state);
				that.id = that.$route.query.sid || 0;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		},
		valueTitle(newStr, oldStr) {
			if (newStr !== oldStr) {
				// log(newStr, '===>变化了');
				that.valueTitleChange(newStr);
			}
		}
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		let query = that.$route.query;
		let records = JSON.parse(sessionStorage.getItem('searchRecords'));
		let index;
		if (records) {
			that.valueTitleChange(records.valueTitle);
			that.inputVal = records.inputVal;
			index = that.selectList.findIndex(item => item.title == records.valueTitle);
		} else {
			that.valueTitleChange(query.val);
			that.inputVal = query.inputVal;
			index = that.selectList.findIndex(item => item.title == query.val);
		}
		that.valueTitle = that.selectList[index].title;
		that.setSearchReq(that.value);
		that.selectIndex = index;
		// 热门赛事直播
		that.getHotMatchPlayer();
		//热门赛事录像
		that.getHotVideo();
		//热点新闻
		that.getHotNews();
		//热门视频
		that.getHotVideos();
		//天下功夫
		that.tianxiagongfu();
		// 专家看球
		that.zhuanjiakanqiu();
	},
	methods: {
		// 监测搜索框文字的选项变化
		valueTitleChange(newStr) {
			switch (newStr) {
				case '直播':
					that.value = 1;

					break;
				case '录像':
					that.value = 2;

					break;
				case '新闻':
					that.value = 3;

					break;
				case '电视':
					that.value = 4;

					break;
				case '视频':
					that.value = 5;

					break;
				case '无':
					that.value = 6;

					break;
			}
		},
		// 专家看球
		zhuanjiakanqiu() {
			let datas = {
				limit: 5,
				offset: 1
			};
			that.$req
				.zhuanjiakanqiu(datas)
				.then(res => {
					// console.log('专家看球数据', res);
					if (res.status == 200 && res.data.resultCode == 1) {
						// that.zjkqList = res.data.data.list;
						let list = res.data.data.list || [];
						list.forEach(item => {
							item.matchBeginTimeStr = that.BW.splitTimeZH(item.matchBeginTime);
						});
						that.zjkqList = list;
					}
					that.$forceUpdate();
				})
				.catch(err => {});
		},
		//天下功夫
		tianxiagongfu() {
			let datas = {
				limit: 5,
				offset: 1
			};
			// console.log("请求前查看",datas)
			that.$req
				.tianxiagongfu(datas)
				.then(res => {
					// console.log('天下功夫数据', res);
					if (res.status == 200 && res.data.resultCode == 1) {
						let list = res.data.data.list || [];
						list.forEach(item => {
							item.matchBeginTimeStr = that.BW.splitTimeZH(item.matchBeginTime);
						});
						that.txgfList = list;
					}

					that.$forceUpdate();
				})
				.catch(err => {});
		},

		/*搜索*/
		searchTap() {
			// console.log('当前选择', that.value);
			// console.log('当前搜索', that.inputVal);
			//按下搜索就记录一次当前的value和inputVal;
			let searchObj = { valueTitle: that.valueTitle, inputVal: that.inputVal };
			// log(searchObj,"===>searchObj")
			sessionStorage.setItem('searchRecords', JSON.stringify(searchObj));
			// 搜索一次清除默认
			that.currentPage = 1;
			that.pageSize = 10;
			that.selectIndex = that.selectList.findIndex(item => item.id == that.value);
			that.valueStr = that.selectList[that.selectIndex].title;
			that.setSearchReq(that.value);
		},
		setSearchReq(i) {
			that.actions[`search_${i}`].call(this);
			this.$nextTick(() => {
				// that.inputVal = '';
			});
		},

		//搜索赛事
		searchMatch() {
			// log('我现在点击的是搜索赛事==>', that.inputVal);
			that.$req
				.searchMatch({
					limit: 10,
					offset: that.currentPage,
					searchKey: that.inputVal
				})
				.then(res => {
					// console.log('查看搜索赛事==>', res);
					let resdata = res.data.data;

					if (resdata.total < 1) {
						that.selectIndex = 5;
						that.total = 0;
						that.isflag = false;
					} else {
						that.isflag = true;
						that.total = resdata.total;
						log(resdata.list[0][0], '===>resdata.list');
						let arr = [];
						// resdata.list[0].forEach(items => {
						// 	// log(items.sportMatchVOS,"===>这是什么？")
						// 	items.sportMatchVOS.forEach(item => {
						// 		arr.push(item);
						// 	});
						// });
						// log(arr, '===>arr');
						resdata.list[0][0].sportMatchVOS.forEach(item => {
							arr.push(item);
						});
						that.addisclick(arr);
						//添加一些标识再传过去
					}
				});
		},
		addisclick(arr) {
			let newArr = [];
			arr.forEach(item => {
				if (item.matchStartState == 0) {
					item.isClick = 'true';
				} else if (item.matchStartState == 1) {
					item.isClick = 'false';
				} else {
					if (item.matchLiveSourceDOS.length < 1) {
						item.isClick = 'false';
					} else {
						item.matchLiveSourceDOS.forEach(items => {
							if (items.sourceType == '1') {
								item.isClick = 'true';
							} else {
								item.isClick = 'false';
							}
						});
					}
				}
				newArr.push(item);
			});
			that.livelist = newArr;
			log(that.livelist, '===>lxxx');
		},
		//搜索视频
		searchLiveTitle() {
			// log('我现在点击的是搜索视频');
			that.$req
				.searchLiveTitle({
					limit: 9,
					offset: that.currentPage,
					searchKey: that.inputVal
				})
				.then(res => {
					// console.log('查看搜索视频', res);
					let resdata = res.data.data;
					if (resdata.total < 1) {
						that.total = 0;
						that.selectIndex = 5;
						that.isflag = false;
					} else {
						that.isflag = true;
						that.videoList = resdata.list;
						that.total = resdata.total;
						that.pageSize = 9;
					}
				});
		},
		//搜索有录像的赛事
		searchMatchListByVideo() {
			// log('我现在点击的是搜索有录像的赛事');
			that.$req
				.searchMatchListByVideo({
					limit: 10,
					offset: that.currentPage,
					searchKey: that.inputVal
				})
				.then(res => {
					// console.log('查看搜索有录像的赛事', res);

					let resdata = res.data.data;
					// log(resdata.list, '===>录像');
					if (resdata.total < 1) {
						that.total = 0;
						that.selectIndex = 5;
						that.isflag = false;
					} else {
						that.isflag = true;
						that.total = resdata.total;
						that.livelist = resdata.list;
						// that.pageSize = 10;
					}
				});
		},
		//模糊查询电视台
		queryLikeTvName() {
			that.$newsReq
				.queryLikeTvName({
					limit: 24,
					offset: that.currentPage,
					tvName: that.inputVal
				})
				.then(res => {
					// console.log('查看模糊查询电视台', res);
					let resdata = res.data.data;
					if (resdata.total < 1) {
						that.total = 0;
						that.selectIndex = 5;
						that.isflag = false;
					} else {
						that.isflag = true;
						that.total = resdata.total;
						that.searchTv = resdata.list;
						that.pageSize = 24;
					}
				});
		},
		//搜索新闻列表
		searchNewsTitle() {
			// log(that.currentPage, '===>搜索新闻列表currentPage');
			that.$req
				.searchNewsTitle({
					limit: 20,
					offset: that.currentPage,
					searchKey: that.inputVal
				})
				.then(res => {
					// console.log('查看搜索新闻列表', res);
					let resdata = res.data.data;

					if (resdata.total < 1) {
						that.total = 0;
						that.selectIndex = 5;
						that.isflag = false;
					} else {
						that.isflag = true;
						that.total = resdata.total;
						that.searchNewsList = resdata.list;
						// log(that.newsList, '===>that.newsList');
						that.pageSize = 20;
					}
				});
		},
		changePage(e) {
			// console.log('页面改变', e);
			that.currentPage = e;
			that.setSearchReq(that.value);
		},
		setindex(i) {
			if (that.sindex != i) {
				that.sindex = i;
			}
		},
		formatTime(e) {
			// console.log(e);
		},
		sizeChange(e) {
			// console.log('每页条数', e);
		},
		currentChange(e) {
			// console.log('当前页', e);
		},
		prevClick(e) {
			// console.log('上一页', e);
		},
		nextClick(e) {
			// console.log('下一页', e);
		},

		// 热门赛事直播
		getHotMatchPlayer() {
			let date = new Date();
			let year = date.getFullYear(),
				month = date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1,
				today = date.getDate() < 10 ? `0${date.getDate()}` : date.getDate();
			let matchDate = `${year}-${month}-${today}`;
			that.$req
				.queryAllMatchList({
					date: matchDate, // 必须的
					id: '',
					limit: 9,
					livePlatform: '0',
					offset: 1,
					teamId: '',
					type: 3 //  0项目 1专题 2赛事类型 3热门 4完结 5全部 6球队
				})
				.then(res => {
					// log(res, '===>热门赛事直播');
					that.hotMatchPlayer = res.data.data.list[0];
					//这模板需要修改
					// log(that.hotMatchPlayer, '===>热门赛事直播');
				});
		},
		// 热门赛事录像
		getHotVideo() {
			that.$newsReq
				.queryMatchByVideo({
					matchDate: '',
					id: '',
					limit: 16,
					offset: 1,
					isRecommend: 0,
					sourceType: 1
				})
				.then(res => {
					// log(res.data.data, '===>res');
					that.oneList = res.data.data;
					// log(that.oneList, '===>oneList');
				});
		},
		// 热点新闻
		getHotNews() {
			that.$newsReq
				.queryNewsTitle({
					// id: '39',
					limit: 26,
					offset: 1,
					type: 3
				})
				.then(res => {
					// log(res, '===>新闻');
					that.newsList = res.data.data.list;
				});
		},
		// 热门视频
		getHotVideos() {
			that.$reqc
				.queryLiveTitle({
					id: '',
					limit: 16,
					offset: 1,
					type: 3
				})
				.then(res => {
					// log(res, '===>热门视频');
					that.hotVideos = res.data.data.list;
				});
		}
	},
	destroyed() {
		sessionStorage.removeItem('searchRecords');
	}
};
</script>

<style lang="scss" scoped>
/* @import "../static/css/55-59.css"; */
/* @import "../static/css/app-2.css"; */

// .mainView {
// 	width: 100%;
// 	min-height: 32em;
// 	display: flex;
// 	justify-content: center;
// }
.noSearch {
	width: 87.5rem;
	height: 33.375rem;
	background: rgba(255, 255, 255, 1);
	padding: 3.125rem;
	font-weight: 400;
	text-align: left;
	.no-top {
		font-size: 1.75rem;
		color: rgba(51, 51, 51, 1);
		line-height: 3.1875rem;
	}
	.no-tip {
		font-size: 1.25rem;
		color: rgba(102, 102, 102, 1);
		line-height: 3.1875rem;
	}
}
.mainView {
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	flex-direction: column;
}
.mainView-top {
	display: flex;
	width: 100%;
	// border: 1px solid red;
	align-items: center;
	> div {
		flex: 1;
	}
}
.mainView-content {
	flex: 1;
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	position: relative;
}
.lx-div {
	// width: 100%;
	// width: 1400px;
	flex: 1;
	display: flex;
	flex-direction: column;
	.totalView {
		width: 100%;
		text-align: left;
		font-size: 0.875rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		line-height: 1.75rem;
		margin-top: 0.625rem;
	}
	/deep/.search-detail-main {
		width: 38.875rem;
		height: auto;
		.search-div {
			flex: 1;
			height: 2.125rem;
			display: flex;
			border: 0.0625rem solid rgba(255, 83, 55, 1);
			border-top-right-radius: 1.0625rem;
			border-bottom-right-radius: 1.0625rem;
			// border-radius:17px;
			align-items: center;
			position: relative;
			background-color: $bg-white;
			.el-dropdown {
				flex: 1;
				// height: 34px;
			}
			.el-select {
				width: 5rem;
				.el-input__icon {
					line-height: 1.3;
				}
			}

			.search-but {
				width: 5rem;
				height: 2.125rem;
				background: rgba(255, 83, 55, 1);
				font-size: 0.75rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(255, 255, 255, 1);
				line-height: 1.75rem;
				display: flex;
				justify-content: center;
				align-items: center;
				border-top-right-radius: 1.0625rem;
				border-bottom-right-radius: 1.0625rem;
				white-space: nowrap;
			}
			.search-input {
				flex: 2;
				display: flex;
				align-items: center;
				input {
					height: 2.125rem !important;
					border: 0 !important;
					background-color: transparent;
					width: 100%;
					padding: 0;
				}
			}
		}
	}

	.nav-main {
		display: flex;
		justify-content: space-between;
		align-items: center;
		flex: 1;
		// height: 50px;
		border-radius: 1.6875rem;
		flex-wrap: nowrap;

		.el-data-css {
			// width: 140px;
			// flex: 1;
			// margin-left: 20px;
			height: 2.1875rem;
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(255, 255, 255, 1);
			line-height: 1.75rem;
			margin-right: 2.125rem;
			// background:rgba(255,255,255,1);
			.el-date-editor.el-input,
			.el-date-editor.el-input__inner {
				height: 100%;
				display: flex;
				align-items: center;
			}
			input {
				/* width: 152px; */
				background: rgba(27, 27, 48, 1);
				color: rgba(255, 255, 255, 1);
				// border-top-right-radius: 27px;
				// border-bottom-right-radius: 27px;

				border-radius: 1.6875rem;
				height: 100%;
			}
		}

		.nav-list {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			// width:45px;
			// height:22px;
			font-size: 1.375rem;
			font-weight: bold;
			color: $bg-main;
			line-height: 1.75rem;
			position: relative;
			span {
				margin-left: 1.375rem;
			}
			&:before {
				content: '';
				width: 0.375rem;
				height: 1.625rem;
				background: $bg-main;
				position: absolute;
			}
		}
		.nav-view,
		.select-view {
			width: 5.5rem;
			// height: 50px;
			font-size: 18px;
			font-family: Microsoft YaHei;
			font-weight: 400;
			line-height: 3.125rem;
		}
		div:first-child {
			border-top-left-radius: 1.6875rem;
			border-bottom-left-radius: 1.6875rem;
		}
		div:last-child {
			border-top-right-radius: 1.6875rem;
			border-bottom-right-radius: 1.6875rem;
		}
		.nav-view {
			color: rgba(51, 51, 51, 1);
		}
		.select-view {
			color: rgba(255, 255, 255, 1);
			background: rgba(27, 27, 48, 1);
		}
	}
}
[v-cloak] {
	display: none !important;
}

.mainView-layout {
	width: 90rem;
	display: flex;
	align-items: flex-start;
	justify-content: space-between;
}
</style>
