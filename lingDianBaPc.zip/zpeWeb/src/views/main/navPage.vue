<template>
	<div class="mainView ">
		<div class="mt15">
			<!-- <div>预留广告位</div> -->
			<div class="nav-view">
				<div class="nav-top flex">
					<div class="column-left">
						<!-- 广告位 -->
						<AdSlot :AdName="'EJ-1'" locationPosition="1" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="ejfl"></AdSlot>
						<div style="height: 15px;width: 100%;"></div>

						<div class="nav-main">
							<div class="nav-list">
								<span>{{ title }}</span>
							</div>
							<!-- <div class="el-data-css">
								<el-date-picker 
								prefix-icon="datePickerImage"
								:editable="false"
								@change="formatTime" 
								v-model="timevalue" 
								value-format="yyyy-MM-dd"
								align="center"
								type="date" placeholder="选择日期"
								:picker-options="pickerOptions">
								</el-date-picker>
							</div> -->
							<!-- 选择日期 -->
							<el-date-picker @formatTime="formatTime" ref="elPicker"></el-date-picker>
						</div>
						<div style="height: 15px; width: 100%;"></div>
						<div style="background:rgba(27,27,48,1);height: 2px;width: 100%;"></div>

						<div v-if="liveEventList[0] && liveEventList[0].length">
							<liveList :liveEventList="liveEventList[0]"></liveList>
							<paging :total="total" @changePage="changePage"></paging>
						</div>
						<div v-else class="nodataDiv"></div>
						<div style="width: 100%;height: 0.9375rem;"></div>
						<div class="matchIntroduceClass">
							<img v-if="matchLogo" :src="matchLogo" />
							<div :class="[matchIntroduce.length < 250 ? 'lheight' : '']">{{ matchIntroduce }}</div>
						</div>
					</div>
					<div class="column-right">
						<!-- 广告位 -->
						<AdSlot :AdName="'EJ-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="ejfl"></AdSlot>
						<div style="height: 15px; width: 100%;"></div>
						<!-- 相关新闻 -->
						<!-- <unit-related-news 
						:newsList="newsList" 
						:eventTypeName="navItem.name"
						v-if="newsList.length"
						></unit-related-news> -->
						<unit-related-news :newsList="newsList" :eventTypeName="navItem.name"></unit-related-news>

						<!-- 广告位 -->
						<AdSlot :AdName="'EJ-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="ejfl"></AdSlot>
						<div style="height: 15px; width: 100%;"></div>

						<!-- <onelist v-if="remenLX.length" ftitle="热门赛事录像" :oneList="remenLX" :isTime="true"></onelist> -->

						<!-- <remenLX 
						v-if="remenLX.length" 
						:pageType="2"
						:ftitle="navItem.name + '录像'"
						:list="remenLX" 
						:isTime="true"></remenLX> -->
						<remenLX :pageType="2" :ftitle="navItem.name + '录像'" :list="remenLX" :isTime="true"></remenLX>

						<div style="height: 15px; width: 100%;"></div>

						<!-- 积分排行 -->
						<ranking :rankType="rankType"></ranking>

						<div style="width: 100%;height: 18px;"></div>
					</div>
				</div>
				<!-- <div class="nav-content">

				</div> -->
			</div>
			<div style="width: 100%;height: 0.9375rem;"></div>
			<!-- 广告位 -->
			<!-- <AdSlot :AdName="'EJ-4'"></AdSlot> -->
			<!-- <div>预留广告位</div> -->
			<div class="footGG"></div>
		</div>
	</div>
</template>

<script>
import liveList from '../../atemp/live-list.vue';
import unitRelatedNews from '../../atemp/unit-related-news.vue';
import ranking from '../../atemp/ranking.vue';
import onelist from '../../atemp/list-one.vue';
import remenLX from '../../atemp/remenLX.vue';
import elDatePicker from '../../a-ellery/el-data-layout.vue';

import paging from '../../atemp/paging.vue';
var that;
export default {
	components: {
		liveList,
		unitRelatedNews,
		ranking,
		onelist,
		remenLX,
		paging,
		elDatePicker
	},
	data() {
		return {
			id: 1,
			title: '足球',
			timevalue: '',
			hid: 1,
			navItem: {},
			matchType: 5,
			matchId: '',
			limit: 10,
			offset: 1,
			teamId: 0,
			total: 10, //总条数
			liveEventList: [],
			rankType: {}, //积分类型
			newsList: [], //相关新闻
			remenLX: [], //热门赛事录像
			// matchIntroduce:'',
			matchLogo: '', //赛事简介logo
			matchIntroduce: '', //赛事简介
			pickerOptions: {
				disabledDate(time) {
					return time.getTime() > Date.now();
				},
				shortcuts: [
					{
						text: '今天',
						onClick(picker) {
							picker.$emit('pick', new Date());
						}
					},
					{
						text: '昨天',
						onClick(picker) {
							const date = new Date();
							date.setTime(date.getTime() - 3600 * 1000 * 24);
							picker.$emit('pick', date);
						}
					},
					{
						text: '一周前',
						onClick(picker) {
							const date = new Date();
							date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
							picker.$emit('pick', date);
						}
					}
				]
			}
		};
	},
	watch: {
		$route: {
			handler() {
				this.$refs.elPicker.clearboth();
				let query = this.$route.query;
				this.hid = query.hid;
				this.navItem = JSON.parse(query.data);
				this.title = this.navItem.name || '足球';
				that.getQueryAllMatchList();
				that.getQueryNewsTitle();
				that.getQueryMatchListByVideo();
				that.rankType = that.returnRankType(this.navItem);
				that.queryIntroduce();
			},
			deep: true
		}
	},
	created: function() {
		that = this;
		let query = this.$route.query;
		this.hid = query.hid;
		this.navItem = JSON.parse(query.data);
		this.title = this.navItem.name || '足球';
		that.getQueryAllMatchList();
		that.getQueryNewsTitle();
		that.getQueryMatchListByVideo();
		that.rankType = that.returnRankType(this.navItem);
		that.queryIntroduce();
	},
	mounted() {
	},
	onReady() {},
	mounted: function() {},
	methods: {
		/*查看赛事简介*/
		queryIntroduce: function() {
			let datas = {
				id: that.navItem.id,
				type: that.navItem.type
			};
			that.$req.queryIntroduce(datas).then(res => {
				// console.log("查看赛事简介：",res);
				if (res.status == 200 && res.data.resultCode == 1) {
					// that.matchIntroduce = res.data.data;
					that.matchLogo = res.data.data.logo;
					that.matchIntroduce = res.data.data.introduce;
				}
			});
		},

		/*返回积分调用类型*/
		returnRankType(navItem) {
			let arrZ = ['足球'];
			let indexZ = arrZ.indexOf(navItem.name);
			if (navItem.name == '足球') {
				return { req: 'queryFIFA', index: 0, name: '足球' };
			}
			let arrN = ['篮球', 'NBA', 'CBA'];
			let indexN = arrN.indexOf(navItem.name);
			if (indexN != -1) {
				return { req: 'queryBasketball', index: 0, name: arrN[indexN] };
			}
			let arrX = ['西甲', '意甲', '英超', '德甲', '欧冠', '法甲'];
			let indexX = arrX.indexOf(navItem.name);
			if (indexX != -1) {
				return { req: 'queryIntegral', index: indexX + 5, name: arrX[indexX] };
			}
			return { req: '', index: 0 };
		},
		// 新闻列表
		getQueryNewsTitle: function() {
			let datas = {
				id: that.navItem.id,
				limit: 14,
				offset: 1,
				type: that.navItem.type
			};
			that.$reqc.queryNewsTitle(datas).then(res => {
				// console.log("新闻列表：",res);
				if (res.status == 200 && res.data.resultCode == 1) {
					that.newsList = res.data.data.list || [];
					that.$forceUpdate();
				}
			});
		},

		formatTime(e) {
			this.timevalue = e;
			that.getQueryAllMatchList();
		},
		changePage(e) {
			that.offset = e;
			that.getQueryAllMatchList();
		},
		/*查看录像*/
		getQueryMatchListByVideo(op) {
			return new Promise((resolve, reject) => {
				let time = that.BW.returnNowTime('YYYY-MM-DD');
				let datas = {
					// "date": time,
					// "limit": 10,
					// "livePlatform": that.livePlatform,
					// "offset": 1,
					// "sourceType":'1',

					eventId: that.navItem.type == 0 ? that.navItem.id : '', // 项目id
					eventTypeId: that.navItem.type == 2 ? that.navItem.id : '',
					limit: 10,
					offset: 1,
					sourceType: 1
				};
				// console.log('录像请求参数：', datas);
				that.BW.queryMatchByVideo(datas).then(res => {
					// console.log( '查询热门录像',res);
					let arr = res.list || [];
					arr.forEach((item, index) => {
						item.matchBeginTimeStr = that.BW.splitTimeZH(item.matchBeginTime);
					});
					let arr2 = arr.filter(item => item.homeTeamId && item.guestTeamId);
					that.remenLX = arr2;
					resolve();
				});
			});
		},
		getQueryAllMatchList() {
			let time = that.BW.returnNowTime('YYYY-MM-DD');
			let datas = {
				date: that.timevalue ? that.timevalue : time,
				id: that.navItem.id,
				limit: that.limit,
				livePlatform: that.livePlatform,
				offset: that.offset,
				teamId: that.teamId,
				type: that.navItem.type
			};
			that.BW.queryAllMatchList(datas).then(res => {
				// console.log("查看首页所有赛事数据",res);
				that.total = res.total;
				let list = res.list || [];
				that.liveEventList = list;
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.matchIntroduceClass {
	width: 100%;
	height: 10.5rem;
	background: rgba(27, 27, 48, 1);

	font-size: 0.75rem;
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
	line-height: 1.25rem;
	// padding: 1.0625rem;
	padding: 0.625rem;
	display: flex;
	justify-content: center;
	align-items: center;
	img {
		width: 9rem;
		height: 9rem;
	}
	div {
		flex: 1;
		padding-left: 0.625rem;
		text-align: left;
	}

	.lheight {
		line-height: 1.75rem;
		// color: red;
	}
}

/deep/.nav-view {
	flex: 1;

	.nav-top {
		flex: 1;

		.nav-main {
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex: 1;
			// height: 50px;
			// border-radius: 27px;
			flex-wrap: nowrap;

			// border-bottom:1px solid rgba(27,27,48,1);
			// .el-data-css {
			// 	height: 2.125rem;
			// 	// border: 1px solid red;
			// 	.el-date-editor.el-input,
			// 	.el-date-editor.el-input__inner {
			// 		height: 100%;
			// 		display: flex;
			// 		align-items: center;
			// 		// width: 150px;
			// 		// width: 8.4375rem;
			// 		// border:1px solid red;
			// 		background: rgba(27, 27, 48, 1);
			// 		border-radius: 1.0625rem;

			// 		min-width: 7.875rem !important;
			// 		max-width: 8.75rem !important;
			// 	}
			// 	.el-input__inner {
			// 		cursor: pointer;
			// 		// font-size: 0.625rem !important;
			// 		font-family: Microsoft YaHei;
			// 		font-weight: 400;
			// 		color: rgba(255, 255, 255, 1);
			// 		// width: 8.4375rem;
			// 		// border: 1px solid red;
			// 		text-align: center;

			// 		&::placeholder {
			// 			font-size: 1rem;
			// 			// font-size: 8px !important;
			// 			color: rgba(255, 255, 255, 1) !important;
			// 		}

			// 		&::-webkit-input-placeholder {
			// 			/* WebKit browsers 适配谷歌 */
			// 			font-size: 1rem;
			// 			color: rgba(255, 255, 255, 1);
			// 		}

			// 		&:-moz-placeholder {
			// 			/* Mozilla Firefox 4 to 18 适配火狐 */
			// 			font-size: 1rem;
			// 			color: rgba(255, 255, 255, 1);
			// 		}
			// 		&:-moz-input-placeholder {
			// 			/* Mozilla Firefox 4 to 18 适配火狐 */
			// 			font-size: 1rem;
			// 			color: rgba(255, 255, 255, 1);
			// 		}
			// 		&:-ms-input-placeholder {
			// 			/* Internet Explorer 10+  适配ie*/
			// 			font-size: 1rem;
			// 			color: rgba(255, 255, 255, 1);
			// 		}
			// 	}
			// 	input {
			// 		/* width: 152px; */
			// 		background: rgba(27, 27, 48, 1);
			// 		color: rgba(255, 255, 255, 1);
			// 		// border-top-right-radius: 27px;
			// 		// border-bottom-right-radius: 27px;

			// 		border-radius: 1.6875rem;
			// 		height: 100%;
			// 		// border: 1px solid red;
			// 	}
			// }

			.nav-list {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				// width:45px;
				// height:22px;
				font-size: 1.375rem;
				font-weight: bold;
				color: $bg-main;
				line-height: 1.75rem;
				position: relative;

				span {
					margin-left: 22px;
				}

				&:before {
					content: '';
					width: 0.375rem;
					height: 1.625rem;
					background: $bg-main;
					position: absolute;
				}
			}

			.nav-view,
			.select-view {
				width: 5.5rem;
				// height: 50px;
				font-size: 1.125rem;
				font-family: Microsoft YaHei;
				font-weight: 400;
				line-height: 3.125rem;
			}

			div:first-child {
				border-top-left-radius: 27px;
				border-bottom-left-radius: 27px;
			}

			div:last-child {
				border-top-right-radius: 27px;
				border-bottom-right-radius: 27px;
			}

			.nav-view {
				color: rgba(51, 51, 51, 1);
			}

			.select-view {
				color: rgba(255, 255, 255, 1);
				background: rgba(27, 27, 48, 1);
			}
		}
	}
	.nav-content {
		flex: 1;
		padding: 24px;
		background-color: $bg-white;
		margin-top: 24px;
	}
}
</style>
