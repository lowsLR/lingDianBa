<template>
	<div class="mt15" style="margin: 0;">
		<div class="mainView">
			<AdSlot :AdName="'LX-1'" locationPosition="1" locationType="0" :adWidth="87.5" :adHeight="5.625" adStr="lx" style="margin: 0.625rem 0;"></AdSlot>
			<div class="mainView-flex">
				<div class="left">
					<div class="mainView-top">
						<div class="lx-div">
							<!-- 面包屑 -->
							<crumbs :breadcumb="breadcumb"></crumbs>
							<div class="nav-main">
								<div class="nav-list">
									<span>{{ stitle }}</span>
								</div>
								<!-- 选择日期 -->
								<el-date-picker @formatTime="formatTime" ref="elPicker"></el-date-picker>
							</div>
						</div>
						<!-- <div class="ggview"></div> -->
					</div>
					<div style="width: 100%;height: 1.375rem;"></div>
					<div class="mainView-content">
						<div class="column-left">
							<div class="lx-div">
								<div>
									<!-- <div style="width: 100%;height: 15px;"></div> -->
									<lx-list :livelist="livelist" :videotapeFlag="true" :navItem="navItem"></lx-list>
									<div style="width: 100%;height:1.5rem"></div>
									<div class="">
										<template v-if="total">
											<paging :total="total" @changePage="changePage" :currentPage="currentIndex" :pageSize="pageSize"></paging>
										</template>
										<template v-else>
											<div class="nodata"><nodata fontSize="1rem" color="#666666"></nodata></div>
										</template>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="right">
					<div class="column-right" v-if="templateIndex == 0">
						<AdSlot :AdName="'LX-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="lx" style="margin: 0 0 0.625rem 0;"></AdSlot>
						<lx-video-hot-list ftitle="热门赛事录像" :oneList="oneList" :isTime="true" :isMore="false"></lx-video-hot-list>
						<AdSlot :AdName="'LX-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="lx" style="margin:0.625rem 0 0 0;"></AdSlot>
						<div style="width: 100%;height: 1.375rem;"></div>
						<!-- <div class="ggview"></div> -->
					</div>

					<div class="column-right" v-if="templateIndex == 1">
						<AdSlot :AdName="'LX-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="lx" style="margin: 0 0 0.625rem 0;"></AdSlot>
						<!-- 球队筛选 -->
						<team-selection :ranksList="ranksList"></team-selection>
						<AdSlot :AdName="'LX-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="lx" style="margin:-1.25rem 0 0.625rem 0"></AdSlot>
						<!-- 搜索框 -->
						<searchView :selectList="selectList"></searchView>
						<!-- <div class="ggview"></div> -->
					</div>
				</div>
			</div>
		</div>
		<div class="footGG"></div>
	</div>
</template>

<script>
import lxList from '../../atemp/lx-list.vue';
import onelist from '../../atemp/list-one.vue';
import paging from '../../atemp/paging.vue';
import lxVideoHotList from '../../atemp/lx-video-hot-list.vue';
import teamSelection from '../../atemp/team-selection';
import searchView from '../../atemp/search.vue';
import elDatePicker from '../../a-ellery/el-data-layout.vue';

let that;
const { log } = console;
export default {
	components: {
		lxList,
		onelist,
		paging,
		lxVideoHotList,
		teamSelection,
		searchView,
		elDatePicker
	},
	data() {
		return {
			total: 100, //数据总条数
			breadcumb: {
				list: [{ name: '录像', path: '' }, { name: '全部录像', path: '' }]
			},
			stitle: '全部', //分类标题
			timevalue: '', //日期时间
			sindex: 0,
			id: '',
			routerUrl: '',
			slist: ['全部', 'NBA', '英超', '西甲', '法甲', '意甲', '欧洲杯', '中超', '欧冠杯', '欧罗巴杯', '亚洲预选', 'CBA', '澳洲杯', '韩K联'],
			livelist: [],
			pageSize: 30, //每次页面加载多少条
			currentIndex: 1, //页码
			oneList: {}, //热门赛事录像
			templateIndex: 0, // 侧边栏模板控制
			selectList: [{ id: 1, title: '录像' }, { id: 2, title: '直播' }, { id: 3, title: '新闻' }, { id: 4, title: '电视' }, { id: 5, title: '视频' }],
			// 录像首页重要参数
			eventId: '', //赛事项目
			eventTypeId: '', //赛事类型
			matchDate: '', //赛事日期
			navItem: {}, //赛事类型数据
			ranksList: [], //球队筛选的数据
			rankId: '39' //球队筛选id
		};
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		let query = that.$route.query;
		that.hotVideo(); //热门录像
		that.getQueryTeamByEvent(that.rankId); //球队筛选
		// sessionStorage.clear()
		let videoList = JSON.parse(sessionStorage.getItem('videoList'));
		// videoList:{eventId,eventTypeId,matchDate,offset,templateIndex,name}
		// query.data: "{"name":"足球","sort":1,"id":3,"SN":"585478","type":0}"
		if (videoList) {
			that.navItem = videoList;
		} else {
			if (query.data) {
				that.navItem = JSON.parse(query.data);
				if (that.navItem.id == '39') {
					that.navItem.eventTypeId = that.navItem.id;
					that.navItem.templateIndex = 1;
				} else {
					that.navItem.eventId = that.navItem.id;
					that.navItem.templateIndex = 0;
				}
			} else {
				that.navItem = {
					eventId: '', // 标签id
					eventTypeId: '',
					name: '全部', // 标签名称
					templateIndex: 0,
					offset: 1
				};
			}
		}
		that.stitle = that.navItem.name ? that.navItem.name : '全部';
		that.breadcumb.list[1].name = that.navItem.name ? that.navItem.name + '录像' : '全部录像';
		that.currentIndex = that.navItem.offset ? that.navItem.offset : 1;
		that.timevalue = that.navItem.matchDate ? that.navItem.matchDate : '';
		that.getQueryMatchByVideo(that.navItem);
	},
	methods: {
		// 录像接口
		getQueryMatchByVideo(obj) {
			let videoObj = {
				eventId: obj.eventId,
				eventTypeId: obj.eventTypeId,
				offset: that.currentIndex,
				matchDate: that.timevalue,
				templateIndex: obj.templateIndex,
				name: obj.name
			};
			sessionStorage.setItem('videoList', JSON.stringify(videoObj));
			let datas = {
				eventId: obj.eventId ? obj.eventId : '', // 选项栏-足球，篮球
				eventTypeId: obj.eventTypeId ? obj.eventTypeId : '', //赛事的名称-NAB等
				isRecommend: obj.isRecommend ? obj.isRecommend : 1,
				limit: obj.limit ? obj.limit : that.pageSize,
				matchDate: obj.matchDate ? obj.matchDate : '',
				matchId: obj.matchId ? obj.matchId : '',
				offset: obj.offset ? obj.offset : that.currentIndex,
				sourceType: 1,
				specialId: obj.specialId ? obj.specialId : '',
				teamId: obj.teamId ? obj.teamId : '',
				teamName: obj.teamName ? obj.teamName : ''
			};
			that.$newsReq.queryMatchByVideo(datas).then(res => {
				// log(res, '==>拿到的数据');
				if (res.data.data) {
					let resdata = res.data.data;
					that.total = resdata.total;
					that.livelist = resdata.list;
					that.templateIndex = obj.templateIndex;
				} else {
					that.livelist = [];
					that.total = 0;
				}
			});
		},
		//页码
		changePage(e) {
			console.log('页面改变', e);
			that.currentIndex = e;
			that.navItem.offset = e;
			that.getQueryMatchByVideo(that.navItem);
		},
		//日期选择
		formatTime(e) {
			that.currentIndex = 1;
			that.navItem.offset = 1;
			console.log(e, '===>e');
			that.timevalue = e;
			that.navItem.matchDate = e;
			that.getQueryMatchByVideo(that.navItem);
		},
		//球队筛选
		getQueryTeamByEvent(id) {
			let datas = {
				eventTypeId: id,
				limit: 30,
				offset: 1
			};
			that.$newsReq.queryTeamByEvent(datas).then(res => {
				// log(res.data, '===>球队筛选');
				that.ranksList = res.data.data.list;
			});
		},
		//热门录像
		hotVideo() {
			let datas = {
				isRecommend: 0,
				offset: 1,
				limit: that.pageSize,
				sourceType: 1
			};
			that.$newsReq.queryMatchByVideo(datas).then(res => {
				that.oneList = res.data.data;
				// log(that.oneList, '===>热门录像');
			});
		},
		//test选择日期
		test() {
			log('wo dian ;');
		}
	},
	watch: {
		$route: {
			handler() {
				// log(that.$route.query, '监听改变');
				// 清除时间等
				that.timevalue = '';
				this.$refs.elPicker.clearboth();
				that.currentIndex = 1;
				let query = this.$route.query;
				if (query.data) {
					that.navItem = JSON.parse(query.data);
					if (that.navItem.id == '39') {
						that.navItem.eventTypeId = that.navItem.id;
						that.navItem.templateIndex = 1;
					} else {
						that.navItem.eventId = that.navItem.id;
						that.navItem.templateIndex = 0;
					}
				} else {
					that.navItem = {
						eventId: '', // 标签id
						eventTypeId: '',
						name: '全部', // 标签名称
						templateIndex: 0,
						offset: 1
					};
				}
				that.stitle = that.navItem.name;
				that.breadcumb.list[1].name = that.navItem.name + '录像';
				that.getQueryMatchByVideo(that.navItem);
				// this.$forceUpdate();
			},
			deep: true
		}
	},
	destroyed() {
		sessionStorage.removeItem('videoList');
	}
};
</script>

<style lang="scss" scoped>
/* @import "../static/css/55-59.css"; */
/* @import "../static/css/app-2.css"; */

// .mainView {
// 	width: 100%;
// 	min-height: 32em;
// 	display: flex;
// 	justify-content: center;
// }
.mainView {
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	flex-direction: column;
}
.mainView-top {
	display: flex;
	width: 66.5rem;
	> div {
		flex: 1;
		// width: ;
	}
}
.mainView-content {
	flex: 1;
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	position: relative;
	// border: 1px solid red;
}
.lx-div {
	// width: 100%;
	// width: 1400px;
	flex: 1;
	display: flex;
	flex-direction: column;
	.nav-main {
		display: flex;
		justify-content: space-between;
		align-items: center;
		flex: 1;
		// height: 50px;
		border-radius: 1.6875rem;
		flex-wrap: nowrap;

		width: 66.5rem;
		// border:1px solid red;
		// .el-data-css {
		// 	height: 2.125rem;
		// 	// border: 1px solid red;
		// 	.el-date-editor.el-input,
		// 	.el-date-editor.el-input__inner {
		// 		height: 100%;
		// 		display: flex;
		// 		align-items: center;
		// 		// width: 150px;
		// 		// width: 8.4375rem;
		// 		// border:1px solid red;
		// 		background: rgba(27, 27, 48, 1);
		// 		border-radius: 1.0625rem;

		// 		min-width: 7.875rem !important;
		// 		max-width: 8.75rem !important;
		// 	}
		// 	.el-input--prefix .el-input__inner {
		// 		// padding-left: 30px;
		// 	}
		// 	.el-input--suffix .el-input__inner {
		// 		padding-left: 10px;
		// 	}
		// 	.el-input__inner {
		// 		cursor: pointer;
		// 		// font-size: 0.625rem !important;
		// 		font-family: Microsoft YaHei;
		// 		font-weight: 400;
		// 		color: rgba(255, 255, 255, 1);
		// 		// width: 8.4375rem;
		// 		// border: 1px solid red;
		// 		text-align: center;

		// 		&::placeholder {
		// 			font-size: 1rem;
		// 			// font-size: 8px !important;
		// 			color: rgba(255, 255, 255, 1) !important;
		// 		}

		// 		&::-webkit-input-placeholder {
		// 			/* WebKit browsers 适配谷歌 */
		// 			font-size: 1rem;
		// 			color: rgba(255, 255, 255, 1);
		// 		}

		// 		&:-moz-placeholder {
		// 			/* Mozilla Firefox 4 to 18 适配火狐 */
		// 			font-size: 1rem;
		// 			color: rgba(255, 255, 255, 1);
		// 		}
		// 		&:-moz-input-placeholder {
		// 			/* Mozilla Firefox 4 to 18 适配火狐 */
		// 			font-size: 1rem;
		// 			color: rgba(255, 255, 255, 1);
		// 		}
		// 		&:-ms-input-placeholder {
		// 			/* Internet Explorer 10+  适配ie*/
		// 			font-size: 1rem;
		// 			color: rgba(255, 255, 255, 1);
		// 		}
		// 	}
		// 	input {
		// 		/* width: 152px; */
		// 		background: rgba(27, 27, 48, 1);
		// 		color: rgba(255, 255, 255, 1);
		// 		// border-top-right-radius: 27px;
		// 		// border-bottom-right-radius: 27px;

		// 		border-radius: 1.6875rem;
		// 		height: 100%;
		// 		// border: 1px solid red;
		// 	}
		// }

		.nav-list {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			// width:45px;
			// height:22px;
			// font-size:22px;
			font-size: 1.375rem;
			font-weight: bold;
			color: $bg-main;
			line-height: 1.75rem;
			position: relative;

			span {
				margin-left: 1.375rem;
			}
			&:before {
				content: '';
				width: 0.375rem;
				height: 1.625rem;
				background: $bg-main;
				position: absolute;
			}
		}
		.nav-view,
		.select-view {
			width: 5.5rem;
			// height: 50px;
			font-size: 1.125rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			line-height: 3.125rem;
		}
		div:first-child {
			border-top-left-radius: 1.6875rem;
			border-bottom-left-radius: 1.6875rem;
		}
		div:last-child {
			border-top-right-radius: 1.6875rem;
			border-bottom-right-radius: 1.6875rem;
		}
		.nav-view {
			color: rgba(51, 51, 51, 1);
		}
		.select-view {
			color: rgba(255, 255, 255, 1);
			background: rgba(27, 27, 48, 1);
		}
	}
}
.nodata {
	height: 16.875rem;
	// border: 1px solid red;
	background: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
}
.advertisingSpace {
	// width: 66.5rem;
	height: 5.625rem;
	display: flex;
	align-items: center;
	justify-content: center;
	// border: 1px solid red;
	background: #f5f5f5;
	margin-top: 1.875rem;
}
//重新构建选择日期
.new-data-layout {
	border: 1px solid red;
	width: 200px;
	// height: 100px;
	position: relative;
	display: flex;
	align-items: center;
	flex-direction: column;
	justify-content: center;

	.test {
		position: absolute;
		z-index: 10;
		background: #000000;
		color: #ffffff;
		// width: 150px;
	}
	.el-date-editor.el-input {
		position: absolute;
		// border: 1px solid yellow;
		z-index: 1;
		width: 150px;
		color: #ffffff;
	}
}

.mainView-flex {
	// border:1px solid red;
	width: 100%;
	display: flex;
	align-items: flex-start;
	flex-direction: row;
}
</style>
