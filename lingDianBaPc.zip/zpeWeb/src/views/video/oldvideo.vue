<template>
	<div>
		<!-- 阿里播放器vue-ali -->
		<!-- <aliPlayer 
		@play="play" 
		:useH5Prism="true" 
		:useFlashPrism="true"
		:autoplay="autoplay" 
		:isLive="isLive" 
		:rePlay="false" 
		:showBuffer="true"
		 showBarTime="5000" 
		 controlBarVisibility="hover" 
		 width="100%" 
		 height="550px" 
		 :source="source" 
		 ref="player"></aliPlayer> -->
		 <!-- vue-video-palyer -->
		 
		<!-- <bwVideoPlayer
		 width="100%" 
		 height="550px"
		 :sourceUrl="source"
		 :isPlaySource="true"
		 ref="player"
		 ></bwVideoPlayer> -->
		 
		 <!-- 阿里播放器 web -->
		<!-- <bwVideo
		width="100%"
		height="550px"
		:sourceUrl="source"
		:isPlaySource="true"
		ref="player"
		></bwVideo> -->
	</div>
</template>

<script>
</script>

<style>
</style>
