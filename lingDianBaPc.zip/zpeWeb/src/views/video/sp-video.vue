<template>
	<div class="container">
		<!-- 广告位 -->
		<AdSlot :AdName="'SP-1'" locationPosition="1" locationType="0" :adWidth="87.5" :adHeight="5.625" adStr="sp" style="margin: 0.625rem 0 0 0;"></AdSlot>
		<div class="column-top">
			<div class="left">
				<!-- 面包屑 -->
				<crumbs :breadcumb="breadcumb"></crumbs>
			
				<unit-title-tag :tagType="0" :title="navItem.name"></unit-title-tag>
			</div>
		</div>
		
		<div class="main">
			<unit-video-list :videoList="tabData" :tagObj="navItem"></unit-video-list>
		</div>
		
		<div v-if="tabData.length > 0">
			<div style="width: 100%;height:24px"></div>
			<paging :total="total" :current-page="currentPage" :page-size="pageSize" @changePage="changePage"></paging>
		</div>
		
		<!-- 底部占位div -->
		<div class="footGG"></div>
	</div>
</template>

<script>
	import unitTitleTag from '../../atemp/unit-title-tag.vue'
	import unitVideoList from '../../atemp/unit-video-list.vue'
	import paging from '../../atemp/paging.vue'
	let that;
	export default {
		components: {
			unitTitleTag,
			unitVideoList,
			paging
		},
		data() {
			return {
				/* tagObj: {
					id: '',			// 标签id
					type: 5,		// 标签类型 3热门 4完结 5全部
					name: '最新',	// 标签名称
				}, */
				navItem:{},
				
				currentPage: 1, 	// 当前页数
				pageSize: 12,		// 每页显示条目个数
				total: 0,			// 数据总条数
				tabData: [],		// 数据列表
				
				breadcumb:{
					list: [
						{name: "视频", path: ""},
						{name: "全部视频", path: ""}
					]
				},
				
				id:'',
				routerUrl:''
			}
		},
		created: function () {
			that = this;
			that.routerUrl = that.$route.path;
			that.id = that.$route.params.id;
			// console.log('执行初始化');
			
			let query = this.$route.query;
			if (query.data) {
				this.navItem = JSON.parse(query.data);
				that.breadcumb.list[1].name = this.navItem.name + '视频';
			} else {
				this.navItem = {
					id: '',			// 标签id
					type: 5,		// 标签类型 3热门 4完结 5全部
					name: '全部',	// 标签名称
				}
			}
			
			that.queryLiveTitle();
		},
		methods:{
			queryLiveTitle: function () {
				let datas = {
					"id": that.navItem.id || '', // 对应的专题/赛事类型/项目id
					"limit": that.pageSize,
					"offset": that.currentPage,
					"type": that.navItem.type, // 查询所属类型 0项目 1专题 2赛事类型 3热门 4完结 5全部
					"livePlatform": 0,
				}
				// console.log('sp - 请求参数：', datas);
				that.$reqc.queryLiveTitle(datas).then(res => {
					// console.log('视频列表数据：',res);
					that.total = res.data.data.total;
					that.tabData = res.data.data.list;
				});
			},
			
			changePage(e){
				// console.log("页面改变",e)
				that.currentPage = e;
				that.queryLiveTitle();
			},
		},
		watch: {
			$route: {
				handler() {
					// console.log("获取路由变化参数",this.$route.query);
					
					let data,
						query = this.$route.query;
					
					if (query.data) {
						data = JSON.parse(this.$route.query.data)
					}
					else {
						data = {
							SN: '2',
							id: '',
							name: '全部',
							sort: 1,
							type: 5
						}
					}
					
					that.navItem = data;
					// console.log(that.navItem);
					// 标签切换 初始化页数
					that.currentPage = 1;
					that.queryLiveTitle();
					
					// console.log("子页获取vuex数据",that.$store.state);
					that.id = that.$route.query.sid||2;
					// that.stitle = that.$route.query.stitle;
					if (that.breadcumb.list.length == 1) {
						that.breadcumb.list.push({name: data.name+'视频'})
					} else {
						that.breadcumb.list[1].name = data.name+'视频'
					}
					// that.routerUrl = that.$route.fullPath;
				},
				deep: true,
			}
		},
	}
</script>

<style lang="scss" scoped>
	.container {
		// width: 1400px;
		width: 87.5rem;
		/* height: auto; */
		// min-height:900px;
		min-height: 56.25rem;
		margin: 0 auto;
		/* margin-top: 10px; */
		background-color: #F5F5F5;
		display: flex;
		flex-direction: column;
	}
	
	.column-top {
		width: 87.5rem;
		display: flex;
		align-items: center;
		justify-content: space-between;
		
		.left {
			width: 43.75rem;
		}
		
	}

	.main {
		// width: 1400px;
		width: 87.5rem;
		// width: 1064px;
		// width: 100%;
		height: 100%;
		background-color: #FFFFFF;
	}

</style>
