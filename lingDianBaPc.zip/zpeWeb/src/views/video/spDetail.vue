<template>
	<div class="container">
		<!-- 面包屑 -->
		<!-- <crumbs :breadcumb="breadcumb"></crumbs> -->

		<div class="main">
			<div class="column-left">
				<!-- 广告位 -->
				<AdSlot :AdName="'SPXQ-1'" locationPosition="1" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="spxq"></AdSlot>
				<!-- 面包屑 -->
				<crumbs :breadcumb="breadcumb"></crumbs>

				<!-- <aliPlayer @play="play" :useH5Prism="true" :autoplay="autoplay" :isLive="isLive" :rePlay="false" :showBuffer="true"
				 showBarTime="5000" controlBarVisibility="hover" width="100%" height="550px" :source="source" ref="player"></aliPlayer> -->
				<!-- <vueVideoPlayer
				  width="100%" 
				  height="550px"
				  :sourceUrl="source"
				  :poster='poster'
				  :isPlaySource="true"
				  ref="player"
				  ></vueVideoPlayer> -->
				<div class="videoPlayer-layout">
					<ckplayer
						width="100%"
						height="34.375rem"
						:sourceUrl="source"
						:isPlaySource="isPlaySource"
						:isLive="false"
						:isAutoplay="autoplay"
						:videoMsg="videoMsg"
						ref="player"
						v-if="videoPlayerType == 1"
					></ckplayer>
					<!-- iframe页面播放 -->
					<div class="iframe" v-if="videoPlayerType == 2"><iframe v-if="isWebView" scrolling="no" frameborder="0" :src="iframeSrc" allowfullscreen="true"></iframe></div>
					<!-- 跳转 -->
					<div v-if="videoPlayerType == 3" class="flex-cc w100 h100 bgc-black navBlankView">
						点击跳转：
						<a :href="ahref" target="_blank">{{ aName }} {{ aSourceName }}</a>
					</div>
					<!-- 等待播放 -->
					<div class="flex-cc w100 h100 bgc-black guoduDiv" v-if="videoPlayerType == 10"><img src="../../static/main/lod.gif" /></div>
				</div>
				<!-- 广告位 -->
				<div style="width: 100%;height: 0.625rem;"></div>
				<AdSlot :AdName="'SPXQ-3'" locationPosition="3" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="spxq"></AdSlot>
				<!-- 相关视频 -->
				<!-- <div style="width: 100%; height: 24px;"></div> -->
				<unit-title-tag :title="tagObj.name + '视频'" :tagStyle="tagStyle" :isMore="true" :moreText="'更多视频'" :pageRouter="'/sp-video'"></unit-title-tag>
				<!-- <unit-video-list :isSwitchPages="false" :videoId.sync="videoId" :videoList="videoList" :row="3"></unit-video-list> -->
				<unit-video-list :isSwitchPages="false" :videoList="videoList" :row="3"></unit-video-list>
				<!-- 相关赛程 -->
				<unit-title-tag :title="tagObj.name + '赛程'" :tagStyle="tagStyle" :isMore="true" :moreText="'更多直播'" :pageRouter="'/main'"></unit-title-tag>
				<live-list v-if="liveEventList[0] && liveEventList[0].length > 0" :liveEventList="liveEventList[0]" adSlotType="sp"></live-list>
				<div
					v-else
					class="noData"
					style="width: 100%; height: 100px; line-height: 100px; font-size: 1.25rem; color: #414550; text-align: center; background-color: #FFFFFF;"
				>
					暂无相关赛程
				</div>
			</div>
			<div class="column-right">
				<!-- 广告位 -->
				<AdSlot :AdName="'SPXQ-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="spxq"></AdSlot>
				<div style="width: 100%;height: 0.625rem;"></div>

				<!-- 相关新闻 -->
				<unit-related-news :newsList="newsList" :eventTypeName="tagObj.name"></unit-related-news>

				<!-- 广告位 -->
				<AdSlot :AdName="'SPXQ-4'" locationPosition="4" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="spxq"></AdSlot>
				<div style="width: 100%;height: 0.625rem;"></div>

				<!-- 相关录像 -->
				<unit-match-list :lxList="lxList" :eventTypeName="tagObj.name"></unit-match-list>
			</div>
		</div>
	</div>
</template>

<script>
// import aliPlayer from '../../atemp/aliPlayer.vue'
// import vueVideoPlayer from '../../components/vue-video-player.vue'
import ckplayer from '../../components/ckplayer.vue';

import unitTitleTag from '../../atemp/unit-title-tag.vue';
import unitVideoList from '../../atemp/unit-video-list.vue';
import liveList from '../../atemp/live-list.vue';
import unitRelatedNews from '../../atemp/unit-related-news.vue';
import unitMatchList from '../../atemp/unit-match-list.vue';
let that;
export default {
	components: {
		// aliPlayer,
		// vueVideoPlayer,
		ckplayer,
		unitTitleTag,
		unitVideoList,
		liveList,
		unitRelatedNews,
		unitMatchList
	},
	data() {
		return {
			videoMsg: '暂未获取信号,请选择其他播放源观看', //错误信息
			ahref: '', //跳转链接
			aName: '', //跳转链接名
			aSourceName: '', //跳转链接地址
			isPlaySource: true, //是否存在播放源
			iframeSrc: '', //ifarme 播放地址
			isWebView: true, //是否是webview
			videoPlayerType: 10, //播放类型
			videoList: [], // 视频列表
			liveEventList: [], // 赛程列表
			newsList: [], // 新闻列表
			lxList: [], // 录像列表
			source: '', // 信号源地址
			// source: 'http://yf.ugc.v.cztv.com/cztv/ugcvod/2018/04/14/A98CD7B26B06D94A5CEA56AA7D723572/h264_800k_mp4.mp4_playlist.m3u8',
			poster: '', // 封面图地址
			isLive: false, //是否直播
			autoplay: true, //是否自动播放
			useH5Prism: true, //指定H5播放器
			useFlashPrism: false, //指定flash播放器
			playsinline: false, //h5内置播放
			format: 'mp4', //

			tagStyle: {
				'margin-top': '24px'
			},

			videoId: '',
			tagObj: {},

			breadcumb: {
				list: [{ name: '视频', path: '/sp-video?hid=3' }, { name: '全部视频', path: '/sp-video?hid=3' }, { name: '未定义', path: '' }]
			},

			routerUrl: ''
		};
	},
	created: function() {
		that = this;
		document.body.onkeydown = function(event) {
			var e = window.event || event;
			if (e.preventDefault) {
				if (e && e.keyCode == 32) {
					e.preventDefault();
				}
			} else {
				window.event.returnValue = false;
			}
		};

		// 获取会话存储(id)
		let id = sessionStorage.getItem('videoId');
		if (that.$route.query.vid) {
			that.videoId = Number(that.$route.query.vid);
			that.getQueryLiveContent(that.videoId);
		} else {
			if (id) {
				that.videoId = Number(id);
				that.getQueryLiveContent(that.videoId);
			}
		}

		that.tagObj = JSON.parse(that.$route.query.tagObj);
		// console.log('query：', that.$route.query);
		/* that.routerUrl = that.$route.path;
			console.log(that.$route.path) */

		// ***修改面包屑 赛事类型 跳转路由
		that.breadcumb.list[1].name = that.tagObj.name + '视频';
		let p = `/sp-video?hid=3&sid=${that.tagObj.SN}&data=${JSON.stringify(that.tagObj)}`;
		that.breadcumb.list[1].path = p;

		that.$nextTick(() => {
			// 相关视频列表
			that.getQueryLiveTitle();
			// 相关赛程列表
			that.getQueryAllMatchList();
			// 新闻列表
			that.getQueryNewsTitle();
			// 录像列表
			that.getQueryMatchByVideo();

			// that.getTime()
		});
	},
	// 页面销毁
	destroyed() {
		// console.log('销毁');
		sessionStorage.removeItem('videoId'); // 清除(会话级别的)本地存储
		document.body.onkeydown = null;
	},
	watch: {
		videoId(newValue, oldValue) {}
	},
	methods: {
		play(event) {
			console.log(event);
		},
		/*加载ifrmae*/
		beginIframe(res) {
			that.iframeSrc = res.iframeSrc;
			// console.log('设置ifrmae', that.iframeSrc);
		},
		// 初始化播放器
		beginVideo() {
			that.isPlaySource = true;
			that.$nextTick(() => {
				that.$refs.player.initVideo({
					url: that.source,
					hm: that.getFileExt(that.source) == '.m3u8' ? true : false
				});
			});
		},
		// 修改视频 (切换播放源)
		changeVideo() {
			that.$refs.player.changeVideo({
				url: that.source,
				hm: that.getFileExt(that.source) == '.m3u8' ? true : false
			});
		},
		getFileExt: function(filepath) {
			if (filepath != '') {
				if (filepath.indexOf('?') > -1) {
					filepath = filepath.split('?')[0];
				}
				let pos = '.' + filepath.replace(/.+\./, '');
				return pos.toLowerCase();
			}
			return '';
		},

		// 视频内容
		getQueryLiveContent: function(id) {
			sessionStorage.setItem('videoId', id);
			let datas = {
				liveId: id,
				livePlatform: 0
			};
			that.$reqc.queryLiveContent(datas).then(res => {
				// console.log('视频内容：', res);
				if (res) {
					let data = res.data.data;
					if (data.addressType == 1 && data.sourceLive) {
						that.videoPlayerType = 1;
						that.source = data.sourceLive;
						that.beginVideo();
					} else if (data.addressType == 2 && data.onLineLive) {
						let num = Number(data.playType);
						switch (num) {
							case 1:
								that.videoPlayerType = 1;
								that.source = data.onLineLive;
								that.beginVideo();
								break;
							case 2:
								that.videoPlayerType = 2;
								that.beginIframe({
									iframeSrc: data.onLineLive
								});
								break;
							case 3:
								that.videoPlayerType = 3;
								that.ahref = data.onLineLive;
								that.aSourceName = data.liveTitle;
								break;
						}
					} else {
						that.loswer();
					}
					that.breadcumb.list[2].name = data.liveTitle;
				}
				// that.source = res.data.data.sourceLive;
				// that.poster = res.data.data.liveImg;
				// // 修改面包屑指向的视频名称
				// that.breadcumb.list[2].name = res.data.data.liveTitle;
				// that.videoPlayerType = 1;
				// that.changeVideo();
				// resolve();
			});
		},
		//视频失效
		loswer(title) {
			that.videoPlayerType = 1;
			that.isPlaySource = false;
			that.videoMsg = title || '暂未获取信号,请选择其他播放源观看';
			// that.$forceUpdate();
		},
		// 相关视频列表
		getQueryLiveTitle: function() {
			let datas = {
				id: that.tagObj.id || '',
				limit: 9,
				offset: 1,
				type: that.tagObj.type,
				livePlatform: 0
			};
			// console.log('视频列表请求参数：', datas);
			that.$reqc.queryLiveTitle(datas).then(res => {
				// console.log('视频列表数据：', res);
				// that.total = res.data.data.total;
				that.videoList = res.data.data.list;
			});
		},

		// 相关赛程列表
		getQueryAllMatchList: function() {
			let datas = {
				date: that.$utils.getCurrentDate(),
				id: that.tagObj.id,
				limit: 10,
				livePlatform: '0',
				offset: 1,
				teamId: 0, // 球队id
				type: that.tagObj.type
			};
			// console.log('赛程列表请求参数：', datas);
			that.$req.queryAllMatchList(datas).then(res => {
				// console.log("赛程列表数据",res);
				if (res.status == 200 && res.data.resultCode == 1) {
					that.liveEventList = res.data.data.list || [];
					that.$forceUpdate();
				}
			});
		},

		// 新闻列表
		getQueryNewsTitle: function() {
			let datas = {
				id: that.tagObj.id,
				limit: 14,
				offset: 1,
				type: that.tagObj.type
			};
			// console.log('新闻列表请求参数：', datas);
			that.$reqc.queryNewsTitle(datas).then(res => {
				// console.log("新闻列表：",res);
				if (res.status == 200 && res.data.resultCode == 1) {
					that.newsList = res.data.data.list || [];
					that.$forceUpdate();
				}
			});
		},

		// 录像列表
		getQueryMatchByVideo: function() {
			let datas = {
				// "eventId": 4,	// 项目id
				eventTypeId: that.tagObj.id, // 赛事类型id Number
				limit: 12, // 条数
				offset: 1, // 页码
				sourceType: 1 // 播放类型 0直播 1录像 2集锦
				/* "eventId": 39,		// 项目id
					"isRecommend": 1,	// 是否(热门)推荐 0是 1否
					"matchDate": "",	// 比赛日期查询录像 'YYYY-MM-DD'
					"matchId": 1,		// 赛事id
					"specialId": 39,	// 专题id
					"teamId": 1,		// 球队id
					"teamName": "湖人",	// 球队名称 */
			};
			// console.log('录像列表请求参数：', datas);
			that.$reqc.queryMatchByVideo(datas).then(res => {
				// console.log('录像列表：', res);
				if (res.status == 200 && res.data.resultCode == 1) {
					let list = (res.data.data && res.data.data.list) || [];
					that.lxList = list;
					that.$forceUpdate();
				}
			});
		}
	}
};
</script>

<style lang="scss" scoped>
.container {
	// width: 1400px;
	width: 87.5rem;
	/* min-height:900px; */
	height: auto;
	margin: 0 auto;
	/* margin-top: 10px; */
	background-color: #f5f5f5;
	display: flex;
	/* justify-content: space-between; */
	flex-direction: column;
}

.main {
	display: flex;
	justify-content: space-between;
	margin-top: 0.625rem;
}

.column-left {
	// width: 1064px;
	width: 66.5rem;
	/* height: auto; */
	height: 100%;
}

.column-right {
	width: 19.875rem;
}
.iframe {
	width: 100%;
	height: 34.375rem;
	iframe {
		width: 66.5rem;
		height: 34.375rem;
		background: rgba(0, 0, 0, 1);
		overflow: hidden;
	}
}
.guoduDiv {
	width: 100%;
	height: 34.375rem;
	img {
		width: 10rem;
		height: 10rem;
	}
}
.navBlankView {
	width: 100%;
	height: 34.375rem;
	font-size: 1.8rem;
	color: #ffffff;
	a {
		font-size: 1.8rem;
		font-weight: 600;
		color: $bg-chengse;
		text-decoration: underline;
	}
}
</style>
