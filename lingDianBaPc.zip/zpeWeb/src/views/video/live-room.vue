<template>
	<div class="mt15">
		<div class="mainView ">
			<div class="lx-div">
				<!-- 广告位 -->
				<AdSlot :AdName="'ZBS-1'" locationPosition="1" locationType="0" :adWidth="87.5" :adHeight="5.625" adStr="zbs"></AdSlot>
				<div style="width: 100%;height: 0.625rem;"></div>

				<div class="nav-main" v-if="isMatch">
					<div class="nav-title1">{{ matchBeginTimeTampStr }}</div>
					<div class="nav-title2" :class="[homeTeamId && guestTeamId ? '' : 'pt90']">
						{{
							eventTypeName == '' || eventTypeName == null
								? specialName + (matchTitle == '' || matchTitle == null ? '' : ' ') + matchTitle
								: eventTypeName == '其他'
								? eventName + (matchTitle == '' || matchTitle == null ? '' : ' ') + matchTitle
								: eventTypeName + matchTitle
						}}
					</div>

					<div class="nav-title3" v-if="homeTeamId && guestTeamId">
						<div class="t3-left flex-cc">
							<div>{{ homeTeamName }}</div>
							<img @error="errorImg($event, homeTeamImg)" :src="homeTeamLogoPath ? homeTeamLogoPath : require('../../static/image/nodata/homeTeam.png')" />
						</div>
						<div class="t3-content">—</div>
						<div class="t3-right flex-cc">
							<img @error="errorImg($event, guestTeamImg)" :src="guestTeamLogoPath ? guestTeamLogoPath : require('../../static/image/nodata/guestTeam.png')" />
							<div>{{ guestTeamName }}</div>
						</div>
					</div>
					<!-- <div class="nav-title3 " style="padding-top: 4rem;" v-else>
						暂无队伍
					</div> -->
					<!-- {{matchStartState==0?'进行中':matchStartState==1?'未开始':'已完赛'}} -->
					<div class="nav-title4 flex-cc" v-if="matchStartState == 1">
						<span>比赛将在</span>
						<div>{{ dtime }}</div>
						<span>后开始</span>
					</div>
					<div class="nav-title4 flex-cc" v-if="matchStartState == 0"><span>比赛进行中</span></div>
					<div class="nav-title4 flex-cc" v-if="matchStartState == 2"><span>已完赛</span></div>
				</div>
				<div class="nav-main cF fs30 flex-cc" v-else>未找到该比赛</div>
				<div style="width: 100%;height: 0.9375rem;"></div>
				<div class="mainView">
					<div class="column-left">
						<!-- 广告位 -->
						<AdSlot :AdName="'ZBS-2'" locationPosition="2" locationType="0" :adWidth="63.875" :adHeight="5.625" adStr="zbs"></AdSlot>
						<div style="width: 100%;height: 0.625rem;"></div>

						<el-tabs class="el-tab-header" v-model="activeName" @tab-click="handleClick" :stretch="isStretch">
							<!-- 直播完后又点击进去，提示直播结束 -->
							<template v-if="matchStartState == 2 && isOverHours && isLx != 'islx'">
								<el-tab-pane style="margin: 0;" label="直播信号" name="first"><div class="tip">比赛已结束</div></el-tab-pane>
							</template>

							<template v-if="matchStartState != 2 || (matchStartState == 2 && !isOverHours)">
								<el-tab-pane style="margin: 0;" label="直播信号" name="first">
									<div class="grid-title" v-if="matchIntroduction">{{ matchIntroduction }}</div>
									<div class="main-signal">
										<el-row :gutter="24" v-if="matchLiveSourceDOS.length">
											<el-col :span="6" v-for="(item, index) in matchLiveSourceDOS" :key="item.liveSourceName + index">
												<div @click="toplayer({ index: index })" :class="[sindex == index ? 'is-grid-content' : '']" class="grid-content pointer">
													<span>{{ item.liveSourceName | filterStr }}</span>
													<!-- <span>{{ testStr | filterStr}}</span> -->
												</div>
											</el-col>
										</el-row>
										<div class="ad-content">
											<!-- <div>广告广告广告广告</div>
											<div>广告广告广告广告</div> -->
											<AdSlot
												:AdName="'ZBS-1'"
												locationPosition="5"
												locationType="0"
												:adWidth="61.375"
												:adHeight="5.625"
												adStr="zbs"
												style="margin-top: 1rem"
											></AdSlot>
										</div>

										<div class="prompt" v-if="!matchLiveSourceDOS.length">
											<!-- 距离比赛时间3分钟之内以及比赛已经开始了 -->
											<div class="within-three-minutes" v-if="t <= 180">
												<div>抱歉，暂无信号源</div>
												<div>管理员正在努力寻找，请稍后再试或者观看其他比赛</div>
											</div>
											<!-- 距离比赛时间在3分钟-1小时内 -->
											<div class="within-an-hour" v-if="t > 180 && t <= 3600">比赛信号将在赛前更新</div>
											<!-- 距离比赛时间在1小时以上 -->
											<div class="more-than-an-hour" v-if="t > 3600">您来的太早了，请先观看本站其他视频</div>
										</div>
										<div class="gameIsOver" v-if="matchStartState == 2 && !isOverHours">比赛可能已结束</div>
										<!-- <nodata v-else 
										title="直播已经结束了，上面还有其他内容要不要了解下"></nodata> -->
									</div>
								</el-tab-pane>
							</template>

							<template v-if="matchProspect">
								<el-tab-pane label="比赛前瞻" name="second">
									<div class="richTextView">
										<div class="richTextTop">
											<div class="richTextTitle">{{ foresightDetail.newsTitle }}</div>
											<div class="richTextTime">{{ foresightDetail.createTime }}</div>
										</div>
										<div class="richTextContent" v-html="foresightDetail.newsContent"></div>
									</div>
									<!-- 
								<nodata
								v-else
								height="100%"
								title="暂无比赛前瞻"></nodata>
								 -->
								</el-tab-pane>
							</template>

							<template v-if="isTextLivePath">
								<el-tab-pane label="文字直播" name="third"><nodata height="100%" title="暂无文字直播"></nodata></el-tab-pane>
							</template>

							<!-- v-if="hasLXData || pathName == 'lx'" -->
							<template v-if="hasLXData">
								<el-tab-pane label="比赛录像" name="lx"><listThree nodataTitle="暂无数据" :threeList="matchLxList"></listThree></el-tab-pane>
							</template>

							<template v-if="hasHighlights">
								<!-- v-if="hasHighlights" -->
								<el-tab-pane label="比赛集锦" name="jj"><matchHig nodataTitle="暂无数据" :highligList="matchJJList"></matchHig></el-tab-pane>
							</template>

							<!-- v-if="isGrand" -->
							<template v-if="matchReuslt">
								<el-tab-pane label="比赛战报" name="zb">
									<div class="richTextView" v-if="matchReuslt">
										<div class="richTextTop">
											<div class="richTextTitle">{{ grandDetail.newsTitle }}</div>
											<div class="richTextTime">{{ grandDetail.createTime }}</div>
										</div>
										<div class="richTextContent" v-html="grandDetail.newsContent"></div>
									</div>
									<nodata v-else height="100%" title="暂无比赛战报"></nodata>
								</el-tab-pane>
							</template>
						</el-tabs>

						<div style="width: 100%;height: 0.625rem;"></div>
						<!-- 广告位 -->
						<AdSlot :AdName="'ZBS-4'" locationPosition="4" locationType="0" :adWidth="63.875" :adHeight="5.625" adStr="zbs"></AdSlot>
						<div style="width: 100%;height: 0.625rem;"></div>

						<div v-if="guestTeamId && homeTeamId">
							<div class="zb-view">
								<div class="">
									<listTeam @changePlayer="changePlayer" :teamId="homeTeamId" :teamName="homeTeamName" :teamList="homeLiveList" nodataTitle="暂无数据"></listTeam>
								</div>
								<div class="">
									<listTeam
										@changePlayer="changePlayer"
										:teamId="guestTeamId"
										:teamName="guestTeamName"
										:teamList="guestLiveList"
										nodataTitle="暂无数据"
									></listTeam>
								</div>
							</div>

							<div style="width: 100%;height: 0.625rem;"></div>
							<!-- 广告位 -->
							<!-- <AdSlot :AdName="'ZBS-5'"></AdSlot> -->
							<!-- <AdSlot :AdName="'ZBS-5'" locationPosition="5" locationType="0" :adWidth="59" :adHeight="5.625" adStr="zbs"></AdSlot> -->
							<div style="width: 100%;height: 0.625rem;"></div>

							<div class="lx-view">
								<div class=""><listLx :teamName="homeTeamName" :lxList="homeLxList"></listLx></div>
								<div class=""><listLx :teamName="guestTeamName" :lxList="guestLxList"></listLx></div>
							</div>
						</div>
						<div v-else class="">
							<div class="zb-view">
								<div class="">
									<listTeam @changePlayer="changePlayer" :teamId="homeTeamId" :teamName="homeTeamName" :teamList="homeLiveList" nodataTitle="暂无数据"></listTeam>
								</div>
								<div class=""><listLx :teamName="homeTeamName" :lxList="homeLxList"></listLx></div>
							</div>
						</div>

						<div class="footGG"></div>
					</div>

					<div class="column-right">
						<!-- 广告位 -->
						<AdSlot :AdName="'ZBS-3'" locationPosition="3" locationType="0" :adWidth="22.5" :adHeight="12.5" adStr="zbs"></AdSlot>
						<div style="width: 100%;height: 0.625rem;"></div>

						<!-- 评论模块 -->
						<leaveMessage :matchId="matchId"></leaveMessage>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import lxList from '../../atemp/lx-list.vue';
import listThree from '../../atemp/list-three.vue';
import leaveMessage from '../../atemp/leave-message.vue';
import listTeam from '../../atemp/list-team.vue';
import listLx from '../../atemp/list-lx.vue';

import matchHig from '../../atemp/match-highlights.vue';
let that,
	setStartTime = null;
export default {
	components: {
		matchHig,
		lxList,
		listThree,
		leaveMessage,
		listTeam,
		listLx
	},
	data() {
		return {
			isLx: '',
			testStr: '企鹅直播|韩乔生 梁祥宇宙',
			homeTeamImg: require('../../static/image/nodata/homeTeam.png'),
			guestTeamImg: require('../../static/image/nodata/guestTeam.png'),
			matchId: 0, //赛事id
			isMatch: true, //是否有当前赛事
			matchBeginTimeTampStr: '', //时间格式字符串
			matchTitle: '', //标题
			eventId: 0, //项目id
			eventName: '', //项目名称
			eventTypeId: 0, //赛事类型id
			eventTypeName: '', //项目类型名称
			specialId: 0, //所属专题id
			specialName: '', //专题名称
			guestTeamId: 0, //客队id
			guestTeamLogoPath: '', //客队logo
			guestTeamName: '', //客队名
			guestTeamSocre: 0, //客队比分
			homeTeamId: 0, //主队id
			homeTeamLogoPath: '', //主队logo
			homeTeamName: '', //主队名
			homeTeamScore: 0, //主队比分
			matchIntroduction: '', //提示
			matchLiveSourceDOS: [],

			timevalue: '',
			sindex: 0,
			id: '',
			routerUrl: '',
			isStretch: false,
			activeName: 'first',
			otherLimit: 5,
			otherOffset: 1,
			otherType: 6,
			matchState: 0, //比赛状态 0进行中 1未开始 2已结束
			homeLiveList: [], //主队直播数据
			homeLxList: [], //主队录像数据
			guestLiveList: [], //客队直播数据
			guestLxList: [], //客队录像数据

			matchLxList: [], //赛事录像数据
			isGetLX: false, //是否获取录像
			hasLXData: false, //是否有录像

			matchStartState: '1', //赛事进行状态 0进行中 1未开始 2已结束
			isOverHours: false, //是否结束一小时

			matchJJList: [], //赛事集锦数据
			isGetJJ: false, //是否获取集锦
			hasHighlights: true, //是否有集锦

			hasForesight: true, //是否有前瞻
			matchProspect: '', //前瞻
			foresightDetail: '', //前瞻详情

			matchReuslt: '', //战报
			isGrand: true, //是否有战报
			grandTitle: '', //战报标题
			grandDetail: '', //战报详情

			matchTextLivePath: '', //文字
			isTextLivePath: true, //是否有文字
			dtime: '00:00', //未开始 倒计时
			t: 0, //倒计时秒
			// funGetData:{
			// 	getMacthLX:()=> {that.getMacthLX();},
			// 	getMacthJJ:()=> {that.getMacthJJ();}
			// }

			pathName: '' // 记录指向标签名
		};
	},
	filters: {
		filterStr: function(value) {
			return value.substring(0, 12);
		}
	},
	watch: {
		$route: {
			handler() {
				that.id = that.$route.query.id;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	destroyed() {
		clearTimeout(setStartTime);
		setStartTime = null;
	},
	created: function() {
		that = this;
		let query = that.$route.query;
		that.matchId = parseInt(query.matchId);
		that.isLx = query.isLx ? query.isLx : '';
		// that.matchId = '11013';
		// 跳转后显示指定标签(录像)
		if (query.hasOwnProperty('activeName')) {
			that.activeName = query.activeName || 'first';
			that.pathName = query.activeName;
		}
		// 查询单个赛事数据
		that.getQueryMatchById()
			.then(res => {
				that.getRelevantData();
			})
			.catch(err => {
				that.isMatch = false;
			});
	},
	methods: {
		/*获取前瞻*/
		getForesight() {
			let datas = {
				newsId: parseInt(that.matchProspect)
			};
			that.$req.queryNewsContent(datas).then(res => {
				// console.log('前瞻内容', res);
				let resData = res.data;
				if (resData.resultCode == 1) {
					// that.foresightDetail = resData.data.newsContent
					that.foresightDetail = resData.data;
				}
			});
		},

		/*获取战报*/
		getGrand() {
			let datas = {
				newsId: parseInt(that.matchReuslt)
			};
			that.$req.queryNewsContent(datas).then(res => {
				that.isGetGrand = true;
				let resData = res.data;
				// console.log('战报内容', res);
				if (resData.resultCode == 1) {
					// that.grandTitle = resData.data.newsTitle;
					that.grandDetail = resData.data;
				}
			});
		},

		/*获取赛事录像*/
		getMacthLX() {
			if (!that.isGetLX) {
				that.getQueryMatchListByVideo({
					matchId: that.matchId,
					limit: 100,
					sourceType: '1',
					listName: 'matchLxList'
				});
				that.isGetLX = true;
			}
		},
		/*获取赛事集锦*/
		getMacthJJ() {
			if (!that.isGetJJ) {
				that.getQueryMatchListByVideo({
					matchId: that.matchId,
					limit: 100,
					sourceType: '2',
					listName: 'matchJJList'
				});
				that.isGetJJ = true;
			}
		},

		/*获取相关数据*/
		getRelevantData() {
			if (that.homeTeamId && that.guestTeamId) {
				that.getQueryAllMatchList({ teamId: that.homeTeamId, listName: 'homeLiveList' });
				that.getQueryAllMatchList({ teamId: that.guestTeamId, listName: 'guestLiveList' });
				that.getQueryMatchListByVideo({ teamId: that.homeTeamId, listName: 'homeLxList' });
				that.getQueryMatchListByVideo({ teamId: that.guestTeamId, listName: 'guestLxList' });
			} else {
				if (that.eventTypeName == '其他') {
					that.homeTeamName = that.eventName;
					that.getQueryAllMatchList({ eventId: that.eventId, listName: 'homeLiveList' });
					that.getQueryMatchListByVideo({ eventId: that.eventId, listName: 'homeLxList' });
				} else {
					that.homeTeamName = that.eventTypeName;
					that.getQueryAllMatchList({ eventTypeId: that.eventTypeId, listName: 'homeLiveList' });
					that.getQueryMatchListByVideo({ eventTypeId: that.eventTypeId, listName: 'homeLxList' });
				}
			}
		},
		/*查看赛事队伍录像*/
		getQueryMatchListByVideo(op) {
			return new Promise((resolve, reject) => {
				let time = that.BW.returnNowTime('YYYY-MM-DD');
				let datas = {
					date: time,
					eventId: op.eventId || 0,
					eventTypeId: op.eventTypeId || '',
					matchId: op.matchId,
					limit: op.limit || that.otherLimit,
					livePlatform: that.livePlatform,
					offset: that.otherOffset,
					teamId: op.teamId || 0,
					sourceType: op.sourceType || '1'
				};
				that.BW.queryMatchByVideo(datas).then(res => {
					// console.log('查询相关录像', res);
					let list = res.list;
					if (list.length) {
						that[op.listName] = list;
					}
					resolve();
				});
			});
		},

		/*获取当前赛事录像*/
		getMatchVideoLX(op) {
			return new Promise((resolve, reject) => {
				let datas = {
					matchId: that.matchId,
					limit: 50,
					livePlatform: that.livePlatform,
					offset: 1,
					sourceType: '1'
				};
				that.BW.queryMatchByVideo(datas).then(res => {
					// console.log('查询当前赛事录像', res);
					let list = res.list;
					if (list.length) {
						that.matchLxList = list;
					}

					resolve();
				});
			});
		},
		/*获取当前赛事集锦*/
		getMatchVideoJJ(op) {
			return new Promise((resolve, reject) => {
				let datas = {
					matchId: that.matchId,
					limit: 50,
					livePlatform: that.livePlatform,
					offset: 1,
					sourceType: '2'
				};
				that.BW.queryMatchByVideo(datas)
					.then(res => {
						// console.log('查询当前赛事集锦', res);
						let list = res.list || [];
						if (list.length) {
							// that[op.listName] = list;
							that.matchJJList = list;
						}

						resolve();
					})
					.catch(err => {
						// console.log('err：', err);
					});
			});
		},

		/*从相关直播进入直播间*/
		changePlayer(res) {
			that.toplayer({ matchId: res.matchId, index: 0 });
		},
		/*查看赛事*/
		getQueryAllMatchList(op) {
			let time = that.BW.returnNowTime('YYYY-MM-DD');
			let datas = {
				date: time,
				limit: that.otherLimit,
				livePlatform: that.livePlatform,
				offset: that.otherOffset,
				teamId: op.teamId,
				type: that.otherType
			};
			that.BW.queryAllMatchList(datas).then(res => {
				// console.log('查看队伍直播数据', res);
				that.total = res.total;
				let list = res.list || [];
				if (list[0].length) {
					that[op.listName] = list[0];
					that.$forceUpdate();
				}
			});
		},
		/*清空倒计时*/
		clearStartTime() {
			return new Promise((res, rel) => {
				if (setStartTime) {
					clearInterval(setStartTime);
					setStartTime = null;
					this.dtime = '';
				}
				res();
			});
		},
		formatSeconds(t) {
			let mi = 60,
				hh = mi * 60,
				dd = hh * 24;
			let h = this.formatBit(Math.floor(t / hh)),
				m = this.formatBit(Math.floor((t - h * hh) / mi)),
				s = this.formatBit(Math.floor(t - h * hh - m * mi));
			let tstr = h + '小时' + m + '分' + s + '秒';
			return tstr;
		},
		formatBit(v) {
			v = +v;
			return v > 9 ? v : '0' + v;
		},
		setDataTime(time) {
			this.clearStartTime().then(res => {
				this.istime = true;
				this.t = Math.floor(time / 1000);
				setStartTime = setInterval(() => {
					this.t--;
					this.dtime = this.formatSeconds(this.t);
					if (this.t <= 0) {
						clearInterval(setStartTime);
						// setTimeout(function() {this.istime = false;},1000);
						// 倒计时结束 重新开始解析
						// this.$emit('beginAnalysisSource');
						that.getQueryMatchById();
					}
				}, 1000);
				// console.log(this.t,"==>t")
			});
		},
		getQueryMatchById() {
			// let time =  that.BW.returnNowTime("YYYY-MM-DD");
			return new Promise((resolve, reject) => {
				let datas = {
					livePlatform: that.livePlatform,
					matchId: that.matchId
				};
				that.$req
					.queryMatchById(datas)
					.then(res => {
						// console.log('查看单个赛事数据', res.data.data);
						if (res.status == 200 && res.data.resultCode == 1) {
							let rd = res.data.data;
							that.matchBeginTimeTampStr = that.BW.timesToTime(rd.matchBeginTimeTamp);
							that.matchTitle = rd.matchTitle;
							that.eventName = rd.eventName;
							that.eventTypeName = rd.eventTypeName;
							that.eventId = rd.eventId;
							that.eventTypeId = rd.eventTypeId;
							that.specialId = rd.specialId;
							that.specialName = rd.specialName;
							that.guestTeamId = rd.guestTeamId || 0;
							that.guestTeamLogoPath = rd.guestTeamLogoPath;
							that.guestTeamName = rd.guestTeamName;
							that.guestTeamSocre = rd.guestTeamSocre || 0;
							that.homeTeamId = rd.homeTeamId;
							that.homeTeamLogoPath = rd.homeTeamLogoPath;
							that.homeTeamName = rd.homeTeamName;
							that.homeTeamScore = rd.homeTeamScore || 0;
							that.matchIntroduction = rd.matchIntroduction;
							that.matchLiveSourceDOS = rd.matchLiveSourceDOS;
							that.matchStartState = rd.matchStartState;
							that.matchState = rd.matchState;
							if (rd.matchStartState == 1) {
								let time = that.BW.returnRemainTime(rd.matchBeginTimeTamp);
								this.setDataTime(time);
							}

							// if(rd.eventTypeName != null && rd.eventTypeName != '' && rd.eventTypeName != '其他'){
							// 	that.eventTypeName = rd.eventTypeName;
							// }else{
							// 	if(rd.eventName !=  null && rd.eventName != ''){
							// 		that.eventTypeName = rd.eventName;
							// 	}
							// }
							/*比赛前瞻*/
							if (rd.matchProspect) {
								that.hasForesight = true;
								that.matchProspect = rd.matchProspect;
								that.getForesight();
							} else {
								that.hasForesight = false;
							}

							/*文字*/
							if (rd.matchTextLivePath) {
								that.matchTextLivePath = rd.matchTextLivePath;
								that.isTextLivePath = true;
							} else {
								that.isTextLivePath = false;
							}

							/*判断是否有录像*/
							if (rd.isLive == 1) {
								that.hasLXData = false;
							} else {
								that.hasLXData = true;
								that.getMatchVideoLX();
							}

							/*是否有集锦*/
							if (rd.isHighlights == 1) {
								that.hasHighlights = false;
							} else {
								that.hasHighlights = true;
								that.getMatchVideoJJ();
							}

							/*战报*/
							if (rd.matchReuslt || (rd.guestTeamSocre != '' && rd.guestTeamSocre != null)) {
								that.matchReuslt = rd.matchReuslt;
								that.isGrand = true;
								that.getGrand();
							} else {
								that.isGrand = false;
							}

							/*是否已结束*/
							if (rd.matchStartState == 2) {
								if (rd.isOverHours == 1) {
									that.isOverHours = false;
								} else {
									that.isOverHours = true;
								}
							}

							// 判断是否从录像页进入直播室
							if (that.pathName == 'lx') {
								// console.log('指向标签名：',that.pathName)
								// 选中有数据的tab标签（录像 -> 集锦 -> 战报 -> 前瞻）
								/* 是否有录像 */
								if (rd.isLive == 0) {
									that.activeName = 'lx';
								} else if (rd.isHighlights == 0) {
									/* 是否有集锦 */
									that.activeName = 'jj';
								} else if (rd.matchReuslt || (rd.guestTeamSocre != '' && rd.guestTeamSocre != null)) {
									/* 是否有战报 */
									that.activeName = 'zb';
								} else if (rd.matchProspect) {
									/* 是否有比赛前瞻 */
									that.activeName = 'second';
								}
							}

							resolve();
						} else {
							reject(res.data);
						}
					})
					.catch(err => {
						reject();
					});
			});
		},

		handleClick(tab, event) {
			// if(that.funGetData[that.activeName]){
			// 	that.funGetData[that.activeName].call(this);
			// }
		},

		setindex(i) {
			if (that.sindex != i) {
				that.sindex = i;
			}
		},
		formatTime(e) {},
		toplayer(op) {
			// that.$router.push({
			// 	path: '/playerVideo',
			// query: {
			// 	hid: 1,
			// 	mid: op.matchId || that.matchId,
			// 	index: op.index || 0
			// }
			// });
			this.BR.navTo('/playerVideo', {
				hid: 1,
				mid: op.matchId || that.matchId,
				index: op.index || 0
			});
			return;
			if (test == 'test') {
				that.$router.push({
					path: '/playerVideo',
					query: {
						hid: 1,
						mid: 5821
					}
				});
			} else {
				that.$router.push({
					path: '/playerVideo',
					query: {
						hid: 1,
						mid: that.matchId
					}
				});
			}
		}
	}
};
</script>

<style lang="scss" scoped>
@import '@/static/css/color.scss';

.richTextView {
	padding: 1.375rem 2.3125rem;
	.richTextTop {
		border-bottom: 0.0625rem solid rgba(204, 204, 204, 1);
		margin-bottom: 1.375rem;
		.richTextTitle {
			font-size: 1.625rem;
			font-weight: bold;
			color: rgba(51, 51, 51, 1);
			line-height: 1.75rem;
			// padding: 1.375rem 1.375rem 0 1.375rem;
		}
		.richTextTime {
			font-size: 0.875rem;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			// line-height:1.75rem;
			padding: 1rem 1.375rem 1rem 1.375rem;
		}
	}
	.richTextContent {
		text-align: left;
		font-size: 0.875rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(102, 102, 102, 1);
		line-height: 1.75rem;
	}
}

.mainView {
	width: 100%;
	min-height: 32em;
	display: flex;
	justify-content: center;
}
/deep/.column-left {
	width: 63.875rem;
	.main-signal {
		padding: 1.25rem 1.25rem 1.25rem 1.25rem;
		background-color: #ffffff;
		height: calc(100% - 2.375rem) !important;
	}
	.el-tabs__nav {
		background-color: $bg-main;
	}
	.el-tabs__active-bar {
		background-color: #ffffff;
		height: 0.125rem;
		bottom: 0.125rem;
		left: 1.3125rem;
		border-radius: 6.1875rem;
		width: 5.125rem !important;
	}
	.el-tabs__item {
		// color: #FFF0FF;
		// font-size:1.25rem;
		// font-weight:400;
		// color:rgba(255,255,255,1);
		// line-height:3rem;
		// height: 3rem;
		height: 3.9375rem;
		font-size: 1.25rem;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		line-height: 2.875rem;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.el-tabs__item:hover {
		color: #ff5337;
	}
	.el-tabs__nav-wrap::after {
		content: '';
		background-color: $bg-main;
		height: 0.25rem;
	}
	.el-tabs__item.is-active {
		color: #ffffff;
	}
	// .lx-view{
	// 	display: flex;
	// 	justify-content: center;
	// 	align-items: center;
	// }
	.lx-view,
	.zb-view {
		display: flex;
		flex: 1;
		> div {
			flex: 1;
		}
		> div:last-child {
			margin-left: 1.875rem;
		}
	}
}
.column-right {
	width: 22.5rem;
	margin-left: 1.5rem;
	height: 100%;
}

.el-row {
	&:last-child {
		margin-bottom: 0;
	}
}
.el-tab-pane {
	// height: 30rem;
	min-height: 45rem;
	background-color: $bg-white;
	overflow: hidden;
	// overflow-y: scroll;
	// display: flex;
	// align-items: center;
	// justify-content: center;
	scrollbar-width: none; /* Firefox */
	-ms-overflow-style: none; /* IE 10+ */
	&::-webkit-scrollbar {
		widht: 0;
	}
	&::-webkit-scrollbar {
		display: none; /* Chrome Safari */
	}

	> div {
		height: 100%;
	}
}
.nodataMatch {
	min-height: 16.0625rem;
	display: flex;
	align-items: center;
	justify-content: center;
}
.el-row {
	// 一排四个波房源
	// border: 1px solid red;
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	// justify-content: space-around;
}
.el-col {
	border-radius: 6.25rem;
	margin-bottom: 1.25rem;
	// border: 1px solid red;
	// width: 25%;// 一排四个波房源
	// width: auto;
	// min-width: 280px;
	// width: 300px;
	// width: 100%;
}
.bg-purple-dark {
	background: #99a9bf;
}
.bg-purple {
	background: #d3dce6;
}
.bg-purple-light {
	background: #e5e9f2;
}
.grid-title,
.grid-content {
	min-height: 2.25rem;
}
.grid-title {
	// background:rgba(255,83,55,1);
	font-size: 1rem;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: red;
	line-height: 2.25rem;
	text-align: left;
	padding-left: 1.875rem;
	height: 2.375rem !important;
	display: flex;
	align-items: center;
}
.grid-content {
	width: 105%; // 一排四个波房源
	// border: 1px solid red;
	border-radius: 6.25rem;
	display: flex;
	flex-direction: row;
	justify-content: center;
	align-items: center;

	// span{
	// 	overflow: hidden;
	// 	text-overflow:ellipsis;
	// 	white-space: nowrap;
	// 	padding: 0 1.25rem;
	// }
	// span {
	// 	// width: 90%;
	// 	// text-align: left;
	// 	overflow: hidden;
	// 	// white-space: nowrap;
	// 	// border: 1px solid red;
	// 	display: flex;
	// 	align-items: center;
	// 	justify-content: center;
	// }
}
.noselectContent {
	border: 0.0625rem solid rgba(27, 27, 48, 1);
	font-weight: 400;
	color: rgba(27, 27, 48, 1);
}
.selectContent {
	background: rgba(27, 27, 48, 1);
	border: 0.0625rem solid rgba(0, 0, 0, 1);
	font-weight: 400;
	color: rgba(255, 255, 255, 1);
}

.row-bg {
	padding: 0.625rem 0;
	background-color: #f9fafc;
}
.pt90 {
	padding-top: 5.3125rem;
}
.lx-div {
	// width: 100%;
	width: 87.5rem;
	display: flex;
	flex-direction: column;
	.nav-main {
		display: flex;
		align-items: center;
		flex-direction: column;
		// flex:1;
		height: 18.75rem;
		// background-color: $bg-main;
		background-color: #1b1b30;
		font-weight: 400;
		position: relative;
		.nav-title1 {
			font-size: 1rem;
			font-family: Microsoft YaHei;
			color: rgba(153, 153, 153, 1);
			line-height: 1.75rem;
			padding-top: 0.625rem;
		}
		.nav-title2 {
			font-size: 1.875rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(255, 255, 255, 1);
			line-height: 2.5625rem;
		}
		.nav-title3 {
			display: flex;
			justify-content: center;
			align-items: center;
			font-size: 1.5rem;
			font-family: Microsoft YaHei;
			color: rgba(255, 255, 255, 1);
			line-height: 1.75rem;
			padding-top: 1.4375rem;
			.t3-left,
			.t3-right {
				width: 31.25rem;
				display: flex;
				div {
					padding: 1.875rem;
				}
			}
			.t3-content {
				padding: 0 4.375rem;
			}
			.t3-left {
				justify-content: flex-end;
			}
			.t3-right {
				justify-content: flex-start;
			}
			img {
				width: 7.5rem;
				height: 7.5rem;
				// border-radius:50%;
			}
		}
		.nav-title4 {
			// padding-top: 1.4375rem;
			position: absolute;
			bottom: 1rem;
			span {
				font-size: 1rem;
				font-family: Microsoft YaHei;
				color: rgba(255, 83, 55, 1);
				line-height: 1.75rem;
				padding: 0 1.875rem;
			}
			div {
				font-size: 1.5rem;
				font-family: DINPro;
				font-weight: 900;
				color: rgba(255, 255, 255, 1);
				line-height: 1.75rem;
			}
		}
	}
}

/deep/.el-tab-header {
	width: 100%;

	.el-tabs__nav {
		width: 100%;
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}
	/* 标签项 */
	.el-tabs__item {
		width: 9.832rem; // 9.832rem
		padding: 0;
	}
	.is-active {
		/* position: relative; */
	}
	/* 底部选中条 */
	.el-tabs__active-bar {
		margin-left: 1.125rem;
	}
}
.ad-content {
	display: flex;
	flex-direction: column;
	align-items: flex-start;
	justify-content: flex-start;
	font-size: 0.875rem;
	color: #666666;

	> div {
		width: auto;
		margin: 0.625rem 0;
		&:first-child {
			width: 17.5rem;
			border-top: 0.0625rem solid #dfdfdf;
			padding-top: 1.25rem;
			text-align: left;
		}
	}
}
.prompt,
.gameIsOver,
.tip {
	width: 100%;
	// width: 63.875rem;
	// height: 18.5rem !important;
	background-color: #ffffff;
	display: flex;
	align-items: center;
	flex-direction: column;
	justify-content: center;
	// border: 1px solid yellow;
	font-size: 1.375rem;
	font-family: Microsoft YaHei;
	font-weight: 400;
	color: rgba(102, 102, 102, 1);
	// border: 1px solid red;
	margin-top: 15rem;
	.within-three-minutes {
		display: flex;
		align-items: center;
		flex-direction: column;
		justify-content: center;

		> div:first-child {
			margin-bottom: 0.625rem;
		}
	}
}

// .ttest{
// 	height: 18.5rem !important;
// 	border: 1px solid red;
// }
</style>
