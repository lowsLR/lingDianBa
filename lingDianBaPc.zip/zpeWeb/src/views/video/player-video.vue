<template>
	<div class="main-body mt15">
		<div class="player-main">
			<div class="player-view">
				<div class="player-top flex">
					<div class="player-left">
						<!-- 广告位 -->
						<AdSlot :AdName="'BF-1'" locationPosition="1" locationType="0" :adWidth="63.875" :adHeight="5.625" adStr="bfq"></AdSlot>
						<div style="width: 100%;height: 1.125rem"></div>

						<div class="player-title">
							<div class="title-image">
								<!-- <img :src="eventLogoPath ? eventLogoPath : require('../../static/image/nodata/teamLogo_default.png')" /> -->
								<img @error="errorImg($event, defaultImg)" :src="eventLogoPath ? eventLogoPath : require('../../static/image/nodata/teamLogo_default.png')" />
							</div>
							<div class="title-top">
								<div class="zbs-title">
									{{
										eventTypeName == '' || eventTypeName == null
											? specialName + (matchTitle == '' || matchTitle == null ? '' : ' ') + matchTitle
											: eventTypeName == '其他'
											? eventName + (matchTitle == '' || matchTitle == null ? '' : ' ') + matchTitle
											: eventTypeName + matchTitle
									}}
									<span v-if="homeTeamName">{{ homeTeamName }} vs {{ guestTeamName }}</span>
								</div>
								<div class="title-span">
									<span>{{ matchBeginTimeTampStr }}</span>
									<span>当前观众：{{ userNumber }}</span>
								</div>
							</div>
						</div>
						<!-- ck -->
						<div class="eventView">
							<ckplayer
								v-if="videoPlayerType == 1"
								width="100%"
								height="34.375rem"
								:sourceUrl="source"
								:videoMsg="videoMsg"
								:isPlaySource="isPlaySource"
								@playerError="playerError"
								:dataTime="dataTime"
								@beginAnalysisSource="beginAnalysisSource"
								ref="player"
							></ckplayer>
							<iframe v-if="videoPlayerType == 2" width="100%" height="100%" :src="iframeSrc" allowfullscreen="true"></iframe>
							<div v-if="videoPlayerType == 3" class="flex-cc w100 h100 bgc-black navBlankView">
								点击跳转：
								<a :href="ahref" target="_blank">{{ matchLiveSourceDOS[sourceIndex].liveSourceName }}</a>
							</div>

							<div class="flex-cc w100 h100 bgc-black guoduDiv" v-if="videoPlayerType == 10"><img src="../../static/main/lod.gif" /></div>
						</div>

						<!-- 信号源列表 -->
						<!-- 一排四个 -->
						<div class="player-content">
							<el-row :gutter="20">
								<el-col :span="5" v-for="(item, index) in matchLiveSourceDOS" :key="item.matchId + item.sourceId" class="">
									<div class="grid-content" :class="[sourceIndex == index ? 'is-grid-content' : '', 'pointer']" @click="switchSource(item, index)">
										<span>{{ item.liveSourceName | filterStr }}</span>
										<!-- <span>{{ testStr | filterStr }}</span> -->
									</div>
								</el-col>
							</el-row>
						</div>
						<!-- 一排三个 -->
						<!-- <div class="player-content">
							<el-row :gutter="24">
								<el-col :span="6" v-for="(item, index) in matchLiveSourceDOS" :key="item.matchId + item.sourceId" class="">
									<div class="grid-content" :class="[sourceIndex == index ? 'is-grid-content' : '', 'pointer']" @click="switchSource(item, index)">
										<span>{{ item.liveSourceName | filterStr}}</span>
										<span>{{ testStr | filterStr}}</span>
									</div>
								</el-col>
							</el-row>
						</div> -->
						<div style="width: 100%;height: 0.9375rem;"></div>
						<!-- 广告位 -->
						<AdSlot :AdName="'BF-3'" locationPosition="3" locationType="0" :adWidth="63.875" :adHeight="5.625" adStr="bfq"></AdSlot>
					</div>

					<div class="player-right">
						<!-- 广告位 -->
						<AdSlot :AdName="'BF-2'" locationPosition="2" locationType="0" :adWidth="22.5" :adHeight="12.5" adStr="bfq"></AdSlot>
						<div style="width: 100%;height: 0.625rem"></div>

						<div class="message-view bb3" id="chatView">
							<div class="message-text" v-for="(item, index) in msgList" :key="'msg' + index">
								<span class="message-name">{{ item.nickName }}:</span>
								<span class="message-msg bq-message-img" v-html="item.content"></span>
							</div>
						</div>
						<div class="message-input">
							<div class="message-input-div">
								<!-- :autofocus='inputFocus' -->
								<input
									class=""
									ref="input"
									v-model="inputVal"
									@keyup.enter="setmsg"
									:placeholder="inpPlaceholder"
									:disabled="!isChatRoom || !isTouristChatSwitch"
								/>
								<div class="msg-bq">
									<el-popover placement="right" width="400" v-model="visible" trigger="click" v-if="isChatRoom && isTouristChatSwitch">
										<!-- 表情区域 -->
										<div class="browBox">
											<ul>
												<li v-for="(item, index) in faceList" :key="index" @click="handleEmoji(index)">{{ item }}</li>
											</ul>
										</div>

										<img slot="reference" src="../../static/main/bq.png" class="poinbut" />
									</el-popover>
								</div>
								<div class="msg-but poinbut" @click="setmsg" v-if="isChatRoom && isTouristChatSwitch">发送</div>
								<div class="msg-but poinbut disabled" v-else>发送</div>
							</div>
						</div>

						<div style="width: 100%;height: 0.625rem"></div>
						<!-- 广告位 -->
						<AdSlot :AdName="'BF-4'" locationPosition="4" locationType="0" :adWidth="22.5" :adHeight="5.625" adStr="bfq"></AdSlot>
					</div>
				</div>
			</div>
			<div class="footGG"></div>
		</div>
	</div>
</template>

<script>
import ckplayer from '../../components/ckplayer.vue';
import strophe from 'strophe.js/src/strophe.js';
import mContenteditable from '@/components/mContenteditable.vue';
// 导入JSON格式的表情库 (emoticon)
const Emoji = require('@/assets/emojis.json');

var that;
export default {
	components: {
		ckplayer,
		mContenteditable
	},
	data() {
		return {
			inpPlaceholder: '我来说两句', //提示语
			defaultImg: require('../../static/image/nodata/teamLogo_default.png'), // 默认图片
			testStr: '企鹅直播|韩乔生 梁祥宇宙',
			guestTeamName: '', //客队
			homeTeamName: '', //主客队
			dataTime: 0, //未到解析时间
			source: '',
			faceList: [], // 表情列表
			visible: false, //显示隐藏表情框
			faceBoxFlag: false,
			isLive: false, //是否直播
			autoplay: false, //是否自动播放
			useH5Prism: true, //指定H5播放器
			useFlashPrism: true, //指定flash播放器
			playsinline: false, //h5内置播放
			format: 'mp4', //
			inputVal: '',
			isPlaySource: true, //是否有播放源
			matchId: 0,
			matchTitle: '',
			eventName: '',
			eventTypeName: '',
			eventLogoPath: '', //赛事logo
			specialName: '',
			matchIntroduction: '', //提示
			matchBeginTimeTampStr: '', //时间字符串
			matchLiveSourceDOS: [],
			sourceIndex: 0,
			videoPlayerType: 10,
			matchStartState: 1, //赛事进行状态 0进行中 1未开始 2已结束
			isOverHours: false, //是否结束一小时
			iframeSrc: '',
			ahref: '',
			videoMsg: '',
			resultMsg: '',
			analysisSourceNumber: 0, //解析次数
			timeOutAnalys: null, //延迟解析对象
			pindex: 0, //记录是否有参数传入
			inputFocus: false,
			/*聊天*/
			userNumber: '', //当前人数
			bindStyle: false,
			submitBtn: false,
			textMsg: '', //输入框
			connection: null, //xmpp链接
			connected: false, //链接状态
			typeMessage1: 1,
			bosh: '',
			roomService: '',
			email: '',
			password: '', //密码
			historyUrl: '',
			nickname: '', //昵称
			atName: '',
			isVisitor: true,
			mtBackArray: [],
			imageUrl: '', //用户头像
			msgList: [], //消息数组
			delMarks: [],
			preLastMsgTime: 0,
			userId: '', //用户uid
			listTopHeight: 0,
			scrollBottom: true,
			heartSec: 0,
			sendSec: 0,
			heartInterval: null,
			inPage: false,
			isFirst: true,
			unReadCounts: 0,
			solHeight: 0,
			stanzaId: 0, //历史记录id（最后一条）
			inputbottom: 0,
			isChatRoom: true, //是否开启聊天室
			isTouristChatSwitch: true, //游客聊天权限
			isTouristState: true //是否开启游客聊天权限
		};
	},
	filters: {
		filterStr: function(value) {
			return value.substring(0, 12);
		}
	},
	destroyed() {
		// document.body.onkeydown = null;
		that.playerDispose();
		if (that.connection) {
			try {
				that.connection.disconnect('退出聊天室');
			} catch (e) {
				//TODO handle the exception
			}
			that.connection = null;
		}
	},
	mounted: function() {},
	computed: {
		loginState() {
			return this.$store.state.hasLogin;
		}
	},
	//监听执行
	watch: {
		loginState(val) {
			if (this.isChatRoom && !this.isTouristState) {
				if (val) {
					this.isTouristChatSwitch = true;
					this.inpPlaceholder = '我来说两句';
				} else {
					this.isTouristChatSwitch = false;
					this.inpPlaceholder = '请登录后发评论';
				}
				// console.log(this.isTouristChatSwitch, '==>游客');
				// this.$forceUpdate();
			}
			if (val) {
				let userInfo = this.$ls.get('userInfo');
				that.nickname = (userInfo && userInfo.nickName) || '';
				that.imageUrl = (userInfo && userInfo.imageUrl) || '';
				that.userId = (userInfo && userInfo.userId) || '';
			} else {
				that.nickname = '';
				that.imageUrl = '';
				that.userId = '';
			}
			this.getaddChatRoom();
		}
	},
	created() {
		that = this;
		// that.islogin = this.$store.state.hasLogin;
		// 取消浏览器 空格键按下页面下滑 的默认事件
		/* document.body.onkeydown = function(event) {
				var e = window.event || event;
				if (e.preventDefault) {
					if (e && e.keyCode == 32) {
						e.preventDefault();
					}
				} else {
					window.event.returnValue = false;
				}
			} */

		let query = that.$route.query;
		that.matchId = query.mid;
		that.pindex = query.index || 0;
		let userInfo = this.$ls.get('userInfo');
		that.nickname = (userInfo && userInfo.nickName) || '';
		that.imageUrl = (userInfo && userInfo.imageUrl) || '';
		that.userId = (userInfo && userInfo.userId) || '';

		// 生成表情列表
		for (let i in Emoji) {
			that.faceList.push(Emoji[i].char);
		}
		// console.log('表情列表：', that.faceList);
		that.$nextTick(() => {
			that.getQueryMatchById();
			// that.getaddChatRoom();
		});
	},
	methods: {
		//断是否可以聊天
		switchInfo() {
			this.$newsReq.switchInfo().then(res => {
				// console.log(res, '=>聊天室');
				if (!res.data.data.chatroomTouristSwitch) {
					if (!this.$store.state.hasLogin) {
						that.isTouristChatSwitch = false;
						that.isTouristState = false;
						that.inpPlaceholder = '请登录后聊天';
					}
				}
			});
		},
		/*销毁播放器*/
		playerDispose() {
			return new Promise((res, rel) => {
				try {
					that.$refs.videoplay.videoDispose();
					// that.$refs.videoplay.clearStartTime();
				} catch (e) {
					//TODO handle the exception
				}
				res();
			});
		},
		/*重新解析*/
		beginAnalysisSource() {
			that.playerDispose().then(res => {
				let mlist = that.matchLiveSourceDOS,
					index = that.sourceIndex;
				// that.matchReport(mlist[index].sourceId).then(ress=>{
				// 	console.log("当前解析,",mlist);
				if (mlist.length > 0) {
					that.analysisSource(mlist[index].sourceId);
					// that.setPlaySource(mlist[index]);
				} else {
					that.setNoPlay('暂未获取信号');
				}
				// })
			});
		},
		playerError(e) {
			// console.log('播放器出错测试事件', e);
		},
		/* 输入/发送 表情 */
		handleEmoji(i) {
			that.inputVal += that.faceList[i];
			that.visible = !that.visible;
			that.$refs.input.focus();
		},
		/*发送消息*/
		setmsg(val) {
			that.textMsg = that.inputVal;
			that.sendText();
		},
		testvideo() {
			let url = 'http://cctvalih5ca.v.myalicdn.com/live/cctv1_2/index.m3u8';
			that.sourceIndex = -1;
			console.log('进入测试');
			that.setVideo({
				analysisPlayPathPc: url,
				liveSourceName: '测试'
			});
		},
		/*初始化播放源*/
		init() {
			let data = that.matchLiveSourceDOS;
			if (data.length && (that.matchStartState != 2 || !that.isOverHours)) {
				// if(that.pindex > 0){
				that.sourceIndex = ~~that.pindex;
				// that.setPlaySource(data[~~that.pindex], true);
				that.analysisSource(data[~~that.pindex].sourceId);
				// }else{
				// 	that.setPlaySource(data[0],true);
				// }
			} else {
				that.setNoPlay('暂未获取信号');
			}
		},
		/*点击切换播放源*/
		switchSource(item, index) {
			if (index == that.sourceIndex) {
				return;
			}
			that.videoPlayerType = 10;
			if (that.timeOutAnalys) {
				clearTimeout(that.timeOutAnalys);
			}
			that.sourceIndex = index;
			// that.setPlaySource(item);
			that.analysisSource(item.sourceId);
		},
		/*设置播放源*/
		setPlaySource(item, initType = false) {
			// if (item.valid == 1) {
			// 	that.analysisSource(item.sourceId);
			// } else {
			switch (item.isAnalysis) {
				case '0':
					that.setVideo(item, initType);
					break;
				case '1':
					that.videoPlayerType = 2;
					that.$nextTick(() => {
						if (item.notAnalysisPlayPath) {
							that.beginIframe({
								liveSourceName: item.liveSourceName,
								iframeSrc: item.notAnalysisPlayPath
							});
						} else {
							that.pcLink(item, initType);
						}
					});
					break;
				case '2':
					that.setVideo(item, initType);
					break;
				case '3':
					that.ahref = '';
					if (item.notAnalysisPlayPath) {
						that.beginToWebView({
							url: item.notAnalysisPlayPath
						});
					} else {
						that.pcLink(item, initType);
					}
					break;
				default:
					break;
			}
			// }
		},
		setVideo(item, initType = false) {
			// console.log('播放器', item);
			that.videoPlayerType = 1;
			that.$nextTick(() => {
				if (item.analysisPlayPathPc != null) {
					that.beginVideo({
						analysisPlayPathPc: item.analysisPlayPathPc,
						liveSourceName: item.liveSourceName,
						initType: initType,
						hm: item.hm,
						// hm:1,
						ap: item.ap ,
						fp: item.fp ,
						l: item.l
					});
				} else {
					// that.setNoPlay();
					that.pcLink(item, initType);
				}
			});
		},
		pcLink(item, initType) {
			let pcLink;
			if (item.pcLink) {
				pcLink = item.pcLink;
			} else {
				if (webLink) {
					pcLink = item.pcLink;
				} else {
					that.setNoPlay();
					return;
				}
			}
			// let str = type(item.linkPlayType) == 'string' ? item.linkPlayType : item.linkPlayType.toString();
			switch (item.linkPlayType) {
				case '2':
					that.videoPlayerType = 2;
					that.beginIframe({
						liveSourceName: item.liveSourceName,
						iframeSrc: pcLink
					});
					break;
				case '3':
					that.beginToWebView({
						url: pcLink
					});
					break;
			}
		},
		/*加载跳转按钮*/
		beginToWebView(res) {
			that.videoPlayerType = 3;
			that.isPlaySource = false;
			that.ahref = res.url;
		},
		/*加载ifrmae*/
		beginIframe(res) {
			console.log('iframe');
			that.isPlaySource = false;
			that.resultMsg = res.liveSourceName;
			that.iframeSrc = res.iframeSrc;
		},
		/*初始化播放器*/
		beginVideo(res) {
			that.isPlaySource = true;
			that.sourceUrl = res.analysisPlayPathPc;
			that.videoMsg = res.liveSourceName;
			that.resultMsg = res.liveSourceName;
			that.$nextTick(() => {
				if (res.initType) {
					that.$refs.player.initVideo({
						url: res.analysisPlayPathPc,
						// hm:1,
						hm: res.hm || false,
						ap: res.ap || false,
						fp: res.fp || false,
						l: res.l || false
					});
				} else {
					that.$refs.player.changeVideo({
						url: res.analysisPlayPathPc,
						// hm:1,
						hm: res.hm || false,
						ap: res.ap || false,
						fp: res.fp || false,
						l: res.l || false
					});
				}
			});
		},
		setNoPlay(title) {
			that.isPlaySource = false;
			that.videoPlayerType = 1;
			that.videoMsg = title || '暂未获取信号,请选择其他播放源观看';
			// that.resultMsg = title||'暂未获取信号,请选择其他播放源观看';
		},
		/*解析*/
		analysisSource(sid) {
			let datas = {
				sourcePathId: sid
			};
			that.analysisSourceNumber = 0;
			that.analysisMatchLiveSource(datas);
		},
		analysisMatchLiveSource(datas) {
			// 解析直播源
			that.analysisSourceNumber++;
			that.$req
				.analysisMatchLiveSource(datas)
				.then(res => {
					// console.log('解析直播信息', res);
					if (res) {
						let data = res.data.data;
						if (res.status == 200 && res.data.resultCode == 1) {
							data.valid = '0';
							that.setPlaySource(data);
						} else {
							if (res.data.resultCode == -199) {
								if (that.analysisSourceNumber < 10) {
									that.timeOutAnalys = setTimeout(() => {
										that.analysisMatchLiveSource(datas);
									}, 1000);
								} else {
									that.setNoPlay();
								}
							} else {
								that.setTimeAndVideoMsg(res.data);
							}
						}
					} else {
						that.setNoPlay();
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		setTimeAndVideoMsg(res) {
			that.videoPlayerType = 1;
			setTimeout(function() {
				that.isPlaySource = false;
				that.videoMsg = res.resultMsg;
				that.resultMsg = res.resultMsg;
				if (res.data > 0) {
					that.dataTime = res.data;
					that.$refs.player.setDataTime(res.data);
					// that.$refs.player.setDataTime(15000);
				} else {
					that.$refs.player.getVideoData();
				}
			}, 0);
		},
		play(event) {},
		switchVideo(url) {
			that.source = url;
			that.changeVideo();
		},
		getQueryMatchById() {
			// let time =  that.BW.returnNowTime("YYYY-MM-DD");
			let datas = {
				livePlatform: that.livePlatform,
				matchId: that.matchId
			};
			that.$req
				.queryMatchById(datas)
				.then(res => {
					// console.log('查看单个赛事数据', res);
					if (res.status == 200 && res.data.resultCode == 1) {
						let rd = res.data.data;
						that.matchBeginTimeTampStr = that.BW.timesToTime(rd.matchBeginTimeTamp);
						that.matchTitle = rd.matchTitle;
						that.eventName = rd.eventName;
						that.eventTypeName = rd.eventTypeName;
						that.eventLogoPath = rd.eventLogoPath;
						that.specialName = rd.specialName;
						// that.guestTeamLogoPath = rd.guestTeamLogoPath;
						that.guestTeamName = rd.guestTeamName;
						// that.guestTeamSocre = rd.guestTeamSocre || 0;
						// that.homeTeamLogoPath = rd.homeTeamLogoPath;
						that.homeTeamName = rd.homeTeamName;
						// that.homeTeamScore = rd.homeTeamScore || 0;
						that.matchIntroduction = rd.matchIntroduction;
						that.matchLiveSourceDOS = rd.matchLiveSourceDOS;
						that.matchStartState = rd.matchStartState;
						// that.isChatRoom = rd.chatRoom;
						that.isChatRoom = true;
						that.inpPlaceholder = that.isChatRoom ? '我来说两句' : '聊天室已关闭';
						if (that.isChatRoom) {
							that.getaddChatRoom().then(() => {
								that.switchInfo();
							});
						}
						if (rd.matchStartState == 2) {
							if (rd.isOverHours == 1) {
								that.isOverHours = false;
							} else {
								that.isOverHours = true;
							}
						}
						that.init();
					} else {
						that.setNoPlay(res.data.resultMsg);
					}
				})
				.catch(err => {
					that.setNoPlay('请求失败，请重新请求');
				});
		},
		/*修改视频*/
		changeVideo() {
			that.$refs.player.changeVideo({
				url: that.source
			});
		},

		setLiveSource(index = 0) {
			let mlist = that.matchLiveSourceDOS;
			if (mlist.length) {
				that.source = mlist[0].analysisPlayPathPc;
				that.beginVideo();
			}
		},
		/*获取聊天房间*/
		getaddChatRoom() {
			return new Promise((resolve, reject) => {
				that.$req
					.addChatRoom({
						roomId: ~~that.matchId,
						userId: that.userId || '',
						count: 20,
						stanzaId: 0
					})
					.then(res => {
						// console.log('获取聊天室结果', res);
						let resp = res.data.data;
						if (resp) {
							that.isChatRoom = true;
							that.userNumber = ++resp.peopleNumber;
							that.bosh = resp.bosh;
							that.roomService = resp.roomService;
							that.email = resp.email;
							that.password = resp.password;
							that.historyUrl = resp.historyUrl;
							that.nickname = resp.nickname;
							that.isVisitor = resp.isVisitor;
							that.atName = '@' + resp.nickname;
							that.mtBackArray = resp.mt.toString().split(',');
							that.$forceUpdate();
							that.toConnectLiveRoom();
							resolve();
						} else {
							// that.getRoomDetailError(res.data.resultMsg)
						}
					});
			});
		},
		toConnectLiveRoom() {
			if (!that.connected) {
				that.getPreLastMsgTime();
				that.msgList.splice(0, that.msgList.length);
				if (!that.connection) {
					that.connection = new strophe.Strophe.Connection(that.bosh);
				}
				that.connection.connect(
					that.email,
					that.password,
					that.onConnect
				);
			}
		},
		getRoomDetailError(msg) {
			that.isChatRoom = false;
			return;
		},
		getPreLastMsgTime() {
			if (that.userId) {
				try {
					let preLastMsgTime = uni.getStorageSync(that.getLastMsgTimeKey());
					if (preLastMsgTime) {
						that.preLastMsgTime = preLastMsgTime;
					}
				} catch (e) {}
			}
		},
		getLastMsgTimeKey() {
			return that.roomId + '_' + that.userId;
		},
		/*链接状态*/
		onConnect(status) {
			switch (status) {
				case Strophe.Status.ERROR:
					that.connected = false;
					break;

				case Strophe.Status.CONNECTING:
					console.log('链接中。。。');
					break;

				case Strophe.Status.CONNFAIL:
					console.log('链接失败。。');
					that.connected = false;
					break;

				case Strophe.Status.AUTHENTICATING:
					console.log('正在授權');
					break;

				case Strophe.Status.AUTHFAIL:
					console.log('身份验证失败');
					that.connected = false;
					break;

				case Strophe.Status.CONNECTED:
					console.log('連接成功');
					that.connectSuccess();
					break;

				case Strophe.Status.DISCONNECTED:
					console.log('链接断开');
					that.connected = false;
					break;

				case Strophe.Status.DISCONNECTING:
					console.log('斷開連接中');
					break;

				case Strophe.Status.ATTACHED:
					console.log('連接已附加');
					break;

				case Strophe.Status.REDIRECT:
					console.log('REDIRECT');
					that.connected = false;
					break;

				case Strophe.Status.CONNTIMEOUT:
					console.log('链接超时。。。');
					that.connected = false;
					break;
			}
		},
		onMessage(msg) {
			var resultMsg = this.parseMsg(msg);
			if (resultMsg) {
				that.bindMsg(resultMsg);
				if (resultMsg.userId == 0 && resultMsg.mt == 1) {
					that.userNumber = resultMsg.content;
				}
				if (resultMsg.userId == 0 && resultMsg.content == '关闭聊天室') {
					that.isChatRoom = false;
					that.setPreLastMsgTime(new Date().getTime());
					if (that.connection) {
						that.connection.disconnect('退出聊天室');
					}
					that.getRoomDetailError('聊天室已关闭');
				}
			}
			return true;
		},
		bindMsg(msg) {
			// if(msg.delMsg==that.isDelete) {
			// 	const delContent = msg.content
			// 	if(that.delMarks.indexOf(delContent)==-1) {
			// 		that.delMarks.push(delContent)
			// 	}
			// }else if(that.mtBackArray.indexOf(msg.bmt)!=-1 || that.mtFrontArray.indexOf(msg.fmt)!=-1) {

			let msgContent = msg.content;
			if (msgContent.indexOf(that.atName) != -1) {
				msg.content = msgContent.replace(new RegExp(that.atName, 'gm'), '<text style="color:#F0AD4E;margin-right: 8px;">' + that.atName + '</text>');
				that.addAtMsg(msg);
				// 拿at的上一個id
				if (!that.atMsgId && this.msgList.length > 0 && msg.timeTs > that.preLastMsgTime) {
					that.atMsgId = that.msgList[that.msgList.length - 1].msgId;
				}
			}
			if (msg.hidden == 1) {
				// 	that.msgList.push(msg)
				return;
			}
			that.msgList.push(msg);
			if (that.scrollBottom || msg.userId == that.userId) {
				that.$nextTick(function() {
					that.scrollToBottom();
					that.$nextTick(function() {
						that.scrollAnimation = true;
					});
				});
			} else {
				that.unReadCounts++;
			}

			// }
		},
		connectSuccess() {
			if (that.connection) {
				if (that.msgList.length > 0) {
					that.msgList.splice(0, that.msgList.length);
				}
				if (that.delMarks.length > 0) {
					that.delMarks.splice(0, that.delMarks.length);
				}

				that.connected = true;
				try {
					that.getHistory(true);
				} catch (e) {
					//TODO handle the exception
				}

				that.connection.addHandler(that.onMessage, null, 'message');
				that.connection.send(strophe.$pres().tree());

				var pres = strophe
					.$pres({
						from: that.email,
						to: that.roomService + '/' + that.email.substring(0, that.email.indexOf('@'))
					})
					.c('x', {
						xmlns: 'http://jabber.org/protocol/muc'
					})
					.c('history', {
						maxchars: 0
					})
					.tree();
				that.connection.send(pres);
			}
		},
		parseMsg(msg) {
			try {
				if (msg.children.length == 1 && msg.getElementsByTagName('body').length > 0) {
					var tipContent = strophe.Strophe.getText(msg.getElementsByTagName('body')[0]).replace(/'/g, '"');
					if (tipContent && tipContent != this.$COMMON.CHAT_ROOM_HEART_PONG) {
						var msgContent = {
							msgId: that.uuid(5, 16),
							fmt: that.typeMessage3,
							center: that.messageCenterYes,
							content: tipContent
						};
						return msgContent;
					}
				} else {
					var typeMsg = msg.getAttribute('type');
					if (typeMsg == 'groupchat') {
						var bodyEles = msg.getElementsByTagName('body');
						if (bodyEles.length > 0) {
							// var content = crypto.resultChatDecrypt(strophe.Strophe.getText(bodyEles[0])).replace(/'/g, "\"");
							var content = strophe.Strophe.getText(bodyEles[0]).replace(/'/g, '"');
							var msgName = '';
							var mt = '';
							var roles = '';
							var ut = '';
							var iconUrl = '';
							var userId = '';
							var admin = '';
							var reject = '';
							var hidden = '';
							var center = '';
							var delMsg = '';
							var fmt = '';
							var bmt = '';
							var ir = '';
							var userProfessorTitle = null;
							var timeTs = 0;
							var msgId = msg.getAttribute('id');
							var hcEles = msg.getElementsByTagName('hc');
							if (hcEles.length > 0) {
								var hcEle = hcEles[0];
								msgName = hcEle.getAttribute('nn');
								mt = hcEle.getAttribute('mt');
								userId = hcEle.getAttribute('uid');
								roles = hcEle.getAttribute('roles');
								ut = hcEle.getAttribute('ut');
								iconUrl = hcEle.getAttribute('icon');
								admin = hcEle.getAttribute('admin');
								reject = hcEle.getAttribute('reject');
								hidden = hcEle.getAttribute('hidden');
								center = hcEle.getAttribute('center');
								delMsg = hcEle.getAttribute('delMsg');
								fmt = hcEle.getAttribute('fmt');
								bmt = hcEle.getAttribute('mt');
								ir = hcEle.getAttribute('ir');
								timeTs = hcEle.getAttribute('ts');
								const upt = hcEle.getAttribute('upt');
								if (upt) {
									userProfessorTitle = JSON.parse(upt);
								}
								if (timeTs) {
									// timeTs = parseInt(timeTs)
									timeTs = that.BW.returnMsgTime(parseInt(timeTs));
									// timeTs = new Date(delayValue).getTime();
								} else {
									var delayEles = msg.getElementsByTagName('delay');
									if (delayEles.length > 0) {
										var delayValue = delayEles[0].getAttribute('stamp');
										timeTs = new Date(delayValue).getTime();
									}
								}
							}

							var stanzaId = '';
							var stanzaIdEles = msg.getElementsByTagName('stanza-id');
							if (stanzaIdEles && stanzaIdEles.length > 0) {
								stanzaId = stanzaIdEles[0].getAttribute('id');
							}

							if (content) {
								let redpacketId;
								if (content.indexOf('[==红包==:') != -1) {
									redpacketId = content.split(':')[1].split(']')[0];
								} else if (
									(that.roomId != that.room_id_lh && that.chatroomInfos[that.room_id_lh] && content.indexOf(that.room_flag_lh) != -1) ||
									(that.roomId != that.room_id_ssc && that.chatroomInfos[that.room_id_ssc] && content.indexOf(that.room_flag_ssc) != -1)
								) {
									content = '<text style="color: #3498db;">' + content + '</text>';
								}
								content = content.replace(/0.12rem/g, '26rpx');
								return {
									mt: mt,
									nickName: msgName,
									content: that.escape2Html(content),
									timeTs: timeTs,
									roles: roles,
									icon: iconUrl,
									userId: userId,
									msgId: msgId,
									ut: ut,
									admin: admin,
									reject: reject,
									hidden: hidden,
									center: center,
									delMsg: delMsg,
									fmt: fmt,
									bmt: bmt,
									ir: ir,
									stanzaId: stanzaId,
									redpacketId: redpacketId,
									upt: userProfessorTitle
								};
							}
						}
					} else {
					}
				}
			} catch (e) {}
		},
		escape2Html(str) {
			var arrEntities = {
				lt: '<',
				gt: '>',
				nbsp: ' ',
				amp: '&',
				quot: '"'
			};
			return str.replace(/&(lt|gt|nbsp|amp|quot);/gi, function(all, t) {
				return arrEntities[t];
			});
		},
		uuid(len, radix) {
			var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
			var uuid = [],
				i;
			radix = radix || chars.length;

			if (len) {
				for (i = 0; i < len; i++) uuid[i] = chars[0 | (Math.random() * radix)];
			} else {
				var r;
				uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
				uuid[14] = '4';
				for (i = 0; i < 36; i++) {
					if (!uuid[i]) {
						r = 0 | (Math.random() * 16);
						uuid[i] = chars[i == 19 ? (r & 0x3) | 0x8 : r];
					}
				}
			}
			return 'msg' + uuid.join('');
		},
		/*获取历史消息*/
		getHistory(hideLoading) {
			let msgId;
			let stanzaId = 0;
			if (this.msgList.length > 0) {
				msgId = this.msgList[0].msgId;
				stanzaId = this.msgList[0].stanzaId;
			}
			that.$req
				.getHistory({
					url: that.historyUrl,
					count: 20,
					stanzaId: that.stanzaId
				})
				.then(res => {
					if (res.data && res.data.length > 0) {
						let dataArray = that.bindMsgList(res.data);
						that.msgList.splice(0, 0, ...dataArray);
						that.$nextTick(function() {
							if (msgId) {
								that.scrollToView = msgId;
							} else {
								that.scrollToBottom();
							}
							that.$nextTick(function() {
								that.scrollAnimation = true;
							});
						});
					} else {
						if (!hideLoading) {
							// uni.showToast({
							// 	title:'加載完成',
							// 	icon:'none'
							// })
						}
					}
				});
		},
		sendmsg() {
			// 创建一个<message>元素并发送
			var msg = $msg({
				to: toJid,
				from: fromJid,
				type: 'chat'
			}).c('body', null, that.textMsg);
			that.connection.send(msg.tree());
		},
		scrollToBottom() {
			if (this.msgList.length > 0) {
				// const msgId = this.msgList[this.msgList.length-1].msgId
				// this.scrollToView = msgId
				let msg = document.getElementById('chatView'); // 获取对象
				msg.scrollTop = msg.scrollHeight; // 滚动高度
			}
		},
		scrollToUserItem(msgId) {
			// let msgId = this.msgList[this.msgList.findIndex((item => {item.userId == uid}))].msgId
			return new Promise((res, rel) => {
				this.scrollToView = msgId;
				res();
			});
		},
		toScroll(e) {
			let eDetail = e.detail;
			const h = eDetail.scrollHeight - eDetail.scrollTop - that.scrollViewHeight;
			if (h > that.distanceBottomMaxHeight) {
				that.scrollBottom = false;
			} else {
				that.scrollBottom = true;
			}
			if (h < 10) {
				that.unReadCounts = 0;
			}
		},
		bindMsgList(historyMsg) {
			let dataArray = [];
			historyMsg.forEach(function(item, index) {
				try {
					let msg = that.parseMsg(that.string2XML(item).children[0]);
					if (msg) {
						let msgContent = msg.content;
						if (msgContent.indexOf(that.atName) != -1) {
							// 拿最上层的msgId   (that.msgList.length==0 && index==0):排除如果是在底部的
							if (msg.timeTs > that.preLastMsgTime && !(that.msgList.length == 0 && index == 0)) {
								that.atMsgId = msg.msgId;
							}
						}
						dataArray.unshift(msg);
					}
				} catch (e) {
					//TODO handle the exception
				}
			});
			return dataArray;
		},
		string2XML(xmlString) {
			var parser = new DOMParser();
			var xmlObject = parser.parseFromString(xmlString, 'text/xml');
			return xmlObject;
		},
		setPreLastMsgTime(ts) {},
		/*发送消息*/
		sendText() {
			if (that.connected) {
				let mtext = this.textMsg.trim().replace(new RegExp('\n', 'gm'), '<br/>');

				if (mtext) {
					let hcObject = {
						// roles:that.roles,
						uid: that.userId,
						nn: that.nickname,
						fmt: that.typeMessage1,
						xmlns: 'hc:client'
					};
					if (that.imageUrl) {
						hcObject['icon'] = that.imageUrl;
					}
					// if(that.userProfessorTitle) {
					// 	hcObject['upt'] = JSON.stringify(that.userProfessorTitle)
					// }

					// crypto.requestChatEncrypt(mtext)
					var msg = strophe
						.$msg({
							to: that.roomService,
							from: that.email,
							type: 'groupchat',
							id: that.uuid(5, 16)
						})
						.c('body', null, mtext)
						.c('hc', hcObject);
					that.connection.send(msg.tree());
					that.textMsg = '';
					that.inputVal = '';
					that.sendSec = 0;
				} else {
					// uni.showToast({
					// 	title:'發送內容不能為空',
					// 	icon:'none'
					// })
				}
			} else {
				that.getRoomDetailError();
			}
		}
	}
};
</script>

<style lang="scss" scoped>
.eventView {
	width: 100%;
	background-color: black;
	height: 34.375rem;
}

.guoduDiv {
	img {
		height: 10rem;
		width: 10rem;
	}
}

.navBlankView {
	font-size: 1.8rem;
	color: #ffffff;

	a {
		font-size: 1.8rem;
		font-weight: 600;
		color: $bg-chengse;
		text-decoration: underline;
	}
}

.player-main {
	display: flex;
	width: 87.5rem;
	flex-direction: column;

	.player-view {
		flex: 1;

		.player-top {
			flex: 1;

			.player-left {
				// width: 66.5rem;
				width: 63.875rem;
				/* height: 40.625rem; */

				.player-title {
					flex: 1;
					height: 6.25rem;
					background-color: $bg-white;
					padding: 1.5rem;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					.zbs-title {
						display: flex;
						align-items: center;
						flex-direction: row;
						span {
							margin-left: 0.3125rem;
						}
					}
					.title-image {
						width: 2.875rem;
						height: 2.875rem;

						img {
							width: 100%;
							height: 100%;
						}
					}

					.title-top {
						padding-left: 1.2rem;
						flex: 1;
						font-size: 1.375rem;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: rgba(51, 51, 51, 1);
						line-height: 2.5625rem;
						text-align: left;
					}

					.title-span {
						display: flex;
						justify-content: space-between;
						flex: 1;
						font-size: 1.125rem;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: rgba(102, 102, 102, 1);
						line-height: 1.375rem;
					}
				}
			}

			.player-right {
				// width: 19.875rem;
				width: 22.5rem;
				margin-left: 1.125rem;
				/* height: 40.625rem; */

				.message-view {
					flex: 1;
					height: 37.1875rem;
					background-color: $bg-white;
					padding: 0.875rem;
					overflow-y: auto;
					overflow-x: hidden;
					box-shadow: inset 0px 20px 20px -15px rgba(0, 0, 0, 0.2);
					scrollbar-width: none;
					/* Firefox */
					-ms-overflow-style: none;

					/* IE 10+ */
					&::-webkit-scrollbar {
						widht: 0;
					}

					&::-webkit-scrollbar {
						display: none;
						/* Chrome Safari */
					}

					.message-text {
						font-size: 0.875rem;
						// font-family: Microsoft YaHei;
						font-weight: 500;
						// line-height: 1.375rem;
						line-height: 1.5rem;
						text-align: left;

						.message-name {
							color: rgba(255, 83, 55, 1);
							padding-right: 0.625rem;
							line-height: 1.375rem;
							display: inline-block;
						}

						.message-msg {
							color: #999999;
							// line-height: 1.375rem;
							line-height: 1.5rem;
							// display: inline-block;
							display: inline-block;
							align-items: center;
						}
					}
				}

				.message-input {
					height: 3.4375rem;
					padding: 0.5625rem;
					background-color: $bg-white;

					&-div {
						display: flex;
						flex: 1;
						justify-content: space-between;
						height: 2.125rem;
						align-items: center;

						input {
							height: 100%;
							flex: 1;
							padding-left: 0.6875rem;
							background-color: transparent;
							border: 0;
							outline: none;
							background: rgba(232, 232, 232, 0.5);
							margin-right: 0.5625rem;
						}

						.msg-but {
							width: 3.125rem;
							height: 1.5rem;
							background: rgba(255, 83, 55, 1);
							border-radius: 0.75rem;
							color: rgba(255, 255, 255, 1);
						}
						.disabled {
							background: #ccc;
						}

						.msg-bq {
							font-size: 1.5rem;
							margin-right: 0.5625rem;
							display: flex;
							justify-content: center;
							align-items: center;

							span {
								display: flex;
								justify-content: center;
								align-items: center;
							}

							img {
								width: 1.5rem;
								height: 1.5rem;
							}
						}
					}
				}
			}
		}

		.player-content {
			flex: 1;
			padding: 1.5rem 0;
			background-color: $bg-white;
			margin-top: 1.5rem;

			.el-row {
				// border: 1px solid red;
				&:last-child {
					margin-bottom: 0;
				}
			}
			.el-col {
				// border: 1px solid red;
				// padding: 0;
				border-radius: 6.25rem;
				margin-bottom: 1.25rem;
				margin-left: 2rem;
				// width: auto;
				// min-width: 280px;
			}

			.grid-content {
				display: flex;
				align-items: center;
				justify-content: center;
				width: 17.5rem;
				height: 2.375rem;
				border-radius: 1.1875rem;
				border: 0.0625rem solid rgba(27, 27, 48, 1);
				font-size: 1.25rem;
				line-height: 1.75rem;
				color: rgba(27, 27, 48, 1);
				// width: auto;
				// padding: 0 1.25rem;
				// span{
				// 	overflow: hidden;
				// 	text-overflow:ellipsis;
				// 	white-space: nowrap;
				// 	padding: 0 1.25rem;
				// }
				// span {
				// 	// width: 90%;
				// 	// text-align: left;
				// 	overflow: hidden;
				// 	// white-space: nowrap;
				// 	// border: 1px solid red;
				// 	display: flex;
				// 	align-items: center;
				// 	justify-content: center;
				// }
			}

			.is-grid-content {
				background: rgba(27, 27, 48, 1);
				border: 0 !important;
				color: rgba(255, 255, 255, 1);
				// span{
				// 	overflow: hidden;
				// 	text-overflow:ellipsis;
				// 	white-space: nowrap;
				// 	padding: 0 1.25rem;
				// }
			}

			.grid-title,
			.grid-content {
				min-height: 2.25rem;
				// border: 1px solid red;
				width: 120%; // 一排四个波房源
				// margin: 0;
			}

			.row-bg {
				padding: 0.625rem 0;
				background-color: #f9fafc;
			}

			/* .bg-purple-dark {
					background: #99a9bf;
				}
				
				.bg-purple {
					background: #d3dce6;
				}
				
				.bg-purple-light {
					background: #e5e9f2;
				} */
		}
	}
}

/* 表情区域 */
.browBox {
	/* width: 100%; */
	height: 12.5rem;
	background: papayawhip;
	overflow: scroll;

	/* 隐藏滚动条 */
	scrollbar-width: none;
	/* Firefox */
	-ms-overflow-style: none;

	/* IE 10+ */
	&::-webkit-scrollbar {
		widht: 0;
	}

	&::-webkit-scrollbar {
		display: none;
		/* Chrome Safari */
	}

	ul {
		display: flex;
		flex-wrap: wrap;

		li {
			width: 12.5%;
			padding: 0.25rem 0;
			font-size: 26px;
			list-style: none;
			text-align: center;
			cursor: pointer;
		}
	}
}
</style>
