<template>
	<div class="mt15" style="margin: 0;">
		<div class="mainView">
			<div class="mainView-top">
				<div class="lx-div">
					<!-- 面包屑 -->
					<crumbs :breadcumb="breadcumb"></crumbs>
					<!-- <div class="nav-main">
					<div class="nav-list">
						<span>{{title}}</span> 
					</div>
				</div> -->
				</div>
				<!-- <div class="ggview"></div> -->
			</div>
			<div style="width: 100%;height: 1.375rem;"></div>

			<!-- 录像列表 -->
			<div class="mainView-content">
				<div class="column-left">
					<template v-if="!matchData.homeTeamName">
						<div class="lx-div">
							<div class="lx-title">{{ matchData.matchBeginTime | timeFilters}} {{ matchData.eventTypeName }} {{ matchData.matchTitle }}</div>
							<div class="lx-list" v-for="(item, index) in matchData.matchLiveSourceDOS" :key="index">
								<div class="lx-item-text pointer">
									<span v-if="item.matchSourcePathShortName">[{{ item.matchSourcePathShortName }}]</span>
									<span>{{ matchData.matchBeginTime | timeFilters}}</span>
									<span>{{ matchData.eventTypeName }} {{ matchData.matchTitle }}</span>
									<span>{{ item.liveSourceName }}</span>
								</div>
								<div class="lx-item-but poinbut" @click="navToSpPlayback(item)">立即播放</div>
							</div>
						</div>
					</template>

					<template v-if="matchData.homeTeamName">
						<div class="lx-div">
							<!-- <div class="lx-title">02月21日 NBA 国王 VS 灰熊</div> -->

							<div class="lx-title">{{ matchData.matchBeginTime | timeFilters }} <span>{{ matchData.matchTitle }}</span> {{ matchData.homeTeamName }} vs {{ matchData.guestTeamName }}</div>
							<div class="lx-list" v-for="(item, index) in matchData.matchLiveSourceDOS" :key="index">
								<div class="lx-item-text pointer">
									<span v-if="item.matchSourcePathShortName">[{{ item.matchSourcePathShortName }}]</span>
									<span>{{ matchData.matchBeginTime | timeFilters}}</span>
									<span>{{ matchData.matchTitle }}</span>
									<span>{{ matchData.homeTeamName }} vs {{ matchData.guestTeamName }}</span>
									<span>{{ item.liveSourceName }}</span>
								</div>
								<div class="lx-item-but poinbut" @click="navToSpPlayback(item)">立即播放</div>
							</div>
						</div>
					</template>
				</div>
				<div class="column-right">
					<!-- <lx-detail-NBA-news :newsList="newsList" :title="title" :eventTypeName="eventTypeName" :eventName="eventName" :isMore="true"></lx-detail-NBA-news> -->
					<lx-detail-NBA-news :newsList="newsList" :title="title" :isMore="true"></lx-detail-NBA-news>
					<div style="width: 100%;height: 1.375rem;"></div>
					<!-- <div class="ggview"></div> -->
				</div>
			</div>

			<div class="lx-detail-content">
				<!-- <lxListDetail></lxListDetail> -->
				<lx-detail-NBAlist flag="false" @isnoNavto="isnoNavto" :ftitle="ftitle" :livelist="livelist"></lx-detail-NBAlist>
				<div style="width: 100%;height: 0.9375rem;"></div>

				<div class="list-atemp-head">
					<div class="list-atemp-tip">
						<!-- <span class="tip-text fs22">{{ queryVideoType == 2 ? (eventTypeName !=='其他'?eventTypeName:eventName) : eventName }}视频</span> -->
						<span class="tip-text fs22">{{ nbaTitle }}</span>
					</div>
					<div>
						<span class="list-more pointer" @click="newNavTo">
							<!-- 更多{{ eventTypeName == '' || eventTypeName == null ? eventName : eventTypeName == '其他' ? eventName : eventTypeName }}视频>> -->
							更多>>
						</span>
					</div>
				</div>
				<hr style="width: 100%height:0.125rem;background:rgba(27,27,48,1);" />
				<unit-video-list :videoList="videoList"></unit-video-list>
			</div>
		</div>
	</div>
</template>

<script>
import lxList from '../../atemp/lx-list.vue';
import onelist from '../../atemp/list-one.vue';

// import lxListDetail from '../../atemp/lx-list-detail.vue';

import unitVideoList from '../../atemp/unit-video-list.vue';

import ckplayer from '../../components/ckplayer.vue';

import lxDetailNBAlist from '../../atemp/lx-detail-NBAlist.vue';
import lxDetailNBANews from '../../atemp/lx-detail-NBA-news.vue';
let that;
const { log } = console;
export default {
	components: {
		lxList,
		onelist,
		// lxListDetail,
		unitVideoList,
		ckplayer,
		lxDetailNBANews,
		lxDetailNBAlist
	},
	data() {
		return {
			breadcumb: {
				list: [{ name: '录像', path: '/lx-video?hid=2' }, { name: '', path: '' }, { name: '', path: '' }]
			},
			timevalue: '',
			sindex: 0,

			id: '',
			routerUrl: '',
			lxid: 0,
			matchData: [],

			// NBA新闻
			newsList: [],
			queryNewsType: 2, // (视频列表)查询所属类型 0项目 1专题 2赛事类型 3热门 4完结 5全部

			// 视频列表
			videoList: [],
			queryVideoType: 2, // (视频列表)查询所属类型 0项目 1专题 2赛事类型 3热门 4完结 5全部

			//录像
			livelist: [],

			// 侧边栏
			ftitle: '',

			title: '',

			//侧边栏
			matchType: '',

			eventTypeId: '',

			specialId: '',

			eventId: '',

			eventName: '',

			numberType1: 0,

			numberType2: 0,

			nbaTitle: '',

			matchTypeData: {},

			eventTypeName: '',
			// 传过来的
			navItem: {}
		};
	},
	watch: {
		$route: {
			handler() {
				console.log(this.$route.path);
				console.log('获取路由变化参数', this.$route.query);
				// that.id = that.$route.query.id || 0;
				console.log('子页获取vuex数据', that.$store.state);
				// that.id = that.$route.query.sid || 0;

				// that.title = that.$route.query.title;

				// that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	created: function() {
		that = this;
		let query = that.$route.query;
		console.log(query, '====>lxDetailsquery');
		if (!query.data) {
			that.navItem = {
				id: '', // 标签id
				type: 5, // 标签类型 3热门 4完结 5全部
				name: '全部' // 标签名称
			};
		} else {
			that.navItem = JSON.parse(that.$route.query.data);
		}

		that.getQueryMatchByVideoDetial(query.matchId);
		that.breadcumb.list[1] = {
			name: that.navItem.name,
			path: `/lx-video?hid=2&sid=${that.navItem.SN}&data=${JSON.stringify(that.navItem)}`
		};
	},
	methods: {
		isnoNavto(matchId) {
			// log("传过来？")
			that.getQueryMatchByVideoDetial(matchId);
			// window.scroll(0,0);
			let timer = setInterval(function() {
				let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
				let ispeed = Math.floor(-scrollTop / 10);
				// console.log(ispeed)
				if (scrollTop == 0) {
					clearInterval(timer);
				}
				document.documentElement.scrollTop = document.body.scrollTop = scrollTop + ispeed;
			}, 15);
		},
		// 相关录像
		viedeoList() {
			let datas;
			log(that.eventTypeId, '===?that.eventTypeI');
			if (that.eventTypeId) {
				datas = {
					eventId: '',
					eventTypeId: that.eventTypeId,
					limit: 5,
					matchDate: '',
					offset: 1,
					sourceType: 1
					// specialId: type
				};
			} else {
				datas = {
					eventId: that.eventId,
					eventTypeId: '',
					limit: 5,
					matchDate: '',
					offset: 1,
					sourceType: 1
					// specialId: type
				};
			}
			that.$newsReq.queryMatchByVideo(datas).then(res => {
				log(res, '===>NBA录像');
				that.livelist = res.data.data.list;
				if (that.eventTypeId && that.livelist[0].eventTypeName !== '其他') {
					that.ftitle = that.livelist[0].eventTypeName + '录像';
				} else {
					that.ftitle = that.livelist[0].eventName + '录像';
				}
			});
		},

		// 查询有录像比赛的详情
		getQueryMatchByVideoDetial(matchId) {
			let datas = {
				matchDate: '',
				matchId: matchId,
				sourceType: 1,
				offset: 1,
				limit: 4
				// isRecommend: 0
			};
			that.$newsReq.queryMatchByVideo(datas).then(res => {
				log(res, '====>lx-detail');
				let resdata = res.data.data.list[0];
				// log(resdata, '===>resdata');
				let matchLiveData = [];
				// that.breadcumb.list[1].name = resdata.eventName + '录像';

				if (resdata.guestTeamName) {
					that.breadcumb.list[2].name = `${resdata.homeTeamName} vs ${resdata.guestTeamName}`;
					that.navItem.secondName = that.breadcumb.list[2].name;
				} else {
					that.breadcumb.list[2].name = `${resdata.eventTypeName} ${resdata.matchTitle}`;
					that.navItem.secondName = that.breadcumb.list[2].name;
				}

				that.eventTypeId = resdata.eventTypeId;
				that.specialId = resdata.specialId;
				that.eventId = resdata.eventId;
				that.eventName = resdata.eventName;
				that.eventTypeName = resdata.eventTypeName;
				//调用之前清除 轮巡
				that.numberType1 = 0;
				that.numberType2 = 0;
				that.viedeoList();
				// 相关视频
				that.spVideoNBA();
				//相关新闻
				that.newsNBA();

				resdata.matchLiveSourceDOS.forEach(items => {
					matchLiveData.push(items);
				});
				resdata.matchLiveSourceDOS = matchLiveData;
				// resdata.matchBeginTime = that.BW.timesToTime(resdata.matchBeginTime);
				// log(resdata, '===>resdata数据');
				that.matchData = resdata;
				log(that.matchData, '===>matchData数据');

				// 侧边栏
				// 获取新闻列表
				// that.getNewsList();
				// 获取视频列表
				// that.getVideoList();
			});
		},

		navToSpPlayback(item) {
			// log(item,":===?xxx")
			let obj = {
				eventTypeId: that.eventTypeId,
				specialId: that.specialId,
				eventId: that.eventId,
				eventName: that.eventName
			};
			that.$router.push({
				path: '/lx-VideoPlayback',
				query: {
					hid: 2,
					lxid: 1,
					sourceId: item.sourceId,
					matchId: item.matchId,
					sid: 3,
					data: JSON.stringify(that.navItem)
				}
			});
		},
		setindex(i) {
			if (that.sindex != i) {
				that.sindex = i;
			}
		},
		formatTime(e) {
			console.log(e);
		},
		sizeChange(e) {
			console.log('每页条数', e);
		},
		currentChange(e) {
			console.log('当前页', e);
		},
		prevClick(e) {
			console.log('上一页', e);
		},
		nextClick(e) {
			console.log('下一页', e);
		},
		newNavTo() {
			that.$router.push({
				path: '/sp-video',
				query: {
					hid: 3
				}
			});
		},
		// 相关视频
		spVideoNBA() {
			let datas;
			let newArr = ['eventTypeId', 'specialId', 'eventId'];
			let newType = [2, 1, 0];
			if (that.numberType1 < 3) {
				datas = {
					id: that[newArr[that.numberType1]],
					limit: 8,
					offset: 1,
					type: newType[that.numberType1]
				};
			} else {
				log('meiyou zhi');
				that.nbaTitle = that.eventName + '视频';
				return;
			}

			that.$reqc.queryLiveTitle(datas).then(res => {
				// log(res, '===>视频');
				that.numberType1++;
				if (res.data.data.list.length) {
					log('视频有数据======>', that.numberType1);
					that.videoList = res.data.data.list;
					if (that.numberType1 == 3) {
						that.nbaTitle = that.eventName + '视频';
					} else {
						that.eventTypeName == '其他' ? (that.nbaTitle = that.eventName + '视频') : (that.nbaTitle = that.eventTypeName + '视频');
					}
				} else {
					log('重新调用');

					that.spVideoNBA();
				}
				// that.newsList = res.data.data.list;
			});
		},

		//相关新闻
		newsNBA() {
			let datas;
			let newArr = ['eventTypeId', 'specialId', 'eventId'];
			let newType = [2, 1, 0];
			if (that.numberType2 < 3) {
				datas = {
					id: that[newArr[that.numberType2]],
					limit: 8,
					offset: 1,
					type: newType[that.numberType2]
				};
			} else {
				log('meiyou zhi');
				that.title = that.eventName + '新闻';
				return;
			}

			that.$newsReq.queryNewsTitle(datas).then(res => {
				log(res, '===>新闻');
				that.numberType2++;
				if (res.data.data.list.length) {
					log('有数据新闻==>', that.numberType2);
					that.newsList = res.data.data.list;
					if (that.numberType1 == 3) {
						that.title = that.eventName + '视频';
					} else {
						that.eventTypeName == '其他' ? (that.title = that.eventName + '视频') : (that.title = that.eventTypeName + '视频');
					}
				} else {
					log('重新调用');

					that.newsNBA();
				}

				// that.newsList = res.data.data.list;
				// that.title = that.eventName + '新闻';
			});
		}
	},
	filters: {
		timeFilters: function(time) {
			if (!time) {
				return ' ';
			} else {
				const date = new Date(time);

				const dateNumFun = num => (num < 10 ? `0${num}` : num);

				const [Y, M, D, h, m, s] = [
					date.getFullYear(),

					dateNumFun(date.getMonth() + 1),

					dateNumFun(date.getDate()),

					dateNumFun(date.getHours()),

					dateNumFun(date.getMinutes()),

					dateNumFun(date.getSeconds())
				];

				return `${M}月${D}日`;
			}
		}
	}
};
</script>

<style lang="scss" scoped>
/* @import "../static/css/55-59.css"; */
/* @import "../static/css/app-2.css"; */

// .mainView {
// 	width: 100%;
// 	min-height: 32em;
// 	display: flex;
// 	justify-content: center;
// }
.mainView {
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	flex-direction: column;
}
.mainView-top {
	display: flex;
	width: 100%;
	> div {
		flex: 1;
	}
}
.lx-detail-content {
	width: 100%;
	flex: 1;
	// border: 1px solid red;
	.list-atemp-head {
	}
	.list-atemp-tip {
		margin-bottom: 0.5rem;
		&:before {
			content: '';
			width: 0.375rem;
			height: 1.625rem;
			background: #1b1b30;
			display: inline-block;
			margin-right: 0.75rem;
			margin-left: 0.25rem;
			vertical-align: middle;
		}
	}
}
.mainView-content {
	flex: 1;
	// min-height: 32em;
	// min-height: 382px;
	min-height: 23.875rem;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	position: relative;
	margin-bottom: 1.25rem;
	// border: 1px solid red;
}
.lx-div {
	// width: 100%;
	// width: 1400px;
	flex: 1;
	display: flex;
	flex-direction: column;

	.lx-title {
		// height:66px;
		height: 4.125rem;
		background: $bg-main;
		// font-size:22px;
		font-size: 1.375rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		// line-height:66px;
		line-height: 4.125rem;
		text-align: left;
		// padding-left: 24px;
		padding-left: 1.5rem;
		span{
			margin: 0 0.625rem;
		}
	}
	.lx-list {
		// height: 79px;
		height: 4.9375rem;
		display: flex;
		justify-content: space-between;
		align-items: center;
		background-color: $bg-white;
		// padding: 0 26px;
		padding: 0 1.625rem;
		border-bottom: 1px solid rgba(204, 204, 204, 1);

		&:last-child {
			border: 0;
		}
		.lx-item-text {
			// font-size:20px;
			font-size: 1.25rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: #333333;
			// line-height:28px;
			line-height: 1.75rem;
			flex: 1;
			text-align: left;

			span {
				margin-left: 0.625rem;

				&:first-child {
					margin-left: 0;
				}
			}
		}
		.lx-item-but {
			width: 6.125rem;
			height: 1.75rem;
			background: $bg-main;
			border-radius: 0.875rem;
			// font-size:16px;
			font-size: 1rem;
			font-weight: 400;
			color: rgba(255, 255, 255, 1);
			line-height: 1.75rem;
			margin: 0 1.375rem;
		}
	}
}

.container {
	// width: 1400px;
	width: 87.5rem;
	/* min-height:900px; */
	height: auto;
	margin: 0 auto;
	margin-top: 0.625rem;
	background-color: #f5f5f5;
	display: flex;
	justify-content: space-between;
	// border: 1px solid red;
}

.column-left {
	// width: 1064px;
	width: 66.5rem;
	/* height: auto; */
	height: 100%;
	// border: 1px solid red;
}
</style>
