<template>
	<div class="mt15" style="margin: 0;">
		<div class="mainView">
			<div class="layout">
				<AdSlot :AdName="'LX-1'" locationPosition="1" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="lx" style="margin-top: 0.625rem;"></AdSlot>
				<div class="mainView-top">
					<div class="lx-div">
						<!-- 面包屑 -->
						<crumbs :breadcumb="breadcumb"></crumbs>
					</div>
				</div>
				<div style="width: 100%;height: 1.375rem;"></div>
				<!-- 视频播放器播放 -->
				<div class="container">
					<div class="column-left">
						<ckplayer
							width="100%"
							height="34.375rem"
							:sourceUrl="source"
							:isPlaySource="isPlaySource"
							:isLive="false"
							:isAutoplay="isAutoplay"
							:videoMsg="videoMsg"
							ref="player"
							v-if="videoPlayerType == 1"
						></ckplayer>
						<!-- iframe页面播放 -->
						<div class="iframe" v-if="videoPlayerType == 2">
							<iframe v-if="isWebView" scrolling="no" frameborder="0" :src="iframeSrc" allowfullscreen="true"></iframe>
						</div>
						<!-- 等待播放 -->
						<div class="flex-cc w100 h100 bgc-black guoduDiv" v-if="videoPlayerType == 10"><img src="../../static/main/lod.gif" /></div>
						<!-- 跳转 -->
						<div v-if="videoPlayerType == 3" class="flex-cc w100 h100 bgc-black navBlankView">
							点击跳转：
							<a :href="ahref" target="_blank">{{ aTvName }} {{ aSourceName }}</a>
						</div>
					</div>
				</div>
				<AdSlot :AdName="'LX-3'" locationPosition="3" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="lx" style="margin: -1rem 0 1rem 0;"></AdSlot>
				<div class="lx-detail-content">
					<!-- <lxListDetail></lxListDetail> -->
					<lx-detail-NBAlist :livelist="livelist" :ftitle="ftitle" :navItem="navItem"></lx-detail-NBAlist>
					<div style="width: 100%;height: 0.9375rem;"></div>
					<div class="list-atemp-head">
						<div class="list-atemp-tip">
							<span class="tip-text fs22">{{ nbaTitle }}</span>
						</div>
						<div><span class="list-more pointer" @click="newNavTo">更多>></span></div>
					</div>
					<hr style="width:66.5rem;height:0.125rem;background:rgba(27,27,48,1);" />
					<unit-video-list :videoList="videoList" videoListWidth="66.5rem"></unit-video-list>
				</div>
			</div>
			<div class="column-right">
				<AdSlot :AdName="'LX-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="lx" style="margin:0.625rem 0"></AdSlot>
				<lx-detail-NBA-news :newsList="newsList" :title="title" :isMore="true"></lx-detail-NBA-news>
				<!-- <div style="width: 100%;height: 1.375rem;"></div> -->
				<!-- 暂时用着 -->
				<AdSlot :AdName="'LX-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="lx" style="margin:0.625rem 0"></AdSlot>
			</div>
		</div>
	</div>
</template>

<script>
import lxListDetail from '../../atemp/lx-list-detail.vue';
import ckplayer from '../../components/ckplayer.vue';
import unitVideoList from '../../atemp/unit-video-list.vue';

import lxDetailNBAlist from '../../atemp/lx-detail-NBAlist.vue';
import lxDetailNBANews from '../../atemp/lx-detail-NBA-news.vue';

let that;
const { log } = console;
export default {
	components: {
		lxListDetail,
		ckplayer,
		unitVideoList,
		lxDetailNBANews,
		lxDetailNBAlist
	},
	data() {
		return {
			breadcumb: {
				list: [{ name: '录像', path: '/lx-video?hid=2' }, { name: '', path: '' }, { name: '', path: '' }, { name: '', path: '' }]
			},

			//录像播放源
			source: '',
			isAutoplay: true,
			clickSourceId: '',
			timeIndex: 0,

			timer: '',

			timerData: null,

			sourceArr: {},

			//iframe
			isWebView: true, //是否是webview
			iframeSrc: '', //路径

			// NBA新闻
			newsList: [],
			queryNewsType: 2, // (视频列表)查询所属类型 0项目 1专题 2赛事类型 3热门 4完结 5全部

			// 视频列表
			videoList: [],
			queryVideoType: 2, // (视频列表)查询所属类型 0项目 1专题 2赛事类型 3热门 4完结 5全部

			livelist: [],

			// 侧边栏
			ftitle: '',

			title: '',

			//侧边栏
			matchType: '',

			eventTypeId: '',

			specialId: '',

			eventId: '',

			eventName: '',

			numberType1: 0,

			numberType2: 0,

			nbaTitle: '',

			matchTypeData: {},

			numberType3: 0,
			navItem: {},
			matchId: '',
			eventTypeName: '',
			//轮巡
			analysisSourceNum: 0,
			isPlaySource: true, //播放源
			videoPlayerType: 10, //播放类型
			videoMsg: '暂未获取信号,请选择其他播放源观看',
			ahref: '', //页面跳转路径
			aSourceName: '', //页面线路
			aTvName: '' //电视名
		};
	},
	watch: {
		$route: {
			handler() {
				that.id = that.$route.query.id || 0;
				that.title = that.$route.query.title;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	created: function() {
		that = this;
		let query = that.$route.query;
		that.matchId = query.matchId;
		// 查询sourceId所在的数组
		if (!query.data) {
			that.navItem = {
				id: '', // 标签id
				type: 5, // 标签类型 3热门 4完结 5全部
				name: '全部' // 标签名称
			};
		} else {
			that.navItem = JSON.parse(that.$route.query.data);
		}

		that.breadcumb.list[1] = {
			name: that.navItem.name,
			path: `/lx-video?hid=2&sid=${that.navItem.SN}&data=${JSON.stringify(that.navItem)}`
		};
		if (that.navItem.secondName) {
			that.breadcumb.list[2] = {
				name: that.navItem.secondName,
				path: `/liveRoom?matchId=${query.matchId}&activeName=lx`
			};
		}
		let sourceType = query.sourceType ? query.sourceType : 1;
		that.sourceArray(query.matchId, query.sourceId, sourceType);
	},
	methods: {
		// 相关录像
		viedeoList() {
			let datas;
			// log(that.eventTypeId, '===?that.eventTypeI');
			if (that.eventTypeId) {
				datas = {
					eventId: '',
					eventTypeId: that.eventTypeId,
					limit: 5,
					matchDate: '',
					offset: 1,
					sourceType: 1
					// specialId: type
				};
			} else {
				datas = {
					eventId: that.eventId,
					eventTypeId: '',
					limit: 5,
					matchDate: '',
					offset: 1,
					sourceType: 1
					// specialId: type
				};
			}
			that.$newsReq.queryMatchByVideo(datas).then(res => {
				// log(res, '===>NBA录像');
				that.livelist = res.data.data.list;
				if (that.eventTypeId && that.livelist[0].eventTypeName !== '其他') {
					that.ftitle = that.livelist[0].eventTypeName + '录像';
				} else {
					that.ftitle = that.livelist[0].eventName + '录像';
				}
			});
		},
		//相关新闻
		getNewsList() {
			// log(that.eventTypeId, that.eventId, '===>eventTypeId/eventId');
			let datas = {
				id: that.queryNewsType == 2 ? that.eventTypeId : that.eventId,
				limit: 8,
				offset: 1,
				type: that.queryNewsType == 2 ? 2 : 0
			};
			that.$newsReq.queryNewsTitle(datas).then(res => {
				let list = res.data.data.list;
				if (list.length) {
					// log('有数据===>', list);
					that.newsList = list;
					if (that.queryNewsType == 2) {
						that.title = that.eventTypeName + '新闻';
					} else {
						that.title = that.eventName + '新闻';
					}
				} else {
					switch (that.queryNewsType) {
						case 2:
							// 专题
							that.queryNewsType = 1;
							that.getNewsList();
							break;
						case 1:
							// 项目
							that.queryNewsType = 0;
							that.getNewsList();
							break;
						default:
							break;
					}
				}
			});
		},
		// 初始化播放器
		beginVideo(item) {
			// this.isAutoplay = item.ap ? true : false;
			that.isPlaySource = true;
			this.$nextTick(() => {
				// log('舒适化===', that.source);
				// that.source = 'http://cctvalih5ca.v.myalicdn.com/live/cctv1_2/index.m3u8';
				that.$refs.player.initVideo({
					url: that.source,
					hm: item.hm,
					fp: item.fp
				});
			});
		},
		// 修改视频 (切换播放源)
		changeVideo() {
			that.isPlaySource = true;
			this.$nextTick(() => {
				that.$refs.player.changeVideo({
					url: that.source
				});
			});
		},
		/*加载ifrmae*/
		beginIframe(res) {
			that.iframeSrc = res.iframeSrc;
			console.log('设置ifrmae');
		},

		//获取赛事
		sourceArray(matchId, sourceId, sourceType = 1) {
			// log(matchId, sourceId, '===>matchId---sourceId');
			that.$newsReq
				.queryMatchByVideo({
					matchDate: '',
					matchId: matchId,
					// matchId:6035,
					sourceType: sourceType
				})
				.then(res => {
					// log(res, '===>数组');
					let resdatas = res.data.data.list[0];
					// sourceType 为 2 ==>集锦时
					if (sourceType == 2) {
						let name = resdatas.homeTeamName ? `${resdatas.homeTeamName} - ${resdatas.guestTeamName}` : `${resdatas.eventName} ${resdatas.matchTitle}`;
						that.breadcumb.list[2] = {
							name: name,
							path: `/liveRoom?matchId=${matchId}&activeName=lx`
						};
					}

					that.eventTypeId = resdatas.eventTypeId;
					that.specialId = resdatas.specialId;
					that.eventId = resdatas.eventId;
					that.eventName = resdatas.eventName;
					that.eventTypeName = resdatas.eventTypeName;
					//调用之前清除 轮巡
					that.numberType1 = 0;
					that.numberType2 = 0;
					// 侧边栏
					that.viedeoList();
					// 相关视频
					that.spVideoNBA();
					//相关新闻
					that.newsNBA();

					// that.getNewsList();
					// that.viedeoList();
					// that.getVideoList();

					let resdata = res.data.data.list[0].matchLiveSourceDOS;
					// log(resdata, '===>数组');

					let index = resdata.findIndex(item => item.sourceId == sourceId);
					that.sourceArr = resdata[index];
					// that.breadcumb.list.push({name: resdata[index].liveSourceName,path:''})
					that.breadcumb.list[3].name = resdata[index].liveSourceName;
					// log(that.breadcumb.list[3].name,"擦撒大苏打大")

					that.init();
				});
		},
		//初始化
		init() {
			that.getAnalysisSource(that.sourceArr.sourceId);
		},
		// 设置播放源
		setPlaySource(item) {
			// log('设置播放源===>', item);
			if (item.isAnalysis) {
				// log('==>我解析到了<==', item.isAnalysis);
				switch (item.isAnalysis) {
					case '0':
						that.videoPlayerType = 1;
						setTimeout(() => {
							if (item.analysisPlayPathWeb) {
								that.source = item.analysisPlayPathWeb;
								that.beginVideo(item);
							} else {
								if (item.analysisPlayPathPc) {
									that.source = item.analysisPlayPathPc;
									that.beginVideo(item);
								} else {
									that.pcLink(item);
								}
							}
						});
						break;
					case '1':
						that.videoPlayerType = 2;
						if (item.notAnalysisPlayPath) {
							setTimeout(() => {
								that.beginIframe({
									// liveSourceName: item.liveSourceName,
									iframeSrc: item.notAnalysisPlayPath
								});
							}, 0);
						} else {
							that.pcLink(item);
						}
						break;
					case '2':
						that.videoPlayerType = 1;
						setTimeout(() => {
							if (item.analysisPlayPathWeb) {
								that.source = item.analysisPlayPathWeb;
								that.beginVideo(item);
							} else {
								if (item.analysisPlayPathPc) {
									that.source = item.analysisPlayPathPc;
									that.beginVideo(item);
								} else {
									that.pcLink(item);
								}
							}
						}, 0);
						break;
					case '3':
						that.videoPlayerType = 3;
						if (item.notAnalysisPlayPath) {
							that.ahref = item.notAnalysisPlayPath;
							that.aSourceName = item.liveSourceName;
							that.aTvName = that.breadcumb.list[2].name;
						} else {
							that.pcLink(item);
						}
						break;
				}
			}
		},
		// 视频地址为空的时候,用pcLink
		pcLink(item) {
			let pcLink;
			if (item.pcLink) {
				pcLink = item.pcLink;
			} else {
				if (webLink) {
					pcLink = item.pcLink;
				} else {
					that.loswer();
					return;
				}
			}
			switch (item.linkPlayType) {
				case '2':
					that.videoPlayerType = 2;
					that.beginIframe({
						iframeSrc: pcLink
					});
					break;
				case '3':
					that.videoPlayerType = 3;
					that.ahref = pcLink;
					that.aSourceName = item.liveSourceName;
					that.aTvName = that.breadcumb.list[2].name;
					break;
			}
		},
		// 解析直播源
		getAnalysisSource(sourceId) {
			// log('解析的是==>', sourceId);
			let datas = {
				sourcePathId: sourceId
			};
			that.analysisSourceNum = 0;
			that.analysisMatchLiveSource(datas);
		},

		analysisMatchLiveSource(datas) {
			that.analysisSourceNum++;
			that.$newsReq
				.analysisMatchLiveSource(datas)
				.then(res => {
					// log(res, '==>解析');
					let data = res.data.data;
					// log(data, '===>data');
					if (res.data.resultCode == 1) {
						data.valid = '0';
						that.setPlaySource(data);
					} else {
						if (res.data.resultCode == -199) {
							if (that.analysisSourceNum < 10) {
								setTimeout(() => {
									that.analysisMatchLiveSource(datas);
								}, 1000);
							} else {
								that.loswer();
							}
						} else {
							that.loswer(res.data.resultMsg);
						}
					}
				})
				.catch(err => {
					// log(err, '录像解析失败原因');
					// that.loswer();
				});
		},
		//解析失败
		loswer(title) {
			that.isPlaySource = false;
			that.videoPlayerType = 1;
			that.videoMsg = title || '暂未获取信号,请选择其他播放源观看';
		},
		setindex(i) {
			if (that.sindex != i) {
				that.sindex = i;
			}
		},
		formatTime(e) {
			// console.log(e);
		},
		sizeChange(e) {
			// console.log('每页条数', e);
		},
		currentChange(e) {
			// console.log('当前页', e);
		},
		prevClick(e) {
			// console.log('上一页', e);
		},
		nextClick(e) {
			// console.log('下一页', e);
		},

		newNavTo() {
			this.BR.navTo('/sp-video', {
				hid: 3
			});
		},
		// 相关视频
		spVideoNBA() {
			let datas;
			let newArr = ['eventTypeId', 'specialId', 'eventId'];
			let newType = [2, 1, 0];
			if (that.numberType1 < 3) {
				datas = {
					id: that[newArr[that.numberType1]],
					limit: 8,
					offset: 1,
					type: newType[that.numberType1]
				};
			} else {
				that.nbaTitle = that.eventName + '视频';
				return;
			}

			that.$reqc.queryLiveTitle(datas).then(res => {
				// log(res, '===>视频');
				that.numberType1++;
				if (res.data.data.list.length) {
					// log('视频有数据======>', that.numberType1);
					that.videoList = res.data.data.list;
					if (that.numberType1 == 3) {
						that.nbaTitle = that.eventName + '视频';
					} else {
						that.eventTypeName == '其他' ? (that.nbaTitle = that.eventName + '视频') : (that.nbaTitle = that.eventTypeName + '视频');
					}
				} else {
					// log('重新调用');

					that.spVideoNBA();
				}
				// that.newsList = res.data.data.list;
			});
		},
		//相关新闻
		newsNBA() {
			let datas;
			let newArr = ['eventTypeId', 'specialId', 'eventId'];
			let newType = [2, 1, 0];
			if (that.numberType2 < 3) {
				datas = {
					id: that[newArr[that.numberType2]],
					limit: 8,
					offset: 1,
					type: newType[that.numberType2]
				};
			} else {
				that.title = that.eventName + '新闻';
				return;
			}

			that.$newsReq.queryNewsTitle(datas).then(res => {
				// log(res, '===>新闻');
				that.numberType2++;
				if (res.data.data.list.length) {
					// log('有数据新闻==>', that.numberType2);
					that.newsList = res.data.data.list;
					if (that.numberType1 == 3) {
						that.title = that.eventName + '视频';
					} else {
						that.eventTypeName == '其他' ? (that.title = that.eventName + '视频') : (that.title = that.eventTypeName + '视频');
					}
				} else {
					// log('重新调用');

					that.newsNBA();
				}
			});
		}
	}
};
</script>

<style lang="scss" scoped>
/* @import "../static/css/55-59.css"; */
/* @import "../static/css/app-2.css"; */

// .mainView {
// 	width: 100%;
// 	min-height: 32em;
// 	display: flex;
// 	justify-content: center;
// }
.mainView {
	display: flex;
	align-items: flex-start;
	// border: 1px solid red;
	.layout {
		display: flex;
		justify-content: center;
		align-items: flex-start;
		flex-direction: column;
		min-height: 32em;
		width: 66.5rem;
	}
}
.mainView-top {
	display: flex;
	width: 100%;
	> div {
		flex: 1;
	}
}
.lx-detail-content {
	width: 100%;
	flex: 1;
}
.mainView-content {
	flex: 1;
	min-height: 32em;
	display: flex;
	justify-content: center;
	align-items: flex-start;
	position: relative;
}
/deep/.lx-div {
	// width: 100%;
	// width: 1400px;
	// border: 1px solid red;
	flex: 1;
	display: flex;
	flex-direction: column;

	.lx-title {
		// height:66px;
		height: 4.125rem;
		background: $bg-main;
		// font-size:22px;
		font-size: 1.375rem;
		font-family: Microsoft YaHei;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		// line-height:66px;
		line-height: 4.125rem;
		text-align: left;
		// padding-left: 24px;
		padding-left: 1.5rem;
	}
	.lx-list {
		// height: 79px;
		height: 4.9375rem;
		display: flex;
		justify-content: space-between;
		align-items: center;
		background-color: $bg-white;
		// padding: 0 26px;
		padding: 0 1.625rem;
		border-bottom: 0.0625rem solid rgba(204, 204, 204, 1);

		&:last-child {
			border: 0;
		}
		.lx-item-text {
			// font-size:20px;
			font-size: 1.25rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: #333333;
			// line-height:28px;
			line-height: 1.75rem;
			flex: 1;
			text-align: left;

			span {
				margin-left: 0.625rem;

				&:first-child {
					margin-left: 0;
				}
			}
		}
		.lx-item-but {
			width: 6.125rem;
			height: 1.75rem;
			background: $bg-main;
			border-radius: 0.875rem;
			// font-size:16px;
			font-size: 1rem;
			font-weight: 400;
			color: rgba(255, 255, 255, 1);
			line-height: 1.75rem;
			margin: 0 1.375rem;
		}
	}
}

.container {
	// width: 1400px;
	width: 66.5rem;
	/* min-height:900px; */
	height: auto;
	margin: 0 auto;
	margin-top: 0.625rem;
	background-color: #f5f5f5;
	display: flex;
	justify-content: space-between;
	// border: 1px solid red;
	margin-bottom: 2.5rem;
}

.column-left {
	// width: 1064px;
	width: 66.5rem;
	/* height: auto; */
	// height: 100%;
	// width: 100%;
	min-height: 34.375rem;
	// height: 40.625rem;
	// border: 1px solid red;
}

.iframe {
	width: 100%;
	// border: 1px solid red;
	// height: 50rem;
	// margin-bottom: 2.5rem;
	// overflow: hidden;

	iframe {
		// width: 100%;
		// height: 50rem;
		width: 66.5rem;
		height: 40.625rem;
		background: rgba(0, 0, 0, 1);
		overflow: hidden;
	}
}

.black-msk {
	width: 66.5rem;
	height: 40.625rem;
	background: rgba(0, 0, 0, 1);
	opacity: 0.3;
	// margin-bottom: 6.25rem;
}

.guoduDiv {
	img {
		width: 10rem;
		height: 10rem;
	}
}
.navBlankView {
	width: 100%;
	height: 34.375rem;
	font-size: 1.8rem;
	color: #ffffff;
	a {
		font-size: 1.8rem;
		font-weight: 600;
		color: $bg-chengse;
		text-decoration: underline;
	}
}
.list-atemp-head {
	width: 66.5rem;
}
</style>