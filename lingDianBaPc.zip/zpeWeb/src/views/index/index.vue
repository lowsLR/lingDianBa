<template>
	<div>
	<zHeader/></zHeader>
	<!-- <z-main></z-main> -->
	<router-view></router-view>
	<zFooter></zFooter>
	</div>
</template>

<script>
	
	import zHeader from '../../components/header.vue' 
	// import zMain from '../../components/main.vue' 
	import zFooter from '../../components/foot.vue' 
	export default {
	  components: {
		zHeader,
		// zMain, 
		zFooter
	  },
	  data() {
	  	return {
	  		sid: 1,
	  	}
	  },
	}
</script>

<style>
</style>
