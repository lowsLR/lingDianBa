<template>
	<div class="container">
		<div class="main">
			<div class="column-left">
				<AdSlot :AdName="'DSXQ-1'" locationPosition="1" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="dsxq" style="margin: 0.625rem 0"></AdSlot>
				<crumbs :breadcumb="breadcumb"></crumbs>
				<div class="live">
					<!-- <video src="https://media.w3.org/2010/05/sintel/trailer.mp4" controls width="960">
							您的浏览器不支持 video 标签。
							Internet Explorer 9+, Firefox, Opera, Chrome 以及 Safari 支持 video 标签。
					</video> -->
					<!-- <aliPlayer
						@play="play"
						:useH5Prism="useH5Prism"
						:useFlashPrism="useFlashPrism"
						:autoplay="autoplay"
						:isLive="isLive"
						:rePlay="false"
						:showBuffer="true"
						showBarTime="5000"
						controlBarVisibility="hover"
						width="100%"
						height="550px"
						:source="source"
						ref="player"
					></aliPlayer> -->

					<div class="tv-layout">
						<ckplayer
							width="100%"
							height="34.375rem"
							:sourceUrl="source"
							:isPlaySource="isPlaySource"
							:isLive="isLive"
							:isAutoplay="isAutoplay"
							:videoMsg="videoMsg"
							ref="player"
							v-if="videoPlayerType == 1"
						></ckplayer>
						<!-- iframe页面播放 -->
						<div class="iframe" v-if="videoPlayerType == 2">
							<iframe v-if="isWebView" scrolling="no" frameborder="0" :src="iframeSrc" allowfullscreen="true"></iframe>
						</div>
						<!-- 跳转 -->
						<div v-if="videoPlayerType == 3" class="flex-cc w100 h100 bgc-black navBlankView">
							点击跳转：
							<a :href="ahref" target="_blank">{{ aTvName }} {{ aSourceName }}</a>
						</div>
						<!-- 等待播放 -->
						<div class="flex-cc w100 h100 bgc-black guoduDiv" v-if="videoPlayerType == 10"><img src="../../static/main/lod.gif" /></div>
					</div>
					<div class="signalSource">
						<p
							v-for="(item, index) in signalList"
							:key="index"
							:class="signalSourceId === item.sourceId ? 'active' : ''"
							@click="sourceIndex(item.sourceId, item.isAnalysis, item)"
						>
							{{ item.sourceName }}
						</p>
					</div>
				</div>
				<AdSlot :AdName="'DSXQ-3'" locationPosition="3" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="dsxq" style="margin: 0.625rem 0"></AdSlot>
				<div class="module">
					<unit-title-tag :title="'频道介绍'"></unit-title-tag>
					<div class="introduce">
						<div class="img"><img @error="errorImg($event, defaultImg)" :src="tvData.imgLog ? tvData.imgLog : require('../../static/image/default_img.png')" /></div>
						<div class="content" v-html="tvData.tvDetails"></div>
						<!-- <div class="content">{{tvData.tvDetails}}</div> -->
						<!-- <div class="content">{{tvBrief}}</div> -->
					</div>
				</div>
			</div>

			<div class="column-right">
				<AdSlot :AdName="'DSXQ-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="dsxq" style="margin: 0.625rem 0"></AdSlot>
				<!-- 热门频道 -->
				<channel @toUpdateTv="toUpdateTv" :isNoNavto="true" pageType="4"></channel>
				<div style="width: 100%;height: 1.5rem;"></div>
				<!-- 其他体育频道 -->
				<!-- <channel @toUpdateTv="toUpdateTv" :isNoNavto="true"></channel> -->
				<channel-tv-about :isFlag="false" :clist="tyClist" :other="false" @toUpdateTv="toUpdateTv" :isNoNavto="true"></channel-tv-about>
				<div style="width: 100%;height: 1.5rem;"></div>
				<!-- 其他CCTV频道 -->
				<AdSlot :AdName="'DSXQ-4'" locationPosition="4" locationType="0" :adWidth="19.875" :adHeight="12.5" adStr="dsxq" style="margin:-0.625rem 0 0 0"></AdSlot>
				<channel-tv-about
					:isFlag="false"
					:clist="wsClist"
					:other="false"
					@toUpdateTv="toUpdateTv"
					:isNoNavto="true"
					title="其他CCTV频道"
					:showTvNum="12"
				></channel-tv-about>
			</div>
		</div>

		<div class="footGG"></div>
	</div>
</template>

<script>
import aliPlayer from '../../atemp/aliPlayer.vue';
import unitTitleTag from '../../atemp/unit-title-tag.vue';
import channel from '../../atemp/channel.vue';

import ckplayer from '../../components/ckplayer.vue';
import channelTvAbout from '../../atemp/channel-tv-about.vue';
let that;
const { log } = console;
export default {
	components: {
		aliPlayer,
		unitTitleTag,
		channel,
		ckplayer,
		channelTvAbout
	},
	data() {
		return {
			isLive: true, //是否直播
			// sourceIndex: 0,
			id: '',
			routerUrl: '',
			tvData: {}, // 电视台数据
			// source: 'http://by4.nty.tv189.cn/tm-btv1hd-800k.m3u8',
			source: '', // 视频播放地址
			signalList: [], //播放源
			signalSourceId: '', // 切换播放源

			clickAnalysis: false,

			breadcumb: {
				list: [{ name: '电视', path: '/tv?hid=4' }, { name: '', path: '/localTv?' }, { name: '', path: '' }]
			},
			//其他体育频道
			tyClist: [],
			// 其他的cctv
			wsClist: [],
			// 频道简介
			tvBrief: '',
			isPlaySource: true, //是否存在播放源
			videoMsg: '暂未获取信号,请选择其他播放源观看', //错误信息
			isAutoplay: true, //是否自动播放
			videoPlayerType: 10, //播放类型
			analysisSourceNum: 0, //轮巡
			//iframe
			isWebView: true, //是否是webview
			iframeSrc: '', //路径
			ahref: '', //页面跳转路径
			aSourceName: '', //页面线路
			aTvName: '', //电视名
			defaultImg: require('../../static/image/default_img.png') // 默认图片
		};
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		that.id = that.$route.params.id;
		// sessionStorage.clear();清除缓存
		// 频道简介
		that.tvBrief = that.$route.query.tvBrief;
		this.$nextTick(() => {
			let storageTvId = sessionStorage.getItem('tvPlayer'); //查询缓存
			// log('查询缓存====>', storageTvId);
			if (that.$route.query.tid) {
				that.getQueryTvConten(that.$route.query.tid);
			} else {
				if (storageTvId) {
					that.getQueryTvConten(storageTvId);
				}
			}
			//侧边栏
			// 其他的体育频道
			// "id": 7,"typeName": "其它",
			// "id": 6,"typeName": "科教",
			// "id": 4,"typeName": "少儿",
			// "id": 1,"typeName": "综艺",
			// "id": 3,"typeName": "影视",
			// "id": 2,"typeName": "体育",
			// "id": 10,"typeName": "卫视",
			that.getQueryTvInfoList('2');
			// 其他的cctv
			// that.getQueryTvInfoList('10');
			that.getQueryLikeTvName('cctv');
		});
	},
	methods: {
		//查询电视台信息
		getQueryTvInfo(id, name) {
			that.$newsReq
				.queryTvInfo({
					id: id,
					livePlatform: '0',
					type: 3
				})
				.then(res => {
					// log(res, '==>查询电视台信息');
					that.breadcumb.list[1] = {
						name: res.data.data[0].provincialAreaName,
						path: '/localTv?hid=4&tid=' + JSON.stringify(res.data.data[0].provincialArea)
					};
					// log(that.breadcumb.list[1], '===>成功');
					that.breadcumb.list[2].name = name;
				});
		},
		// 切换播放源
		sourceIndex(sourceId, isAnalysis, item) {
			that.clickAnalysis = true;
			// that.isPlaySource = false;
			that.videoPlayerType = 0;
			// log(sourceId, isAnalysis, item, '===>切换');
			that.signalSourceId = that.signalSourceId === sourceId ? that.signalSourceId : sourceId;
			if (isAnalysis == 0) {
				that.getAnalysisTv(sourceId);
			} else {
				that.setPlaySource(item);
			}
			that.pageScrollTop();
		},
		// 视频解析
		getAnalysisTv(sourceId) {
			let datas = {
				livePlatform: '0',
				sourceId: sourceId
			};
			that.analysisSourceNum = 0;
			that.analysisMatchLiveSource(datas);
		},
		analysisMatchLiveSource(datas) {
			that.analysisSourceNum++;
			that.$newsReq.analysisTv(datas).then(res => {
				// log(res.data, '==>视频解析');
				let data = res.data.data;
				if (res.data.resultCode == 1) {
					// data.valid = '0';
					that.setPlaySource(data);
				} else {
					if (res.data.resultCode == -199) {
						if (that.analysisSourceNum < 10) {
							setTimeout(() => {
								that.analysisMatchLiveSource(datas);
							}, 1000);
						} else {
							that.loswer();
						}
					} else {
						that.loswer(res.data.resultMsg);
					}
				}
			});
		},
		// 设置播放源
		setPlaySource(item) {
			// log(item, '===>设置播放源');
			if (item.playType) {
				switch (item.playType) {
					case 1:
						that.videoPlayerType = 1;
						if (item.sourcePath) {
							that.source = item.sourcePath;
							that.beginVideo(item);
							// log('11解析后的地址===>', that.source);
						} else {
							that.sourceLinkFun(item);
						}
						break;
					case 2:
						that.videoPlayerType = 2;
						if (item.analysisPath) {
							setTimeout(() => {
								that.beginIframe({
									// liveSourceName: item.liveSourceName,
									iframeSrc: item.analysisPath
								});
							}, 0);
							// log('22解析后的地址===>', item.analysisPath);
						} else {
							that.sourceLinkFun(item);
						}
						break;
					case 3:
						that.videoPlayerType = 3;
						if (item.sourcePath) {
							that.ahref = item.sourcePath;
							that.aSourceName = item.sourceName;
							that.aTvName = that.breadcumb.list[2].name;
						} else {
							that.sourceLinkFun(item);
						}
				}
			}
		},
		// sourcePath为空,用sourceLink代替
		sourceLinkFun(item) {
			if (!item.sourceLink) {
				that.loswer(item.invalidMessage);
				return;
			}
			// log('sourcePath为空,用sourceLink代替');
			switch (item.linkPlayType) {
				case '2':
					that.videoPlayerType = 2;
					that.beginIframe({
						iframeSrc: item.sourceLink
					});
					break;
				case '3':
					that.videoPlayerType = 3;
					that.ahref = item.sourceLink;
					that.aSourceName = item.sourceName;
					that.aTvName = that.breadcumb.list[2].name;
					break;
			}
		},
		//解析失败
		loswer(title) {
			that.videoPlayerType = 1;
			// log('****解析失败***');
			that.isPlaySource = false;
			that.videoMsg = title || '暂未获取信号,请选择其他播放源观看';
			// that.$forceUpdate();
		},
		play(event) {
			// console.log(event);
		},
		//电视台内容信息
		getQueryTvConten(tvId) {
			sessionStorage.setItem('tvPlayer', tvId);
			let datas = {
				livePlatform: '0',
				tvId: tvId
			};
			that.$newsReq.queryTvConten(datas).then(res => {
				let list = (res.data.data && res.data.data) || [];
				// log(list, '===>电视台数据');

				that.getQueryTvInfo(list.provincialArea, list.tvName);
				that.tvBrief = list.tvBrief;
				that.tvData = {
					id: list.id,
					imgLog: list.imgLog,
					playbackAddress: list.playbackAddress,
					tvDetails: that.richTextFormat(list.tvDetails, 400),
					tvName: list.tvName,
					tvType: list.tvType,
					webTvInfoSourceList: list.webTvInfoSourceList
				};
				list.webTvInfoSourceList.forEach(item => {
					let obj = {
						sourceId: item.sourceId,
						tvId: item.tvId,
						sourcePathId: item.sourcePathId,
						sourceName: item.sourceName,
						livePlatform: item.livePlatform,
						sourcePath: item.sourcePath,
						analysisPath: item.analysisPath,
						playType: item.playType,
						isAnalysis: item.isAnalysis,
						sourceLink: item.sourceLink
					};

					that.signalList.push(obj);
				});
				that.signalSourceId = that.signalList[0].sourceId; //选中播放源
				// isAnalysis 1==>不解析 0==>解析
				if (that.signalList[0].isAnalysis == 0) {
					that.getAnalysisTv(that.signalList[0].sourceId);
				} else {
					that.setPlaySource(that.signalList[0]);
				}
			});
		},
		/*加载ifrmae*/
		beginIframe(res) {
			that.iframeSrc = res.iframeSrc;
			console.log('设置ifrmae');
		},
		/*修改视频*/
		changeVideo() {
			that.isPlaySource = true;
			that.$nextTick(() => {
				that.$refs.player.changeVideo({
					url: that.source
					// hm: item.hm || false,
					// ap: item.ap || false,
					// fp: item.fp || false,
					// l: item.l || false
				});
			});
		},
		beginVideo(item) {
			that.isPlaySource = true;
			that.$nextTick(() => {
				that.$refs.player.initVideo({
					url: that.source,
					hm: item.hm || false, //H5的m3u8
					ap: item.ap || that.isAutoplay, //是否自动播放
					fp: item.fp || false, //flase插件播放器
					l: item.l || that.isLive //是否直播
				});

				/* 存储观看记录 */
				let arr = [],
					datas = {
						id: that.tvData.id,
						tvName: that.tvData.tvName,
						time: that.$utils.getCurrentDate('MM-DD')
					};
				// that.$ls.remove('tvWatchHistory');return;
				if (that.$ls.get('tvWatchHistory')) {
					arr = that.$ls.get('tvWatchHistory');
					let index = arr.findIndex(item => {
						return item.id == datas.id && item.tvName == datas.tvName;
					});
					if (index != -1) {
						arr.splice(index, 1);
					}
					if (arr.length >= 8) {
						arr = arr.slice(0, 8);
					}
					arr.unshift(datas);
					that.$ls.set('tvWatchHistory', arr);
					// console.log('观看记录：', that.$ls.get('tvWatchHistory'));
				} else {
					arr.push(datas);
					that.$ls.set('tvWatchHistory', arr);
					// console.log('观看记录：', that.$ls.get('tvWatchHistory'));
				}
			});
		},
		toUpdateTv(id) {
			that.source = '';
			that.signalList = [];
			that.videoPlayerType = 0;
			that.getQueryTvConten(id);
			that.pageScrollTop();
		},
		//页面滚动
		pageScrollTop() {
			window.scrollTo(0, 0);
		},
		// 根据分类查询频道
		getQueryTvInfoList(id) {
			that.$newsReq
				.queryTvInfo({
					id: id,
					livePlatform: '0',
					type: 2
				})
				.then(res => {
					// log(res, '===>根据分类查询频道');
					switch (id) {
						case '2':
							that.tyClist = res.data.data;
							break;
						case '10':
							that.wsClist = res.data.data;
					}
				});
		},
		//其他CCTV频道
		getQueryLikeTvName(str) {
			that.$newsReq
				.queryLikeTvName({
					limit: 18,
					offset: 1,
					tvName: str
				})
				.then(res => {
					let resdata = res.data.data.list;
					that.wsClist = resdata;
					// log(that.wsClist, '===>其他CCTV频道');
				});
		},
		// 正则过滤富文本
		richTextFormat(value, length) {
			// value = value.replace(/<\/?[^>]*>/g,'')
			value = value.replace(/<\/?.+?>/g, '');
			value = value.replace(/\s+/g, '');
			if (value.length > 30) {
				return value.slice(0, length) + '...';
			}
			return value;
		}
	},
	watch: {
		$route: {
			handler() {
				// console.log(this.$route.path);
				that.id = that.$route.query.id;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	destroyed() {
		sessionStorage.removeItem('tvPlayer'); //清除缓存
	}
};
</script>

<style lang="scss" scoped>
.container {
	// width: 1400px;
	width: 87.5rem;
	height: auto;
	/* min-height: 900px; */
	margin: 0 auto;
	background-color: #f5f5f5;
	display: flex;
	flex-direction: column;
}

.main {
	display: flex;
	justify-content: space-between;
	// border: 1px solid red;
}

.column-left {
	// width: ;
	width: 66.5rem;
	height: auto;
}

.live {
	.tv-layout {
		width: 100%;
		height: 34.375rem;
		background: #000;
	}
	.signalSource {
		display: flex;
		flex-wrap: wrap;
		// justify-content: center;
		align-items: center;
		min-height: 4.125rem;
		background-color: #ffffff;
		// border:1px solid red;

		p {
			// width: 200px;
			width: 12.5rem;
			// height: 44px;
			height: 2.75rem;
			// margin: 11px 25px;
			margin: 0.6875rem 1.5625rem;
			// line-height: 44px;
			line-height: 2.75rem;
			border-radius: 1.375rem;
			border: 0.0625rem solid #1b1b30;
			// font-size: 16px;
			font-size: 1rem;
			color: #1b1b30;
			cursor: pointer;
			// border:1px solid red;
		}
		p.active {
			background-color: #1b1b30;
			color: #ffffff;
		}
	}
}

.module {
	margin-top: 1.5rem;
	.introduce {
		width: 66.5rem;
		// height: 12.625rem;
		background: rgba(255, 255, 255, 1);
		overflow: hidden;
		padding: 0.625rem;
		display: flex;
		// align-items: center;
		// border: 1px solid red;

		.img {
			width: 11.375rem;
			height: 11.375rem;
			background: rgba(255, 255, 255, 1);
			border: 0.0625rem solid rgba(27, 27, 48, 1);
			display: flex;
			justify-content: center;
			align-items: center;
			img {
				width: 9.875rem;
				height: 4.25rem;
				display: block;
			}
			// border: 1px solid red;
			margin-top: 1.25rem;
		}

		.content {
			flex: 1;
			// border: 1px solid red;
			// height: 11.375rem;
			// overflow: hidden;
			margin-left: 1.625rem;
			text-align: left;

			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: rgba(102, 102, 102, 1);
			line-height: 1.85rem;
			text-align: left;
			text-indent: 2em;
			padding: 0;
			// margin-top: -1.875rem;
		}
	}

	.tvGuide {
		height: auto;
		text-align: left;
		background-color: #ffffff;
		p {
			// height: 88px;
			// line-height: 87px;
			height: 5.5rem;
			line-height: 5.5rem;
			border-bottom: 0.0625rem dashed #999999;

			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space: nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
			font-size: 1rem;
			font-family: Microsoft YaHei;
			font-weight: 400;
			/* color: rgba(102, 102, 102, 1); */
			color: #666666;
		}
		p:last-child {
			border: 0;
		}

		.time {
			// padding: 0 60px;
			padding: 0 3.75rem;
		}
	}
}

.column-right {
	// width: 318px;
	width: 19.875rem;
	height: auto;
}

.content p {
	color: red !important;
}

.iframe {
	width: 100%;
	// border: 1px solid red;
	// height: 50rem;
	// margin-bottom: 2.5rem;
	// overflow: hidden;
	height: 34.375rem;

	iframe {
		// width: 100%;
		// height: 50rem;
		width: 66.5rem;
		height: 34.375rem;
		background: rgba(0, 0, 0, 1);
		overflow: hidden;
	}
}

.guoduDiv {
	width: 100%;
	height: 34.375rem;
	img {
		width: 10rem;
		height: 10rem;
	}
}

.navBlankView {
	width: 100%;
	height: 34.375rem;
	font-size: 1.8rem;
	color: #ffffff;
	a {
		font-size: 1.8rem;
		font-weight: 600;
		color: $bg-chengse;
		text-decoration: underline;
	}
}
</style>
