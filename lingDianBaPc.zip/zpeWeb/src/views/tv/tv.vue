<template>
	<div class="container">
		<div class="channel">
			<div class="column-left">
				<AdSlot :AdName="'DS-1'" locationPosition="1" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="ds" style="margin: 0.625rem 0"></AdSlot>
				<crumbs :breadcumb="breadcumb"></crumbs>

				<unit-title-tag :tagType="0" :title="'地区电视台'"></unit-title-tag>
				<ul class="tv-list">
					<li class="pointer" v-for="(item, index) in HotTv" :key="index" @click="navTo(item.id, index)">{{ item.provincialArea }}</li>
				</ul>

				<div class="hotTv">
					<unit-title-tag :title="hotTvTitle"></unit-title-tag>
					<div class="tvlayout">
						<div class="tvList">
							<div class="tvItem" v-for="(citem, cindex) in hotTv" :key="cindex" @click="navToTvDetails(citem.id)">
								<img @error="errorImg($event, defaultImg)" :src="citem.imgLog ? citem.imgLog : require('../../static/image/default_img.png')" />
								<p class="name pointer">{{ citem.tvName }}</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="column-right">
				<searchView :selectList="selectList" style="margin-bottom: 0.625rem;"></searchView>
				<AdSlot :AdName="'DS-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="ds" style="margin: 0.625rem 0"></AdSlot>
				<!-- 热门频道 -->
				<channel pageType="4" :isShow="false"></channel>
				<AdSlot :AdName="'DS-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="ds" style="margin: 0.625rem 0 0 0"></AdSlot>
				<div class="history"><unit-watch-history :historyArr="historyArr"></unit-watch-history></div>
			</div>
		</div>
		<div class="footGG"></div>
	</div>
</template>

<script>
import unitTitleTag from '../../atemp/unit-title-tag.vue';
import unitWatchHistory from '../../atemp/unit-watch-history.vue';
import searchView from '../../atemp/search.vue';
import channel from '../../atemp/channel.vue';
let that;
const { log } = console;
export default {
	components: {
		unitTitleTag,
		unitWatchHistory,
		searchView,
		channel
	},
	data() {
		return {
			hotTv: [],
			HotTv: [],
			hotTvTitle: '热门频道',
			id: '',
			routerUrl: '',
			hiddemsk: false,
			//搜索电台
			searchTvData: [],
			// 搜索内容
			searchContent: '',

			breadcumb: {
				list: [{ name: '电视', path: '' }, { name: '热门', path: '' }]
			},

			valueTitle: '',

			selectList: [{ id: 1, title: '电视' }, { id: 2, title: '直播' }, { id: 3, title: '录像' }, { id: 4, title: '新闻' }, { id: 5, title: '视频' }],

			nowIndex: 0,
			historyArr: [], // 电视观看记录
			queryObj: {}, //记录电视分类
			defaultImg: require('../../static/image/default_img.png') // 默认图片
		};
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		that.id = that.$route.params.id;
		let query = that.$route.query;
		// console.log(that.$route.params,"params==>页面初始化时");

		// 获取观看记录
		if (that.$ls.get('tvWatchHistory')) {
			that.historyArr = that.$ls.get('tvWatchHistory');
		}

		// 查询电视台信息
		let datas;
		if (query.data) {
			let data = JSON.parse(query.data);
			if (data.name == '地区电视台') {
				datas = {
					id: '',
					livePlatform: 0,
					type: 1 //查询电视类型 1热门电视台 2电视台类型 3根据地区查询电视台
				};
				that.breadcumb.list[1].name = '热门';
				that.hotTvTitle = '热门频道';
				that.queryObj = {
					id: '',
					name: '地区电视台',
					SN: 2
				};
			} else {
				datas = {
					id: data.id,
					livePlatform: 0,
					type: 2 //查询电视类型 1热门电视台 2电视台类型 3根据地区查询电视台
				};
				that.breadcumb.list[1].name = data.name;
				that.hotTvTitle = data.name + '频道';
				that.queryObj = data;
			}
		} else {
			datas = {
				id: '',
				livePlatform: 0,
				type: 1 //查询电视类型 1热门电视台 2电视台类型 3根据地区查询电视台
			};
			that.breadcumb.list[1].name = '热门';
			that.hotTvTitle = '热门频道';
			that.queryObj = {
				id: '',
				name: '地区电视台',
				SN: 2
			};
		}

		that.$newsReq.queryTvInfo(datas).then(res => {
			// log(res,"===>res");
			that.hotTv = res.data.data;
		});

		//查询省区
		that.$newsReq.queryTvProvincen().then(res => {
			// log(res.data.data, 'res=>>>查询省区');
			that.HotTv = res.data.data;
		});
	},
	methods: {
		navTo(id, index) {
			that.nowIndex = index;
			that.$router.push({
				path: '/localTv',
				query: {
					hid: 4,
					tid: id,
					sid: 3,
					data: JSON.stringify(that.queryObj)
				}
				// params: {hid: nid} -> 如何接收值
			});
		},
		showMsk() {
			if (!that.hiddemsk) that.hiddemsk = true;
			let datas = {
				limit: 10,
				offset: 1,
				searchKey: that.searchContent
			};
			that.$newsReq.searchAll(datas).then(res => {
				// log(res.data.data.webTvInfoDOS, '搜索');
				that.searchTvData = res.data.data.webTvInfoDOS;
			});
		},
		hiddenMsk() {
			if (that.hiddemsk)
				setTimeout(() => {
					that.hiddemsk = false;
				}, 500);
		},
		textClick() {
		},
		navToTvDetails(id) {
			this.BR.navTo('/tvDetails', {
				hid: 4,
				tid: id,
				sid: 3
			});
		}
	},
	watch: {
		$route: {
			handler() {
				// console.log(this.$route, '==?电视台变化');
				that.id = that.$route.query.id;
				that.routerUrl = that.$route.fullPath;
				// log('电台页面-');
				let query = that.$route.query;
				let datas;
				if (query.data) {
					let data = JSON.parse(query.data);
					if (data.name == '地区电视台') {
						datas = {
							id: '',
							livePlatform: 0,
							type: 1 //查询电视类型 1热门电视台 2电视台类型 3根据地区查询电视台
						};
						that.breadcumb.list[1].name = '热门';
						that.hotTvTitle = '热门频道';
						that.queryObj = {
							id: '',
							name: '地区电视台',
							SN: 2
						};
					} else {
						datas = {
							id: data.id,
							livePlatform: 0,
							type: 2 //查询电视类型 1热门电视台 2电视台类型 3根据地区查询电视台
						};
						that.breadcumb.list[1].name = data.name;
						that.hotTvTitle = data.name + '频道';
						that.queryObj = data;
					}
				} else {
					datas = {
						id: '',
						livePlatform: 0,
						type: 1 //查询电视类型 1热门电视台 2电视台类型 3根据地区查询电视台
					};
					that.breadcumb.list[1].name = '热门';
					that.hotTvTitle = '热门频道';
					that.queryObj = {
						id: '',
						name: '地区电视台',
						SN: 2
					};
				}

				that.$newsReq.queryTvInfo(datas).then(res => {
					// log(res,"===>res");
					that.hotTv = res.data.data;
				});
			},
			deep: true
		}
	}
};
</script>

<style lang="scss" scoped>
.container {
	// width: 1400px;
	width: 87.5rem;
	height: auto;
	margin: 0 auto;
	background-color: #f5f5f5;
	display: flex;
	flex-direction: column;
}

.channel {
	display: flex;
	justify-content: space-between;
	// height: 192px;
	// height: 12rem;
	// overflow: hidden;
	margin-bottom: 1.5rem;
}

.tv-list {
	display: flex;
	flex-wrap: wrap;
	// width: 1064px;
	width: 66.5rem;
	padding: 0 0.75rem;
	overflow-y: auto;
	background-color: #ffffff;
	cursor: pointer;

	li {
		// margin: 10px 30px;
		margin: 0.625rem 1.875rem;
		// font-size: 20px;
		font-size: 1.25rem;
		color: #666666;
	}

	.active {
		color: $bg-chengse;
	}
}

.column-right {
	// width: 318px;
	width: 19.875rem;
	margin-top: 0.625rem;

	.history {
		height: 9.875rem;
		width: 20.5rem;
		overflow: hidden;
		// border: 1px solid red;
		margin-top: -0.625rem;
	}
}

.hotTv {
	width: 66.5rem;
	height: auto;
	// border: 1px solid red;
	.tvlayout {
		display: flex;
		flex-direction: column;
	}
	.tvList {
		display: flex;
		flex-wrap: wrap;
		// justify-content: space-between;
		overflow: hidden;
		background-color: #ffffff;
	}
	.tvItem {
		// border: 1px solid red;
		width: 20%;
		// width: 9.875rem;
		height: auto;
		// margin: 30px 37px;
		// margin: 1.875rem 2.3125rem;
		// background-color: peachpuff;
		// border: 1px solid red;
		margin: 1.875rem 0;

		img {
			width: auto;
			// max-width: 158px;
			max-width: 9.875rem;
			height: 4.25rem;
			margin: 0 auto;
			display: block;
		}
		p {
			// font-size: 18px;
			font-size: 1.125rem;
			color: #333333;
			// margin-top: 18px;
			margin-top: 1.125rem;

			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space: nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
		}
	}
}
</style>
