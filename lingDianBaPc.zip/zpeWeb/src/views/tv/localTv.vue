<template>
	<div class="container">
		<div class="main">
			<div class="column-left">
				<AdSlot :AdName="'DS-1'" locationPosition="1" locationType="0" :adWidth="66.5" :adHeight="5.625" adStr="ds" style="margin: 0.625rem 0"></AdSlot>
				<crumbs :breadcumb="breadcumb"></crumbs>
				<unit-title-tag :tagType="0" :title="'地区电视台'"></unit-title-tag>
				<!-- <div class="main"> -->
				<!-- <div class="column-left"> -->
				<ul class="tv-list">
					<li v-for="(item, index) in HotTv" :key="index" @click="regional(item.id)" :class="{ active: item.id == nowIndex }" class="pointer">
						{{ item.provincialArea }}
					</li>
				</ul>

				<div class="hotTv" v-for="(item, index) in districtTv" :key="index">
					<template v-if="item.urbanDistrictList.length">
						<unit-title-tag :title="item.urbanDistrictName"></unit-title-tag>
						<unit-channel-list :urbanDistrictList="item.urbanDistrictList"></unit-channel-list>
					</template>
					<template v-if="item.urbanDistrictName == districtTv[0].urbanDistrictName">
						<!-- <AdSlot AdName="DS-10" width="66.5rem" height="5.625rem" fontSize="4.5rem" style="margin:0.625rem 0 0 0"></AdSlot> -->
					</template>
				</div>
			</div>
			<div class="column-right">
				<AdSlot :AdName="'DS-2'" locationPosition="2" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="ds" style="margin: 0.625rem 0"></AdSlot>
				<!-- 热门频道 -->
				<channel pageType="4"></channel>
				<div style="width: 100%;height: 1.5rem;"></div>
				<!-- 相关频道 -->
				<channel-tv-about :isFlag="false" :clist="clist" :noData="noData"></channel-tv-about>
				<AdSlot :AdName="'DS-3'" locationPosition="3" locationType="0" :adWidth="19.875" :adHeight="10.625" adStr="ds" style="margin: 0.625rem 0 0 0"></AdSlot>
			</div>
		</div>
		<!-- 底部占位div -->
		<div class="footGG"></div>
	</div>
</template>

<script>
import unitTitleTag from '../../atemp/unit-title-tag.vue';
import unitChannelList from '../../atemp/unit-channel-list.vue';
import channel from '../../atemp/channel.vue';
import channelTvAbout from '../../atemp/channel-tv-about.vue';
let that;
const { log } = console;
export default {
	components: {
		unitTitleTag,
		unitChannelList,
		channel,
		channelTvAbout
	},
	data() {
		return {
			tabCurrentIndex: 0, //默认选中第一个tab
			// HotTv: ['央视', '广州', '湖南', '江苏', '安徽', '浙江', '北京', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台', '地区电视台'],
			// districtTv: ['广东', '广州', '深圳'],
			districtTv: [],
			HotTv: [],
			id: '',
			routerUrl: '',
			//地区电视台分类
			localTVID: '',
			//防止多次点击卡顿
			isClick: true,
			regionalId: '', //根据地区id查询详情
			breadcumb: {
				list: [{ name: '电视', path: '/tv?hid=4' }, { name: '', path: '' }]
			},
			nowIndex: 0,
			//相关频道
			clist: [],
			noData: false,
			// 当前的地址
			region: ''
		};
	},
	created: function() {
		that = this;
		that.routerUrl = that.$route.path;
		that.id = that.$route.params.id;
		that.localTVID = that.$route.query.tid;
		// sessionStorage.clear()
		//查询省区
		that.$newsReq.queryTvProvincen().then(res => {
			// log(res.data.data, 'res=>>>查询省区');
			that.HotTv = res.data.data;
		});
		// 查询电视台信息
		let tvInfo = sessionStorage.getItem('tvInfo');
		if (tvInfo) {
			that.queryTvInfo(tvInfo);
			that.nowIndex = tvInfo;
		} else {
			that.queryTvInfo(that.localTVID);
			that.nowIndex = that.$route.query.tid;
		}
	},
	methods: {
		// 查询电视台信息
		queryTvInfo(regionalId) {
			let datas = {
				id: regionalId,
				livePlatform: '0',
				type: 3
			};
			let tvInfoarr = [];
			let tvInfoobj = {};

			that.$newsReq.queryTvInfo(datas).then(res => {
				let tvInfoRes = res.data.data;
				tvInfoRes.forEach((item, index) => {
					tvInfoobj = {
						id: item.id,
						isHot: item.isHot,
						playbackAddress: item.playbackAddress,
						provincialAreaName: item.provincialAreaName,
						tvName: item.tvName,
						urbanDistrictName: item.urbanDistrictName
					};

					Object.keys(item.urbanDistrictList).forEach(function(key) {
						tvInfoobj.urbanDistrictList = item.urbanDistrictList[key];
					});

					tvInfoarr.push(tvInfoobj);
				});
				that.districtTv = tvInfoarr;
				that.breadcumb.list[1].name = that.districtTv[0].provincialAreaName;

				tvInfoarr.forEach(item => {
					//相关频道
					item.urbanDistrictList.forEach(items => {
						that.clist.push(items);
					});
				});
			});
		},
		navTo(id) {
			that.$router.push({
				path: '/tvDetails',
				query: {
					hid: 4,
					tid: id
				}
				// params: {hid: nid} -> 如何接收值
			});
		},
		regional(regionalId) {
			sessionStorage.setItem('tvInfo', regionalId);
			that.nowIndex = regionalId;
			let isClick = that.isClick;
			that.clist = [];
			if (isClick) {
				that.isClick = false;
				that.regionalId = regionalId;
				that.queryTvInfo(regionalId);
				setTimeout(() => {
					that.isClick = true;
				}, 500);
			}
		}
	},
	watch: {
		$route: {
			handler() {
				that.id = that.$route.query.id;
				that.routerUrl = that.$route.fullPath;
			},
			deep: true
		}
	},
	destroyed() {
		sessionStorage.removeItem('tvInfo');
	}
};
</script>

<style lang="scss" scoped>
.container {
	// width: 1400px;
	width: 87.5rem;
	/* height: auto; */
	// min-height: 900px;
	min-height: 56.25rem;
	margin: 0 auto;
	background-color: #f5f5f5;
	// display: flex;
	// flex-direction: column;
}

.main {
	display: flex;
	// justify-content: space-between;
	// border:1px solid red;
}

.column-left {
	// width: 1064px;
	width: 66.5rem;
	height: auto;
	// border:1px solid red;
	margin-right: 1.125rem;

	.tv-list {
		display: flex;
		flex-wrap: wrap;
		// width: 1064px;
		width: 66.5rem;
		// height: 192px;
		height: 12rem;
		padding: 0 12px;
		overflow-y: auto;
		background-color: #ffffff;
		cursor: pointer;

		li {
			// margin: 10px 30px;
			margin: 0.625rem 1.875rem;
			// font-size: 20px;
			font-size: 1.25rem;
			color: #666666;
		}
		.active {
			color: $bg-chengse;
		}
	}

	.hotTv {
		margin-top: 0.625rem;
	}
}

.column-right {
	// width: 318px;
	width: 19.875rem;
	height: auto;
}
</style>
