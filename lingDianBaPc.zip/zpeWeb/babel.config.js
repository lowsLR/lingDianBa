module.exports = {
  presets: [
    '@vue/app'
  ],
  // css:{
  // 	  loaderOptions:{
  // 		  sass:{
  // 			  data:`@import "~@/static/css/color.scss";`
  // 		  }
  // 	  }
  // } 
}
