# zepWeb

#### 介绍
0.8pc端

#### 软件架构
vue+elemen-UI


#### 安装教程

1.  npm i

#### 使用说明

1. npm run serve

#### 主要文件说明
~~~
┌─node_modules        			npm i 下载的文件（忽略）
│─public            			公共资源
│  ├─index.html					页面title等配置
│  └─ckplayer         			ck播放器             		
├─src                 			主要页面配置
│  ├─a-ellery           		主要存放日期选择框、反馈模板、加载提示
│  ├─assets						表情包
│  ├─atemp						主要存放侧边栏组件，比如热门录像，热门新闻，最近直播,广告等自定义模板
│  │  └─ad-slot.vue 			广告模板
│  │  └─leave-message.vue 		留言模板
│  │  └─loginDialog.vue			登录注册模板
│  │  └─team-selection.vue		筛选球队
│  ├─components        			主要存放公共组件，比如暂无数据提示，ck播放器，底部栏，顶部栏等
│  ├─plugins					vue的video播放器
│  ├─request 					用于写接口的文件
│  │  └─api	
│  │  │	└─base.js				接口域名的管理
│  │  │	└─news_req.js			请求接口
│  │  │	└─req.js				请求接口
│  │  │ └─reqc.js				请求接口
│  │  └─http.js					请求拦截、响应拦截、错误统一处理
│  ├─router						路由导航配置
│  ├─static						存放静态资源图片等
│  ├─store						vuex第三方数据存储
│  ├─utils						公用方法处理
│  └─views						用于写页面view的文件
│  │  └─datas        			数据页面
│  │  └─download				app下载页面
│  │  └─index 					首页的导航页和尾部
│  │  └─main					首页的文件夹
│  │  	└─main.vue				首页页面
│  │  	└─navPage.vue			首页二级页面
│  │  	└─search-details.vue	搜索页面
│  │  └─news					新闻页面
│  │  └─tv						电视页面
│  │  	└─tvDetails.vue			电视播放页面
│  │  └─video					视频，直播，录像页面
│  │  	└─lx-VideoPlayback.vue  录像播放页面
│  │  	└─spDetail.vue  		视频播放页面
│  │  	└─player-video.vue 		直播播放页面
│  │  	└─live-room.vue			首页二级页面的录像，直播，战报页面
│  │─App.vue 					页面首次加载处理
│  ├─main.js 					vue注册配置
└─vue.config.js            		vue的webpack配置
~~~

#### 打包方式
	1.npm run build
#### 修改页面title标题、关键字、描述,pc跳转H5页
	在public文件夹下的index.html：
	动态修改title:需要修改 ' var urlHeard = "http://8.129.19.0:8891"'; //修改请求地址 ';
	pc跳转H5页:需要修改 'var webUrl = '"http://8.129.19.0:8091"';
	关键字修改: 需要修改 '<meta name="keywords" content="零点吧,NBA直播,CCTV5在线直播,cba直播吧,NBA直播吧,直播8,直播吧,西甲直播，英超直播">' content的里内容;
	描述修改: 需要修改 '<meta name="description" content="零点吧是国内最好最全面的nba直播吧,主要提供火箭视频直播,CCTV5在线直播,NBA直播,NBA视频直播,西甲直播，西班牙人，欢迎观看免费nba直播吧,为你搜球吧，收藏本站可以确保有球看">' content的里内容