// vue.config.js
const proxy = require('http-proxy-middleware');
const webpack = require('webpack')
module.exports = {
	publicPath: './',
	productionSourceMap: false,
	css: {
		loaderOptions: {
			sass: {
				// data:`@import "~@/static/css/color.scss";`
				prependData: `@import "~@/static/css/color.scss";`
			}
		}
	}
}
