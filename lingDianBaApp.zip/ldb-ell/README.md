# 零点八(lingdianba)

## 介绍
0.8

## 软件架构
### 软件架构说明
**开发框架：Uniapp、Vue**
**基于weex改进的原生渲染引擎：Nvue**
**请求后台资源的模块：Axios** ```$ npm install axios -S```


## 项目目录结构

### 基础文件结构
|  文件			|  说明  |
|  ----			|  ----  |
|  App.vue		|  项目网站首页  |
|  config.js	|  端口参数配置(环境配置 => BASE_URL)  |
|  components	|  公共插件目录  |
|  api			|  功能接口目录  |
|  bw			|  公共函数文件、公共样式文件  |
|  colorui		|  第三方样式库  |
|  common		|  公共函数库、axios请求封装目录  |
|  components	|  第三方插件目录、公共组件目录  |
|  nvuecss		|  直播室nvue页面样式  |
|  pages		|  项目页面目录  |
|  platform		|  第三方播放器目录  |
|  static		|  静态资源目录(图片、字体)  |
|  store		|  Vuex 状态管理库  |
|  unpackage	|  logo、启动图目录、打包文件目录  |
|  utils		|  第三方请求封装、配置文件  |
|  crossdomain.xml		|  页面配置文件  |
|  json.js		|  测试数据文件  |
|  main.js		|  项目入口文件  |
|  manifest.json|  项目配置文件  |
|  package.json	|  项目所需模块与项目配置信息  |
|  package-lock.json	|  模块的版本信息  |
|  pages.json	|  页面路由配置文件  |
|  template.h5.html		|  自定义模板文件  |
|  uni.scss		|  uni公共scss文件  |


### pages(页面目录)
|  文件		|  说明  |
|  ----		|  ----  |
|  component|  公共组件  |
|  index	|  主页、直播页、聊天室  |
|  login	|  登录、注册、修改密码  |
|  lx		|  录像页  |
|  mine		|  个人中心、设置页、任务大厅、积分商城、意见反馈、邀请好友  |
|  news		|  新闻与新闻详情页  |
|  search	|  搜索页  |
|  tv		|  电视列表页、电视详情页、地方电视列表  |
|  video	|  视频列表与视频详情页  |
|  webview	|  第三方页面跳转页面(webview.vue/adWebview.vue)  |

### api(功能接口目录)
|  文件		|  说明  |
|  ----		|  ----  |
|  util.js	|  公共函数文件 与 广告请求接口  |
|  req.js	|  页面主要功能接口  |
|  reqc.js	|  页面主要功能接口  |
|  index.js	|  导出接口  |
|  user.js	|  用户相关功能(注册登录修改密码)接口位置  |


## 项目使用说明

1、```$ npm i```  初始化项目

2、	然后发现报错 找不到 VideoJS.eot 这里很简单，只需要知道这个模板引入的了什么js，就能知道什么js报错了
如果引入的是video.js 就去video.js文件夹去找,如果是video.min.js就去相应的文件里面找就可以了。
然后只需要找到 **node_modules/video.js/dist/video-js.css** 的**13行** 我也不是很确定，自己当前文件搜索 **VideoJS.eot** 就可以找到了，然后改成绝对路径 ```src: url("~@/node_modules/video.js/dist/font/VideoJS.eot?#iefix") format("eot");```
注意因为 **}**在同行，所以别全覆盖了。现在就算是引入成功，可以使用了


### App更新说明（升级包制作）
1.  manifest.json：同步修改 应用版本名称与应用版本号


### 重要提示
1.	一旦文件打包成apk或ipa安装包后，**请勿再 修改或重新获取 manifest.json文件中的appid**，否则可能导致app无法热更(wgt升级包无法更新)等问题
