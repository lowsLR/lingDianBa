<template>
	<view class="content">
		<view class="row b-b">
			<text class="tit">联系人</text>
			<input class="input" type="text" maxlength="10" v-model="addressData.realName" placeholder="收货人姓名" placeholder-class="placeholder" />
		</view>
		<view class="row b-b">
			<text class="tit">手机号</text>
			<input class="input" type="number" maxlength="11" v-model="addressData.phone" placeholder="收货人手机号码" placeholder-class="placeholder" />
		</view>
		<view class="row b-b" @tap="openAddres">
			<text class="tit">地址信息</text>
			<text class="title"></text>{{ addressData.provincialLevel ? (addressData.provincialLevel + ' - ' + addressData.municipalLevel + ' - ' + addressData.areaLevel) : '请选择' }}
		</view>
		<view class="row b-b">
			<text class="tit">街道</text>
			<input class="input" type="text" maxlength="20" v-model="addressData.street" placeholder="选填" placeholder-class="placeholder" />
		</view>
		<view class="row b-b"> 
			<text class="tit">详细地址</text>
			<input class="input" type="text" maxlength="30" v-model="addressData.detailsAddress" placeholder="街道门牌信息" placeholder-class="placeholder" />
		</view>
		<view class="row default-row">
			<text class="tit">设为默认</text>
			<switch :checked="addressData.isDefault == 0 ? true : false" color="#fa436a" @change="switchChange" />
		</view>
		
		<!-- 按钮类型 -->
		<view class="btn-group" v-if="addressData.hasOwnProperty('id')">
			<button class="btn del-btn" @click="confirm(3)">删除</button>
			<button class="btn upd-btn" @click="confirm(2)">修改</button>
		</view>
		<button v-else class="btn add-btn" @click="confirm(1)">提交</button>
		
		<simple-address ref="simpleAddress" :pickerValueDefault="cityPickerValueDefault" @onConfirm="onConfirm" themeColor='#007AFF'></simple-address>
	</view>
</template>

<script>
	import simpleAddress from "@/components/simple-address/simple-address.nvue"
	let that;
	const prePage = () => {
	    let pages = getCurrentPages();  
	    let prePage = pages[pages.length - 2];  
	    // #ifdef H5  
	    return prePage;  
	    // #endif  
	    return prePage.$vm;  
	}
	
	export default {
		components: {
			simpleAddress
		},
		data() {
			return {
				isAllowClick: true,		// 是否允许提交表单
				addressData: {
					realName: '',		// *真实姓名
					phone: '',			// *手机
					provincialLevel: '',// *省级
					municipalLevel: '',	// *市级
					areaLevel: '',		// 区级
					street: '',			// 街道
					detailsAddress: '',	// *详情地址
					isDefault: '1',		// 是否默认地址 0默认1否
				},
				cityPickerValueDefault: [0, 0, 1], // 地址默认选中值
			}
		},
		onLoad(option){
			that = this;
			let data = JSON.parse(decodeURIComponent(option.data));
			let title = '新增收货地址';
			if(data.hasOwnProperty('id')){ // 判断参数中是否存在id属性
				title = '编辑收货地址'
				this.addressData = data;
				// console.log(this.addressData);
			}
			uni.setNavigationBarTitle({
				title
			})
		},
		methods: {
			// 提交
			confirm(type){
				let data = this.addressData;
				// 数据验证
				if (type != 3) {
					if (!this.verifyUserInfo(data)) return;
				}
				
				if (!this.isAllowClick) return; // 避免重复提交
				this.isAllowClick = false;
				
				let query = '';
				switch (type){
					case 1:
						query = this.$req.reqc.addAddress(data); // 添加
						break;
					case 2:
						data.valid = 0; // 是否删除 0无效 1有效
						query = this.$req.reqc.updateAddress(data); // 修改
						break;
					case 3:
						let obj = {
							id: data.id,
							valid: 1, // 是否删除 0无效 1有效
						};
						query = this.$req.reqc.updateAddress(obj); // 删除
						break;
					default:
						break;
				}
				
				query.then( res => {
					if (res.statusCode == 200 && res.data.resultCode == 1) {
						this.isWarn(`地址${data.hasOwnProperty('id') ? '修改' : '添加'}成功`)
						// prePage()获取上一页实例，可直接调用上页所有数据和方法，在App.vue定义
						prePage().refreshList(); // 刷新地址列表页数据
						uni.$emit('updateAddressData', {msg:'页面更新'}); // 全局事件监听 刷新订单页地址数据
						setTimeout(()=>{
							uni.navigateBack();
						}, 1000)
					}
					else {
						this.isAllowClick = true;
						this.isWarn(res.data.resultMsg);
					}
				})
				.catch( err => {
					this.isAllowClick = true;
					console.log(err);
				})
			},
			
			// 验证用户信息
			verifyUserInfo(data) {
				let flag = true;
				
				if(!data.realName){
					this.isWarn('请填写收货人姓名')
					return false; // 终止程序
				}
				if(!/(^1[3|4|5|7|8][0-9]{9}$)/.test(data.phone)){
					this.isWarn('请输入正确的手机号码')
					return false;
				}
				if (!data.provincialLevel || !data.municipalLevel) {
					this.isWarn('请选择所在行政区域')
					return false;
				}
				if(!data.detailsAddress){
					this.isWarn('请填写门牌号信息')
					return false;
				}
				
				return flag;
			},
			
			// 是否设为默认地址
			switchChange(e){
				this.addressData.isDefault = e.detail.value ? '0' : '1';
			},
			
			// 三级联动地址列表
			openAddres() {
				this.$refs.simpleAddress.open();
			},
			onConfirm(e) {
				// console.log('行政区：',e);
				let arr = e.label.split('-');
				that.addressData.provincialLevel = arr[0]
				that.addressData.municipalLevel = arr[1]
				that.addressData.areaLevel = arr[2]
				this.$forceUpdate();
			},
			
			// 提示
			isWarn(msg) {
				uni.showToast({
					icon: 'none',
					title: msg
				})
			},
		}
	}
</script>

<style lang="scss">
	page{
		background: $page-color-base;
		padding-top: 16upx;
	}

	.row{
		display: flex;
		align-items: center;
		position: relative;
		padding:0 30upx;
		height: 110upx;
		background: #fff;
		
		.tit{
			flex-shrink: 0;
			width: 150rpx;
			font-size: 30upx;
			color: $font-color-dark;
		}
		.input{
			flex: 1;
			font-size: 30upx;
			color: $font-color-dark;
		}
		.icon-shouhuodizhi{
			font-size: 36upx;
			color: $font-color-light;
		}
	}
	.default-row{
		margin-top: 16upx;
		.tit{
			flex: 1;
		}
		switch {
			transform: translateX(16upx) scale(.9);
			// 未选中样式
			/deep/.uni-switch-input {
				background-color: #dfdfdf !important;
			}
			// 选中样式
			/deep/.uni-switch-input-checked {
				background: #fa436a !important;
			}
		}
	}
	
	/* 按钮组 */
	.btn-group {
		display: flex;
		padding: 0 30rpx;
		
		.upd-btn {
			background-color: #007AFF;
		}
		.del-btn {
			background-color: #E64340;
		}
	}
	
	.btn {
		display: flex;
		align-items: center;
		justify-content: center;
		flex: 1;
		// width: 690rpx;
		height: 80rpx;
		margin: 60rpx 30rpx;
		font-size: $font-lg;
		color: #FFFFFF;
		background-color: #1B1B30;
		border-radius: 10rpx;
		box-shadow: 1px 2px 5px rgba(27, 27, 48, .4);
		
		&:active {
			
		}
	}
	
	.add-btn{
		margin: 60rpx;
	}
</style>
