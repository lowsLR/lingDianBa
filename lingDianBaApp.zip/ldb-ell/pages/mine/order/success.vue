<template>
	<view class="container">
		<view class="icon"></view>
		<view class="hint">
			兑换请求已提交，请耐心等待审核
		</view>
		<view class="complete" @tap="back">完成</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				id: null,
			};
		},
		onLoad() {
			
		},
		onBackPress(options) {  
			if (options.from === 'navigateBack') {  
				return false;  
			}  
			this.back();  
			return true;  
		},
		methods: {
			back: function () {
				uni.navigateBack({
					delta: 2
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: #F7F7F7;
	}
	.container {
		width: 100%;
		height: 100%;
		overflow: hidden;
		margin-bottom: 88rpx;
		color: #333333;
		display: flex;
		flex-direction: column;
		align-items: center;
		
		.icon {
			min-width: 200rpx;
			max-width: 200rpx;
			height: 200rpx;
			background-size: cover;
			background-image: url(../../../static/images/complete.png);
			margin: 50rpx 0 20rpx 0;
		}
		
		.hint {
			font-size: 16px;
		}
		
		.complete {
			min-width: 400rpx;
			max-width: 400rpx;
			height: 72rpx;
			line-height: 72rpx;
			text-align: center;
			border-radius: 36rpx;
			font-size: 36rpx;
			color: #FFFFFF;
			background-color: #1B1B30;
			margin-top: 100rpx;
		}
	}
</style>
