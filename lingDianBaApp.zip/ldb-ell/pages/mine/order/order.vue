<template>
	<view class="container">
		<!-- ES6的Object.keys()方法，返回值是对象中属性名组成的数组 -->
		<view class="address" @tap="selAddress" v-if="Object.keys(ackAddress).length > 0">
			<view class="hint">
				<view class="addressIcon"></view>
				<view class="addressMsg">
					<text>{{ackAddress.provincialLevel}} {{ackAddress.municipalLevel}} {{ackAddress.areaLevel}} {{ackAddress.street ? '，'+ackAddress.street : ''}}</text>
					<text>{{ackAddress.detailsAddress}}</text>
					<text>姓名：{{ackAddress.realName}}&emsp;手机号：{{ackAddress.phone}}</text>
				</view>
			</view>
			<view class="right"></view>
		</view>
		
		<view class="selAddress" @tap="selAddress" v-else>
			<view class="hint"><view class="addressIcon"></view>请填写收货信息</view>
			<view class="right"></view>
		</view>
		
		<view class="a-bg"></view>
		
		<view class="commodityInfo">
			<image :src="data.commodityImg ? data.commodityImg : '../../../static/assets/default.png'"></image>
			<view class="innerBox">
				<view class="title">{{data.name}}</view>
				<view class="pricing">库存{{inventory}}件</view>
				<view><text class="total">{{data.commodityIntegral}}</text>积分</view>
				<view class="count">
					<view class="minus" @tap.stop="calcNum(0)">-</view>
					{{Qty}}
					<view class="add" @tap.stop="calcNum(1)">+</view>
				</view>
			</view>
		</view>
		<view class="orderInfo">
			<view class="item">
				<text class="title">配送方式：</text><text class="msg">包邮</text>
			</view>
			<view class="item">
				<text class="title">成交日期：</text><text class="msg">{{data.orderDate}}</text>
			</view>
			<view class="item">
				<text class="title">订单号：</text><text class="msg">{{data.orderNumber}}</text>
			</view>
			<view class="item rule" v-if="data.ruleDetails">
				<text class="title">兑换规则：</text><text class="msg">{{data.ruleDetails}}</text>
			</view>
		</view>
		<view class="totalPrice">
			<view class="price">总价:<text>{{totalPrice}}积分</text></view>
			<view class="confirm" @tap="exchange">确认兑换</view>
		</view>
	</view>
</template>

<script>
	let that;
	export default {
		data() {
			return {
				data: {},
				myIntegral: 0,	// 用户积分
				Qty: 1,			// 购买数量
				totalPrice: 0 ,	// 总价
				inventory: 0,	// 库存
				
				addressList: [],// 用户地址列表
				ackAddress: '',	// 选中/默认地址
				ackAddressId: '',// 选中/默认地址id
			};
		},
		onLoad(options) {
			that = this;
			// 接收参数
			this.data = JSON.parse(options.data);
			console.log('商品参数：',this.data);
			// 查询用户全部地址
			this.GetUserAddress();
			// 获取用户积分
			this.QueryUserIntegral();
			// 总价计算
			this.calcPrice();
			// 获取下单时间
			this.data.orderDate = this.getTime()
			// 库存计算
			this.inventory = this.data.commodityNumber - this.data.quantitySold;
			
			
			// console.log('监听到事件来自 update ，携带参数 msg 为：' + data.msg);
			uni.$on('updateAddressData', this.GetUserAddress);
		},
		onUnload() {
			// 移除监听事件
			uni.$off('updateAddressData',this.GetUserAddress);
		},
		methods: {
			// 查询用户全部地址
			GetUserAddress: function () {
				this.$req.reqc.queryAddressAll({
					"limit": 0,
					"offset": 0
				})
				.then( res => {
					that.addressList = res.data.data.list || [];
					// console.log('用户地址列表：', that.addressList);
					that.getSpecifyAddress();
				})
			},
			
			// 查询用户积分
			QueryUserIntegral: function () {
				this.$req.reqc.queryUserInfo()
				.then( res => {
					this.myIntegral = res.data.data.userIntegral;
					console.log('当前用户积分：',this.myIntegral);
				})
			},
			// 计算总价
			calcPrice: function() {
				this.totalPrice = this.data.commodityIntegral * this.Qty;
			},
			// 数量增减
			calcNum: function (type) {
				if (type === 0) {
					if (this.Qty === 1) {
						uni.showToast({
							icon: 'none',
							title: '至少购买1件商品'
						})
						return false
					}
					this.Qty--
				} else if (type === 1) {
					let tempPrice = this.data.commodityIntegral * (this.Qty+1)
					if (this.Qty === this.inventory || this.myIntegral < tempPrice) {
						if (this.Qty === this.inventory) {
							uni.showToast({
								icon: 'none',
								title: '已达最大商品购买数量'
							})
						} else if (this.myIntegral < tempPrice) {
							uni.showToast({
								icon: 'none',
								title: '积分不足'
							})
						}
						return false
					}
					this.Qty++
				}
				this.calcPrice()
			},
			
			// 选择地址
			selAddress: function () {
				/* let temp = this.userInfo
				uni.navigateTo({
					url: '/pages/mine/order/addAddress?data=' + encodeURIComponent(JSON.stringify(temp))
				}) */
				// 地址列表
				uni.navigateTo({
					url: '/pages/mine/order/address'
				})
			},
			
			// 兑换商品
			exchange: function () {
				// if (Object.keys(that.ackAddress).length == 0) return;
				if (!that.ackAddress.hasOwnProperty('id')) {
					uni.showToast({
						icon: 'none',
						title: '请填写收货信息'
					})
					return;
				}
				
				uni.showLoading({
					title: '请稍后...',
					mask: true
				});
				let datas = {
					"addressId": that.ackAddress.id, // 地址id
					"orderNumber": that.data.orderNumber, // 订单号
					"shoppingNumber": that.Qty, // 商品数量
				}
				// console.log(datas);return;
				this.$req.reqc.shoppingExchange(datas)
				.then( res => {
					uni.hideLoading();
					// console.log(res)
					if (res.statusCode == 200 && res.data.resultCode == 1) {
						// console.log("兑换"+res.data.resultMsg)
						uni.navigateTo({
							url: '/pages/mine/order/success'
						})
					} else {
						let text = res&&res.data.resultMsg ? res.data.resultMsg : '兑换失败，请稍后再试...'
						uni.showToast({
							icon: 'none',
							title: text,
							duration: 2000
						})
					}
				})
				.catch( err => {
					console.log(err);
				})
			},
			
			//获取时间
			getTime: function () {
				var date=new Date();
			
				var year=date.getFullYear();
				var month=date.getMonth()+1;
				var day=date.getDate();
			
				var hour=date.getHours();
				var minute=date.getMinutes();
				var second=date.getSeconds();
			
				//这样写显示时间在1~9会挤占空间；所以要在1~9的数字前补零;
				if (hour<10) {
					hour='0'+hour;
				}
				if (minute<10) {
					minute='0'+minute;
				}
				if (second<10) {
					second='0'+second;
				}
				
				var x=date.getDay();//获取星期
				
				var time=year+'-'+month+'-'+day+' '+hour+':'+minute+':'+second
				
				return time;
			},
			
			// 获取用户选中/默认地址
			getSpecifyAddress() {
				if (that.ackAddressId != '') {
					// 获取用户选中地址
					that.addressList.forEach ((item, index) => {
						if (item.id == that.ackAddressId) {
							that.ackAddress = item;
						}
					})
				} else {
					// 获取用户默认地址
					that.addressList.forEach ((item, index) => {
						if (item.isDefault == 0) {
							that.ackAddress = item;
						}
					})
				}
			},
			
			// 更新用户选中的地址（刷新数据函数 每个页面最好都有 用于子页调用）
			refreshData(id) {
				console.log('地址信息：',id);
				this.ackAddressId = id;
				this.getSpecifyAddress();
			},
		},
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 100%;
		/* display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center; */
		overflow: hidden;
		background-color: #F7F7F7;
		font-size: 15px;
		margin-bottom: 88rpx;
		color: #333333;
		
		/* 公共样式 */
		.selAddress, .address, .orderInfo, .totalPrice {
			background-color: #FFFFFF;
		}
		/* 地址信息 公共部分 */
		.address, .selAddress {
			.addressIcon, .right {
				min-width: 40rpx;
				max-width: 40rpx;
				height: 40rpx;
				background-size: cover;
			}
			.hint {
				display: flex;
				justify-content: space-between;
			}
			.addressIcon {
				margin-right: 17rpx;
				background-image: url(../../../static/images/address.png);
			}
			.right {
				margin-left: 17rpx;
				background-image: url(../../../static/images/order_right.png);
			}
		}
		
		/* 选择收货地址 */
		.selAddress {
			height: 88rpx;
			padding: 0 20rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			.hint {
				align-items: center;
			}
		}
		/* 收货地址 */
		.address {
			min-height: 176rpx;
			padding: 20rpx;
			display: flex;
			justify-content: space-between;
			// align-items: center;
			.addressMsg {
				display: flex;
				flex-direction: column;
				font-size: 15px;
				
				text:last-child {
					color: #000000;
				}
			}
		}
		.a-bg {
			width: 750rpx;
			height: 5rpx;
			background-color: pink;
			background-image: url(../../../static/a-bg.png);
			background-size: cover;
		}
		
		/* 商品信息 */
		.commodityInfo {
			height: 220rpx;
			padding: 20rpx;
			display: flex;
			align-items: center;
			
			image {
				min-width: 250rpx;
				max-width: 250rpx;
				height: 154rpx;
			}
			.innerBox {
				width: 100%;
				height: 180rpx;
				overflow: hidden;
				box-sizing: border-box;
				margin-left: 16rpx;
				padding: 12rpx 0;
				position: relative;
				.title {
					font-size: 17px;
					line-height: 50rpx;
					color: #000000;
					/* 超出1行时，隐藏并显示省略符 */
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 1; /* 行数控制 */
					-webkit-box-orient: vertical;
				}
				.pricing {
					font-size: 12px;
					color: #666666;
				}
				.total {
					font-size: 25px;
					color: #FF5337;
					margin-right: 16rpx;
				}
				.count {
					position: absolute;
					right: 0;
					bottom: 0;
					width: 178rpx;
					height: 42rpx;
					overflow: hidden;
					border-radius: 30rpx;
					border: 1px solid #CCCCCC;
					display: flex;
					justify-content: space-between;
					align-items: center;
					.minus, .add {
						width: 30%;
						text-align: center;
					}
					.minus {
						border-right: 1px solid #CCCCCC;
					}
					.add {
						border-left: 1px solid #CCCCCC;
					}
				}
			}
		}
		/* 订单信息 */
		.orderInfo {
			padding: 0 20rpx;
			.item{
				height: 88rpx;
				display: flex;
				align-items: center;
				font-size: 15px;
				border-bottom: 1px solid #CCCCCC;
				
				&:last-child {
					border: 0;
				}
				
				.title {
					width: 200rpx;
					color: #666666;
				}
			}
			
			.rule {
				color: red;
			}
		}
		/* 合计 */
		.totalPrice {
			position: fixed;
			bottom: 0;
			width: 100%;
			height: 88rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			.price {
				font-size: 15px;
				margin-left: 20rpx;
				text {
					margin-left: 20rpx;
					color: #FF5337;
				}
			}
			.confirm {
				width: 230rpx;
				height: 88rpx;
				line-height: 88rpx;
				text-align: center;
				background-color: #FF5337;
				font-size: 18px;
				color: #FFFFFF;
			}
		}
	}
</style>
