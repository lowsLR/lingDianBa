<template>
	<view class="container">
		<view class="addressInfo">
			<view class="item itemBorder">
				<text class="title">收货人：</text><input type="text" v-model="infoList.userName" placeholder="姓名" />
			</view>
			<view class="item itemBorder">
				<text class="title">手机号码：</text><input type="number" maxlength="11" v-model="infoList.phoneNum" placeholder="11位手机号" />
			</view>
			<view class="item itemBorder" @tap="openAddres">
				<text class="title">地址信息：</text>{{infoList.district}}
			</view>
			<view class="item itemBorder">
				<text class="title">详细地址：</text><input type="text" v-model="infoList.address" placeholder="街道门牌信息" />
			</view>
			<view class="item">
				<text class="title">邮政编号：</text><input type="number" maxlength="6" v-model="infoList.zipCode" placeholder="邮政编码" />
			</view>
		</view>
		<view class="btnBox">
			<view class="btn cancel" @tap="backButton">取消</view>
			<view class="btn save" @tap="save">保存</view>
		</view>
		
		<simple-address ref="simpleAddress" :pickerValueDefault="cityPickerValueDefault" @onConfirm="onConfirm" themeColor='#007AFF'></simple-address>
	</view>
</template>

<script>
	import simpleAddress from "@/components/simple-address/simple-address.nvue"
	export default {
		components: {
			simpleAddress
		},
		data() {
			return {
				cityPickerValueDefault: [0, 0, 1], // 地址默认选中值
				infoList: {
					userName: '',
					phoneNum: '',
					district: '请选择',
					address: '',
					zipCode: '',
				},
				selAddress: false
			};
		},
		onLoad(options) {
			let val = JSON.parse(options.data)
			if (val != null) {
				this.infoList = val
			}
			// console.log(val);
			if (this.infoList.district != '请选择') {
				this.selAddress = true
			}
		},
		// 监听页面返回
		// onBackPress: function () {
		// 	this.beforePage();
		// },
		methods: {
			openAddres() {
				this.$refs.simpleAddress.open();
			},
			onConfirm(e) {
				// this.infoList.district = JSON.stringify(e)
				this.infoList.district = e.label
				this.selAddress = true
				// console.log(this.infoList.district);
			},
			
			// 保存
			save: function () {
				for (let i in this.infoList) {
					// 去除左右空格;
					this.infoList[i] = this.infoList[i].replace(/(^\s*)|(\s*$)/g, "")
					if (this.infoList[i] == '') {
						uni.showToast({
							icon: 'none',
							title: '请填写正确信息'
						})
						return false;
					}
				}
				
				if (this.selAddress) {
					this.beforePage();
					uni.navigateBack();
				} else {
					uni.showToast({
						icon: 'none',
						title: '请选择地区'
					})
				}
			},
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				uni.navigateBack();
			},
			
			beforePage() {
				let pages = getCurrentPages(); //当前页
				let beforePage = pages[pages.length - 2]; //上个页面
				let temp = this.infoList; // 传递的参数
				// #ifdef H5
				beforePage.refreshData(temp)
				// #endif
				// #ifndef H5
				beforePage.$vm.refreshData(temp)
				// #endif
			},
		}
	}
</script>

<style lang="scss" scoped>
	page, .container {
		height: 100%;
	}
	.container {
		width: 100%;
		/* display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center; */
		overflow: hidden;
		background-color: #F7F7F7;
		margin-bottom: 88rpx;
		color: #333333;
		
		.addressInfo {
			padding: 0 20rpx;
			background-color: #FFFFFF;
			.item{
				height: 88rpx;
				display: flex;
				align-items: center;
				font-size: 14px;
				.title {
					min-width: 180rpx;
					max-width: 180rpx;
				}
				input {
					width: 100%;
					font-size: 14px;
				}
			}
			.itemBorder {
				border-bottom: 1px solid #DFDFDF;
			}
		}
		
		.btnBox {
			margin: 74rpx 44rpx 0 44rpx;
			display: flex;
			justify-content: space-between;
			.btn {
				width: 314rpx;
				height: 72rpx;
				border-radius: 36rpx;
				border: 1px solid #1B1B30;
				font-size: 18px;
				text-align: center;
			}
			.cancel {
				color: #333333;
			}
			.save {
				color: #FFFFFF;
				background-color: #1B1B30;
			}
		}
	}
</style>
