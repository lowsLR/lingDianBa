<template>
	<view class="content b-t">
		<block v-if="addressList.length">
			<view class="list b-b"
				v-for="(item, index) in addressList" :key="index"
				@click="checkAddress(item)"
			>
				<view class="wrapper">
					<view class="address-box">
						<text v-if="item.isDefault == 0" class="tag">默认</text>
						<text class="address">{{item.provincialLevel}} {{item.municipalLevel}} {{item.areaLevel}} {{item.detailsAddress}}</text>
					</view>
					<view class="u-box">
						<text class="name">{{item.realName}}</text>
						<text class="mobile">{{item.phone}}</text>
					</view>
				</view>
				<text class="editor" @click.stop="addAddress(item)"></text>
			</view>
		</block>
		
		<!-- 无数据列表 -->
		<view v-else class="no-data"></view>
		
		<text style="display:block;padding: 16upx 30upx 10upx;lihe-height: 1.6;color: #fa436a;font-size: 24upx;">
			重要：个人信息将严格保密，请放心填写！
		</text>
		
		<button class="add-btn" @click="addAddress({})">新增地址</button>
	</view>
</template>

<script>
	let that;
	export default {
		data() {
			return {
				addressList: [], // 用户地址列表
			}
		},
		onLoad(){
			that = this;
			// 查询用户全部地址
			this.GetUserAddress();
		},
		methods: {
			// 查询用户全部地址
			GetUserAddress: function () {
				this.$req.reqc.queryAddressAll({
					"limit": 0,
					"offset": 0
				})
				.then( res => {
					that.addressList = res.data.data.list || [];
					// console.log('用户地址列表：', that.addressList);
				})
			},
			
			//选择地址
			checkAddress(item){
				/* //this.$api.prePage()获取上一页实例，在App.vue定义
				this.$api.prePage().addressData = item; */
				
				this.beforePage(item.id);
				uni.navigateBack();
			},
			beforePage(aid) {
				let pages = getCurrentPages(); //当前页
				let beforePage = pages[pages.length - 2]; //上个页面
				// let data = this.addressList; // 传递的参数
				// #ifdef H5
				beforePage.refreshData(aid)
				// #endif
				// #ifndef H5
				beforePage.$vm.refreshData(aid)
				// #endif
			},
			
			// 添加或修改地址
			addAddress(item){
				let addressData = {
					id: item.id,
					realName: item.realName,
					phone: item.phone,
					provincialLevel: item.provincialLevel,
					municipalLevel: item.municipalLevel,	
					areaLevel: item.areaLevel,
					street: item.street,
					detailsAddress: item.detailsAddress,
					isDefault: item.isDefault
				}
				uni.navigateTo({
					url: '/pages/mine/order/addressManage?data='+ encodeURIComponent(JSON.stringify(addressData))
					// url: `/pages/mine/order/addressManage?type=${type}&data=${JSON.stringify(item)}`
				})
			},
			
			// 添加或修改成功之后回调(更新列表)
			refreshList(){
				this.GetUserAddress();
			}
		}
	}
</script>

<style lang='scss' scoped>
	page{
		padding-bottom: 120upx;
	}
	.content{
		position: relative;
	}
	.list{
		display: flex;
		align-items: center;
		padding: 20upx 30upx;;
		background: #fff;
		position: relative;
	}
	.wrapper{
		display: flex;
		flex-direction: column;
		flex: 1;
	}
	.address-box{
		display: flex;
		/* align-items: center; */
		.tag{
			min-width: 48rpx;
			max-width: 48rpx;
			min-height: 24rpx;
			max-height: 24rpx;
			font-size: 24rpx;
			color: $base-color;
			margin: 6rpx 10rpx 0 0;
			background: #fffafb;
			border: 1px solid #ffb4c7;
			border-radius: 4upx;
			padding: 6rpx 10rpx;
			line-height: 1;
		}
		.address{
			font-size: 30rpx;
			color: $font-color-dark;
		}
	}
	.u-box{
		font-size: 28upx;
		color: $font-color-light;
		margin-top: 16upx;
		.name{
			margin-right: 30upx;
		}
	}
	/* 编辑按钮 */
	.editor{
		display: flex;
		align-items: center;
		width: 70rpx;
		height: 80rpx;
		background-size: 50rpx;
		background-repeat: no-repeat;
		background-position: center;
		background-image: url(../../../static/images/edit.png);
	}
	
	.add-btn{
		position: fixed;
		left: 30upx;
		right: 30upx;
		bottom: 16upx;
		z-index: 95;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 690upx;
		height: 80upx;
		font-size: 32upx;
		color: #fff;
		background-color: #1B1B30;
		border-radius: 10rpx;
		box-shadow: 1px 2px 5px rgba(27, 27, 48, .4);
	}
	
	.no-data {
		min-width: 750rpx;
		max-width: 750rpx;
		height: 352rpx;
		background-size: cover;
		background-image: url(../../../static/home_no_data.png);
	}
</style>
