<template>
	<view class="container">
		<view class="formItem">
			<view class="title">反馈名称:</view>
			<view class="list">
				<block v-for="(item,index) in records" :key="index">
					<view class="item" @tap="setIndex(index,1)" :class="index == rIndex ? 'active' : ''">{{item.name}}</view>
				</block>
			</view>
		</view>
		<view class="formItem">
			<view class="title">联系方式:</view>
			<view class="list">
				<view v-for="(item,index) in contact" :key="index">
					<view class="item" @tap="setIndex(index,2)" :class="index == cIndex ? 'active' : ''">{{item.name}}</view>
				</view>
				
				<input type="text" v-model="contactWay" placeholder="请留下您的联系方式" />
			</view>
			
		</view>
		<!-- 意见反馈 -->
		<textarea v-model="multiline" maxlength="300" :placeholder="records[rIndex].prompt" @input="MonitorIn" />
		
		<!-- 验证码 -->
		<view class="formItem">
			<view class="title">验证码:</view>
			<view class="yzm">
				<input class="input2" type="text" v-model="verifyCode" placeholder="请输入图片验证码" />
				<image :src="getCodeUrl2" @tap.stop="handleGetImgCode" class="btnGet" mode=""></image>
			</view>
		</view>
		
		<button :disabled="btnState" type="primary" @tap="submit">提交</button>
	</view>
</template>

<script>
	import envConfig from '@/config.js'
	
	// 导入JSON格式的 反馈名称、联系方式 数据
	const fbData = require("@/bw/feedback.json");
	import BWU from '../../../bw/js/bw-util.js'
	let that;
	export default {
		data() {
			return {
				records: [],	// 反馈名称
				contact: [],	// 联系方式
				rIndex: 0,		// 反馈名称索引
				cIndex: 3,		// 联系方式索引
				contactWay: '', // 联系方式
				multiline: '', 	// 反馈内容
				btnState: true, // 提交按钮状态（默认禁用）
				
				userId: '',		// 用户id
				verifyCode: '',	// 图片验证码
				getCodeUrl: `${envConfig.dev.BASE_URL}/app/login/userAccount/getFeedbackVerify`, // 图片验证码地址
				getCodeUrl2: '',
				isClickCodeUrl: false, // 是否已点击获取图片验证码
			}
		},
		onLoad(op) {
			that = this;
			
			// 获取 反馈名称、联系方式 本地数据
			that.records = fbData.RECORDS;
			that.contact = fbData.CONTACT;
			// console.log(that.records,that.contact);
			
			that.userId = uni.getStorageSync('user').userId || '';
			
			// 获取验证码
			that.handleGetImgCode();
		},
		methods: {
			// 选择对应项
			setIndex(i,t){
				if(t == 1){
					if(i == this.rIndex) return;
					this.rIndex = i == this.rIndex ? '' : i;
				}else{
					if(i == this.cIndex) return;
					this.cIndex = i == this.cIndex ? '' : i;
				}
			},
			
			// 获取图片验证码
			handleGetImgCode: function () {
				// 避免重复点击的问题
				if (that.isClickCodeUrl) return;
				
				that.isClickCodeUrl = true;
				that.getCodeUrl2 = '';
				uni.request({
					url: that.getCodeUrl + "?key=" + that.userId,
					method: 'GET',
					data: {},
					success: res => {
						that.getCodeUrl2 = that.getCodeUrl + "?key=" + that.userId;
					},
					fail: () => {},
					complete: () => {}
				});
				setTimeout(function() {
					that.isClickCodeUrl = false;
				}, 1000);
			},
			
			// 输入监听
			MonitorIn: function (e) {
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				this.multiline = val;
				// console.log('val：',val)
				if (val != '' && val != null) {
					this.btnState = false;
				} else {
					this.btnState = true;
				}
			},
			
			// 提交
			submit: function () {
				if (this.multiline == '') {
					uni.showToast({
						icon: 'none',
						title: '写点什么吧'
					})
					return;
				}
				switch (~~this.cIndex){
					case 2:
						if(!BWU.email_validation(this.contactWay)){
							uni.showToast({
								icon: 'none',
								title: '请输入有效的邮箱'
							})
							return;
						}
						break;
					case 3:
						if(!BWU.phone_validation(this.contactWay)){
							uni.showToast({
								icon: 'none',
								title: '请输入正确的手机号'
							})
							return;
						}
						break;
					case 0:
					case 1:
					case 4:
						if(this.contactWay == ''){
							uni.showToast({
								icon: 'none',
								title: '请输入联系方式'
							})
							return;
						}
						break;
					default:
						break;
				}
				if (this.verifyCode == '') {
					uni.showToast({
						icon: 'none',
						title: '请输入图片验证码'
					})
					return;
				}
				
				let datas = {
					// "feedbackMsg": this.multiline,
					"feedbackContact": this.contactWay,
					"feedbackContactInformation": that.contact[this.cIndex].type,
					"feedbackContent": this.multiline,
					"feedbackPlatform": this.appPlatform.toString(),
					"feedbackTitle": that.records[this.rIndex].name,
					"feedbackType": that.records[this.rIndex].type.toString(),
					"verify": this.verifyCode
				}
				// console.log(datas);
				// return;
				this.$req.reqc.createFeedback(datas)
				.then( res => {
					// console.log("返回：",res)
					if (res.data.resultCode === 1 && res.statusCode === 200) {
						this.multiline = '';
						uni.showToast({
							icon: 'none',
							title: '提交成功',
							mask: true
						})
						setTimeout(function() {
							uni.navigateBack();
						}, 1500);
					} else{
						uni.showToast({
							icon: 'none',
							title: res.data.resultMsg
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	page, .container {
		display: flex;
		flex-direction: column;
		align-items: center;
		overflow: hidden;
		width: 100%;
		background-color: #FFFFFF;
		
		.formItem, textarea, button {
			width: 90%;
		}
		
		/* 反馈名称、联系方式 */
		.formItem {
			// background-color: hotpink;
			display: flex;
			padding: 10rpx 0;
			
			.title {
				min-width: 140rpx;
				max-width: 140rpx;
				padding-top: 10rpx;
				// background-color: red;
			}
			
			.list {
				display: flex;
				flex-wrap: wrap;
			}
			
			.item {
				margin: 10rpx 20rpx 10rpx 0;
				padding: 0 16rpx;
				border: 1px solid #1B1B30;
				font-size: 24rpx;
				border-radius: 10rpx;
				// box-shadow: 2px 2px 5px rgba(0, 0, 0, .8);
				
				&.active {
					background-color: #1B1B30;
					color: #FFFFFF;
				}
			}
			
			input {
				width: 370rpx;
				height: 50rpx;
				padding: 0 30rpx;
				margin-top: 20rpx;
				font-size: 24rpx;
				border-radius: 10rpx;
				border: 1px solid #1B1B30;
			}
			
			/* 验证码 */
			.yzm {
				display: flex;
				align-items: center;
				
				.input2 {
					border-radius: 10rpx 0 0 10rpx;
					margin: 0;
				}
				.btnGet {
					width: 136rpx;
					height: 50rpx;
					color: $default-text-color-white;
					background-color: $default-bg-black;
					border-radius: 0 10rpx 10rpx 0;
				}
			}
		}
		
		textarea {
			// border: 1px solid #EEEEEE;
			font-size: 15px;
			border-radius: 20rpx;
			box-shadow: 0 0 8px rgba(0, 0, 0, .3);
			background-color: #FFFFFF;
			padding: 20rpx;
			margin: 30rpx 0 30rpx 0;
		}
		
		
		/* 提交按钮 */
		uni-button {
			margin-top: 40rpx;
		}
		uni-button[type=primary] {
			color: #fff;
			background-color: rgba(27, 27, 48, 1);
		}
		uni-button[disabled][type=primary] {
			background-color: rgba(27, 27, 48, .7);
		}
	}
</style>
