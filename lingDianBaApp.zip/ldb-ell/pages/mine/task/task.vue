<template>
	<view class="container" style="padding-top:var(--status-bar-height);">
		<!-- 任务大厅 -->
		<view class="header">
			<!-- #ifndef H5 -->
			<view class="status"></view>
			<!-- #endif -->
			<view class="topItem">
				<view class="back" @tap.stop="backButton"></view>
				<view class="mainTitle">任务大厅</view>
				<view @tap="particulars">积分明细</view>
			</view>
			<view class="myMarks">
				<text>我的积分：</text>
				<view class="score">{{myIntegral === null ? 0 : myIntegral}}</view>
			</view>
			<view class="myExchange" @tap="myExchange"><view class="btn">我的兑换</view></view>
		</view>
		
		<!-- 占位盒子 -->
		<!-- #ifdef H5 -->
		<view style="height: 268rpx;"></view>
		<!-- #endif -->
		<!-- #ifdef APP-PLUS -->
		<view style="height: calc(268rpx - var(--status-bar-height))"></view>
		<!-- #endif -->
		
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="74" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<scroll-view
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						class="taskBox"
			>
				<view class="taskTag">做任务 赚积分</view>
				<view class="taskItem" v-for="(item, index) in dataList" :key="index">
					<view class="left">
						<view>{{item.taskName}}<text class="award">+{{item.taskRewardNum}}</text></view>
						<view class="progress">完成<text>{{item.completCount}}</text>/{{item.finshCount}}</view>
					</view>
					<view :class="item.finshState == 0 ? 'complet' : 'state'" v-if="item.taskType == 2" @tap.stop="togglePopup('center', 'popup')">{{item.finshState == 0 ? '已' : '去'}}{{item.taskType | filtersTextChange}}</view>
					<view :class="item.finshState == 0 ? 'complet' : 'state'" v-if="item.taskType != 2" @tap.stop="performTask(index)">{{item.finshState == 0 ? '已' : '去'}}{{item.taskType | filtersTextChange}}</view>
				</view>
				<!-- 上滑加载更多组件 -->
				<mix-load-more :status="loadMoreStatus"></mix-load-more>
			</scroll-view>
		</mix-pulldown-refresh>
		
		<!-- 签到弹出框  :show="showpopup" -->
		<uni-popup ref="popup" :type="type" @change="change">
			<view class="popup-view" style="background-color: #FFFFFF;">
				<view class="sign-view ">
					<view class="view-1 flex-cc" @tap.stop="performTask(0)">
						<view class="view-2 flex-cc">
							<view class="view-3 flex-cc">
								签到
							</view>
						</view>
					</view>
					
					<view class="sign-text">
						您已经连续签到 {{signInCount}} 天，积分{{myIntegral === null ? 0 : myIntegral}}
					</view>
				</view>
				<view class="cale-view">
					<!-- <uni-calendar ref="calendar" :insert="info.insert" :range="info.range" :lunar="info.lunar" :date="info.date" :selected="info.selected" @change="taskChange"/> -->
					<uni-calendar ref="calendar" :insert="info.insert" :range="info.range" :lunar="info.lunar" :date="info.date" :selected="info.selected" :start-date="info.startDate" :end-date="info.endDate" @change="taskChange"/>
				</view>
			</view>
			
			<!-- <text class="popup-content">{{ content }}</text> -->
		</uni-popup>
	</view>
</template>

<script>
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import uniCalendar from '@/components/uni-calendar/uni-calendar.vue'
	
	export default {
		components: {
			mixPulldownRefresh,
			mixLoadMore,
			uniPopup,
			uniCalendar
		},
		data() {
			return {
				myIntegral: 0,	// 我的积分
				signInCount: 0, // 连续登录次数
				userId: null,
				enableScroll: true,
				loadMoreStatus: 0,	//加载更多 0加载前，1加载中，2没有更多了
				dataList: [],
				offset: 1,
				refreshing: 0,
				total: 0,	// 记录条数
				isTap: true, // 是否允许点击(防止完成任务 点击过快)
				
				showpopup: false,
				type: '',
				
				/*日历插件 显示数据*/
				selectedCalendar:'',
				info: {
					lunar: false,	//是否开启农历
					range: false,	//开启范围选择
					insert: true,	//设置是否显示
					// selected: [{date: "2020-04-28",info: "已签到"}],	//设置指定日期 标点
					selected: [],	//设置指定日期 标点
					startDate: '',	// 日历开始时间
					endDate: '',	// 日历结束时间
				},
				currentDate: '',	// 当前日期 'YYYY-MM-DD'
			}
		},
		onLoad:	function() {
			// 获取当前时间
			this.currentDate = this.utils.getCurrentDate();
			// console.log('当前日期：',this.currentDate);
			
			// 查询用户积分
			this.QueryUserIntegral();
			// 查询连续签到次数
			this.ContSignIn();
			
			try {
				const val = uni.getStorageSync('user');
				if (val) {
					this.userId = val.userId;
					console.log('用户Id：',this.userId);
				}
			} catch (e) {
				// error
				console.log(e);
			}
		},
		onReady: function () {
			// (初始化)分发任务 → 显示任务列表
			this.$req.reqc.distributionTask()
			.then( res => {
				console.log("任务初始化(分发任务)：",res)
				this.loadTaskList('add');
			})
		},
		// 监听页面返回
		// onBackPress: function (options) {
		// 	if (options.from === 'navigateBack') {
		// 		return false;
		// 	}
		// 	this.beforePage(); 
		// 	return true; 
		// },
		methods: {
			//监听日期选择插件
			taskChange(e){
				if(this.selectedCalendar == e.fulldate){
					return;
				}
				this.selectedCalendar = e.fulldate;
				console.log("选择日期：",e.fulldate);
			},
			
			// 查询用户积分
			QueryUserIntegral: function () {
				this.$req.reqc.queryUserInfo()
				.then( res => {
					// console.log("用户信息：",res)
					this.myIntegral = res.data.data.userIntegral;
					console.log('当前用户积分：',this.myIntegral);
				})
			},
			// 查询签到次数
			ContSignIn: function () {
				let dateList = this.info.selected;
				let date = new Date();
				let month = date.getMonth()+1 < 10 ? ('0' + (date.getMonth()+1)) : (date.getMonth()+1);
				console.log('查询月份：', month);
				let datas = {
					"month": month // "01"-"12"
				}
				this.$req.reqc.countBySign(datas)
				.then( res => {
					this.signInCount = res.data.data.count;
					console.log('连续签到次数：',this.signInCount);
					let data = res.data.data.userTaskDOList;
					data.forEach((item, index) => {
						if (item.finshState == "0") {
							let temp = {
								date: item.beginTime.split(' ')[0], // "2019-12-30"
								info: '已签到'
							};
							dateList.push(temp)
						}
						// console.log(item,index);
					})
					console.log('已签到日期：',dateList);
					
					// 设置日历开始、结束时间
					this.info.startDate = dateList.length&&dateList[0].date || this.currentDate;
					this.info.endDate = dateList.length&&dateList[dateList.length - 1].date || this.currentDate;
				})
			},
			
			// 任务列表
			loadTaskList(type){
				uni.showLoading({
				    title: '加载中',
					mask: true
				});
				let that = this;
				// type add 加载更多 refresh下拉刷新
				if(type === 'add'){
					if(that.loadMoreStatus === 2){
						return;
					}
					if(that.dataList && that.dataList.length > 0){
						that.offset++;
					}
					that.loadMoreStatus = 1;
				}
				// #ifdef APP-PLUS
				else if(type === 'refresh'){
					that.refreshing = true;
				}
				// #endif
				let datas = {
					// "finshState": 0, // 完成状态：0完成 1未完成
					"limit": 10,
					"offset": that.offset
				}
				this.$req.reqc.queryTaskToday(datas)
				.then( res => {
					uni.hideLoading();
					
					// console.log("数据",res)
					// return false;
					if(type === 'refresh'){
						that.dataList = []; //刷新前清空数组
						that.offset = 1;
					}
					let list = res.data.data.list;
					that.total = res.data.data.total;
					list.forEach((item,index) => {
						let items = {
							userTaskId: item.userTaskId, // 任务Id
							finshState: item.finshState, // 完成状态 0完成1未完成
							completCount: item.completCount, // 已完成次数
							finshCount: item.finshCount, // 需要完成次数
							taskName: item.taskName,
							taskType: item.taskType, // 任务类型 0分享 1邀请人 2签到
							taskRewardNum: item.taskRewardNum
						}
						that.dataList.push(items);
					})
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						that.refreshing = false;
						// #endif
						that.loadMoreStatus = 0;
					}
					//上滑加载 处理状态
					if(type === 'add' || type === 'refresh'){
						that.loadMoreStatus = that.dataList.length >= this.total ? 2 : 0;
					}
					console.log("任务列表：",that.dataList);
					
					this.$forceUpdate();
				})
			},
			
			//下拉刷新
			onPulldownReresh(){
				this.loadTaskList('refresh');
			},
			//上滑加载
			loadMore(){
				this.loadTaskList('add');
			},
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			},
			
			
			change(e) {
				console.log('是否打开:' + e.show)
				if (!e.show) {
					this.showpopup = false
				}
			},
			togglePopup(type, open) {
				switch (type) {
					case 'top':
						this.content = '顶部弹出 popup'
						break
			
					case 'bottom':
						this.content = '底部弹出 popup'
						break
					case 'center':
						this.content = '居中弹出 popup'
						break
				}
				this.type = type
				this.$refs.popup.open();
				// this['show' + open] = !this['show' + open]
			},
			
			
			// 执行任务
			performTask: function (index) {
				// console.log(index);return
				let that = this;
				if (!that.isTap || that.dataList[index].finshState == "0") {
					if (!that.isTap) {
						uni.showToast({
							icon: 'none',
							title: '请稍后...'
						})
					} else if (that.dataList[index].finshState == "0") {
						uni.showToast({
							icon: 'none',
							title: '当前任务已完成!'
						})
					}
					return false;
				}
				// 邀请用户任务 跳转至 邀请好友页
				if (that.dataList[index].taskType === "1") {
					uni.navigateTo({
						url: '/pages/mine/invitation/invitation'
					})
					return false;
				}
				
				// 任务执行前(发起请求) → 改变点击状态(防止快速点击的问题)
				that.isTap = false;
				
				let datas = {
					"userTaskId": that.dataList[index].userTaskId
				}
				this.$req.reqc.finshTask(datas)
				.then( res => {
					console.log("已执行：",res)
					that.dataList[index].completCount++;
					if (that.dataList[index].completCount == that.dataList[index].finshCount) {
						that.dataList[index].finshState = "0"
					}
					that.isTap = true;
					
					// 任务状态为签到时 退出签到日历，并更新连续签到数
					if (that.dataList[index].taskType == '2') {
						// this.togglePopup('center', 'popup');
						this.$refs.popup.close();
						// 查询连续签到次数(先清除原有数据)
						this.info.selected = []
						this.ContSignIn();
					}
					
					this.QueryUserIntegral();
				})
			},
			
			// 积分明细
			particulars: function () {
				uni.navigateTo({
					url: '/pages/mine/integral/pointHistory'
				})
			},
			// 我的兑换
			myExchange: function() {
				uni.navigateTo({
					url: '/pages/mine/integral/myExchange'
				})
			},
			
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				// this.beforePage();
				uni.navigateBack();
			},
			
			beforePage() {
				let pages = getCurrentPages(); //当前页
				let beforePage = pages[pages.length - 2]; //上个页面 (-2：上一页面)
				// console.log(beforePage);
				// #ifdef H5
				beforePage.RefreshIntegral()
				// #endif
				// #ifndef H5
				beforePage.$vm.RefreshIntegral()
				// #endif
				// that.toBack(1);
			},
		},
		filters: {
			filtersTextChange: function(val) {
				let value = '完成';
				switch (val){
					case '0':
						value = '分享'
						break;
					case '1':
						value = '邀请'
						break;
					case '2':
						value = '签到'
						break;
					default:
						break;
				}
				return value;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		display: flex;
		flex-direction: column;
		overflow: hidden;
		width: 100%;
		.header {
			position: fixed;
			top: 0px;
			z-index: 10;
			display: flex;
			flex-direction: column;
			width: 100%;
			height: 268rpx;
			background-color: #1B1B30;
			.status {
				height: var(--status-bar-height);
			}
		}
		/* 头部栏 */
		.topItem {
			height: 88rpx;
			box-sizing: border-box;
			padding: 0 30rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 13px;
			color: #FFFFFF;
			position: relative;
			.back {
				width: 30rpx;
				height: 36rpx;
				background-size: cover;
				background-image: url(../../../static/images/user_left_w.png);
			}
			.mainTitle {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				font-size: 18px;
			}
		}
		/* 我的积分 */
		.myMarks {
			height: 80rpx;
			line-height: 80rpx;
			box-sizing: border-box;
			padding: 0 30rpx;
			font-size: 13px;
			color: #FFFFFF;
			position: relative;
			.score {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -40%);
				text-align: center;
				font-size: 30px;
			}
		}
		/* 我的兑换 */
		.myExchange {
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100rpx;
			background-size: cover;
			background-image: url('../../../static/assets/bg_mask.png');
			font-size: 12px;
			color: #FFFFFF;
			.btn {
				width: 140rpx;
				height: 44rpx;
				line-height: 44rpx;
				text-align: center;
				box-sizing: border-box;
				border-radius: 22rpx;
				border: 1px solid #FFFFFF;
			}
		}
		
		/* 任务模块 */
		.taskBox {
			box-sizing: border-box;
			padding: 0 20rpx 250rpx 20rpx;
			font-size: 14px;
			color: #333333;
			.taskTag {
				line-height: 76rpx;
			}
			.taskItem {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 0 22rpx 0 27rpx;
				margin-bottom: 16rpx;
				height: 110rpx;
				border-radius: 10rpx;
				background-color: rgba(255, 83, 55, .1);
				.state, text {
					color: #FF5337;
				}
				.state, .complet {
					width: 141rpx;
					height: 43rpx;
					line-height: 43rpx;
					text-align: center;
					box-sizing: border-box;
					border-radius: 20rpx;
				}
				.state {
					border: 1px solid #FF5337;
				}
				.complet {
					border: 1px solid #666666;
					color: #666666;
				}
			}
			.left {
				.award {
					margin-left: 28rpx;
				}
				.progress {
					line-height: 32rpx;
					font-size: 12px;
					color: #666666;
				}
			}
		}
	}


	.popup-view{
		background-color: #FFFFFF;
		border-radius: 20upx;
	}
	.sign-view{
		height: 270upx;
		width: 100%;
		background:rgba(27,27,48,1);
		color:rgba(255,254,254,1);
		display: flex;
		justify-content: center;
		align-items: center;
		border-top-left-radius: 20upx;
		border-top-right-radius: 20upx;
		flex-direction: column;
	}
	.cale-view{
		padding: 20upx;
	}
	
	.view-1{
		width: 164upx;
		height: 164upx;
		background-color: #FFFFFF;
		border-radius: 50%;
		background-color: #494959;
	}
	.view-2{
		width: 140upx;
		height: 140upx;
		background-color: #FFFFFF;
		border-radius: 50%;
		background:#FFFFFF;
	}
	.view-3{
		width: 120upx;
		height: 120upx;
		background-color: #FFFFFF;
		border-radius: 50%;
		border: 1upx solid rgba(27,27,48,1);
		background:#FFFFFF;
		color: rgba(27,27,48,1);
	}
</style>
