<template>
	<view class="container">
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="90" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<scroll-view
				class="panel-scroll-box" 
				:scroll-y="enableScroll" 
				@scrolltolower="loadMore"
				>
				<view class="list-item" v-for="(item, index) in dataList" :key="index">
					<view>
						<view class="taskName">{{item.taskType == '1' ? (item.inviterName != null ? ('邀请用户（'+item.inviterName+'）') : '邀请新用户') : item.taskTypeName}}</view>
						<view class="time">{{item.updetedTime}}</view>
					</view>
					<view :class="item.integralType == '0' ? 'income' : 'expend'">{{item.integralNum}}</view>
				</view>
				<!-- 上滑加载更多组件 -->
				<mix-load-more :status="loadMoreStatus"></mix-load-more>
			</scroll-view>
		</mix-pulldown-refresh>
	</view>
</template>

<script>
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	export default {
		components: {
			mixPulldownRefresh,
			mixLoadMore
		},
		data() {
			return {
				enableScroll: true,
				loadMoreStatus: 0,	//加载更多 0加载前，1加载中，2没有更多了
				dataList: [],
				offset: 1,
				refreshing: 0,
				total: 0,	// 记录条数
			}
		},
		onLoad:	function() {
			this.loadTaskList('add');
		},
		methods: {
			// 任务列表
			loadTaskList(type){
				let that = this;
				// type add 加载更多 refresh下拉刷新
				if(type === 'add'){
					if(that.loadMoreStatus === 2){
						return;
					}
					if(that.dataList && that.dataList.length > 0){
						that.offset++;
					}
					that.loadMoreStatus = 1;
				}
				// #ifdef APP-PLUS
				else if(type === 'refresh'){
					that.refreshing = true;
				}
				// #endif
				let datas = {
					"limit": 20,
					"offset": that.offset
				}
				// console.log(datas);
				this.$req.reqc.IntegralLog(datas)
				.then( res => {
					console.log("数据",res)
					// return false;
					if(type === 'refresh'){
						that.dataList = []; //刷新前清空数组
						that.offset = 1;
					}
					let list = res.data.data.list;
					that.total = res.data.data.total;
					list.forEach((item,index) => {
						let items = {
							logId: item.logId, // 任务Id
							integralType: item.integralType, // 收入/支出类型 0收入 1支出
							integralNum: item.integralNumString, // 收入/支出数量
							taskType: item.taskType, // 任务类型 0分享 1邀请人 2签到
							taskTypeName: item.integralType == '0' ? item.taskTypeName : item.name, // 任务名称
							inviterName: item.inviterName, // 被邀请人昵称
							updetedTime: item.updetedTime
						}
						that.dataList.push(items);
					})
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						that.refreshing = false;
						// #endif
						that.loadMoreStatus = 0;
					}
					//上滑加载 处理状态
					if(type === 'add' || type === 'refresh'){
						that.loadMoreStatus = that.dataList.length >= this.total ? 2 : 0;
					}
					console.log('状态码 ' + that.loadMoreStatus + ' → 加载更多 0加载前，1加载中，2没有更多了');
					console.log("积分列表：",that.dataList);
					
					this.$forceUpdate();
				})
			},
			
			//下拉刷新
			onPulldownReresh(){
				this.loadTaskList('refresh');
			},
			//上滑加载
			loadMore(){
				this.loadTaskList('add');
			},
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.container {
		width: 100%;
		display: flex;
		flex-direction: column;
		overflow: hidden;
		// align-items: center;
		// justify-content: center;
		// background-color: #F7F7F7;
		// padding-bottom: 250rpx;
		
		.panel-scroll-box{
			height: 100vh;
		}
		
		.list-item {
			height: 114rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-bottom: 1px solid #CCCCCC;
			background-color: #FFFFFF;
			padding: 0 31rpx;
			
			.taskName {
				font-size: 15px;
				color: #333333;
			}
			.time {
				font-size: 11px;
				color: #999999;
			}
			.income, .expend {
				font-size: 16px;
			}
			.income {
				color: #FF5337;
			}
			.expend {
				color: #1B1B30;
			}
		}
	}
</style>
