<template>
	<view class="container" style="padding-top:var(--status-bar-height);">
		<!-- 积分商城 -->
		<view class="header">
			<!-- #ifndef H5 -->
			<view class="status"></view>
			<!-- #endif -->
			<view class="topItem">
				<view class="back" @tap.stop="backButton"></view>
				<view class="mainTitle">积分商城</view>
				<view @tap="pointHistory">积分明细</view>
			</view>
			<view class="myMarks">
				<text>我的积分：</text>
				<view class="score">{{myIntegral === null ? 0 : myIntegral}}</view>
			</view>
			<view class="myExchange"><view class="btn" @tap="myExchange">我的兑换</view></view>
		</view>
		<!-- 顶部选项卡 -->
		<scroll-view class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<view 
			 v-for="(item,index) in tabBars" :key="item.name"
				class="uni-tab-item"
				:class="{current: index === tabCurrentIndex}"
				:id="'tab'+index"
				@click="changeTab(index)"
				
			>
			<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{item.name}}</text>
			<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
		</scroll-view>
		
		<!-- 占位盒子 -->
		<!-- #ifdef H5 -->
		<view style="height: 432rpx;"></view>
		<!-- #endif -->
		<!-- #ifdef APP-PLUS -->
		<!-- 432rpx - 38px - 15px -->
		<!-- <view style="height: 326rpx;"></view> -->
		<view style="height: calc(326rpx - var(--status-bar-height))"></view>
		<!-- #endif -->
		
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="74" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<!-- 内容部分 -->
			<swiper 
				id="swiper"
				class="swiper-box" 
				:duration="300" 
				:current="tabCurrentIndex" 
				@change="changeTab"
			>
				<swiper-item v-for="(tabItem, cindex) in tabBars" :key="cindex">
					<scroll-view 
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<block v-for="(item, index) in tabItem.data" :key="index">
							<view class="list-item">
								<image :src="item.commodityImg != null ? item.commodityImg : '../../../static/default_img.png'"></image>
								<view class="rightBox">
									<view class="title">{{item.name}}</view>
									<view class="price">{{item.commodityIntegral}}积分</view>
									<!-- <view>共{{item.commodityNumber}}件，已售{{item.quantitySold}}件</view> -->
									<view :class="item.commodityNumber > item.quantitySold ? 'convertBtn' : 'forbid'" @tap="openOrder(item)">兑换</view>
								</view>
							</view>
						</block>
						<!-- 上滑加载更多组件 -->
						<mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more>
					</scroll-view>
				</swiper-item>
			</swiper>
		</mix-pulldown-refresh>
	</view>
</template>

<script>
	import json from '@/json'
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	let windowWidth = 0, scrollTimer = false, tabBar;
	export default {
		components: {
			mixPulldownRefresh,
			mixLoadMore,
		},
		data() {
			return {
				myIntegral: 0,
				tabCurrentIndex: 0, //当前选项卡索引
				scrollLeft: 0, //顶部选项卡左滑距离
				enableScroll: true,
				tabBars: [
					{id:'', name:'热门兑换', data: [], loadMoreStatus: 0, refreshing: 0, offset: 1, isLastPage: false, isFocus:true},
					{id:'', name:'全部兑换', data: [], loadMoreStatus: 0, refreshing: 0, offset: 1, isLastPage: false, isFocus:true},
					
				],
				total:100,
			}
		},
		//async
		onLoad() {
			// 获取屏幕宽度
			windowWidth = uni.getSystemInfoSync().windowWidth;
			// this.QueryUserIntegral();
			this.loadGoodsList('add');
		},
		onShow:function(){
			// console.log('显示');
			this.QueryUserIntegral();
		},
		// 监听页面返回
		// onBackPress: function (options) {
		// 	if (options.from === 'navigateBack') {
		// 		return false;
		// 	}
		// 	this.beforePage(); 
		// 	return true; 
		// },
		methods: {
			// 查询用户积分
			QueryUserIntegral: function () {
				this.$req.reqc.queryUserInfo()
				.then( res => {
					// console.log("用户信息：",res)
					this.myIntegral = res.data.data.userIntegral;
					console.log('当前用户积分：',this.myIntegral);
				})
			},
			// 商品列表
			loadGoodsList(type){
				let tabItem = this.tabBars[this.tabCurrentIndex];
				// console.log("选中",tabItem)
				// type add 加载更多 refresh下拉刷新
				if(type === 'add'){
					if(tabItem.loadMoreStatus === 2 || tabItem.isLastPage){
						console.log("分页状态(最后一页)",tabItem.isLastPage)
						return;
					}
					if(tabItem.data&&tabItem.data.length > 0){
						tabItem.offset++;
					}
					tabItem.loadMoreStatus = 1;
				}
				// #ifdef APP-PLUS
				else if(type === 'refresh'){
					tabItem.refreshing = true;
				}
				// #endif
				let datas = {
					"limit": 10,
					"offset": tabItem.offset
				}
				// console.log(datas);return;
				this.$req.reqc.queryShoppingAll(datas)
				.then( res => {
					// console.log("商品",res)
					if(type === 'refresh'){
						tabItem.data = []; //刷新前清空数组
						tabItem.offset = 1;
					}
					let list = res.data.data.list;
					// 更新分页状态
					tabItem.isLastPage = res.data.data.isLastPage;
					// 数据总条数
					this.total = res.data.data.total;
					// console.log("商品列表",list)
					list.forEach((item,index) => {
						let items = {
							id: item.id, // 商品Id
							name: item.name, // 商品名称
							commodityImg: item.commodityImg, // 商品图片
							commodityNumber: item.commodityNumber, // 商品数量(库存)
							quantitySold: item.quantitySold, // 商品已售数量
							commodityIntegral: item.commodityIntegral, // 商品兑换积分
							isHot: item.isHot, // 是否热门 0是 1否 默认1
							isRecommend: item.isRecommend, // 是否推荐 0是 1否 默认1
							// commodityContent: item.commodityContent, // 商品内容
							ruleDetails: item.ruleDetails, // 商品兑换规则
						}
						tabItem.data.push(items);
					})
					// console.log(tabItem);return
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;
					}
					//上滑加载 处理状态
					if(type === 'add'){
						tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2 : 0;
					}
					// console.log("全部数据",this.tabBars)
					// console.log("商品列表数据",tabItem);
					
					this.$forceUpdate();
				})
			
			},
			
			//下拉刷新
			onPulldownReresh(){
				this.loadGoodsList('refresh');
			},
			//上滑加载
			loadMore(){
				this.loadGoodsList('add');
			},
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			},
	
			//tab切换
			async changeTab(e){
				
				if(scrollTimer){
					//多次切换只执行最后一次
					clearTimeout(scrollTimer);
					scrollTimer = false;
				}
				let index = e;
				//e=number为点击切换，e=object为swiper滑动切换
				if(typeof e === 'object'){
					index = e.detail.current
				}
				if(typeof tabBar !== 'object'){
					tabBar = await this.getElSize("nav-bar")
				}
				//计算宽度相关
				let width = 0; 
				let nowWidth = 0;
				//获取可滑动总宽度
				for (let i = 0; i <= index; i++) {
					let result = await this.getElSize('tab' + i);
					width += result.width;
					if(i === index){
						nowWidth = result.width;
					}
				}
				if(typeof e === 'number'){
					//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
					this.tabCurrentIndex = index; 
				}
				//延迟300ms,等待swiper动画结束再修改tabbar
				scrollTimer = setTimeout(()=>{
					if (width - nowWidth/2 > windowWidth / 2) {
						//如果当前项越过中心点，将其放在屏幕中心
						this.scrollLeft = width - nowWidth/2 - windowWidth / 2;
					}else{
						this.scrollLeft = 0;
					}
					if(typeof e === 'object'){
						this.tabCurrentIndex = index; 
					}
					this.tabCurrentIndex = index; 
					
					
					//第一次切换tab，动画结束后需要加载数据
					let tabItem = this.tabBars[this.tabCurrentIndex];
					if(this.tabCurrentIndex !== 0 && tabItem.loaded !== true){
						this.loadGoodsList('add');
						tabItem.loaded = true;
					}
				}, 300)
			},
			//获得元素的size
			getElSize(id) { 
				return new Promise((res, rej) => {
					let el = uni.createSelectorQuery().select('#' + id);
					el.fields({
						size: true,
						scrollOffset: true,
						rect: true
					}, (data) => {
						res(data);
					}).exec();
				});
			},
			// 兑换订单
			openOrder: function (data) {
				if (this.myIntegral < data.commodityIntegral) {
					uni.showToast({
						icon: 'none',
						title: '积分不足'
					})
					return false;
				}
				if (data.commodityNumber > data.quantitySold) {
					uni.showLoading({
						title: '请稍后...',
						mask: true
					});
					let datas = {
						"shoppingID": data.id,
					}
					// console.log(datas);return;
					this.$req.reqc.queryOrderNumber(datas)
					.then( res => {
						let oId = res.data.data.orderNumber
						// console.log("订单号：",oId);return
						let temp = {
							orderNumber: oId, // 订单号
							id: data.id, // 商品Id
							name: data.name, // 商品名称
							commodityImg: data.commodityImg, // 商品图片
							commodityNumber: data.commodityNumber, // 商品数量
							quantitySold: data.quantitySold, // 商品已售数量
							commodityIntegral: data.commodityIntegral, // 商品兑换积分
							ruleDetails: data.ruleDetails, // 商品兑换规则
						}
						// console.log(temp);return
						uni.hideLoading();
						uni.navigateTo({
							url: '/pages/mine/order/order?data=' + encodeURIComponent(JSON.stringify(temp))
						})
					})
				} else {
					uni.showToast({
						icon: 'none',
						title: '当前商品已售罄'
					})
				}
			},
			// 积分明细
			pointHistory: function() {
				uni.navigateTo({
					url: '/pages/mine/integral/pointHistory'
				})
			},
			// 我的兑换
			myExchange: function() {
				uni.navigateTo({
					url: '/pages/mine/integral/myExchange'
				})
			},
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				// this.beforePage();
				uni.navigateBack();
			},
			
			beforePage() {
				let pages = getCurrentPages(); //当前页
				let beforePage = pages[pages.length - 2]; //上个页面 (-2：上一页面)
				// console.log(beforePage);
				// #ifdef H5
				beforePage.RefreshIntegral()
				// #endif
				// #ifndef H5
				beforePage.$vm.RefreshIntegral()
				// #endif
				// that.toBack(1);
			},
		},
		filters: {
			CaptureTime: function (str) {
				return str.trim().split(/\s+/)[1];
			}
		}
	}
</script>

<style lang="scss" scoped>
	page, .container {
		height: 100%;
	}
	.container {
		display: flex;
		flex-direction: column;
		overflow: hidden;
		width: 100%;
		background-color: #FFFFFF;
		.header {
			position: fixed;
			top: 0px;
			z-index: 100;
			display: flex;
			flex-direction: column;
			width: 100%;
			height: 268rpx;
			background-color: #1B1B30;
			.status {
				height: var(--status-bar-height);
			}
		}
		/* 头部栏 */
		.topItem {
			height: 88rpx;
			box-sizing: border-box;
			padding: 0 30rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 13px;
			color: #FFFFFF;
			position: relative;
			.back {
				width: 30rpx;
				height: 36rpx;
				background-size: cover;
				background-image: url(../../../static/images/user_left_w.png);
			}
			.mainTitle {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				font-size: 18px;
			}
		}
		/* 我的积分 */
		.myMarks {
			height: 80rpx;
			line-height: 80rpx;
			box-sizing: border-box;
			padding: 0 30rpx;
			font-size: 13px;
			color: #FFFFFF;
			position: relative;
			.score {
				position: absolute;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -40%);
				text-align: center;
				font-size: 30px;
			}
		}
		/* 我的兑换 */
		.myExchange {
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100rpx;
			background-size: cover;
			background-image: url('../../../static/assets/bg_mask.png');
			font-size: 12px;
			color: #FFFFFF;
			.btn {
				width: 140rpx;
				height: 44rpx;
				line-height: 44rpx;
				text-align: center;
				box-sizing: border-box;
				border-radius: 22rpx;
				border: 1px solid #FFFFFF;
			}
		}
		
		/* 任务模块-tab切换 */
		.nav-bar{
			position: fixed;
			top: 268rpx;
			z-index: 999;
			width: 100%;
			height: 38px;
			box-sizing: border-box;
			flex-direction: row;
			// white-space: nowrap;
			background-color: #FFFFFF;
			border-bottom: 1px solid #EAEAEA;
			
			.uni-tab-item {
				width: 50%;
				display: inline-block;
				flex-wrap: nowrap;
				/* border: 1px solid red; */
				position: relative;
				text-align: center;
				
				.uni-tab-item-title {
					color: #999999;
					font-size: 12px;
					height: 38px;
					line-height: 38px;
					flex-wrap: nowrap;
					white-space: nowrap;
				}
				.uni-tab-item-title-active {
					color: #000000;
				}
				/* 滚动tab 底部选中条 */
				.uni-tab-item-border {
					position: absolute;
					bottom: 0;
					left: 50%;
					transform: translate(-50%,-50%);
				}
				.uni-tab-item-border-active {
					width: 100%;
					height: 1px;
					background-color: #000000;
				}
			}
		}
		
		.swiper-box{
			/* #ifdef H5 */
			height: 100%;
			/* #endif */
			
			/* #ifdef APP-PLUS */
			/* 268rpx 已包含顶部状态栏高度的高度 */
			height: calc(100% - 268rpx + var(--status-bar-height));
			/* #endif */
			
			.panel-scroll-box{
				height: 100%;
			}
			
			.list-item {
				width: 710rpx;
				height: 254rpx;
				margin: 30rpx auto;
				overflow: hidden;
				position: relative;
				display: flex;
				
				box-sizing: border-box;
				border-radius: 10rpx;
				box-shadow: 0 0 10px rgba(0, 0, 0, .2);
					
				image {
					max-width: 342rpx;
					min-width: 342rpx;
					height: 100%;
				}
				.rightBox {
					padding: 20rpx 0 0 20rpx;
					font-size: 14px;
					
					.title {
						color: #333333;
						/* 超出2行时，隐藏并显示省略符 */
						overflow: hidden;
						text-overflow: ellipsis;
						display: -webkit-box;
						-webkit-line-clamp: 2; /* 行数控制 */
						-webkit-box-orient: vertical;
					}
					.price {
						font-size: 16px;
						color: #FF5337;
					}
					// 按钮按钮
					.convertBtn, .forbid {
						position: absolute;
						right: 20rpx;
						bottom: 20rpx;
						width: 194rpx;
						height: 42rpx;
						line-height: 42rpx;
						text-align: center;
						border-radius: 20rpx;
					}
					// 可兑换
					.convertBtn {
						color: #FFFFFF;
						background-color: #000000;
					}
					// 不可兑换
					.forbid {
						color: #ACACAC;
						background-color: #F7F7F7;
					}
				}
			}
		}
		
	}
</style>
