<template>
	<view class="container">
		<uni-list>
			<!-- #ifndef APP-PLUS -->
			<uni-list-item title="下载 App 版" @tap="downloadApp" />
			<!-- #endif -->
		</uni-list>
		
		<!-- <uni-list>
			<uni-list-item title="内容显示" />
			<uni-list-item :show-badge="true" title="字体大小" badge-text="标准" />
			<uni-list-item title="提醒设置" />
		</uni-list> -->

		<uni-list class="map-t20">
			<uni-list-item title="赏一个五星好评"/>
			<uni-list-item title="关于零点八" />
			<!-- #ifdef APP-PLUS -->
			<uni-list-item title="版本更新" @tap="downloadFile" />
			<!-- #endif -->
		</uni-list>

		<uni-list class="map-t20">
			<uni-list-item title="退出登录" @tap="toLogout" />
		</uni-list>
	</view>
</template>

<script>
import { mapState } from 'vuex';
import uniList from '@/components/uni-list/uni-list.vue';
import uniListItem from '@/components/uni-list-item/uni-list-item.vue';
import { mapMutations } from 'vuex';
export default {
	computed: mapState(['hasLogin']),
	components: {
		uniList,
		uniListItem
	},
	onBackPress(options) {
		// let page = getCurrentPages();
		// // #ifdef H5
		// if (options.from === 'navigateBack') {
		// 	if(page.length < 2){
		// 		window.history.back(-1);
		// 		// history.go(-1)
		// 		// history.back(-1)
		// 		// history.back()
		// 		return false;
		// 	}
		// 	return false;
		// }
		// // #endif
		// return false;
	},
	data() {
		return {};
	},
	methods: {
		...mapMutations(['logout']),

		navTo(url) {
			this.$api.msg(`跳转到${url}`);
		},
		//退出登录
		toLogout() {
			// console.log('退出登录');return;
			if (!this.hasLogin) {
				uni.showToast({
					icon: 'none',
					title: '当前未登录账户'
				});
				return;
			}
			uni.showModal({
				content: '确定要退出登录么',
				success: e => {
					if (e.confirm) {
						// 清空我的页面积分记录
						let pages = getCurrentPages(); //当前页
						let beforePage = pages[pages.length - 2]; //上个页面
						// console.log('初始',beforePage.$data.myIntegral);
						// #ifdef H5
						beforePage.$data.myIntegral = 0;
						// #endif
						// #ifndef H5
						beforePage.$vm.$data.myIntegral = 0;
						// #endif
						// beforePage.$data.myIntegral = 0;
						// console.log('完成',beforePage.$data.myIntegral);
						this.logout();
						uni.removeStorage({
							key: 'userInfo'
						});

						try {
							uni.removeStorageSync('user');
							uni.removeStorageSync('token');
						} catch (e) {
							// error
							console.log(e);
						}
						setTimeout(() => {
							uni.navigateBack();
						}, 200);
					}
				}
			});
		},
		
		// 前往app下载页
		// #ifndef APP-PLUS
		downloadApp() {
			uni.navigateTo({
				url: '/pages/mine/downloadApp'
				// url: '/pages/mine/downloadApp?shareUserId='+ 30,
			})
		},
		// #endif
		
		// 检查版本更新
		// #ifdef APP-PLUS
		downloadFile() {
			let that = this;
			// 获取本地应用资源版本号
			plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) {
				console.log('当前应用版本：' + widgetInfo.version, '应用名称：' + widgetInfo.name);
				// return;
				let datas = {
					version: widgetInfo.version
				};
				that.$req.reqc.verificationAppVersion(datas)
				.then(res => {
					console.log('版本号校验信息：',res);
					if (res.statusCode === 200 && res.data.resultCode === 1) {
						let data = res.data.data;
						console.log('>>>>>版本更新信息<<<<<', data);
						// 下载wgt文件
						if (data.appDownloadPath !== null && data.appVersion !==  datas.version) {
							console.log('下载地址：', data.appDownloadPath);
							uni.showModal({
								title: '版本更新',
								content: '当前有可用版本更新',
								cancelText: '以后再说',
								confirmText: '立即更新',
								success: function (res) {
									if (res.confirm) {
										// console.log('用户点击确定');
										//创建一个showWaiting对象
										let showLoading = plus.nativeUI.showWaiting("正在初始化");
										
										const downloadTask = uni.downloadFile({
											url: data.appDownloadPath,
											success: downloadResult => {
												console.log('升级包地址：', downloadResult);
												if (downloadResult.statusCode === 200) {
													showLoading.setTitle("正在安装");
													plus.runtime.install(
														downloadResult.tempFilePath,
														{
															force: true
														},
														function() {
															showLoading.setTitle("准备重启应用");
															plus.nativeUI.closeWaiting();
															console.log('install success...');
															// 重启应用
															plus.runtime.restart();
														},
														function(e) {
															console.log(e);
															uni.showToast({
																icon: 'none',
																title: e.message
															});
															plus.nativeUI.closeWaiting();
															console.error('install fail...');
														}
													);
												}
											}
										});
										
										// 监听下载进度
										downloadTask.onProgressUpdate((res) => {
											// if (res.progress > 0) {}
												// let titleText = '下载中:'+res.progress+'%';
												let titleText = `下载中: ${res.progress}%`;
												showLoading.setTitle(titleText);
												// console.log('下载进度' + res.progress, typeof res.progress);
										});
									}
									else if (res.cancel) {
										console.log('用户点击取消');
									}
								}
							});
						}
					} else {
						console.log(res.data.resultMsg);
						uni.showToast({
							icon:'none',
							title: '已是最新版本了~'
						})
					}
				})
				.catch(err => {
					console.log(err);
				})
			})
		},
		// #endif
		
		//switch
		switchChange(e) {
			let statusTip = e.detail.value ? '打开' : '关闭';
			this.$api.msg(`${statusTip}消息推送`);
		},
	}
};
</script>

<style lang="scss">
page {
	background: $page-color-base;
}
.container {
	width: 100vw;
}

.map-t20 {
	margin-top: 20rpx;
}
</style>
