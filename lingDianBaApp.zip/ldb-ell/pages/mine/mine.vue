<template>
	<!-- style="padding-top:var(--status-bar-height);" -->
	<view class="container">

		<view class="header">
			<!-- #ifndef H5 -->
			<view class="status"></view>
			<!-- #endif -->
			<view class="topBar">
				<view class="btn comeBack" @tap="backButton"></view>
				<!-- <view class="iconfont" @tap.stop="navTo('ptions')">&#xe657;</view> -->
				<view class="btn setting" @tap.stop="navTo('ptions')"></view>
			</view>
			<view v-if="hasLogin" class="user" @tap.stop="navTo('modifyUser')">
				<image :src="imageUrl ? ('https://images.weserv.nl/?url='+imageUrl) : '/static/assets/user_default.png'" mode="aspectFill"></image>
				<text class="name">{{nickName === null ? '新用户' : nickName}}</text>
				<text class="arrow_r">
					<text></text> 
				</text>
			</view>
			
			<view v-if="!hasLogin" class="user" @tap="navTo('../login/login')">
				<image src="/static/assets/user_default.png" mode="aspectFill"></image>
				<text class="name">游客</text>
				<text class="arrow_r">
					<text></text>
				</text>
			</view>
			
			<view class="controls">
				<view class="controls_l"  @tap.stop="sheetTap(integral)">
					当前积分: {{myIntegral === null ? 0 : myIntegral}}
				</view>
				<view class="controls_c">|</view>
				<!-- 弹出签到日历 -->
				<view class="controls_r" type="primary" @tap.stop="togglePopup('center', 'popup')">
				<!-- 每日签到跳转至任务大厅页 -->
				<!-- <view class="controls_r" type="primary" @tap.stop="sheetTap(sheetData[1])"> -->
					<view class="btn signin"></view>
					签到领积分
				</view>
			</view>
		</view>
		<view class="content">
			<view class="sheet">
				<block v-for="(item,idx) in sheetData" :key="idx">
					<view class="sheet_item" @tap.stop="sheetTap(item)">
						<view class="sheet_item_icon" :style="{backgroundImage: ''+item.icon+''}"></view>
						<view class="sheet_item_c">{{item.name}}</view>
						<view class="sheet_item_r"></view>
					</view>
				</block>
			</view>
		</view>
		<!-- #ifdef APP-PLUS -->
		<view class="versionView">
			当前版本：{{currVersion}}
		</view>
		<!-- #endif -->
		<!-- 签到弹出框  :show="showpopup" -->
		<uni-popup ref="popup" :type="type" @change="change">
			<view class="popup-view" style="background-color: #FFFFFF;">
				<view class="sign-view ">
					<view class="view-1 flex-cc" @tap.stop="performTask">
						<view class="view-2 flex-cc">
							<view class="view-3 flex-cc">
								签到
							</view>
						</view>
					</view>
					<view class="sign-text">
						您已经连续签到 {{signInCount}} 天，积分{{myIntegral === null ? 0 : myIntegral}}
					</view>
				</view>
				<view class="cale-view">
					<uni-calendar 
					ref="calendar" 
					:insert="info.insert" 
					:range="info.range" 
					:lunar="info.lunar" 
					:date="info.date" 
					:selected="info.selected" 
					:start-date="info.startDate" 
					:end-date="info.endDate" 
					@change="taskChange"/>
				</view>
			</view>
		</uni-popup>
		
	</view>
</template>

<script>
	import {
	    mapState
	} from 'vuex'
	import uniSection from '@/components/uni-section/uni-section.vue'
	import uniIcons from '@/components/uni-icons/uni-icons.vue'
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import uniCalendar from '@/components/uni-calendar/uni-calendar.vue'
	let that
	export default {
		computed: mapState(['forcedLogin', 'hasLogin', 'userName','token']),
		// name: 'user-center',
		components: {
			uniSection,
			uniCalendar,
			uniPopup,
			uniIcons
		},
		// props: {},
		data() {
			return {
				myIntegral: 0,	// 我的积分
				showpopup: false,
				type: 'center',
				content:'test',
				windowHeight: 0,
				// TODO: 个人中心数据
				// userName: '测试数据长达九个字',
				
				dataList: [],	// 任务列表
				signInCount: 0, // 连续登录次数
				/*日历插件 显示数据*/
				selectedCalendar:'',
				info: {
					lunar: false,	//是否开启农历
					range: false,	//开启范围选择
					insert: true,	//设置是否显示
					selected: [],	//设置指定日期 标点
					startDate: '',	// 日历开始时间
					endDate: '',	// 日历结束时间
				},
				currentDate: '',	// 当前日期 'YYYY-MM-DD'
				
				
				// 积分明细 url ↓
				integral: {
					url: 'integral/pointHistory',
				},
				// TODO: 操作菜单数据 ↓
				sheetData: [{
						name: '积分商城',
						id: 1,
						// #ifdef H5
						icon: 'url(static/mine/integral.png)',
						// #endif
						// #ifndef H5
						icon: 'url(../../static/mine/integral.png)',
						// #endif
						url: 'integral/integral'
					},
					{
						name: '任务大厅',
						id: 2,
						// #ifdef H5
						icon: 'url(static/mine/task.png)',
						// #endif
						// #ifndef H5
						icon: 'url(../../static/mine/task.png)',
						// #endif
						url: 'task/task'
					},
					{
						name: '意见反馈',
						id: 3,
						// #ifdef H5
						icon: 'url(static/mine/opinion.png)',
						// #endif
						// #ifndef H5
						icon: 'url(../../static/mine/opinion.png)',
						// #endif
						url: 'opinion/opinion'
					},
					{
						name: '邀请朋友赚积分',
						id: 4,
						// #ifdef H5
						icon: 'url(static/mine/invitation.png)',
						// #endif
						// #ifndef H5
						icon: 'url(../../static/mine/invitation.png)',
						// #endif
						url: 'invitation/invitation'
					}
				],
				nickName:'',
				imageUrl:'',
				currVersion:'',
				shareQrCodeSrc: '', //邀请码图片地址
				
				itemSwitch: {}, // 个人中心功能项开关
			}
		},
		beforeCreate() {
			// #ifndef APP-PLUS
			console.time('renderTime')
			// #endif
		},
		onBackPress(options) {
			let page = getCurrentPages();
			// #ifdef H5
			if (options.from === 'navigateBack') {
				if(page.length < 2){
					window.history.back();
					// history.go(-1)
					// history.back(-1)
					// history.back()
					return true;
				}
				return false;
			}
			// #endif
			return false;
		},
		created() {
			// 个人中心功能列表项开关控制
			this.$req.reqc.verificationMineStatus()
			.then( res => {
				this.itemSwitch = res.data.data;
				console.log('开关信息：',this.itemSwitch);
				
				// mallSwitch：商城开关 1 (1:开；0:关)
				if (!this.itemSwitch.mallSwitch) {
					this.sheetData.splice(this.sheetData.findIndex(item => item.id == 1), 1);
				}
				// taskSwitch：任务开关 2
				if (!this.itemSwitch.taskSwitch) {
					this.sheetData.splice(this.sheetData.findIndex(item => item.id == 2), 1);
				}
				// inviteSwitch：邀请朋友赚积分开关 => id: 4
				if (!this.itemSwitch.inviteSwitch) {
					this.sheetData.splice(this.sheetData.findIndex(item => item.id == 4), 1);
				}
			})
		},
		onLoad() {
			that = this;
			// #ifdef APP-PLUS
			plus.runtime.getProperty(plus.runtime.appid, function(inf) {
				that.currVersion = inf.version;
			})
			// #endif
			// 获取当前时间
			this.currentDate = this.utils.getCurrentDate();
			// console.log('当前日期：',this.currentDate);
		},
		onShow() {
			if (this.hasLogin) {
				// 查询用户积分
				this.QueryUserIntegral().then(e=>{
					this.ContSignIn();
				})
				// 查询连续签到次数
			}
			uni.getStorage({
			    key: 'userInfo',
			    success: function (res) {
			       // console.log("userInfo数据",res.data);
			   		that.nickName = res.data.nickName;
					that.imageUrl = res.data.imageUrl;
			   },
			});
		},
		onReady() {
			// #ifndef APP-PLUS
			// console.log(
			// 	'%c如果渲染用时超过3秒，则列入待优化项目',
			// 	'color: yellow; background-color: black;padding: 2px'
			// )
			// console.timeEnd('renderTime')
			// #endif
		},
		onHide() {},
		onUnload() {},
		onPullDownRefresh() {},
		onReachBottom() {},
		onShareAppMessage() {},
		onPageScroll() {},
		
		methods: {
			// 查询用户积分
			QueryUserIntegral: function () {
				return new Promise((resolve, reject) =>{
					this.$req.reqc.queryUserInfo()
					.then( res => {
						// console.log("用户信息：",res)
						// this.sheetData[3].url = '/pages/mine/invitation/invitation?id='+ res.data.data.userId +'&src='+ encodeURIComponent(JSON.stringify(res.data.data.shareQrCode)); // 更新邀请好友页跳转链接，用户邀请码（地址栏取值：JSON.parse(decodeURIComponent(option.src))）
						this.myIntegral = res.data.data.userIntegral;
						console.log('当前用户积分：',this.myIntegral);
						resolve();
					})
				})
			},
			// 查询签到次数
			ContSignIn: function () {
				let dateList = this.info.selected;
				let date = new Date();
				let month = date.getMonth()+1 < 10 ? ('0' + (date.getMonth()+1)) : (date.getMonth()+1);
				// console.log('查询月份：', month);
				let datas = {
					"month": month // "01"-"12"
				}
				this.$req.reqc.countBySign(datas)
				.then( res => {
					this.signInCount = res.data.data.count;
					// console.log('连续签到次数：',this.signInCount);
					let data = res.data.data.userTaskDOList;
					data.forEach((item, index) => {
						if (item.finshState == "0") {
							let temp = {
								date: item.beginTime.split(' ')[0], // "2019-12-30"
								info: '已签到'
							};
							dateList.push(temp)
						}
						// console.log(item,index);
					})
					console.log('已签到日期：',dateList);
					
					// 设置日历开始、结束时间
					this.info.startDate = dateList[0] && dateList[0].date || this.currentDate;
					this.info.endDate = dateList[dateList.length - 1] && dateList[dateList.length - 1].date || this.currentDate;
					
				})
			},
			
			
			//监听日期选择插件
			taskChange(e){
				if(this.selectedCalendar == e.fulldate){
					return;
				}
				this.selectedCalendar = e.fulldate;
				console.log("选择日期：",e.fulldate);
			},
			// 隐藏签到框
			change(e) {
				console.log('是否打开:' + e.show)
				// if (!e.show) {
				// 	this.showpopup = false
				// }
			},
			// 弹出签到框
			togglePopup(type, open) {
				if (!this.hasLogin) {
					uni.showToast({
						icon:'none',
						title:'请先登录！'
					})
					
					setTimeout(function() {
						uni.navigateTo({
							url: '/pages/login/login'
						})
					}, 1000);
					return;
				}
				
				if (!this.showpopup) {
					// (初始化)分发任务 → 显示任务列表
					this.$req.reqc.distributionTask()
					.then( res => {
						console.log("任务初始化(分发任务)：",res)
						this.loadTaskList('add');
					})
				}
				
				switch (type) {
					case 'top':
						this.content = '顶部弹出 popup'
						break
			
					case 'bottom':
						this.content = '底部弹出 popup'
						break
					case 'center':
						this.content = '居中弹出 popup'
						break
				}
				this.type = type;
				this.$refs.popup.open();
				// this['show' + open] = !this['show' + open]
			},
			
			// 获取任务列表
			loadTaskList(type){
				uni.showLoading({
				    title: '加载中',
					mask: true
				});
				let datas = {
					// "finshState": 0, // 完成状态：0完成 1未完成
					"limit": 10,
					"offset": 1
				}
				this.$req.reqc.queryTaskToday(datas)
				.then( res => {
					uni.hideLoading();
					
					if(type === 'refresh'){
						that.dataList = []; //刷新前清空数组
						that.offset = 1;
					}
					let list = res.data.data.list;
					that.total = res.data.data.total;
					list.forEach((item,index) => {
						let items = {
							userTaskId: item.userTaskId, // 任务Id
							finshState: item.finshState, // 完成状态 0完成1未完成
							completCount: item.completCount, // 已完成次数
							finshCount: item.finshCount, // 需要完成次数
							taskName: item.taskName,
							taskType: item.taskType, // 任务类型 0分享 1邀请人 2签到
							taskRewardNum: item.taskRewardNum
						}
						that.dataList.push(items);
					})
					console.log("任务列表：",that.dataList);
					
					this.$forceUpdate();
				})
			},
			
			// 执行任务
			performTask: function () {
				for (let i = 0; i < that.dataList.length; i++) {
					// 查找每日签到任务
					if (that.dataList[i].taskType == "2") {
						if (that.dataList[i].finshState == "0") {
							uni.showToast({
								icon: 'none',
								title: '当前任务已完成'
							})
							return false;
						}
						let datas = {
							"userTaskId": that.dataList[i].userTaskId
						}
						this.$req.reqc.finshTask(datas)
						.then( res => {
							console.log("已执行：",res)
							that.dataList[i].completCount++;
							if (that.dataList[i].completCount == that.dataList[i].finshCount) {
								that.dataList[i].finshState = "0"
							}
							
							// 退出签到日历、更新连续签到数、更新用户积分
							// this.togglePopup('center', 'popup');
							// this.showpopup = false;
							this.$refs.popup.close();
							// 查询连续签到次数(先清除原有数据)
							this.info.selected = []
							this.ContSignIn();
							
							this.QueryUserIntegral();
						})
					}
				}
			},
			
			
			
			navTo(url){
				
				uni.navigateTo({
					url
				});
			},
			
			sheetTap(item) {
				if (!this.hasLogin) {
					uni.showToast({
						icon:'none',
						title:'请先登录！'
					})
					
					setTimeout(function() {
						uni.navigateTo({
							url: '/pages/login/login'
						})
					}, 1000);
					return;
				}
				uni.navigateTo({
					url: item.url
				});
			},
			
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				uni.navigateBack();
			},
			
			//刷新积分函数
			// RefreshIntegral() {
			// 	this.QueryUserIntegral();
			// },
		},
		watch: {}
	}
</script>

<style lang="scss" scoped>
	$default-text-color-white : white;
	$default-bg-gray: gray;
	$default-bg-black1: black;

	page {
		background: rgba(247,247,247,1);
		// min-height: 100%;
		// width: 100%;
		// height: auto;
	}
	// page {
	// 	display: flex;
	// 	flex-direction: column;
	// 	box-sizing: border-box;
	// 	background-color: #efeff4;
	// 	min-height: 100%;
	// 	height: auto;
	// }
	.versionView{
		width: 100%;
		position: fixed;
		bottom: 0;
		height: 88rpx;
		line-height: 88rpx;
		font-size: 24rpx;
		color: #666666;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.popup-view{
		background-color: #FFFFFF;
		border-radius: 20upx;
	}
	.sign-view{
		height: 270upx;
		width: 100%;
		background:rgba(27,27,48,1);
		color:rgba(255,254,254,1);
		display: flex;
		justify-content: center;
		align-items: center;
		border-top-left-radius: 20upx;
		border-top-right-radius: 20upx;
		flex-direction: column;
	}
	.cale-view{
		padding: 20upx;
	}
	
	.view-1{
		width: 164upx;
		height: 164upx;
		background-color: #FFFFFF;
		border-radius: 50%;
		background:rgba(80,80,48,1);
		
	}
	.view-2{
		width: 140upx;
		height: 140upx;
		background-color: #FFFFFF;
		border-radius: 50%;
		background:#FFFFFF;
	}
	.view-3{
		width: 120upx;
		height: 120upx;
		background-color: #FFFFFF;
		border-radius: 50%;
		border: 1upx solid rgba(27,27,48,1);
		background:#FFFFFF;
		color: rgba(27,27,48,1);
	}
	.sign-text{
		font-size:22upx;
		font-family:PingFang SC;
		font-weight:400;
		color:rgba(255,254,254,1);
	}
	.container {
		display: flex;
		flex-direction: column;
		overflow: hidden;
		width: 100%;
		.header {
			display: flex;
			flex-direction: column;
			width: 100%;
			height: 362rpx;
			background-color: #1B1B30;

			.status {
				height: var(--status-bar-height);
			}

			.topBar {
				height: 88rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				
				.iconfont {
					width: 100rpx;
					text-align: center;
					color: $default-text-color-white;
					font-size: 48rpx;
				}
				
				.btn {
					width: 100rpx;
					height: 100%;
					background-size: cover;
					background-size: 44rpx 44rpx;
					background-position:center center;
					background-repeat: no-repeat;
				}
				
				.setting {
					background-size: 44rpx 42rpx;
					background-image: url(../../static/images/setting.png);
				}
				
				.comeBack {
					background-image: url(../../static/images/video_back_w.png);
				}
			}

			.user {
				flex: 1;
				display: flex;
				align-items: center;
				position: relative;

				image {
					width: 118rpx;
					height: 118rpx;
					margin: 0 21rpx 0 48rpx;
					border-radius: 50%;
				}
				/* 用户名 */
				.name {
					width: 460rpx;
					font-size: 17px;
					color: #FFFFFF;
					
					/* 超出1行时，隐藏并显示省略符 */
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 1; /* 行数控制 */
					-webkit-box-orient: vertical;
				}

				.arrow_r {
					width: 80rpx;
					height: 80rpx;
					position: absolute;
					right: 33rpx;
					top: 50%;
					transform: translateY(-50%);
					text {
						margin: 20rpx auto;
						display: block;
						width: 40rpx;
						height: 40rpx;
						background-size: cover;
						background-image: url(../../static/images/mine_right.png);
					}
				}
			}

			.controls {
				height: 86rpx;
				display: flex;
				align-items: center;
				font-size: 24rpx;
				color: $default-text-color-white;
				background-size: cover;
				background-image: url('../../static/assets/bg_mask.png');

				&_l,
				&_r {
					flex: 1;
					display: flex;
					justify-content: center;
					align-items: center;
				}

				&_r {
					.signin {
						margin-right: 10rpx;
						width: 24rpx;
						height: 24rpx;
						background-size: cover;
						background-size: 24rpx 24rpx;
						background-position:center center;
						background-repeat: no-repeat;
						background-image: url('../../static/mine/signin.png');
					}
					
				}
			}
		}

		.content {
			flex: 1;
			padding: 36rpx 30rpx 0 30rpx;
			width: 100%;
			.sheet {
				width: 100%;
				/* height: 395rpx; */
				height: auto;
				background: $default-bg-white;
				box-shadow: 0rpx 1rpx 10rpx 0rpx $default-shadow-color;
				border-radius: 12rpx;
				padding: 0 10rpx;
				
				:nth-last-child(1) {
					border-bottom: none;
				}

				&_item {
					position: relative; 
					box-sizing: border-box;
					height: 98rpx;
					border-bottom: 1rpx solid $default-border-color-gray;
					display: flex;
					align-items: center;
					color: $default-text-blackBold;
					font-size: 30rpx;
					
					&_icon {
						width: 44rpx;
						height: 44rpx;
						background-size: cover;
						margin: 0 28rpx 0 16rpx;
					}
					
					&_r {
						position: absolute;
						right: 10rpx;
						width: 44rpx;
						height: 44rpx;
						background-size: cover;
						background-image: url(../../static/images/order_right.png);
					}
				}
			}
		}
	}
</style>
