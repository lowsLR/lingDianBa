<template>
	<view class="container">
		<view class="invite record">
			<view class="item">
				<view class="title">邀请好友安装次数</view>
				<view class="count"><text>22</text>次</view>
			</view>
			<view class="item">
				<view class="title">邀请好友注册次数</view>
				<view class="count"><text>21</text>次</view>
			</view>
			<view class="item">
				<view class="title">邀请好友访问二维码次数</view>
				<view class="count"><text>20</text>次</view>
			</view>
		</view>
		
		<label class="textItem" for="">
			<input type="text" disabled :value="invitCode" placeholder="填写邀请码" />
			<button :class="isCopy[0] === 1 ? 'copied' : ''" @tap="copyBtn(0)">复制文本</button>
		</label>
		
		<label class="textItem" for="">
			<input type="text" disabled value="http://47.112.131.52:8091/H5/index.html#/pages/login/regist" placeholder="链接:basfhipwfjfe" />
			<button :class="isCopy[1] === 1 ? 'copied' : ''" @tap="copyBtn(1)">复制链接</button>
		</label>
		
		<view class="QRCodeBox">
			<!-- QRCode 二维码外层框 -->
			<view class="QRCode">
				<!-- usingComponents 是否使用了自定义组件模式（主要是为了修复非自定义组件模式时 v-if 无法生成二维码的问题） -->
				<tki-qrcode cid="qrcode2" ref="qrcode2" :val="val" :size="size" :icon="icon" :iconSize="iconsize" :onval="onval" :loadMake="loadMake" :usingComponents="true" @result="qrR" />
			</view>
		</view>
		<button :class="isCopy[2] === 1 ? 'copied' : ''" @tap="copyBtn(2)">保存图片</button>
	</view>
</template>

<script>
	import downloader from '../../../common/img-downloader.js'
	import { pathToBase64, base64ToPath } from '../../../common/image-tools/index.js'
	import tkiQrcode from '@/components/tki-qrcode/tki-qrcode.vue'
	let that;
	export default {
		components: {
			tkiQrcode
		},
		data() {
			return {
				installCount: 0, // 安装次数
				registCount: 0, // 注册次数
				visitsQRCodeCount: 0, // 访问二维码次数
				
				isCopy: [0,0,0], // 是否已复制
				invitCode: null, // 邀请码
				val: null, // 要生成的二维码值
				size: 450, // 二维码大小(upx)
				icon: '/static/assets/teamLogo_default.png', // 二维码图标
				iconsize: 40, // 二维码图标大小
				onval: false, // val值变化时自动重新生成二维码
				loadMake: false, // 组件加载完成后自动生成二维码
				src: '', // 二维码生成后的图片地址或base64
			}
		},
		onLoad() {
			that = this;
			uni.getStorage({
				key: 'userInfo',
				success: function (res) {
					// console.log("userInfo数据",res.data);
					that.invitCode = res.data.invitationCode
					that.val = 'http://47.112.131.52:8091/H5/index.html#/pages/login/regist?invitCode='+that.invitCode
					console.log('二维码指向地址：',that.val);
					that.loadMake = true;
				},
			});
		},
		methods: {
			// 生成的图片base64或图片临时地址
			qrR(res) {
				this.src = res
				// console.log(this.src);
			},
			
			// 文本复制操作
			copyBtn: function (index) {
				let that = this;
				if (!this.isCopy[index]) {
					switch (index){
						case 0:
							this.copyToClipBoard(this.invitCode, index)
							break;
						case 1:
							this.copyToClipBoard(this.val, index)
							break;
						case 2:
							this.SaveImage(this.src, index);
							break;
						default:
							break;
					}
				} else {
					if (index === 2) {
						uni.showToast({
							icon: 'none',
							title: '已保存'
						})
					} else{
						uni.showToast({
							icon: 'none',
							title: '已复制'
						})
					}
				}
				this.$forceUpdate();
			},
			
			// 保存图片
			SaveImage: function (imgSrc, index) {
				let that = this;
				// imgSrc: H5端为base64格式图片，app端为图片地址
				console.log(imgSrc);
				
				// #ifdef APP-PLUS
				uni.saveImageToPhotosAlbum({
					filePath: imgSrc,
					success: function () {
						that.isCopy[index] = 1;
						that.$forceUpdate();
						uni.showToast({
							title: '保存成功',
							mask: true,
							duration: 2000
						})
					}
				});
				// #endif
				
				// #ifdef H5
				// 将图像base64保存为文件，返回文件路径
				base64ToPath(imgSrc)
				.then(path => {
					console.log('临时图片：',path)
					let promise = downloader.load(path, 'invitCodePic'); //下载
					promise.then(([err, res])=>{	//下载结果 
						console.log(err, res);	// err 和 res 只会有一个存在，另一个为null
						that.isCopy[index] = 1;
						that.$forceUpdate();
						uni.showToast({
							title: '保存成功',
							mask: true,
							duration: 2000
						})
					});
				})
				.catch(error => {
					console.error(error)
				})
				// #endif
			},
			
			// 复制文本到剪切板
			copyToClipBoard: function (text, index) {
				let that = this;
				uni.setClipboardData ({
					data: text,
					success:function(data){
						that.isCopy[index] = 1; // 改变复制按钮状态
						console.log('复制文本：',text);
						uni.showToast({
							icon: 'none',
							title: '复制成功',
							duration: 1500
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: #F7F7F7;
	}
	.container {
		width: 100%;
		padding: 16rpx 20rpx;
		overflow: hidden;
		color: #333333;
		display: flex;
		flex-direction: column;
		align-items: center;
		
		.record {
			width: 100%;
			min-height: 270rpx;
			max-height: 270rpx;
			padding: 0 40rpx;
			background-color: rgba(255, 83, 55, .1);
			border-radius: 8rpx;
			overflow: hidden;
			
			.item {
				display: flex;
				align-items: center;
				justify-content: space-between;
				box-sizing: border-box;
				height: 90rpx;
				border-bottom: 1px solid #FFFFFF;
				
				&:last-child {
					border: 0;
				}
				
				.title {
					font-size: 15px;
				}
				
				.count {
					font-size: 13px;
				}
				text {
					font-size: 40rpx;
					font-weight: bold;
					color: #FF5337;
					margin-right: 10rpx;
				}
			}
		}
		
		button {
			width: 180rpx;
			height: 56rpx;
			line-height: 56rpx;
			border-radius: 28rpx;
			background-color: #FF5337;
			color: #FFFFFF;
			font-size: 13px;
			padding: 0;
			margin: 0;
			
			&::after {
				border: 0;
			}
			
			&.copied {
				color: #666666;
				background-color: #E6E6E6;
			}
		}
		
		.textItem {
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-top: 30rpx;
			
			input {
				width: 500rpx;
				height: 88rpx;
				box-sizing: border-box;
				padding: 0 20rpx;
				line-height: 88rpx;
				text-align: center;
				border-radius: 8rpx;
				background-color: rgba(255, 83, 55, .1);
				font-size: 14px;
				color: #9A9A9A;
			}
		}
		
		.QRCodeBox {
			display: flex;
			justify-content: center;
			align-items: center;
			// min-width: 548rpx;
			min-width: 520rpx;
			max-width: 520rpx;
			min-height: 520rpx;
			max-height: 520rpx;
			border-radius: 8rpx;
			margin: 26rpx 0 22rpx 0;
			background-color: rgba(255, 83, 55, .1);
		}
		.QRCode {
			width: 450rpx;
			height: 450rpx;
		}
	}
</style>
