<template>
	<view class="container">


		<view class="list-cell b-b">
			<view class="cell-tit">头像</view>
			<view class="herder-img" @tap="ChooseImage">
				<image :src="imageUrl != null ? imageUrl : '../../static/assets/user_default.png'" mode="aspectFill"></image>
			</view>
		</view>
		<!-- <view class="list-cell">
			<text class="cell-tit">修改昵称</text>
			<text class="cell-tip" @tap="show9">{{nickName||'新用户'}}</text>
		</view> -->
		<view class="list-cell">
			<text class="cell-tit">修改昵称</text>
			<text class="cell-tip" v-if="!modal6" @tap="modal6=!modal6">{{nickName||'新用户'}}</text>
			<div class="modifyInput" v-if="modal6">
				<input class="prompt-input" type="text" @input="_input" placeholder="输入昵称" :value="cost" />
				<button type="primary" @tap="_confirm">确定</button>
				<button type="warn" @tap="modal6=!modal6">取消</button>
			</div>
		</view>


		<uni-popup :show="showpopup" type="center" @change="change">
			<view class="prompt-content contentFontColor">
				<view class="prompt-title">提示</view>
				<view class="prompt-text">修改昵称</view>
				<input class="prompt-input" type="text" @input="_input" placeholder="输入昵称" :value="cost" />
				<view class="prompt-btn-group">
					<button class="btn-item prompt-cancel-btn contentFontColor" @tap="_cancel">取消</button>
					<button class="btn-item prompt-certain-btn" @tap="_confirm">确定</button>
				</view>
			</view>
		</uni-popup>

		<tui-modal :show="modal9" @cancel="hide9" :custom="true" :fadein="true">
			<view class="tui-modal-custom">
				<view class="tui-prompt-title">用户名</view>
				<input placeholder="请输入用户名" class="tui-input" v-model="cost" />
				<tui-button shape="circle" @click="_confirm" size="small">提交</tui-button>
			</view>
		</tui-modal>
		
		<!-- 等比例绘制临时封面图 -->
		<canvas canvas-id="myCanvas" style="position: absolute; top: -1000px; left: -1000px; width: 640px; height: 640px;"></canvas>
		
	</view>
</template>

<script>
	import uniList from '@/components/uni-list/uni-list.vue'
	import uniListItem from '@/components/uni-list-item/uni-list-item.vue'
	import config from '../../config.js'
	import uniPopup from '@/components/uni-popup/uni-popup.vue'

	import tuiButton from "@/components/button/button"
	import tuiModal from "@/components/modal/modal"
	import {
		mapMutations,
		mapState
	} from 'vuex';

	export default {
		computed: mapState(['userName']),
		components: {
			uniPopup,
			uniList,
			uniListItem,
			tuiModal,
			tuiButton
		},
		data() {
			return {
				showpopup: false,
				imageUrl: '',
				nickName: '',
				invitationCode: '',
				id: 0,
				cost: '',
				modal9: false,
				modal6: false,
			};
		},
		onLoad() {
			uni.getStorage({
				key: 'user',
				success: function(res) {
					// console.log("数据",res.data);
					this.id = res.data.userId;
				},
				fail: function(res) {

				}
			});


		},
		onShow() {
			let that = this;
			uni.getStorage({
				key: 'userInfo',
				success: function(res) {
					// console.log("数据",res.data);
					that.nickName = res.data.nickName;
					that.imageUrl = res.data.imageUrl;
					that.invitationCode = res.data.invitationCode;
				},
			});
		},
		methods: {
			...mapMutations(['setUserName']),
			show9() {
				this.modal9 = true
			},
			hide9() {
				this.modal9 = false
			},
			togglePopup(type) {
				this.showpopup = type == false ? false : true;
				console.log(this.showpopup)
			},
			change(e) {
				if (!e.show) {
					this.showpopup = false
				}
			},
			navTo(url) {
				this.$api.msg(`跳转到${url}`);
			},
			
			// 上传头像
			ChooseImage() {
				let that = this;
				uni.chooseImage({
					count: 1, //默认9
					sizeType: ['compressed'], // original 原图，compressed 压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success: (res) => {
						// uni.showLoading({
						// 	title: '处理中...',
						// 	mask: true
						// })
						// console.log(res);
						// console.log('获取的图片信息：', JSON.stringify(res.tempFilePaths));return;
						
						// #ifndef H5
						// 上传图片
						this.uploadImg(res.tempFilePaths[0]);
						// #endif
						
						// #ifdef H5
						uni.getImageInfo({
							src: res.tempFilePaths[0],
							success: function(image) {
								console.log('图片信息：',image);
								let canvasWidth = image.width //图片原始长宽
								let canvasHeight = image.height

								let size = canvasWidth
								if (canvasWidth > canvasHeight) {
									size = canvasHeight
								}
								let scale = parseInt(size / 100)

								let img = new Image()
								img.src = image.path
								let canvas = document.createElement('canvas');
								let ctx = canvas.getContext('2d')
								canvas.width = canvasWidth / scale
								canvas.height = canvasHeight / scale
								ctx.drawImage(img, 0, 0, canvasWidth / scale, canvasHeight / scale)
								canvas.toBlob(function(fileSrc) {
									let imgSrc = window.URL.createObjectURL(fileSrc)
									console.log('修改后图片路径：',imgSrc);
									
									// 上传图片
									uni.uploadFile({
										url: config.dev.BASE_URL + 'app/user/info/updateUserInfoImg', //仅为示例，非真实的接口地址
										// filePath: res.tempFilePaths[0],
										filePath: imgSrc,
										name: 'file',
										header: {
											// token: localStorage.getItem("token") || ''
											token: uni.getStorageSync('token') || ''
										},
										formData: {
											id: that.id
										},
										success: (uploadFileRes) => {
											let resp = JSON.parse(uploadFileRes.data);
											console.log(resp);
											if (resp.resultCode === 1) {
												uni.hideLoading()
												uni.showToast({
													title: "头像修改成功",
													icon: "none"
												})
												uni.setStorage({
													key: 'userInfo',
													data: {
														nickName: resp.data.nickName,
														imageUrl: resp.data.imageUrl,
														invitationCode: that.invitationCode,
													}
												});
												// 本地图片（文件地址）地址
												// that.imageUrl = resPath;
												// 网络图片地址
												that.imageUrl = resp.data.imageUrl;
												console.log('新头像路径：',that.imageUrl);
											}
										},
										fail: function(res) {
											uni.hideLoading();
											uni.showToast({
												title: '图片上传失败',
												icon: 'none'
											})
										},
										// complete: function() {
										// 	uni.hideLoading()
										// }
									});
									
								})
							},
							fail() {
								uni.hideLoading()
							}
						})
						// #endif
					}
				});
			},
			
			// #ifndef H5
			// app端 上传图片
			uploadImg: function (imgPath) {
				let that = this, resPath = imgPath;
				uni.showLoading({
					title: '图片处理中...',
					mask: true
				})
				// 获取图片信息
				uni.getImageInfo({
					src: resPath,
					success: function(image) {
						console.log('图片信息：',image);
						
						// 处理图片
						let tempVal = image.width, oW = image.width, oH = image.height, ctxWidth, ctxHeight, scale;
						if (oW > oH) {
							tempVal = oH
						}
						scale = parseInt(tempVal / 250) // (/250：值越大 scale值越小，图片越清晰)
						// console.log(scale);
						ctxWidth = oW / scale // 等比缩小宽度
						ctxHeight = oH / scale
						const ctx = uni.createCanvasContext('myCanvas', that);
						let ctxTime = 10;
						setTimeout(() => {
							ctx.drawImage(resPath, 0, 0, ctxWidth, ctxHeight)
							// console.log('绘图宽：',ctxWidth,'，绘图高：',ctxHeight);
							ctx.draw(false, () => {
								let time = 0;
								// #ifndef MP-WEIXIN
								time = 10;
								// #endif
								// #ifdef MP-WEIXIN
								// time = cTime();
								time = 10;
								// #endif
								setTimeout(() => {
									// 把当前画布指定区域的内容导出生成指定大小的图片，并返回文件路径
									uni.canvasToTempFilePath({
										width: ctxWidth,
										height: ctxHeight,
										destWidth: ctxWidth, //  * that.pixelRatio (*像素比) (*2 ：非必要)，防止模糊
										destHeight: ctxHeight,
										canvasId: 'myCanvas',
										success: (res) => {
											// 隐藏第一个加载框
											uni.hideLoading()
											
											console.log('压缩图片临时地址：', res.tempFilePath);
											// return;
											
											uni.showLoading({
												title: '正在上传图片...',
												mask: true
											})
											let imgSrc = res.tempFilePath;
											
											// 上传图片
											uni.uploadFile({
												url: config.dev.BASE_URL + 'app/user/info/updateUserInfoImg', //仅为示例，非真实的接口地址
												// filePath: res.tempFilePaths[0],
												filePath: imgSrc,
												name: 'file',
												header: {
													// token: localStorage.getItem("token") || ''
													token: uni.getStorageSync('token') || ''
												},
												formData: {
													id: that.id
												},
												success: (uploadFileRes) => {
													let resp = JSON.parse(uploadFileRes.data);
													console.log(resp);
													if (resp.resultCode === 1) {
														uni.hideLoading()
														uni.showToast({
															title: "头像修改成功",
															icon: "none"
														})
														uni.setStorage({
															key: 'userInfo',
															data: {
																nickName: resp.data.nickName,
																imageUrl: resp.data.imageUrl,
																invitationCode: that.invitationCode,
															}
														});
														// 本地图片（文件地址）地址
														// that.imageUrl = resPath;
														// 网络图片地址
														that.imageUrl = resp.data.imageUrl;
														console.log('新头像路径：',that.imageUrl);
													}
												},
												fail: function(res) {
													uni.hideLoading();
													uni.showToast({
														title: '图片上传失败',
														icon: 'none'
													})
												},
												// complete: function() {
												// 	uni.hideLoading()
												// }
											});
										},
										fail: (err) => {
											// 隐藏第一个加载框
											uni.hideLoading();
											console.log(err);
											uni.showToast({
												title: '图片创建失败',
												icon: 'none'
											})
										}
									})
								}, time);
							})
						}, ctxTime);
							
						function cTime() {
							let time = that.maxWidth / 5
							if (time >= 600) {
								return 600
							} else if (time <= 100) {
								return 100
							} else {
								return time
							}
						}
					},
					fail(e) {
						that._err(e)
					}
				});
			},
			_err(src) {
				uni.hideLoading();
				console.log(src);
			},
			// #endif
			
			
			
			_cancel() {
				//触发cancel事件，即在外部，在组件上绑定cancel事件即可，bind:cancel，像绑定tap一样
				this.cost = '';
				this.togglePopup(false);
			},
			_confirm() {
				let that = this;
				console.log(this.cost);
				if (that.cost == '') {
					uni.showToast({
						title: '昵称不能为空',
						icon: "none"
					})
					return;
				}
				let datas = {
					nickName: that.cost
				}
				that.$req.req.updateUserInfoName(datas)
					.then(res => {
						console.log("昵称修改", res)
						if (res.data.data != null) {
							that.setUserName(res.data.data.nickName);
							that.nickName = res.data.data.nickName;
							uni.showToast({
								title: '昵称修改成功',
								icon: "none"
							})
							uni.setStorage({
								key: 'userInfo',
								data: {
									nickName: res.data.data.nickName,
									imageUrl: res.data.data.imageUrl,
									invitationCode: that.invitationCode,
								}
							});
							that.hide9();
						} else {
							uni.showToast({
								title: res.data.resultMsg,
								icon: "none"
							})

						}
					})
				that.cost = '';
				that.modal6 = !that.modal6;
				that.togglePopup(false);
			},
			_input(e) {
				this.cost = e.detail.value;
			},
		}
	}
</script>

<style lang='scss'>
	page {
		background: $page-color-base;
	}

	.container {
		width: 100vw;
	}

	.map-t20 {
		margin-top: 20upx;
	}

	.herder-img,
	.herder-img image {
		width: 62rpx;
		height: 62rpx;
		border-radius: 50%;
	}

	.list-cell {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 20rpx $page-row-spacing;
		position: relative;
		background: #fff;

		&.log-out-btn {
			margin-top: 40upx;

			.cell-tit {
				color: $uni-color-primary;
				text-align: center;
				margin-right: 0;
			}
		}

		&.cell-hover {
			background: #fafafa;
		}

		&.b-b:after {
			left: 30upx;
		}

		&.m-t {
			margin-top: 16upx;
		}

		.cell-more {
			align-self: baseline;
			font-size: $font-lg;
			color: $font-color-light;
			margin-left: 10upx;
		}

		.cell-tit {
			flex: 1;
			min-width: 160rpx;
			max-width: 160rpx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			margin-right: 10upx;
		}

		.cell-tip {
			font-size: $font-base;
			color: $font-color-light;
		}

		switch {
			transform: translateX(16upx) scale(.84);
		}
	}

	.prompt-content {
		width: 100%;
		max-width: 600upx;
		border: 2rpx solid #ccc;
		border-radius: 10rpx;
		box-sizing: bordre-box;
		background: #fff;
	}

	.prompt-title {
		width: 100%;
		padding: 20rpx;
		text-align: center;
		font-size: 40rpx;
		border-bottom: 2rpx solid gray;
	}

	.prompt-input {
		margin: 8%;
		padding: 10rpx 15rpx;
		width: 80%;
		height: 85rpx;
		border: 1px solid #ccc;
		border-radius: 10rpx;
	}

	.prompt-btn-group {
		display: flex;
	}

	.btn-item {
		width: 35%;
		margin-bottom: 20rpx;
		height: 100rpx;
		line-height: 100rpx;
		background-color: white;
		justify-content: space-around;
	}

	.prompt-certain-btn {
		color: white;
		background-color: #4FEBDE;
	}

	.prompt-cancel-btn {
		border: 1px solid #4FEBDE;
	}

	.contentFontColor {
		color: #868686;
	}

	.prompt-text {
		margin-top: 15rpx;
		font-size: 38rpx;
		text-align: center;
	}


	.tui-modal-custom {
		text-align: center
	}

	.tui-prompt-title {
		padding-bottom: 20rpx;
		font-size: 34rpx;
	}

	.tui-input {
		margin: 30rpx 40rpx;
		border-bottom: 1rpx solid #E6E6E6;
		/* padding-bottom: 20rpx; */
		font-size: 32rpx;
	}
	
	.modifyInput {
		display: flex;
		align-items: center;
		
		input, button {
			height: 30px;
		}
		
		input {
			width: auto;
			padding: 0;
			margin: 0;
			padding-left: 10px;
			font-size: 13px;
		}
		
		button {
			width: 60px;
			line-height: 30px;
			padding: 0;
			margin-left: 5px;
			font-size: 12px;
		}
	}
</style>
