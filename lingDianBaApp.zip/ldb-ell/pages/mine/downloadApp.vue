<template>
	<view class="container">
		<div class="logo" :class="platform == 'android' ? 'a_logo' : ''"></div>
		<text>立即扫码关注公众号&emsp;更多赛事尽在零点吧</text>
		<image class="QRcode" :class="platform == 'android' ? 'a_qrcode' : ''" :src="QRcodeSrc" mode=""></image>
		<button v-if="platform == 'ios'" @tap="downloadIpa(0)">iphone版 下载</button>
		<button v-if="platform == 'android'" @tap="downloadApk(1)">Android版 下载</button>
		
		<!-- ios安装使用方法 -->
		<view v-if="platform == 'ios'">
			<view class="prompt">ios安装使用方法</view>
			<view class="install">
				<scroll-view scroll-x="true" show-scrollbar="true">
					<view class="img"><image src="../../static/downloadApp/1.png" mode=""></image></view>
					<view class="img"><image src="../../static/downloadApp/2.png" mode=""></image></view>
					<view class="img"><image src="../../static/downloadApp/3.png" mode=""></image></view>
					<view class="img"><image src="../../static/downloadApp/4.png" mode=""></image></view>
				</scroll-view>
			</view>
		</view>
		
		<view class="back" :class="platform == 'android' ? 'a_back' : ''" @tap="backBtn">进入 H5 网页版</view>
	</view>
</template>

<script>
	let that;
	export default {
		data() {
			return {
				QRcodeSrc: '../../static/downloadApp/gzh.png',
				shareUserId: 0, // 分享用户id
				iosSrc: 'https://apps.apple.com/us/app',
				// 'https://apps.apple.com/us/app/APP的包名/id+ID号?l=zh&ls=1' 	ios路径
				
				allowDownload: true, // 是否允许点击下载
			};
		},
		onLoad(option) {
			that = this;
			// ES6的Object.keys()方法，返回值是对象中属性名组成的数组
			if (Object.keys(option).length > 0) {
				this.shareUserId = JSON.parse(option.shareUserId);
				// console.log(this.shareUserId);
				
				// 记录用户扫描二维码
				this.recordScanQRCode();
			}
		},
		methods: {
			// 记录用户扫描二维码
			recordScanQRCode() {
				this.$req.reqc.scanCode({
					shareUserId: that.shareUserId
				})
				.then( res => {
					// console.log(res);
				})
			},
			
			// 下载ipa
			downloadIpa: function () {
				// #ifdef H5
				window.open(this.iosSrc);
				// window.location.href = this.iosSrc;
				// #endif
				
				// #ifndef H5
				plus.runtime.openURL(this.iosSrc)
				// #endif
			},
			// 下载apk
			downloadApk: function (type) {
				if(!that.allowDownload) return;
				that.allowDownload = false;
				
				// 记录用户分享下载链接日志
				this.$req.reqc.recordDownload({
					shareUserId: that.shareUserId,
					downloadType: type // 下载类型：苹果:'0',安卓：'1'
				})
				.then( res => {
					let downLoadUrl = res.data.data.downLoadUrl;
					
					// #ifdef H5
					// 文件/图片 下载方法 动态创建A链接，添加download属性和href属性，并触发点击事件
					let oA = document.createElement("a");
					oA.download = 'apk';// 设置下载的文件名
					oA.href = downLoadUrl;
					// document.body.appendChild(oA);
					oA.click();
					oA.remove(); // 下载之后把创建的元素删除
					// #endif
					
					let timer = setTimeout(() => {
						that.allowDownload = true; // 允许点击下载按钮
					}, 2000);
				})
				.catch( err => {
					that.allowDownload = true; // 允许点击下载按钮
					console.log(err);
					uni.showToast({
						icon: 'none',
						title: '下载失败，请稍后再试...',
						duration: 1500
					})
				})
			},
			
			// 返回
			backBtn: function() {
				uni.navigateBack();
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background: $page-color-base;
	}
	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		width: 100vw;
		height: 100vh;
		background-image: url(../../static/downloadApp/bg.png);
		background-size: cover;
		color: #FFFFFF;
		
		uni-image {
			width: 0;
			height: 0;
		}
		
		.logo {
			width: 436rpx;
			min-height: 136rpx;
			margin: 100rpx 0 80rpx 0;
			background-image: url(../../static/downloadApp/logo.png);
			background-size: cover;
		}
		.a_logo {
			margin: 190rpx 0 102rpx 0;
		}
		
		text {
			font-size: 24rpx;
		}
		
		.QRcode {
			width: 180rpx;
			min-height: 180rpx;
			display: block;
			margin: 40rpx 0;
		}
		.a_qrcode {
			margin: 56rpx 0 80rpx 0;
		}
		
		button {
			// width: 250rpx;
			min-height: 66rpx;
			max-height: 66rpx;
			line-height: 62rpx;
			border-radius: 30rpx;
			font-size: 15px;
			color: #FFFFFF;
			border: 1px solid #FFFFFF;
			background-color: transparent;
			
			&:active {
				color: #333333;
				border: 1px solid #333333;
				background-color: #FFFFFF;
			}
		}
		
		.prompt {
			font-size: 13px;
			line-height: 40rpx;
			text-align: center;
			margin-top: 40rpx;
		}
		.install {
			width: 600rpx;
			height: 440rpx;
			box-sizing: border-box;
			overflow: hidden;
			/* #内部组件不换行 */
			white-space: nowrap;
			
			.img {
				/* #行内块元素 */
				display: inline-block;
				width: 248rpx;
				height: 440rpx;
				margin-right: 10rpx;
				
				image {
					width: 100%;
					height: 100%;
				}
			}
		}
		
		.back {
			margin-top: 40rpx;
			font-size: 15px;
			
			&::after {
				content: '';
				background-image: url(../../static/downloadApp/arrows.png);
				background-size: cover;
				background-repeat: no-repeat;
				/* background-color: red; */
				/* background-position: center center; */
				width: 22px;
				height: 13px;
				display: inline-block;
				margin-left: 20rpx;
			}
		}
		.a_back {
			margin-top: 80rpx;
		}
	}
</style>
