<template>
	<view class="container">
		<!-- 顶部选项卡 -->
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<!-- nav-item -->
			<view 
			 v-for="(item,index) in tabList" :key="item.name+index"
				class="uni-tab-item"
				:class="{current: index === tabCurrentIndex}"
				:id="'tab'+index"
				@click="changeTab(index)"
			>
		<!-- 	{{item.name}} -->
			<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{item.name}}</text>
			<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
		</scroll-view>
		<view class="addTag" @tap="openCustom"></view>
		
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="74" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<!-- 内容部分 -->
			<swiper 
				id="swiper"
				class="swiper-box" 
				:duration="300" 
				:current="tabCurrentIndex" 
				@change="changeTab"
			>
				<swiper-item v-for="(tabItem, cIndex) in tabList" :key="cIndex">
					<view class="calendar">
						<!-- 日历 -->
						<time-selector ref="timeSelector" @selectTime="selectTimeEvent" :startDate="startDate" :endDate="endDate"></time-selector>
						<view class="optDate" @tap="openCalendar"></view>
					</view>
					<scroll-view 
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<view class="list">
							<block v-for="(item, index) in tabItem.data" :key="index">
								
								<!-- 广告位 -->
								<block v-if="AdList.length >= 1 && index  == (AdList[0].advertisementSort > tabItem.data.length ? tabItem.data.length-1 : AdList[0].advertisementSort) && $store.state.ADstatus.lxAD1">
									<bwAdvertising :AdName="'lxAD1'" :AdList="AdList[0]"></bwAdvertising>
								</block>
								<block v-if="AdList.length >= 2 && index  == (AdList[1].advertisementSort > tabItem.data.length ? tabItem.data.length-1 : AdList[1].advertisementSort) && $store.state.ADstatus.lxAD2">
									<bwAdvertising :AdName="'lxAD2'" :AdList="AdList[1]"></bwAdvertising>
								</block>
								
								<view class="list-item" @tap="playVideo(item.matchId)">
									<image class="eventLogo" :src="item.eventLogo" mode=""></image>
									<view class="time">{{item.matchBeginTime}}</view>
									<view class="content" v-html="item.CombinationTitle"></view>
								</view>
							</block>
						</view>
						<!-- 上滑加载更多组件 -->
						<mix-load-more v-if="networkStatus" :status="tabItem.loadMoreStatus"></mix-load-more>
						
						<netWorkErr
						:height="(windowHeight - StatusBar - 44 - 37 - 50 - 44)"
						:newWorlErrMsg="newWorlErrMsg"
						:networkStatus="networkStatus"
						@netWorkButTap="netButClick"
						></netWorkErr>
						
					</scroll-view>
				</swiper-item>
			</swiper>
		</mix-pulldown-refresh>
		
	</view>
</template>
 
<script>
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	import timeSelector from '@/components/xiujun-time-selector/index.vue';
	import {dateData,timeStamp,getSevenDate} from '@/components/xiujun-time-selector/date.js'
	
	import netWorkErr from '../component/netWorkErr'
	
	let that, windowWidth = 0, scrollTimer = false, tabBar;
	export default {
		components: {
			mixPulldownRefresh,
			mixLoadMore,
			timeSelector,
			netWorkErr
		},
		data() {
			return {
				newWorlErrMsg:'网络链接中断,请检查网络链接...',
				networkStatus: true,
				tabCurrentIndex: 0, // 当前选项卡索引
				scrollLeft: 0, // 顶部选项卡左滑距离
				enableScroll: true,
				total:100,
				tabList: [
					{id:'', name:'全部', type:'5', sort: 0},
				],
				
				tabListNo:[],
				tabListAll:[],
				
				startDate: '',
				endDate: '',
				dateList: [], // 日期列表
				
				AdList: [], // 广告列表
			}
		},
		onLoad() {
			that = this;
			// 获取屏幕宽度
			windowWidth = uni.getSystemInfoSync().windowWidth;
			
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'lx'})
			.then( res => {
				that.AdList = res
				console.log('录像广告：',that.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
			
			
			// uni.removeStorage({
			//     key: 'lxTabList',
			//     success: function (res) {
			//         console.log('success');
			//     }
			// });
			uni.getStorage({
			    key: 'lxTabList',
			    success: function (res) {
							// 获取日历的初始与结束日期
							that.getStartAndEnd();
							// 初始化分类
							that.loadtabList();
			    },
				fail:function(res){
					that.getNavigationList()
					.then( res => {
						// 获取日历的初始与结束日期
						that.getStartAndEnd();
						// 初始化分类
						that.loadtabList();
					})
				}
			});
			// this.getNavigationList()
			// .then( res => {
			// 	// 获取日历的初始与结束日期
			// 	this.getStartAndEnd();
			// 	// 初始化分类
			// 	this.loadtabList();
			// })
			
			uni.$on('setLxEventList',(res)=>{
				that.tabList = res.selTagArr;
				that.tabListNo = res.unSelTagArr;
				// console.log(res,that.tabList,that.tabListNo);
				if(that.tabCurrentIndex > that.tabList.length-1){
					that.tabCurrentIndex = that.tabList.length-1;
				}
				uni.setStorage({
				    key: 'lxTabList',
				    data: {
						rd:that.tabListAll,
						rdarr:that.tabList,
						nordarr:that.tabListNo,
					},
				    success: function () {
				        console.log('缓存数据success');
				    }
				});
			})
			
			
			
			// 清除赛事标签本地缓存
			// uni.removeStorage({ 
			// 	key: 'eventList',
			// 	success: function (res) {
			// 		console.log('数据清除成功');
			// 	}
			// });
			/* uni.getStorage({
				key: 'eventList',
				success: function(res) {
					// console.log("有数据", res.data);
					that.tabList = res.data;
					that.loadtabList();
				},
				fail: function(res) {
					console.log("无数据，发起请求");
					that.$req.req.queryAllEventList({
						"limit": 120,
						"offset": 1
					})
					.then(res => {
						console.log("赛事专栏",res.data.data);
						let list = res.data.data.list;
						let Autoincrement = 2; // 初始化标签顺序
						list.forEach((item, index) => {
							// 判断是否为推荐标签
							if (item.isRecommend === 0) {
								item.isFocus = true;
								Autoincrement++;
								item.sortNum = Autoincrement;
							} else {
								item.isFocus = false;
								item.sortNum = null;
							}
						})
						let arr = [
							{id:'',name:'全部',type:'5',isFocus:true,sortNum:1},
							{id:'',name:'热门',type:'3',isFocus:true,sortNum:0},
							{id:'',name:'完赛',type:'4',isFocus:true,sortNum:2},
							...list
						]
						uni.setStorage({
							key: 'eventList',
							data: arr,
						});
						console.log('--------------获取全部 标签数据 成功--------------');
						that.tabList = arr;
						that.loadtabList();
					}).catch(err => {
						console.log("请求返回错误",err)
					})
				}
			});
			*/
			
		},
		methods: {
			netButClick(){
				if(that.tabListAll.length < 2){
					that.getNavigationList()
					.then( res => {
						that.loadtabList();
					})
				}else{
					that.loadNewsList('refresh');
				}
			},
			
			// (点击)选择时间
			selectTimeEvent(item) {
				let reqDate = item.reqDate || '';
				console.log("你选中的时间：", reqDate);
				
				// 修改日期 并发起请求
				let tabItem = this.tabList[this.tabCurrentIndex];
				// 点击相同日期时，清空日期记录 查询全部数据
				if (tabItem.initTime == reqDate) {
					// uni.showToast({
					// 	icon: 'none',
					// 	title: '当前已是目标日期'
					// })
					
					// 相同日期，则取消选中日期 查询全部数据
					tabItem.initTime = '';
					this.loadNewsList('refresh');
				}
				else {
					// 当选中日期不等于''时，更新选中日期的位置
					if (reqDate != '') {
						this.UpdSelectDateLocation(reqDate);
					}
					
					tabItem.initTime = reqDate;
					// console.log(this.tabList[this.tabCurrentIndex]);
					this.loadNewsList('refresh');
				}
			},
			
			// 获取日历的初始与结束日期 (初始化)
			getStartAndEnd() {
				// 获取当前年月日
				let date = new Date(),
					currentYear = date.getFullYear(),
					currentMonth = date.getMonth()+1 < 10 ? ('0'+(date.getMonth()+1)) : (date.getMonth()+1),
					currentDay = date.getDate() < 10 ? ('0'+date.getDate()) : date.getDate(),
					currentDate = currentYear+'-'+currentMonth+'-'+currentDay
				console.log('当前日期：',currentDate);
				
				// 获取日历的初始与结束日期
				let datas = {
					// "date": currentDate, // 选中的月份,其他月份默认日期为01
					"date": '2020-04-01', // 选中的月份,其他月份默认日期为01
					"matchId": 0,
					"sourceType": 1, // 类型 0直播 1录像
					"viedoType": 0,
				}
				console.log('查询日期区间参数：',datas);
				uni.showLoading({
					title: '请稍后...'
				})
				this.$req.reqc.queryMatchByVideoDetail(datas)
				.then( res => {
					uni.hideLoading();
					let list = res.data.data
					console.log('日期区间列表：', res.data);
					
					if (list.length) {
						// 录像只能看当天和以前的数据
						that.startDate = list[0].date;
						// 第一条录像的时间
						// that.startDate = list[0].beginDate;
					}
					else {
						that.startDate = currentYear+'-'+currentMonth+'-01';
						// that.startDate = '2020-04-03';
					}
					// endDate = list[list.length-1].date;
					that.endDate = currentDate;
					
					console.log('-------------> 开始日期：',that.startDate,' 结束日期：',that.endDate);
					
					// 获取两个日期之间所有日期的方法
					that.getDateList();
					
				})
				.catch( err => {
					uni.hideLoading();
					console.log(err);
				})
			},
			
			// 获取两个日期之间所有日期的方法
			getDateList: function () {
				function getDate(datestr) {
					var temp = datestr.split("-");
					var date = new Date(temp[0], temp[1], temp[2]);
					return date;
				}
				
				var start = this.startDate; // '2012-3-25' / '2020-02-23'
				var end = this.endDate; // '2012-4-3' / '2020-03-28'
				var startTime = getDate(start);
				var endTime = getDate(end);
				// console.log(startTime,endTime);
				while ((endTime.getTime() - startTime.getTime()) >= 0) {
					var year = startTime.getFullYear();
					var month = startTime.getMonth().toString().length == 1 ? "0" + startTime.getMonth().toString() : startTime.getMonth();
					var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
					// alert(year+"-"+month+"-"+day);
					this.dateList.push(year + '-' + month + '-' + day)
				
					// 修改开始日期，setDate() 方法用于设置一个月的某一天
					startTime.setDate(startTime.getDate() + 1);
				}
				console.log('日期区间：',this.dateList);
			},
			
			// 更新选中日期的位置
			UpdSelectDateLocation(selDate) {
				let index = this.dateList.indexOf(selDate);
				// console.log('选中日期下标：',index);
				let temp = [6,5,4,3,2,1,0]; // 日期排序顺序
				let indexNum = 4, startIndex = 0;
				let val = this.dateList.length-1 - index;
				if (val <= 3) {
					indexNum = val;
				}
				else if ((val + 3) <= (this.dateList.length-1)) {
					indexNum = 3;
				}
				if (indexNum > 3) {
					startIndex = index;
				} else {
					startIndex = temp[indexNum];
				}
				console.log('当前日期应处位置：',startIndex,' 日期：',this.dateList[index]);
				
				// 获取日期列表
				let arr = getSevenDate(this.dateList[index], startIndex);
				
				// 重新获取日期tab数据
				this.$refs.timeSelector[this.tabCurrentIndex].childMethod(arr, startIndex);
			},
			
			
			// 1、获取导航
			getNavigationList(){
				return new Promise( (res,rel) => {
					this.$req.req.queryNavigationList({
						navigationKey:'app_navigation_videotape'
					})
					.then( resp => {
						console.log("录像导航",resp.data.data)
						// let rd = resp.data.data;
						// that.tabListAll = rd;
						// let rdarr = rd.filter(item => item.sort < 20),
						// 	nordarr = rd.filter(item => item.sort >= 20);
						// // that.tabList = rdarr;
						// that.tabList = [...that.tabList, ...rdarr];
						// that.tabListNo = nordarr;
						// res();
						
						let rd = [{id:'', name:'全部', type:'5', sort: 0},  ...resp.data.data] ;
						let rdarr = rd.filter(item => item.sort < 20),
							nordarr = rd.filter(item => item.sort >= 20);
						uni.setStorage({
						    key: 'lxTabList',
						    data: {
									rd:rd,
									rdarr:rdarr,
									nordarr:nordarr,
								},
						    success: function () {
						        console.log('缓存数据success');
										res();
						    }
						});
						
						
					})
				})
			},
			
			// 2、初始化分类
			loadtabList(){
				let that = this;
				
				// 获取当前日期(标签初始时间)
				let myDate = new Date(),
					curTime = myDate.getFullYear() + '-' + (myDate.getMonth()+1 >= 10 ? myDate.getMonth()+1 : '0'+(myDate.getMonth()+1)) + '-' + (myDate.getDate() >= 10 ? myDate.getDate() : '0'+(myDate.getDate()));
				uni.getStorage({
				    key: 'lxTabList',
				    success: function (res) {
								that.tabListAll =res.data.rd;
								that.tabList = res.data.rdarr;
								that.tabListNo = res.data.nordarr;
								let tabarr = that.tabList;
								tabarr.forEach(item=>{
									item.data = [];
									// item.initTime = curTime; // 赋值 初始时间(今天)
									item.initTime = ''; // 默认显示全部数据，点击日期则查询对应日期数据
									item.loadMoreStatus = 0;  //加载更多 0加载前，1加载中，2没有更多了
									item.refreshing = 0;
									item.offset = 1;
									item.liveRefreshing = false;
									// that.tabList.push(item)
								})
								that.tabList = tabarr;
								that.loadNewsList('add');
				    }
				});
			},
			
			// 3、获取数据（录像）列表
			loadNewsList(type){
				let tabItem = this.tabList[this.tabCurrentIndex];
				// console.log("选中",tabItem)
				
				//type add 加载更多 refresh下拉刷新
				if(type === 'add'){
					if(tabItem.loadMoreStatus === 2){
						return;
					}
					if(tabItem.data&&tabItem.data.length > 0){
						tabItem.offset++;
					}
					tabItem.loadMoreStatus = 1;
				}
				
				// #ifdef APP-PLUS
				else if(type === 'refresh'){
					tabItem.refreshing = true;
				}
				// #endif
				
				if(type === 'refresh'){
					tabItem.offset = 1; // 刷新前重置页码
					console.log('---------------------刷新---------------------');
				}
				
				let datas = {
					"date": tabItem.initTime,
					"id": tabItem.id||'',
					"limit": 20,
					"offset": tabItem.offset,
					"type": tabItem.type
				}
				console.log('请求参数：', datas);
				this.$req.reqc.queryMatchListByVideo(datas)
				.then( res => {
					// console.log(res)
					if(type === 'refresh'){
						tabItem.data = []; //刷新前清空数组
						// tabItem.offset = 1;
					}
					that.networkStatus = true;
					// console.log(res.data.data);
					let list = res.data.data&&res.data.data.list || [];
					this.total = res.data.data.total;
					list.forEach((item,index) => {
						let items = {
							matchId: item.matchId, // 录像Id
							eventTypeId: item.eventTypeId,
							eventId: item.eventId,
							matchTitle: item.matchTitle,
							homeTeamName: item.homeTeamName,
							homeTeamId: item.homeTeamId,
							guestTeamName: item.guestTeamName,
							guestTeamId: item.guestTeamId,
							eventLogo: item.eventLogo,
							// eventLogo:'https://images.weserv.nl/?url='+item.eventLogo,
							matchBeginTime: that.getCovTime(item.matchBeginTime),
						}
						items.CombinationTitle = that.getCombinationTitle(item),
							
						tabItem.data.push(items);
					})
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;
					}
					// （上滑加载/下拉刷新）处理状态
					tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2: 0;
					
					// this.tabList[this.tabCurrentIndex] = tabItem;
					// console.log("全部数据",this.tabList)
					console.log("全部数据",tabItem);
					
					this.$forceUpdate();
				}).catch(err => {
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;						
					}
					// 上滑加载、下拉刷新 处理状态 (返回数据长度小于零/数据长度与总数据量相等 → '没有更多数据了')
					if(type === 'add' || type === 'refresh'){
						tabItem.loadMoreStatus = tabItem.isLastPage ? 2 : 0;
					}
					uni.hideLoading();
					console.log("网络中断")
					that.networkStatus = false;
					this.$forceUpdate();
				})
			
			},
			
			//下拉刷新
			onPulldownReresh(){
				this.loadNewsList('refresh');
			},
			//上滑加载
			loadMore(){
				this.loadNewsList('add');
			},
			
			// 获取组合标题
			getCombinationTitle: function (item) {
				let date, title, topLine, bottomLine;
				// 日期
				let time = item.matchBeginTime.trim().split(/\s+|:|-/g);
				date = time[1] + '-' + time[2];
				if (item.homeTeamName != '' && item.homeTeamName != null && item.guestTeamName != '' && item.guestTeamName != null) {
					// 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题
					if (item.eventTypeName == '' || item.eventTypeName == null) {
						title = item.specialName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle
					} else if (item.eventTypeName == '其他') {
						title = item.eventName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle
					} else {
						title = item.eventTypeName + item.matchTitle
					}
					// topLine = "<div class='typeName'>"+ date + '&emsp;' + title +"</div>"
					topLine = "<div class='typeName'>"+ title +"</div>"
					bottomLine = "<div class='matchTitle'>"+ item.homeTeamName + ' - ' + item.guestTeamName +"</div>"
				}
				else {
					title = (item.eventTypeName == '' || item.eventTypeName == null) ? item.specialName : (item.eventTypeName == '其他' ? item.eventName : item.eventTypeName)
					topLine = "<div class='typeName'>"+ title +"</div>"
					bottomLine = "<div class='matchTitle'>"+ item.matchTitle +"</div>"
				}
				// js空格符：'\xa0'
				return topLine + bottomLine
			},
			// 转换比赛时间
			getCovTime: function (times) {
				let time = times.trim().split(/\s+|:|-/g);
				return time[1] + '-' + time[2];
			},
			
			// 进入录像详情页
			// 判断对象是否存在某个字段：obj.hasOwnProperty("key")
			playVideo: function (matchId) {
				// console.log(matchId);
				
				
				// #ifdef APP-PLUS
				this.uniSkip.navigateTo({
					url: '/pages/index/player',
					data: {
						matchId:matchId,
						tabIndex:3
					}
				});
				// #endif					
				// #ifndef APP-PLUS
				uni.navigateTo({
					// url: 'lxDetail?matchId='+ matchId +'&viedoType='+ 0
					url: '/pages/index/player?matchId='+ matchId +'&tabIndex='+ 3
				});
				// #endif
				
				
				
			},
			
			
			// (日历页)日期选择
			openCalendar: function () {
				// 获取当前时间、半年前的时间
				// let dateObj = this.getDateTime()
				
				// sourceType 类型 0直播 1录像
				let sourceType = 1,
					startDate = that.startDate,
					endDate = that.endDate;
				let dateObj = {startDate, endDate, sourceType}
				uni.navigateTo({
					url: '/pages/index/eventCalendar?item='+ encodeURIComponent(JSON.stringify(dateObj))
				})
			},
			// 获取（日历页）选中日期 返回的日期数据列表
			RefreshMatchData(data, index) {
				this.tabList[this.tabCurrentIndex].initTime = data[index].reqDate;
				console.log('录像查询日期：',this.tabList[this.tabCurrentIndex].initTime);
				// 重新获取日期tab数据（选中日期前七天）
				this.$refs.timeSelector[this.tabCurrentIndex].childMethod(data, index);
				// 刷新页面数据
				this.loadNewsList('refresh');
			},
			
			// 获取当前时间、半年前的时间
			getDateTime: function () {
				let date = new Date(),
					curDate = date.getTime(); // 先获取当前时间戳
				
				let year = date.getFullYear(),
					month = date.getMonth()+1 < 10 ? ('0'+(date.getMonth()+1)) : (date.getMonth()+1),
					day = date.getDate() < 10 ? ('0'+date.getDate()) : date.getDate();
				let startDate = year + '-' + month + '-' + day;
				
				// 将半年的时间单位换算成毫秒
				let halfYear = 365 / 2 * 24 * 3600 * 1000,
					pastResult = curDate - halfYear;  // 半年前的时间戳（毫秒单位）
				// 日期函数，定义起点为半年前
				let pastDate = new Date(pastResult),
					pastYear = pastDate.getFullYear(),
					pastMonth = pastDate.getMonth()+1 < 10 ? ('0'+(pastDate.getMonth()+1)) : (pastDate.getMonth()+1),
					pastDay = pastDate.getDate() < 10 ? ('0'+pastDate.getDate()) : pastDate.getDate();
				let endDate = pastYear + '-' + pastMonth + '-' + pastDay;
				
				return {startDate, endDate};
			},
			
			
			// 自定义标签页
			openCustom: function () {
				uni.navigateTo({
					// url: '/pages/index/customTag'
					// url: '/pages/index/newCustomTag?pageType=2&data='+JSON.stringify(that.tabList)+'&nodata='+JSON.stringify(that.tabListNo)
					url: '/pages/index/newCustomTag?pageType=2&data='+
						encodeURIComponent(JSON.stringify(this.tabList)) + 
						'&nodata=' + encodeURIComponent(JSON.stringify(this.tabListNo))
				})
			},
			
			//tab切换
			async changeTab(e){
				
				if(scrollTimer){
					//多次切换只执行最后一次
					clearTimeout(scrollTimer);
					scrollTimer = false;
				}
				let index = e;
				//e=number为点击切换，e=object为swiper滑动切换
				if(typeof e === 'object'){
					index = e.detail.current
				}
				if(typeof tabBar !== 'object'){
					tabBar = await this.getElSize("nav-bar")
				}
				//计算宽度相关
				let tabListcrollLeft = tabBar.scrollLeft;
				let width = 0; 
				let nowWidth = 0;
				//获取可滑动总宽度
				for (let i = 0; i <= index; i++) {
					let result = await this.getElSize('tab' + i);
					width += result.width;
					if(i === index){
						nowWidth = result.width;
					}
				}
				if(typeof e === 'number'){
					//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
					this.tabCurrentIndex = index; 
				}
				//延迟300ms,等待swiper动画结束再修改tabbar
				scrollTimer = setTimeout(()=>{
					if (width - nowWidth/2 > windowWidth / 2) {
						//如果当前项越过中心点，将其放在屏幕中心
						this.scrollLeft = width - nowWidth/2 - windowWidth / 2;
					}else{
						this.scrollLeft = 0;
					}
					if(typeof e === 'object'){
						this.tabCurrentIndex = index; 
					}
					this.tabCurrentIndex = index; 
					
					
					//第一次切换tab，动画结束后需要加载数据
					let tabItem = this.tabList[this.tabCurrentIndex];
					if(this.tabCurrentIndex !== 0 && tabItem.loaded !== true){
						this.loadNewsList('add');
						tabItem.loaded = true;
					}
					// 页面切换时显示全部数据
					if (tabItem.initTime != "") {
						// 取消 时间选择组件 的选中日期
						this.$refs.timeSelector[this.tabCurrentIndex].UncheckDate();
						// 取消选中日期 查询全部数据
						tabItem.initTime = '';
						this.loadNewsList('refresh');
					}
					
				}, 300)
				
			},
			//获得元素的size
			getElSize(id) { 
				return new Promise((res, rej) => {
					let el = uni.createSelectorQuery().select('#' + id);
					el.fields({
						size: true,
						scrollOffset: true,
						rect: true
					}, (data) => {
						res(data);
					}).exec();
				});
			},
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			},
		}
	}
</script>

<style lang='scss' scoped>
	
	page, .container{
		background-color: #F7F7F7;
		height: 100%;
		overflow: hidden;
		width: 100vw;
		/* background-color: red; */
	}
	
	
	/* 可滚动窗体高度（swiper外层刷新组件高度），100vh(相对于视窗的高度)  */
	/* calc(100vh - 38px - 50px)：100vh(整个浏览器窗口高度) - 38px(顶部标签滑动栏高度) - 50px(底部tabBar栏高度(固定)) 的大小 */
	/* .panel-content {
		height: calc(100vh - 38px - 50px) !important;
		max-height: calc(100vh - 38px - 50px) !important;
		background-color: yellow;
	} */
	
	.swiper-box{
		/* height: 100%; */
		/* #ifdef H5 */
		height: 100%;
		/* height: calc(100% - 74rpx - 50px - 44px); */
		/* #endif */
		/* #ifndef H5 */
		height: calc(100vh - var(--status-bar-height));
		/* #endif */
		
		/* background-color: blue; */
		/* padding-bottom: 60rpx; */
	}
	
	.calendar {
		height: 80rpx;
		position: relative;
		
		/* 赛事日历 */
		.optDate {
			position: absolute;
			top: 50%;
			transform: translateY(-50%);
			right: 0;
			z-index: 100;
			width: 80rpx;
			height: 80rpx;
			/* background-color: pink; */
			overflow: hidden;
			
			background-image: url(../../static/images/index_calendar.png);
			/* background-size: cover; */
			background-size: 43rpx 40rpx;
			background-position:center center;
			background-repeat: no-repeat;
		}
	}
	
	
	.panel-scroll-box {
		/* height: calc(100% - 80rpx); */
		/* #ifdef H5 */
		height: calc(100% - 74rpx - var(--status-bar-height));
		/* #endif */
		/* #ifndef H5 */
		height: calc(100vh - 74rpx - 80rpx);
		/* #endif */
		background-color: #FFFFFF;
		
		/* background-color: pink; */
	}
	.list {
		display: flex;
		flex-direction: column;
		width: 100%;
		/* padding: 0 20rpx; */
	}
	/* 列表项 */
	.list-item {
		display: flex;
		align-items: center;
		/* height: 88rpx; */
		height: 100rpx;
		border-bottom: 1px solid #E1E1E1;
		overflow: hidden;
		
		padding-left: 20rpx;
		
		.eventLogo {
			min-width: 60rpx;
			max-width: 60rpx;
			height: 60rpx;
			/*min-width: 16px;
			height: 16px; */
			display: block;
			/* margin-right: 28rpx; */
		}
		
		.time {
			min-width: 90rpx;
			max-width: 90rpx;
			text-align: center;
			font-size: 12px;
			color: #999999;
		}
		
		/deep/.content {
			height: 100%;
			display: flex;
			flex-direction: column;
			justify-content: center;
			
			.typeName {
				height: 30rpx;
				line-height: 30rpx;
				font-size: 12px;
				color: #999999;
			}
			.matchTitle {
				height: 44rpx;
				line-height: 44rpx;
				font-size: 16px;
				font-family: PingFang SC;
				font-weight: 500;
			}
			.typeName, .matchTitle {
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				/* 文本内容超出1行 显示省略符 */
				-webkit-line-clamp: 1;
				-webkit-box-orient: vertical;
			}
		}
		/* .content:before{
			content: '';
			background: #F5F5F5 url(../../static/sport/basketball.png) no-repeat;
			background-size: cover;
			width: 16px;
			height: 16px;
			display: inline-block;
			margin-right: 28rpx;
			vertical-align: middle;
			margin-top: -2px;
		} */
	}
	
	
	.nav-bar{
		/* 标签栏顶部固定 → 防止 iPhone端 出现下拉移位的问题 */
		position: fixed;
		top: 0;
		
		position: relative;
		z-index: 10;
		width: 100%;
		height: 74upx;
		box-sizing: border-box;
		flex-direction: row;
		white-space: nowrap;
		background-color: #FFFFFF;
		border-bottom: 1px solid #F2F2F2;
		
		.uni-tab-item {
			display: inline-block;
			flex-wrap: nowrap;
			padding-left: 14.5px;
			padding-right: 14.5px;
			position: relative;
		}
		.uni-tab-item:last-child{
			margin-right: 80upx;
		}
		/* 滚动tab 标签 */
		.uni-tab-item-title {
			color: #999999;
			font-size: 12px;
			height: 38px;
			line-height: 38px;
			flex-wrap: nowrap;
			white-space: nowrap;
		}
		.uni-tab-item-title-active {
			color: #000000;
		}
		/* 滚动tab 底部选中条 */
		.uni-tab-item-border {
			position: absolute;
			top: 85%;
			left: 50%;
			transform: translate(-50%,-50%);
		}
		.uni-tab-item-border-active {
			width: 14px;
			height: 2px;
			background-color: #000000;
		}
	}
	
	.addTag {
		position: absolute;
		top: 0;
		right: 0;
		width: 80rpx;
		height: 72rpx;
		background: linear-gradient(to right, rgba(255,255,255,0), rgba(255,255,255,1));
		background-size: cover;
		background-image: url(../../static/images/home_add.png);
		z-index: 11;
	}
</style>
