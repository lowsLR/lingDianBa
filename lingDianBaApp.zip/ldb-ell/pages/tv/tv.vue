<template>
	<view class="container">
		<!-- 顶部选项卡 -->
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<!-- nav-item -->
			<view
				v-for="(item, index) in tabBars"
				:key="item.typeName"
				class="uni-tab-item"
				:class="{ current: index === tabCurrentIndex }"
				:id="'tab' + index"
				@click="changeTab(index)"
			>
				<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{ item.typeName }}</text>
				<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
		</scroll-view>
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="74" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<netWorkErr
				:height="windowHeight - StatusBar - 44 - 37 - 50 - 44"
				:newWorlErrMsg="newWorlErrMsg"
				:networkStatus="networkStatus"
				@netWorkButTap="netButClick"
			></netWorkErr>

			<!-- 内容部分 -->
			<swiper v-if="networkStatus" id="swiper" class="swiper-box" :duration="300" :current="tabCurrentIndex" @change="changeTab" @animationfinish="animationfinish">
				<swiper-item v-for="(tabItem, index) in tabBars" :key="index">
					<scroll-view class="panel-scroll-box" :scroll-y="enableScroll" @scrolltolower="loadMore">
						<view class="list" v-if="tabCurrentIndex !== 1">
							<view class="list-item" v-for="(cItem, cIndex) in tabItem.data" :key="cIndex" @tap="playTv(cItem.id, cItem.tvName)">
								<!-- 'https://images.weserv.nl/?url='+cItem.imgLog -->
								<image class="imgLog" :src="cItem.imgLog != null && cItem.imgLog != '' ? cItem.imgLog : '../../static/default_tv.png'" mode=""></image>
								{{ cItem.tvName }}
							</view>
						</view>
						<view class="list localTv" v-if="tabCurrentIndex === 1">
							<view class="list-item" v-for="(tItem, tIndex) in tvProvinceList" :key="tIndex" @tap="playTv(tItem.id, tItem.provincialArea)">
								{{ tItem.provincialArea }}
							</view>
						</view>
						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabItem.loadMoreStatus" v-if="tabCurrentIndex !== 1"></mix-load-more> -->
						<mix-load-more :status="2" v-if="tabCurrentIndex !== 1 && networkStatus"></mix-load-more>
					</scroll-view>
				</swiper-item>
			</swiper>
		</mix-pulldown-refresh>
	</view>
</template>

<script>
import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
import mixLoadMore from '@/components/mix-load-more/mix-load-more';
import netWorkErr from '../component/netWorkErr';
let that,
	windowWidth = 0,
	scrollTimer = false,
	tabBar;
export default {
	components: {
		mixPulldownRefresh,
		mixLoadMore,
		netWorkErr
	},
	data() {
		return {
			newWorlErrMsg: '网络链接中断,请检查网络链接...',
			networkStatus: true,
			tabCurrentIndex: 0, //当前选项卡索引
			scrollLeft: 0, //顶部选项卡左滑距离
			enableScroll: true,
			tvProvinceList: [], // 地方台数据
			tabBars: [],
			total: 100, // 可查看数据总条数
			tabList: []
		};
	},
	onLoad() {
		that = this;
		// 获取屏幕宽度
		windowWidth = uni.getSystemInfoSync().windowWidth;
		console.log('this.appPlatform' + that.appPlatform);

		// 获取省区
		that.getTvProvince();
		// 获取标签类型
		that.getQueryTvType();
	},
	methods: {
		netButClick() {
			// 获取省区
			that.getTvProvince();

			that.tabList = that.tabBars = [];
			// 获取标签类型
			that.getQueryTvType();
		},
		//动画结束
		animationfinish(e) {
			// console.log(e.detail.current, '==>动画结束后');
			// if(e.detail.current == 1){
			// 	this.tvProvinceList?uni.getStorageSync('tvProvinceList'):'';
			// }
		},
		getQueryTvType() {
			// 清除数据本地缓存
			uni.removeStorage({
				key: 'tvTypeList', // 电视台标签数据
				// key: 'tvProvinceList',	// 电视台省区数据
				success: function(res) {
					console.log('数据清除成功');
				},
				fail: function(err) {
					console.log(err, '--清除数据本地缓存失败');
				}
			});

			uni.getStorage({
				key: 'tvTypeList', // 电视台标签数据
				success: function(res) {
					console.log('******* 电视标签数据已存在 *******');
					that.tabList = res.data;
					that.loadTabbars();
				},
				fail: function(res) {
					console.log('无数据，发起请求');
					that.$req.reqc
						.queryTvType()
						.then(res => {
							console.log('电视分类列表：', res.data.data);
							// reverse()：数组倒序排列
							// let list = res.data.data.reverse();
							let list = res.data.data.sort(sortData);
							let hotTv = { id: 0, typeName: '热门' };
							let dqTv = { id: '', typeName: '地方台' };
							// 拼接函数(索引位置, 要删除元素的数量, 元素)
							list.splice(0, 0, hotTv);
							list.splice(1, 0, dqTv);
							uni.setStorage({
								key: 'tvTypeList',
								data: list
							});
							console.log('--------------获取全部 电视标签数据 成功--------------');
							that.tabList = list;
							that.loadTabbars();
							// console.log(that.tabList,"===>that.tabList")
						})
						.catch(err => {
							console.log('请求返回错误', err);

							console.log('网络中断');
							that.networkStatus = false;

							this.$forceUpdate();
						});

					function sortData(a, b) {
						// 按序号从小到大的顺序
						return a.typeSort - b.typeSort;
						// 按序号从大到小的顺序
						// return b.typeSort - a.typeSort
					}
				}
			});
		},

		//获取分类
		loadTabbars() {
			// let that = this;
			let tabarr = that.tabList;
			tabarr.forEach((item, index) => {
				// console.log('收藏的标签：',index);
				item.data = [];
				item.loadMoreStatus = 0; //加载更多 0加载前，1加载中，2没有更多了
				item.refreshing = 0;
				item.offset = 1;
				item.isLastPage = false;
				that.tabBars.push(item);
			});
			// console.log('电视分类：', that.tabBars);
			this.loadNewsList('add');
		},
		// 频道列表
		loadNewsList(type) {
			// 跳过第二个swiper(地区电视台)
			if (that.tabCurrentIndex === 1) {
				if (type === 'refresh') {
					this.$refs.mixPulldownRefresh.endPulldownRefresh();
				}

				return false;
			}

			let tabItem = this.tabBars[this.tabCurrentIndex];

			// type add 加载更多 refresh下拉刷新
			if (type === 'add') {
				if (tabItem.loadMoreStatus === 2) {
					return;
				}
				if (tabItem.data && tabItem.data.length > 0) {
					tabItem.offset++;
				}
				console.log('---------------------加载---------------------');
				tabItem.loadMoreStatus = 1;
			}

			// #ifdef APP-PLUS
			else if (type === 'refresh') {
				tabItem.refreshing = true;
			}
			// #endif
			if (type === 'refresh') {
				tabItem.offset = 1;
				console.log('---------------------刷新---------------------');
				tabItem.loadMoreStatus = 1;
			}

			uni.showLoading({
				title: '加载中...'
			});

			let datas = {
				id: tabItem.id,
				// "limit": 20,
				// "offset": tabItem.offset,
				livePlatform: String(this.appPlatform) || '3', // 所属平台 0:pc、1:安卓、2:苹果、3:h5
				type: tabItem.id === 0 ? 1 : 2 // 查询电视类型 1热门电视台 2电视台类型
			};
			console.log('请求参数：', datas);
			this.$req.reqc
				.queryTvInfo(datas)
				.then(res => {
					uni.hideLoading();
					// console.log('频道列表：', res);
					if (type === 'refresh') {
						tabItem.data = []; //刷新前清空数组
					}
					that.networkStatus = true;
					// let list = res.data.data&&res.data.data.list || [];
					let list = res.data.data || [];
					this.total = res.data.data.total;
					list.forEach((item, index) => {
						let items = {
							id: item.id, // 频道Id
							tvName: item.tvName, // 频道名称
							imgLog: item.imgLog, // 频道图标
							tvType: item.tvType, // 频道类型
							provincialArea: item.provincialArea,
							provincialAreaName: item.provincialAreaName,
							urbanDistrict: item.urbanDistrict,
							urbanDistrictName: item.urbanDistrictName,
							playbackAddress: item.playbackAddress,
							updatedTime: item.updatedTime
						};
						tabItem.data.push(items);
					});

					if (type === 'refresh') {
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;
					}
					//上滑加载 处理状态
					if (type === 'add') {
						tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2 : 0;
					}
					// this.tabBars[this.tabCurrentIndex] = tabItem;
					// console.log("全部数据",this.tabBars)
					// console.log('全部数据', tabItem);

					this.$forceUpdate();
				})
				.catch(err => {
					uni.hideLoading();
					if (type === 'refresh') {
						this.$refs.mixPulldownRefresh.endPulldownRefresh();
					}
					console.log('网络中断');
					that.networkStatus = false;
					this.$forceUpdate();
				});
		},

		//下拉刷新
		onPulldownReresh() {
			this.loadNewsList('refresh');
		},
		//上滑加载
		loadMore() {
			// this.loadNewsList('add');
		},

		// 进入电视播放/地方电视台
		playTv: function(id, name) {
			// console.log(id, name);return;

			if (that.tabCurrentIndex === 1) {
				uni.navigateTo({
					url: '/pages/tv/localTv?id=' + id + '&name=' + name
				});
			} else {
				// #ifdef APP-PLUS
				this.uniSkip.navigateTo({
					url: '/pages/tv/playTv-iframe',
					data: {
						id: id,
						name: name
					}
				});
				// #endif
				// #ifndef APP-PLUS
				uni.navigateTo({
					// url: '/pages/tv/playTv?id='+id
					url: '/pages/tv/playTv-iframe?id=' + id + '&name=' + name
				});
				// #endif
			}
		},

		// 查询省区
		getTvProvince: function() {
			// 获取省区数据(本地存储)
			uni.getStorage({
				key: 'tvProvinceList',
				success: function(res) {
					console.log('******* 省区数据已存在 *******');
					console.log(res.data, '===>是否存在data');
					that.tvProvinceList = res.data;
				},
				fail: function(res) {
					console.log('无数据，发起请求');
					getProvince();
				}
			});

			// 获取省区数据
			function getProvince() {
				that.$req.reqc
					.queryTvProvince()
					.then(res => {
						// let list = res.data.data.reverse();
						let list = res.data.data;
						let arr = [];
						list.forEach((item, index) => {
							let temp = {
								id: item.id,
								provincialArea: item.provincialArea,
								regionSort: item.regionSort
							};
							arr.push(temp);
							// console.log(arr,"==>arr")
						});
						// 设置省区数据本地存储
						// uni.setStorage({
						// 	key: 'tvProvinceList',
						// 	data: arr,
						// });
						console.log('--------------获取全部 省区数据 成功--------------');
						that.tvProvinceList = arr;
					})
					.catch(err => {
						console.log('请求返回错误', err);

						console.log('网络中断');
						that.networkStatus = false;
					});
			}
		},

		//tab切换
		async changeTab(e) {
			if (scrollTimer) {
				//多次切换只执行最后一次
				clearTimeout(scrollTimer);
				scrollTimer = false;
			}
			// if(this.tabCurrentIndex === 1 && scrollTimer){
			// 	clearTimeout(scrollTimer);
			// 	scrollTimer = false;
			// 	uni.getStorage({
			// 	key: 'tvProvinceList',
			// 	success: function(res) {
			// 		console.log('******* 省区数据已存在 *******');
			// 		console.log(res.data, '===>是否存在data');
			// 		that.tvProvinceList = res.data;
			// 	},
			// 	fail: function(res) {
			// 		console.log('无数据，发起请求');
			// 		getProvince();
			// 	}
			// });
			// }
			let index = e;
			//e=number为点击切换，e=object为swiper滑动切换
			if (typeof e === 'object') {
				index = e.detail.current;
			}
			if (typeof tabBar !== 'object') {
				tabBar = await this.getElSize('nav-bar');
			}
			//计算宽度相关
			let tabBarScrollLeft = tabBar.scrollLeft;
			let width = 0;
			let nowWidth = 0;
			//获取可滑动总宽度
			for (let i = 0; i <= index; i++) {
				let result = await this.getElSize('tab' + i);
				width += result.width;
				if (i === index) {
					nowWidth = result.width;
				}
			}
			if (typeof e === 'number') {
				//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
				this.tabCurrentIndex = index;
			}

			if (typeof e === 'object') {
				this.tabCurrentIndex = index;
			}

			this.tabCurrentIndex = index;

			//延迟300ms,等待swiper动画结束再修改tabbar
			scrollTimer = setTimeout(() => {
				if (width - nowWidth / 2 > windowWidth / 2) {
					//如果当前项越过中心点，将其放在屏幕中心
					this.scrollLeft = width - nowWidth / 2 - windowWidth / 2;
				} else {
					this.scrollLeft = 0;
				}

				//第一次切换tab，动画结束后需要加载数据
				let tabItem = this.tabList[this.tabCurrentIndex];
				console.log(tabItem, '===>列表数据');
				if (this.tabCurrentIndex !== 0 && tabItem.loaded !== true) {
					this.loadNewsList('add');
					tabItem.loaded = true;
				}
			}, 300);
		},
		//获得元素的size
		getElSize(id) {
			return new Promise((res, rej) => {
				let el = uni.createSelectorQuery().select('#' + id);
				el.fields(
					{
						size: true,
						scrollOffset: true,
						rect: true
					},
					data => {
						res(data);
					}
				).exec();
			});
		},
		//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
		setEnableScroll(enable) {
			if (this.enableScroll !== enable) {
				this.enableScroll = enable;
			}
		}
	}
};
</script>

<style lang="scss" scoped>
page,
.container {
	background-color: #f8f8f8;
	/* #ifdef H5 */
	height: 100%;
	/* #endif */
	/* #ifndef H5 */
	height: 100vh;
	/* #endif */
	overflow: hidden;
	width: 100vw;
}

/* 可滚动窗体高度（swiper外层刷新组件高度），100vh(相对于视窗的高度)  */
/* calc(100vh - 38px - 50px)：100vh(整个浏览器窗口高度) - 38px(顶部标签滑动栏高度) - 50px(底部tabBar栏高度(固定)) 的大小 */
.panel-content {
	/* height: calc(100vh - 38px - 50px) !important;
		max-height: calc(100vh - 38px - 50px) !important; */
}

.swiper-box {
	height: 100%;
	/* height: calc(100vh - 74rpx - 50px - 44px); */
	/* padding-bottom: 60rpx; */
}

/* .panel-scroll-box {
		height: 100%;
		padding: 0 20rpx;
	} */
.panel-scroll-box {
	/* #ifdef H5 */
	/* height: calc(100% - var(--status-bar-height)); */
	/* #endif */
	/* #ifndef H5 */
	/* height: calc(100vh - var(--status-bar-height)); */
	/* #endif */

	height: 100%;
	background-color: #ffffff;
}

.list {
	display: flex;
	flex-wrap: wrap;
	justify-content: space-between;
	width: 100%;
	padding: 0 20rpx;
	/* height: 100%; */
}
/* 父级加上after伪类，解决最后一排数量不够两端分布的情况(仅三列布局适用) */
.list:after {
	content: '';
	width: 200rpx;
}
.localTv:after {
	content: '';
	width: 180rpx;
}

.localTv {
	.list-item {
		width: 180rpx;
		height: 60rpx;
		line-height: 60rpx;
		border-radius: 50rpx;
		padding: 0;

		/* &:hover {} */
		&:active {
			color: #ffffff;
			background-color: #1b1b30;
		}
	}
}

/* 列表项 */
.list-item {
	width: 200rpx;
	height: 200rpx;
	line-height: 36rpx;
	margin: 20rpx 0;
	padding: 10rpx 16rpx 0 16rpx;
	border-radius: 10rpx;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
	overflow: hidden;
	font-size: 13px;
	text-align: center;
	background-color: #ffffff;

	.imgLog {
		min-height: 110rpx;
		max-height: 110rpx;
	}
}

.nav-bar {
	/* 标签栏顶部固定 → 防止 iPhone端 出现下拉移位的问题 */
	position: fixed;
	top: 0;

	position: relative;
	z-index: 10;
	width: 100%;
	height: 74rpx;
	box-sizing: border-box;
	flex-direction: row;
	white-space: nowrap;
	background-color: #ffffff;
	border-bottom: 1px solid #f2f2f2;

	.uni-tab-item {
		display: inline-block;
		flex-wrap: nowrap;
		padding-left: 14.5px;
		padding-right: 14.5px;
		position: relative;
	}
	/* 滚动tab 标签 */
	.uni-tab-item-title {
		color: #999999;
		font-size: 12px;
		height: 38px;
		line-height: 38px;
		flex-wrap: nowrap;
		white-space: nowrap;
	}
	.uni-tab-item-title-active {
		color: #000000;
	}
	/* 滚动tab 底部选中条 */
	.uni-tab-item-border {
		position: absolute;
		top: 85%;
		left: 50%;
		transform: translate(-50%, -50%);
	}
	.uni-tab-item-border-active {
		width: 14px;
		/* width: 70%; */
		height: 2px;
		background-color: #000000;
	}
}
</style>
