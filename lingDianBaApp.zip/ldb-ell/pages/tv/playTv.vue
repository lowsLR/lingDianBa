<template>
	<view class="container">
		<view class="backButton" @tap="backButton"></view>
		<!-- 播放器 -->
		<!-- <view class="video-view">
			<div class="prism-player" id="J_prismPlayer"></div>
		</view> -->
		<videoPlayer
		:isPlaySource="isPlaySource"
		:isLive="isVideoLive"
		:sourceUrl="sourceUrl"
		:isAutoplay="isAutoplay"
		:videoMsg="videoMsg"
		ref="videoplay"
		></videoPlayer>
		
		<!-- 信号源 -->
		<view class="video-signal">
			<scroll-view class="signal-nav-bar" scroll-x="true" >
				<view class="video-signal-item"
					v-for="(item, index) in signalList" :key="index"
					:class="index === tabCurrentIndex ? 'active' : ''"
					@click="setSignal(item, index)">
					{{item.sourceName}}
				</view>
			</scroll-view>
		</view>
		
		<!-- 节目预告 -->
		<!-- <view class="epg">
			<view class="epg-title">节目预告</view>
			<view class="epg-item" v-for="(item, index) in 15" :key="index">
				<view class="time">21:00</view>
				<view class="content">国际足球赛场-19-20司机法甲联赛第26轮</view>
			</view>
		</view>
		<view class="noMore">———— 没有更多了 ————</view> -->
	</view>
</template>

<script>
	import videoPlayer from '../component/videoPlayer.vue'
	let that, player;
	export default {
		components: {
			videoPlayer
		},
		data() {
			return {
				isPlaySource:false,
				isVideoLive:false,
				isAutoplay:true,
				videoMsg:'',
				sourceUrl:'',
				tvId: null,
				tabCurrentIndex: 0,
				signalList: [],
			};
		},
		onLoad:function(option){
			that = this;
			that.tvId = Number(option.id)
			console.log(that.tvId);
			that.getTvContent()
		},
		/*卸载页面*/
		onUnload() {
			try{
				that.playerDispose().then( res => {
					console.log('销毁');
				})
				// that.playerDispose()
			}catch(e){
				//TODO handle the exception
			}
		},
		methods: {
			getTvContent: function () {
				uni.showLoading({
					title: '请稍后...'
				})
				let datas = {
					"tvId": that.tvId,
				}
				console.log('请求参数：', datas);
				this.$req.reqc.queryTvConten(datas)
				.then( res => {
					uni.hideLoading()
					// console.log("数据列表",res.data.data)
					let list = res.data.data&&res.data.data || [];
					
					if (list.webTvInfoSourceList.length > 0) {
						list.webTvInfoSourceList.forEach((item,index) => {
							let items = {
								sourceId: item.sourceId,
								tvId: item.tvId,
								sourcePathId: item.sourcePathId,
								sourceName: item.sourceName,
								livePlatform: item.livePlatform,
								sourcePath: item.sourcePath,
								analysisPath: item.analysisPath,
							}
							that.signalList.push(items);
						})
						// console.log('播放源列表：',that.signalList);
						// console.log('当前的播放源：',that.signalList[0].sourceName,that.signalList[0].sourcePath);
						// let pdata = {
						// 	source: that.signalList[0].sourcePath,
						// 	isLive: true,
						// 	autoplay: true
						// }
						// that.initPlayer(pdata)
						
						that.isPlaySource = true;
						that.$refs.videoplay.initVideo({
							url:that.signalList[0].sourcePath,
							isLive:true,
							isAutoplay:true,
						});
						
					}
					else {
						uni.showModal({
							title: '提示',
							content: '该频道暂无播放源',
							cancelText: '返回',
							success: function (res) {
								if (res.confirm) {
									// console.log('用户点击确定');
									uni.navigateBack();
								} else if (res.cancel) {
									// console.log('用户点击取消');
									uni.navigateBack();
								}
							}
						});
					}
					
				})
				.catch(err => {
					console.log(err);
					uni.hideLoading()
				})
			},
			
			// 切换播放源
			setSignal: function (item, index) {
				if (that.tabCurrentIndex == index) {
					uni.showToast({
						icon: 'none',
						title: '正在播放当前源'
					})
					return;
				}
				that.tabCurrentIndex = index
				console.log('切换的播放源：',item.sourceName,item.sourcePath);
				// that.playerDispose().then( res => {
				// 	console.log("销毁后开始重置")
				// 	let pdata = {
				// 		source: item.sourcePath,
				// 		isLive: true,
				// 		autoplay: true
				// 	}
				// 	that.initPlayer(pdata)
				// })
				
				that.playerDispose().then( res => {
							that.isPlaySource = true;
							that.sourceUrl = item.sourcePath;
							that.isVideoLive = true;
							that.$refs.videoplay.initVideo({
								url:item.sourcePath,
								isLive:true,
								isAutoplay:true,
							});
				})
				
				
			},
			
			/*初始化播放器*/
			initPlayer(pdata) {
				player = new Aliplayer({
					id: 'J_prismPlayer',
					width: '100%',
					height: '100%',
					preload: false, //自动加载
					autoplay: false, //自动播放
					useH5Prism: true,
					//支持播放地址播放,此播放优先级最高
					//http://yf.ugc.v.cztv.com/cztv/ugcvod/2018/04/14/A98CD7B26B06D94A5CEA56AA7D723572/h264_800k_mp4.mp4_playlist.m3u8
					source: pdata.source,
					isLive: pdata.isLive || false, //是否是直播
					autoplay: pdata.autoplay || false, //自动播放
					//播放方式二：点播用户推荐
					// vid : '1e067a2831b641db90d570b6480fbc40',
					// playauth : 'ddd',
					cover: '',
					skinLayout:[
						 {name: "bigPlayButton", align: "blabs", x: 30, y: 80},
						    {
						      name: "H5Loading", align: "cc"
						    },
						    {name: "errorDisplay", align: "tlabs", x: 0, y: 0},
						    {name: "infoDisplay"},
						    {name:"tooltip", align:"blabs",x: 0, y: 56},
						    {name: "thumbnail"},
						    {
						      name: "controlBar", align: "blabs", x: 0, y: 0,
						      children: [
						        {name: "progress", align: "blabs", x: 0, y: 44},
						        {name: "playButton", align: "tl", x: 15, y: 12},
						        {name: "timeDisplay", align: "tl", x: 10, y: 7},
						        {name: "fullScreenButton", align: "tr", x: 10, y: 12},
						        // {name:"subtitle", align:"tr",x:15, y:12},
						        // {name:"setting", align:"tr",x:15, y:12},
						        {name: "volume", align: "tr", x: 5, y: 10}
						      ]
						    }
					],
					
					encryptType: 1, //当播放私有加密流时需要设置。
					//播放方式三：仅MPS用户使用
					// accId: 'dd',
					// accSecret: 'dd',
					// stsToken: 'dd',
					// domainRegion: 'dd',
					// authInfo: 'dd',
					//播放方式四：使用STS方式播放
					// accessKeyId: 'dd',
					// securityToken: 'dd',
					// accessKeySecret: 'dd',
					// videoWidth:'300px',
					// videoHeight:'150px',
					region: 'cn-shanghai', //eu-central-1,ap-southeast-1
				}, function(player) {
					console.log('播放器创建好了。')
				});
			},
			
			/*销毁播放器*/
			playerDispose() {
				return new Promise( (res,rel) => {
					// player.dispose();
					that.$refs.videoplay.videoDispose();
					res();
				})
			},
			
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				uni.navigateBack();
			},
		},
	}
</script>

<style lang='scss' scoped>
	page, .container{
		background-color: #F4F4F4;
		height: 100%;
		/* overflow: hidden; */
		width: 100vw;
	}
	
	/* 返回按钮 */
	.backButton {
		position: absolute;
		top: 66rpx;
		left: 36rpx;
		width: 44rpx;
		height: 44rpx;
		background-size: cover;
		background-image: url(../../static/images/video_back_w.png);
		z-index: 999;
	}
	
	/* 视频播放器 */
	.video-view {
		width: 100%;
		height: 420rpx;
	}
	
	.video-signal{
		height: 88rpx;
		background-color: #FFFFFF;
		
		.signal-nav-bar{
			height: 88rpx;
			padding: 0 40rpx;
			white-space: nowrap;
			
			.video-signal-item{
				width: 180rpx;
				height: 44rpx;
				margin: 22rpx 60rpx 0 0;
				display: inline-block;
				line-height: 44rpx;
				text-align: center;
				border-radius: 22rpx;
				border: 1px solid #1B1B30;
				font-size: 20rpx;
				color: #1B1B30;
			}
			.active {
				color: #FFFFFF;
				background-color: #1B1B30;
			}
		}
	}
	
	.epg {
		height: auto;
		margin-top: 8rpx;
		background-color: #FFFFFF;
		
		.epg-title {
			height: 54rpx;
			line-height: 54rpx;
			padding-left: 24rpx;
			font-size: 11px;
			font-weight: bold;
			color: #1B1B30;
			border-bottom: 1px solid #CCCCCC;
		}
		
		.epg-item {
			display: flex;
			align-items: center;
			min-height: 88rpx;
			padding-right: 24rpx;
			border-bottom: 1px dashed #999999;
			
			.time, .content {
				font-size: 12px;
				color: #666666;
			}
			.time {
				min-width: 110rpx;
				text-align: center;
			}
		}
	}
	
	.noMore {
		padding: 22rpx 0;
		text-align: center;
		color: #999999;
	}
</style>
