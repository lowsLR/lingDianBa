<template>
	<view class="container">
		<!-- 下拉刷新组件 -->
		<!-- <mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="90" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll"> -->
			<block v-for="(tabItem, index) in dataList.data" :key="index">
				<view v-if="tabItem.urbanDistrictList[tabItem.urbanDistrictName].length > 0" class="subhead">{{tabItem.urbanDistrictName}}</view>
				<view v-if="tabItem.urbanDistrictList[tabItem.urbanDistrictName].length > 0" class="list">
					<block v-for="(cItem, cIndex) in tabItem.urbanDistrictList[tabItem.urbanDistrictName]" :key="cIndex">
						<view class="list-item" @tap="playTv(cItem.id, cItem.tvName)">
							<image class="imgLog" :src="cItem.imgLog != null && cItem.imgLog != '' ? cItem.imgLog : '../../static/default_tv.png'" mode=""></image>
							{{cItem.tvName}}
						</view>
					</block>
				</view>
			</block>
			<view style="height: 100rpx; line-height: 100rpx; text-align: center; color: #999999;">—— 没有更多了 ——</view>
			<!-- 上滑加载更多组件 -->
			<!-- @scrolltolower="loadMore" -->
			<!-- <mix-load-more :status="dataList.loadMoreStatus"></mix-load-more> -->
		<!-- </mix-pulldown-refresh> -->
	</view>
</template>

<script>
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	let that;
	export default {
		components: {
			mixPulldownRefresh,
			mixLoadMore,
		},
		data() {
			return {
				navBarTitleText: '',
				tvId: null,
				typeName: '',
				dataList: {
					data: [],
					loadMoreStatus: 0, //加载更多 0加载前，1加载中，2没有更多了
					refreshing: 0,
					offset: 1,
					isLastPage: false,
				},
				total:100,
			};
		},
		onLoad: function (option) {
			that = this;
			that.tvId = Number(option.id)
			that.typeName = option.name
			console.log(that.tvId);
			
			this.loadNewsList('add');
			
			// 设置状态栏标题
			uni.setNavigationBarTitle({
				title: that.typeName == '' ? '地方电视台' : that.typeName
			});
		},
		onBackPress(options) {
			let page = getCurrentPages();
			// #ifdef H5
			if (options.from === 'navigateBack') {
				if(page.length < 2){
					window.history.back()
					// history.go(-1)
					// history.back(-1)
					// history.back()
					return true;
				}
				return false;
			}
			// #endif
			return false;
		},
		methods: {
			// 频道列表
			loadNewsList(type){
				let tabItem = that.dataList;
				// type：add 加载更多 refresh下拉刷新
				if(type === 'add'){
					if(tabItem.loadMoreStatus === 2){
						return;
					}
					if(tabItem.data&&tabItem.data.length > 0){
						tabItem.offset++;
					}
					tabItem.loadMoreStatus = 1;
				}
				// #ifdef APP-PLUS
				else if(type === 'refresh'){
					tabItem.refreshing = true;
				}
				// #endif
				if(type === 'refresh'){
					tabItem.offset = 1;
					console.log('---------------------刷新---------------------');
					tabItem.loadMoreStatus = 1;
				}
				
				uni.showLoading({
					title: '加载中...'
				})
				let datas = {
					"id": that.tvId,
					// "limit": 10,
					// "offset": tabItem.offset,
					"livePlatform": String(this.appPlatform) || '3', // 所属平台 0:pc、1:安卓、2:苹果、3:h5
					"type": 3,
				}
				console.log('请求参数：', datas);
				this.$req.reqc.queryTvInfo(datas)
				.then( res => {
					uni.hideLoading()
					// console.log("数据列表",res.data.data)
					if(type === 'refresh'){
						tabItem.data = []; //刷新前清空数组
					}
					// console.log(res.data.data);
					// let list = res.data.data&&res.data.data.list || [];
					let list = res.data.data&&res.data.data || [];
					this.total = res.data.data.total;
					list.forEach((item,index) => {
						let items = {
							id: item.id,
							provincialArea: item.provincialArea,
							provincialAreaName: item.provincialAreaName,
							urbanDistrict: item.urbanDistrict,
							urbanDistrictName: item.urbanDistrictName,
							imgLog: item.imgLog,
							tvName: item.tvName,
							playbackAddress: item.playbackAddress,
							urbanDistrictList: item.urbanDistrictList,
						}
						// console.log(item.urbanDistrictList[item.urbanDistrictName]);
						tabItem.data.push(items);
					})
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;
					}
					//上滑加载 处理状态
					if(type === 'add'){
						tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2: 0;
					}
					
					// console.log("全部数据",tabItem);
					
					this.$forceUpdate();
				})
				.catch(err => {
					uni.hideLoading()
				})
			},
			
			//下拉刷新
			onPulldownReresh(){
				this.loadNewsList('refresh');
			},
			//上滑加载
			loadMore(){
				this.loadNewsList('add');
			},
			
			// 进入电视播放
			playTv: function (id, name) {
				
				
				// #ifdef APP-PLUS
				this.uniSkip.navigateTo({
					url: '/pages/tv/playTv-iframe',
					data: {
						id:id,
						name:name
					}
				});
				// #endif					
				// #ifndef APP-PLUS
				uni.navigateTo({
					// url: '/pages/tv/playTv?id='+id
					url: '/pages/tv/playTv-iframe?id='+id+'&name='+name
				})
				// #endif
				
				
			},
			
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	page, .container{
		background-color: #FFFFFF;
		height: 100%;
		// overflow: hidden;
		width: 100vw;
		
		color: #333333;
	}
	
	.subhead {
		height: 68rpx;
		line-height: 68rpx;
		border-bottom: 1px solid #F2F2F2;
		font-size: 13px;
		padding: 0 36rpx;
	}
	
	.list {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		width: 100%;
		padding: 0 40rpx;
		/* height: 100%; */
		/* border-bottom: 1px solid blue; */
		
		/* 父级加上after伪类，解决最后一排数量不够两端分布的情况(仅三列布局适用) */
		&:after{
			content: '';
			width: 200rpx;
		}
		
		/* 列表项 */
		.list-item {
			width: 200rpx;
			height: 200rpx;
			line-height: 36rpx;
			margin: 20rpx 0;
			padding: 10rpx 16rpx 0 16rpx;
			border-radius: 10rpx;
			box-shadow: 0 0 10px rgba(0, 0, 0, .2);
			overflow: hidden;
			font-size: 13px;
			text-align: center;
			/* background-color: #FFFFFF; */
			/* border: 1px solid red; */
			
			.imgLog {
				min-height: 110rpx;
				max-height: 110rpx;
			}
		}
	}
</style>
