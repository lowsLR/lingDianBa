<template>
	<view class="container">
		<!-- 返回按钮 -->
		<view class="backButton" @tap="backButton">{{tvName}}</view>
		<view class="Prompt" v-if="signalPrompt">
			提醒：{{signalPrompt}}
		</view>
		<view class="video-view" style="width: 750rpx; height: 450rpx; background-color: #000000;">
			<view class="video-player" v-if="PlayMode == 1">
				<!-- 播放器 -->
				<!-- <videoPlayer
				:isPlaySource="isPlaySource"
				:isLive="isVideoLive"
				:sourceUrl="sourceUrl"
				:isAutoplay="isAutoplay"
				:videoMsg="videoMsg"
				@beginAnalysisSource="beginAnalysisSource"
				@videoError="videoErrorfun"
				ref="videoplay"
				></videoPlayer> -->
				<bwVideoPlayer
				:isPlaySource="isPlaySource"
				:isLive="isVideoLive"
				:sourceUrl="sourceUrl"
				:isAutoplay="isAutoplay"
				:videoMsg="videoMsg"
				@videoError="videoErrorfun"
				ref="videoplay"
				></bwVideoPlayer>
			</view>
			
			<!-- iframe -->
			<view class="iframe-view" v-if="PlayMode == 2">
				<iframe v-if="isWebView" scrolling='no' :src="iframeSrc || ''"></iframe>
				
				<button v-else class="navToText" @tap.prevent.stop="navToIframe">
					<text class="navToPrompt">点击此处观看 </text>
					<text class="navToPrompt sourceTitle">{{signalList[tabCurrentIndex].sourceName}}</text>
				</button>
			</view>
		</view>
		
		<!-- 信号源 -->
		<view class="video-signal">
			<scroll-view class="signal-nav-bar" scroll-x="true" >
				<view class="video-signal-item"
					v-for="(item, index) in signalList" :key="index"
					:class="index === tabCurrentIndex ? 'active' : ''"
					@click="setSignal(item, index)">
					<text class="title">{{item.sourceName}}</text>
				</view>
			</scroll-view>
		</view>
		
		<!-- 广告位 -->
		<block v-if="AdList.length >= 1 && $store.state.ADstatus.dsxqAD">
			<view class="boxMargin"></view>
			<bwAdvertising :AdName="'dsxqAD'" :AdList="AdList[0]"></bwAdvertising>
		</block>
		
		<!-- 节目预告 -->
		<!-- <view class="epg">
			<view class="epg-title">节目预告</view>
			<view class="epg-item" v-for="(item, index) in 15" :key="index">
				<view class="time">21:00</view>
				<view class="content">国际足球赛场-19-20司机法甲联赛第26轮</view>
			</view>
		</view>
		<view class="noMore">———— 没有更多了 ————</view> -->
	</view>
</template>

<script>
	// import videoPlayer from '../component/videoPlayer.vue'
	import bwVideoPlayer from '../component/bw-videoPlayer.vue'
	let that, player;
	export default {
		components: {
			// videoPlayer,
			bwVideoPlayer
		},
		data() {
			return {
				PlayMode: 1, // 1：播放器  2：iframe
				
				isWebView: true, // iframe / url
				
				tvId: null, // 频道id
				tvName: null, // 频道名称
				areaId: null,
				typeName: null,
				tabCurrentIndex: 0,
				signalList: [],
				
				signalPrompt: '',
				
				isPlaySource:false,//是否有播放源
				isVideoLive:false,//是否是直播
				isAutoplay:true,//是否自动播放
				videoMsg:'',	//video消息
				sourceUrl:'',//播放路径
				
				playerType: false,
				iframeSrc: '',
				
				AdList: [], // 广告列表
			};
		},
		onLoad:function(option){
			that = this;
			that.tvId = Number(option.id)
			that.tvName = option.name
			console.log('电视id：',that.tvId, '频道名称：',that.tvName);
			
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'dsbf'})
			.then( res => {
				that.AdList = res
				console.log('电视详情广告：',that.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
			
			
			that.getTvContent()
			
			// if (option.hasOwnProperty('name')) {
			// 	console.log(option.name);
			// }
			// else {
			// 	console.log('----- toString or something else -----');
			// }
		},
		/*卸载页面*/
		onUnload() {
			try{
				if (that.PlayMode === 1) {
					that.playerDispose().then( res => {
						console.log('销毁');
					})
				}
			}catch(e){
				//TODO handle the exception
			}
		},
		// 监听页面返回
		onBackPress(options) {
			if (options.from === 'navigateBack') {
				return false;
			}
			this.backButton();
			return true;
		},
		methods: {
			getTvContent: function () {
				uni.showLoading({
					title: '请稍后...'
				})
				let datas = {
					"tvId": that.tvId,
					"livePlatform": String(this.appPlatform) || '3', // 所属平台 0:pc、1:安卓、2:苹果、3:h5
				}
				console.log('请求参数：', datas);
				this.$req.reqc.queryTvConten(datas)
				.then( res => {
					uni.hideLoading()
					console.log("数据列表",res.data.data)
					let list = res.data.data&&res.data.data || [];
					
					if (list.webTvInfoSourceList) {
						list.webTvInfoSourceList.forEach((item,index) => {
							if(item.sourceName.length > 10){
								item.sourceName = item.sourceName.substring(0,10)
							}
						})
						
						that.signalList = [...that.signalList, ...list.webTvInfoSourceList];
						
						console.log('播放源列表：',that.signalList);
						console.log('链接播放类型(playType)：', that.signalList[0].playType);
						console.log('当前的播放源：',that.signalList[0].sourceName,that.signalList[0].sourcePath);
						
						// playType：1：播放器、2：iframe
						that.homeFunction();
						// if (that.signalList[0].playType === 1) {
						// 	that.isPlaySource = true;
						// 	that.invalidMessage = true;
						// 	that.$refs.videoplay.initVideo({
						// 		url:that.signalList[0].sourcePath,
						// 		isLive:true,
						// 		isAutoplay:true,
						// 	});
						// }
						// if (that.signalList[0].playType === 1) {
							
						// }
						
					}
					else {
						uni.showModal({
							title: '提示',
							content: '该频道暂无播放源',
							cancelText: '返回',
							success: function (res) {
								if (res.confirm) {
									// console.log('用户点击确定');
									uni.navigateBack();
								} else if (res.cancel) {
									// console.log('用户点击取消');
									uni.navigateBack();
								}
							}
						});
					}
					
				})
				.catch(err => {
					console.log(err);
					uni.hideLoading()
				})
			},
			
			/* 解析信号源 */
			analysisSource(sid, index) {
				let datas = {
					"livePlatform": 3,
					"sourceId": sid,
				}
				console.log('开始解析');
				uni.showLoading({
					mask: true
				})
				// 解析直播源
				that.$req.reqc.analysisTv(datas)
				.then(res => {
					console.log("解析直播信息", res)
					let data = res.data.data;
					uni.hideLoading();
					if (res.data.resultCode === 1 && res.statusCode == 200) {
						data.isAnalysis = "1";
						// 更新当前播放源的数据，避免重复解析
						that.signalList[index] = data;
						that.judgeSignalType(data);
					}
					else if (res.data.resultCode === -159 && res.statusCode == 200) {
						that.setNoPlay(res.data.resultMsg)
					}
				}).catch(err => {
					uni.hideLoading();
					uni.showToast({
						icon: 'none',
						title: '请稍后再试'
					})
					console.log(err);
				})
			},
			
			// 判断播放源类型
			judgeSignalType(data) {
				console.log(data);
				// ~~：取整(不四舍五入)
				switch (~~data.playType){
					// m3u8
					case 1:
						that.PlayMode = 1;
						console.log(that.PlayMode);
						// 判断当前播放源是否需要解析 isAnalysis：1：不解析，0：解析
						if (data.isAnalysis === "1") {
							setTimeout(function() {
								if(data.sourcePath){
									that.beginVideo({
										liveSourceName:data.sourceName,
										analysisPlayPathWeb:data.sourcePath,
										isLive:true,
										isAutoplay:true,
									})
								}else{
									// 获取并更新解析后数据
									that.judgeIsAnalysis(data);
								}
							}, 0);
						}
						else {
							// 请求解析
							this.analysisSource(data.sourceId, that.tabCurrentIndex)
						}
						
						break;
						
					// iframe (当前页面显示)
					case 2:
						that.PlayMode = 2;
						this.isWebView = true;
						this.$forceUpdate();
						
						setTimeout(function() {
							if (data.analysisPath) {
								that.beginIframe({
									liveSourceName:data.sourceName,
									iframeSrc:data.analysisPath,
								})
								console.log(data.sourceName,data.analysisPath)
							} else {
								// 获取并更新解析后数据
								that.judgeIsAnalysis(data);
							}
						}, 0);
						break;
						
					// url (跳转页面)
					case 3:
						that.PlayMode = 2;
						this.isWebView = false;
						this.$forceUpdate();
						
						if (!data.analysisPath) {
							// 获取并更新解析后数据
							that.judgeIsAnalysis(data);
						}
						break;
						
					default:
						break;
				}
			},
			
			// 获取并更新解析后数据
			judgeIsAnalysis(data) {
				if (data.sourceLink) {
					// linkPlayType：link解析方式 2iframe 3url跳转
					switch (~~data.linkPlayType){
						// m3u8
						case 1:
							that.PlayMode = 1;
							this.$nextTick(()=> {
								that.beginVideo({
									liveSourceName:data.sourceName,
									analysisPlayPathWeb:data.sourceLink,
									isLive:true,
									isAutoplay:true,
								})
							});
							break;
							
						// iframe (当前页面显示)
						case 2:
							that.PlayMode = 2;
							this.isWebView = true;
							this.$forceUpdate();
							
							this.$nextTick(()=> {
								that.beginIframe({
									liveSourceName:data.sourceName,
									iframeSrc:data.sourceLink,
								})
							});
							break;
							
						// url (跳转页面)
						case 3:
							that.PlayMode = 2;
							this.isWebView = false;
							this.$forceUpdate();
							break;
							
						default:
							break;
					}
				}
				else {
					console.log('暂未获取信号,请选择其他播放源观看', that.PlayMode);
					that.setNoPlay('暂未获取信号,请选择其他播放源观看')
				}
				
				/* if (item.sourceLink) {
					this.isWebView = item.linkPlayType == 2 ? true : false;
					this.$forceUpdate();
				}
				else {
					console.log('暂未获取信号,请选择其他播放源观看', that.PlayMode);
					that.setNoPlay('暂未获取信号,请选择其他播放源观看')
				} */
			},
			
			// 首页函数
			homeFunction(){
				let data = that.signalList;
				console.log("查看首页数据",data);
				if(data.length > 0){
					// 信号源提示语
					that.signalPrompt = data[0].invalidMessage
					
					that.judgeSignalType(data[0]);
					
				}else{
					that.setNoPlay('暂未获取信号')
				}
			},
			
			
			// 跳转webview页面
			navToIframe: function () {
				let data = that.signalList[that.tabCurrentIndex];
				let temp = {
					"sourceId": data.sourceId,
					"sourceName": data.sourceName,
					// "sourcePath": data.analysisPath,
					"sourcePath": data.analysisPath ? data.analysisPath : data.sourceLink,
					// "sourcePath": data.sourcePath ? data.sourcePath : data.sourceLink,
					"tvId": data.tvId,
					"tvName": that.tvName,
					"invalidMessage": data.invalidMessage,
					"valid": data.valid,
				}
				// console.log(temp);
				uni.navigateTo({
					url: '/pages/webview/webview?data=' + encodeURIComponent(JSON.stringify(temp))
				})
			},
			
			
			/*加载ifrmae*/
			beginIframe(res){
				that.initLoading();
				that.isPlaySource = true;
				that.playerType = false;
				that.resultMsg = res.liveSourceName;
				that.iframeSrc = res.iframeSrc;
				
				console.log("设置ifrmae：", that.iframeSrc)
			},
			/*初始化播放器*/
			beginVideo(res){
				that.isPlaySource = true;
				that.sourceUrl = res.analysisPlayPathWeb
				that.isVideoLive = true;
				that.videoMsg = res.liveSourceName;
				that.resultMsg =  res.liveSourceName;
				this.$forceUpdate();
				setTimeout(function() {
					that.$refs.videoplay.initVideo({
						url:res.analysisPlayPathWeb,
						isLive:res.isLive,
						isAutoplay:res.isAutoplay,
					});
				}, 10);
			},
			// 无信号源提示
			setNoPlay(title){
				that.isPlaySource = false;
				that.playerType = false;
				that.videoMsg = title||'暂未获取信号,请选择其他播放源观看';
				// that.resultMsg = title||'暂未获取信号,请选择其他播放源观看';
			},
			//加载loading
			initLoading() {
				uni.showLoading({
					title: '加载中...',
					mask: true
				})
				setTimeout(function() {
					uni.hideLoading();
				}, 1000);
			},
			
			// 播放地址失效，销毁播放器 并显示失效提示语
			videoErrorfun: function () {
				// console.log('播放错误');
				that.playerDispose().then( res => {
					console.log('销毁');
					that.isPlaySource=false,
					that.videoMsg = that.signalList[that.tabCurrentIndex].invalidMessage || '播放链接失效'
				})
			},
			
			// 切换播放源
			setSignal: function (item, index) {
				if (that.tabCurrentIndex == index) {
					uni.showToast({
						icon: 'none',
						title: '正在播放当前源'
					})
					return;
				}
				that.tabCurrentIndex = index
				console.log('切换的播放源：',item.sourceName,item.sourcePath);
				
				that.signalPrompt = item.invalidMessage
			
				that.playerDispose().then( res => {
					console.log("销毁后开始重置")

					that.judgeSignalType(item);
				})
			},
			
			/*销毁播放器*/
			playerDispose() {
				return new Promise( (res,rel) => {
					// player.dispose();
					try{
						that.$refs.videoplay.videoDispose();
					}catch(e){
						//TODO handle the exception
					}
					res();
				})
			},
			
			
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				// uni.navigateBack();
				uni.switchTab({
					url: '/pages/tv/tv'
				})
			},
		},
	}
</script>

<style lang='scss' scoped>
	page, .container{
		background-color: #F4F4F4;
		height: 100%;
		/* overflow: hidden; */
		width: 100vw;
	}
	
	/* 返回按钮 */
	.backButton {
		position: absolute;
		top: 66rpx;
		left: 36rpx;
		z-index: 999;
		width: auto;
		height: 44rpx;
		overflow: hidden;
		line-height: 44rpx;
		font-size: 18px;
		color: #FFFFFF;
		/* background-color: pink; */
		
		/* :before 选择器在被选元素的内容前面插入内容 */
		&:before {
			content: '';
			background-image: url(../../static/images/video_back_w.png);
			background-size: cover;
			background-repeat: no-repeat;
			/* background-color: red; */
			/* background-position: center center; */
			width: 44rpx;
			height: 44rpx;
			display: inline-block;
			margin-right: 12rpx;
			vertical-align: middle;
			margin-top: -4px;
		}
	}
	.backButton:before{
		
	}
	
	/* 提示语 */
	.Prompt {
		background: #353235;
		font-size: 11px;
		font-family: PingFang SC;
		font-weight: 400;
		color: white;
		height: 22px;
		line-height: 22px;
		padding-left: 10px;
	}
	
	/* 视频播放器 */
	.video-view {
		width: 100%;
		height: 450rpx;
	}
	
	.iframe {
		width: 100%;
		height: 100%;
		border: 0px !important;
	}
	
	.video-signal{
		height: 88rpx;
		background-color: #FFFFFF;
		
		.signal-nav-bar{
			height: 88rpx;
			/* padding: 0 40rpx; */
			white-space: nowrap;
			
			.video-signal-item{
				min-width: 100rpx;
				/* max-width: 240rpx; */
				padding: 0 20rpx;
				overflow: hidden;
				height: 44rpx;
				margin: 22rpx 40rpx 0 0;
				display: inline-block;
				line-height: 44rpx;
				text-align: center;
				border-radius: 22rpx;
				border: 1px solid #1B1B30;
				font-size: 20rpx;
				color: #1B1B30;
			}
			.video-signal-item:first-child{
				margin-left: 40rpx;
			}
			.active {
				color: #FFFFFF;
				background-color: #1B1B30;
			}
		}
	}
	
	.epg {
		height: auto;
		margin-top: 8rpx;
		background-color: #FFFFFF;
		
		.epg-title {
			height: 54rpx;
			line-height: 54rpx;
			padding-left: 24rpx;
			font-size: 11px;
			font-weight: bold;
			color: #1B1B30;
			border-bottom: 1px solid #CCCCCC;
		}
		
		.epg-item {
			display: flex;
			align-items: center;
			min-height: 88rpx;
			padding-right: 24rpx;
			border-bottom: 1px dashed #999999;
			
			.time, .content {
				font-size: 12px;
				color: #666666;
			}
			.time {
				min-width: 110rpx;
				text-align: center;
			}
		}
	}
	
	
	.scroll-view-iframe{
		width: 100%;
		height: 100%;
		.scroll-view-iframe-view{
			width: 100%;
			height: 80vh;
			/* height: auto; */
			
			iframe{
				width: 100%;
				height: 100%;
				overflow: auto;
				-webkit-overflow-scrolling: touch; 
				-webkit-overflow-scrolling: touch;
				-webkit-overflow:auto;
			}
		}
	}
	
	.noMore {
		padding: 22rpx 0;
		text-align: center;
		color: #999999;
	}
	
	
	.iframe-view{
		width: 100%;
		height:100%;
		overflow: auto;
		iframe{
			width: 100%;
			height: 100%;
			overflow: auto;
		}
	}
	
	
	.navToText {
		position: absolute;
		top: 180rpx;
		left: 175rpx;
		width: 400rpx;
		height: 90rpx;
		background-color: rgba($color: #FFFFFF, $alpha: 0);
		border-width: 1px;
		border-color: #FFFFFF;
		border-style: solid;
	}
	.navToPrompt {
		font-size: 16px;
		line-height: 90rpx;
		/* color: #333333; */
		color: #FFFFFF;
	}
	.sourceTitle {
		color: red;
	}
	
</style>
