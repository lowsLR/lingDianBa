<!--
 * @Description: 注册页
 * @Author: Edmund
 * @Email: q1592193221@gmail.com
 * @Date: 2019-11-10 21:42:14
 * @LastEditTime: 2019-11-26 11:40:08
 * @LastEditors: Edmund
 -->

<template>
  <view class="container">
    <view class="topLayout">
      <image class="iconLogo" src="/static/assets/logo.png"></image>
    </view>
    <view class="contentLayout" :style="[{ height: contentHeight }]">
      <input
        class="input1"
        placeholder="请输入手机号"
		placeholder-class="cueStyle"
        v-model="phoneNo"
        maxlength="11"
        type="number"
      />
	  
	  <view class="yzm" v-if="showVerifyCode">
	    <input
			class="input2"
			v-model="registVerifyCode"
			maxlength="4"
			placeholder="请输入图片验证码"
			placeholder-class="cueStyle"
			type="text"
	    />
		<image :src="getCodeUrl2" @tap.stop="handleGetImgCode" class="btGet" mode=""></image>
	  </view>
	  
      <view class="yzm">
        <input
          class="input2"
          v-model="code"
          placeholder="请输入手机验证码"
		  placeholder-class="cueStyle"
          type="text"
        />
		<view class="btGet" @tap.stop="handleGetCode">
		  {{ count }}
		</view>
      </view>
      <input
        class="input1"
        placeholder="请输入密码"
		placeholder-class="cueStyle"
        v-model="password"
        type="password"
      />
      <input
        class="input1"
        placeholder="请填写6位邀请码（选填）"
		placeholder-class="cueStyle"
        v-model="inviteCode"
        type="text"
      />
      <button class="btSubmit" type="default" @tap.stop="handleRegister">
        注册
      </button>
    </view>
  </view>
</template>

<script>
let that
import _ from 'underscore'
import BWU from '@/bw/js/bw-util.js'
import envConfig from '@/config.js'
import { sendSMS, register } from 'api/user.js'
import {
        mapState,
        mapMutations
} from 'vuex'
export default {
	computed: mapState(['forcedLogin']),
	name: '',
	components: {},
	props: {},
	data() {
		return {
			contentHeight: '0px',
			phoneNo: '',
			password: '',
			inviteCode: '',
			code: '',
			count: '获取',
			isgetCode: true,
			
			showVerifyCode: false, // 是否显示验证码框
			registVerifyCode: '',	// 图片验证码 (注册)
			getCodeUrl: `${envConfig.dev.BASE_URL}app/login/userAccount/getVerify`, // 图片验证码地址
			getCodeUrl2: '',
			isClickCodeUrl: false, // 是否已点击获取图片验证码
		}
	},
	beforeCreate() {
		// #ifndef APP-PLUS
		console.time('renderTime')
		// #endif
	},
	created() {
		that = this
		uni.getSystemInfo({
			success(res) {
				let naviHeight = 45
				if (res.platform == 'android') {
					naviHeight = 50
				}
				that.contentHeight =
					res.windowHeight -
					res.statusBarHeight -
					naviHeight -
					uni.upx2px(360 - 100 - 20) +
					'px'
			}
		})
	},
	onLoad: function (option) {
		if (option.invitCode != undefined) {
			this.inviteCode = option.invitCode;
			console.log('邀请码：',this.inviteCode);
		}
	},
	onShow() {
		// console.log(that.count, 'timer')
	},
	onReady() {
		// #ifndef APP-PLUS
		console.log(
			'%c如果渲染用时超过3秒，则列入待优化项目',
			'color: yellow; background-color: black;padding: 2px'
		)
		console.timeEnd('renderTime')
		// #endif
	},
	onHide() {
		// clearInterval(timer)
	},
	onUnload() {
		console.log('unload')
	},
	watch: {
		phoneNo(newValue, oldValue) {
			if (BWU.phone_validation(newValue)) {
				that.handleGetImgCode();
				that.showVerifyCode = true;
			} else {
				that.showVerifyCode = false;
				that.registVerifyCode = '';
			}
		}
	},
	methods: {
		...mapMutations(['login','setToken']),
		
		// 获取图片验证码
		handleGetImgCode(){
			if (that.isClickCodeUrl) return;
			if (!BWU.phone_validation(that.phoneNo)) {
				console.log('请输入有效手机号');
				return;
			}
			
			that.isClickCodeUrl = true;
			that.getCodeUrl2 = '';
			uni.request({
				url: that.getCodeUrl + "?key=" + that.phoneNo,
				method: 'GET',
				data: {},
				success: res => {
					that.getCodeUrl2 = that.getCodeUrl + "?key=" + that.phoneNo;
				},
				fail: () => {},
				complete: () => {}
			});
			setTimeout(function() {
				that.isClickCodeUrl = false;
			}, 1000);
		},
		
		/**
		 * @Description: 使用工具函数的节流方法，让执行事件时产生间隔
		 */
		handleGetCode: _.throttle(async () => {
			if (that.phoneNo == '') {
				uni.showToast({
					icon: 'none',
					title: '请输入手机号'
				})
				return;
			}
			if (that.registVerifyCode == '') {
				uni.showToast({
					icon: 'none',
					title: '请输入图片验证码'
				})
				return;
			}
			
			let timer;
			// 离开页面清除定时器
			that.$once('hook:beforeDestroy', () => {
				clearInterval(timer)
			})
			
			if (that.isgetCode === false) return
			
			let res = await sendSMS({
				phone: that.phoneNo,
				smsType: 1, // 1 = 注册用短信类型
				verify: that.registVerifyCode,
			})
			if (res.statusCode === 200) {
				
				if (res.data.resultCode == 1) {
					
					that.isgetCode = false
					that.count = 59
					timer = setInterval(() => {
						that.count--
						// console.log(that.count, 'timer')
						// 边界值处理
						if (that.count === 0) {
							that.count = '获取'
							that.isgetCode = true
							// 到0清除定时器
							clearInterval(timer)
						}
					}, 1000)
				}
				
				uni.showToast({
					duration:2000,
					title:res.data.resultMsg,
					icon:'none'
				})
				//that.$sysCall.toast(res.data.resultMsg)
			}
		}, 5000),

		/**
		 * @Description: 点击注册按钮
		 */
		async handleRegister() {
			// uni.navigateBack({delta: 1});
			// return
			
			
			// 拼接参数
			let params = {
				code: that.code,
				password: that.password,
				phone: that.phoneNo,
				smsType: 1
			}
			let res = await register(params)
			if (res.statusCode === 200) {
				// console.log('注册信息：',res);return;
				
				// 接口调用后返回提示内容
				uni.showToast({
					duration:2000,
					title:res.data.resultMsg,
					icon:'none'
				})
				// that.$sysCall.toast(res.data.resultMsg)
				
				// 接口返回状态码为1，表示注册成功
				if (res.data.resultCode === 1) {
					// 注册成功，存储用户信息 并返回个人中心
					this.setToken(res.data.data.token);
					this.login(res.data.data.nickName);
					console.log('userId:'+ res.data.data.userId);
					uni.setStorage({
						key: 'userInfo',
						data: {
							token: res.data.data.token,
							userId: res.data.data.userId,
							nickName: res.data.data.nickName,
							imageUrl: res.data.data.imageUrl,
							shareQrCode: res.data.data.shareQrCode,
							invitationCode: res.data.data.invitationCode,
						}
					});
					try {
						uni.setStorageSync('token', res.data.data.token)
					    uni.setStorageSync('user', {
							phoneNo: that.phoneNo,
							psword:that.password,
							token: res.data.data.token,
							registeIp: res.data.data.registeIp,
							deviceType: that.deviceType,
							userId: res.data.data.userId,
							systemInfo: uni.getSystemInfoSync()
						});
						console.log('user info inject success')
					} catch (e) {
					    // error
						console.log(e)
					}
					
					// 1秒后回到个人中心
					setTimeout(() => {
						getApp().globalData.isLogin = true
						// uni.navigateBack({
						// 	delta: 1
						// });
						uni.switchTab({
							url: '../mine/mine',
						});
					}, 1000)
				}
			}
		}
	},
}
</script>

<style lang="scss" scoped>
page {
	background-color: $default-bg-white;
}
.container{
	width: 100%;
}
.topLayout {
	background-color: $default-bg-black;
	height: 360rpx;
	.iconLogo {
		width: 180rpx;
		height: 180rpx;
		border-radius: 8rpx;
		margin-top: 20rpx;
		margin-left: 285rpx;
	}
}

.contentLayout {
	background-color: $default-bg-white;
	border-radius: 10rpx;
	margin-top: -100rpx;
	width: 690rpx;
	margin-left: 30rpx;
	-moz-box-shadow: 0px 0px 5px $default-border-shadow;
	-webkit-box-shadow: 0px 0px 5px $default-border-shadow;
	box-shadow: 0px 0px 5px $default-border-shadow;
	padding-top: 40rpx;
	
	.input1, .input2 {
		height: 80rpx;
		border: solid 1px #CCCCCC;
		border-radius: 40rpx;
		font-size: 13px;
		text-align: center;
	}
	.input1 {
		width: 580rpx;
		/* margin: 0 auto; */
		margin: 0 auto 20rpx auto;
	}
	// 输入框占位符样式
	.cueStyle {
		color: #999999;
	}
	
	.yzm {
		width: 580rpx;
		height: 80rpx;
		margin: 0 auto;
		margin-bottom: 20rpx;
		display: flex;
		justify-content: space-between;
	}
	.input2 {
		width: calc(580rpx - 136rpx);
		border-top-right-radius: 0;
		border-bottom-right-radius: 0;
	}
	.btGet {
		width: 136rpx;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		color: $default-text-color-white;
		font-size: 13px;
		background-color: $default-bg-black;
		border-top-right-radius: 40rpx;
		border-bottom-right-radius: 40rpx;
	}
	.btSubmit {
		color: $default-text-color-white;
		height: 80rpx;
		line-height: 80rpx;
		border-radius: 40rpx;
		font-size: 15px;
		width: 580rpx;
		background-color: $default-bg-black;
		margin-top: 110rpx;
	}
}
</style>
