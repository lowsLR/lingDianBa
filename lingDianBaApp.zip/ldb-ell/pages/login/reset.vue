<!--
 * @Description: 重置密码
 * @Author: Edmund
 * @Email: q1592193221@gmail.com
 * @Date: 2019-11-10 21:43:59
 * @LastEditTime: 2019-11-22 16:34:10
 * @LastEditors: Edmund
 -->

<template>
    <view class="container">
        <input  class="input1" 
                placeholder="请输入手机号"
				maxlength="11"
                v-model="phoneNo" 
                type="number" />
		
		<view class="yzm" v-if="showVerifyCode">
			<input
				class="input2"
				v-model="resetVerifyCode"
				maxlength="4"
				placeholder="请输入图片验证码"
				placeholder-class="cueStyle"
				type="text"
			/>
			<image :src="getCodeUrl2" @tap.stop="handleGetImgCode" class="btnGet" mode=""></image>
		</view>
		
		<view class="yzm">
			<input
				class="input2"
				v-model="code"
				placeholder="请输入手机号验证码"
				placeholder-class="cueStyle"
				type="number"
			/>
			<view class="btnGet" @tap.stop="handleGetCode">
				{{count}}
			</view>
		</view>
	
        <input  class="input1" 
                placeholder="新密码"
                v-model="newPsw"
                type="password" />
        <input  class="input1"
                placeholder="确认密码"
                v-model="confirmPsw"
                type="password" />
        <button class="btnSubmit" 
                type="default"
                @tap.stop="tapConfirm">
                确定
		</button>
		<!--toast提示-->
    	<!-- <tui-toast ref="toast"></tui-toast> -->
    </view>
</template>

<script>
let that
import _ from 'underscore'
import BWU from '@/bw/js/bw-util.js'
import envConfig from '@/config.js'
// import tuiToast from 'components/extend/toast/toast.vue'
import { resetPsw, sendSMS } from 'api/user.js'
export default {
	name: '',
	components: {
		// tuiToast
	},
	props: {},
	data() {
		return {
			isGetCode: false,
			count: '获取',
			// TODO: 表单验证所用数据
			phoneNo: '', // input-手机号码
			code: '', // input-验证码
			newPsw: '', // input-新密码
			confirmPsw: '' ,//input-确认密码
			
			showVerifyCode: false, // 是否显示验证码框
			resetVerifyCode: '',	// 图片验证码 (重置密码)
			getCodeUrl: `${envConfig.dev.BASE_URL}app/login/userAccount/getVerify`, // 图片验证码地址
			getCodeUrl2: '',
			isClickCodeUrl: false, // 是否已点击获取图片验证码
		}
	},
	beforeCreate() {
		// #ifndef APP-PLUS
		console.time('renderTime')
		// #endif
	},
	created() {
		that = this
	},
	onReady() {
		// #ifndef APP-PLUS
		console.log(
			'%c如果渲染用时超过3秒，则列入待优化项目',
			'color: yellow; background-color: black;padding: 2px'
		)
		console.timeEnd('renderTime')
		// #endif
	},
	watch: {
		phoneNo(newValue, oldValue) {
			if (BWU.phone_validation(newValue)) {
				that.handleGetImgCode();
				that.showVerifyCode = true;
			} else {
				that.showVerifyCode = false;
				that.resetVerifyCode = '';
			}
		}
	},
	methods: {
		// 获取图片验证码
		handleGetImgCode(){
			if (that.isClickCodeUrl) return;
			if (!BWU.phone_validation(that.phoneNo)) {
				console.log('请输入有效手机号');
				return;
			}
			
			that.isClickCodeUrl = true;
			that.getCodeUrl2 = '';
			uni.request({
				url: that.getCodeUrl + "?key=" + that.phoneNo,
				method: 'GET',
				data: {},
				success: res => {
					that.getCodeUrl2 = that.getCodeUrl + "?key=" + that.phoneNo;
				},
				fail: () => {},
				complete: () => {}
			});
			setTimeout(function() {
				that.isClickCodeUrl = false;
			}, 1000);
		},
		
		/**
		 * @Description: 使用工具函数的节流方法，让执行事件时产生间隔
		 */
		handleGetCode: _.throttle(async () => {
			if (that.phoneNo == '') {
				uni.showToast({
					icon: 'none',
					title: '请输入手机号'
				})
				return;
			}
			if (that.resetVerifyCode == '') {
				uni.showToast({
					icon: 'none',
					title: '请输入图片验证码'
				})
				return;
			}
			
			let timer;
			// 离开页面清除定时器
			that.$once('hook:beforeDestroy', () => {
				clearInterval(timer)
			})
			let res = await sendSMS({
				phone: that.phoneNo,
				smsType: 2, // 1：注册，2：重置密码
				verify: that.resetVerifyCode,
			})
			if (res.statusCode === 200) {
				
				if (res.data.resultCode == 1) {
					if (that.isgetCode === false) return
					that.isgetCode = false
					that.count = 59
					timer = setInterval(() => {
						that.count--
						// console.log(that.count, 'timer')
						// 边界值处理
						if (that.count === 0) {
							that.count = '获取'
							that.isgetCode = true
							// 到0清除定时器
							clearInterval(timer)
						}
					}, 1000)
				}
				
				uni.showToast({
					duration:2000,
					title:res.data.resultMsg,
					icon:'none'
				})
				//that.$sysCall.toast(res.data.resultMsg)
			}
		}, 5000),

		/**
		 * @Description: 点击`确认`按钮执行方法
		 * @param {number} smsType 短信类型，1=注册，2=重置密码
		 */
		async tapConfirm() {
			
			// uni.navigateBack({delta: 1});
			// return;
			let params = {
				code: that.code,
				password: that.newPsw,
				confirmPwd: that.confirmPsw,
				phone: that.phoneNo,
				smsType: 2 // 重置密码
			}
			let res = await resetPsw(params)
			if (res.statusCode === 200) {
				uni.showToast({
					duration:2000,
					title:res.data.resultMsg,
					icon:'none'
				})
				// that.$sysCall.toast(res.data.resultMsg)
				if (res.data.resultCode === 1) {
					// do sth TODO: 重新登录操作，更新token，vuex,再将vuex重新写入global

					// 1秒后，使用replace方法不保留history回到登录页
					setTimeout(() => {
						uni.navigateBack({delta: 1});
						
						// that.$Router.replace({ path: '/pages/user/login' })
					}, 1000)
				}
			}
		}
	},
	computed: {},
}
</script>

<style lang="scss" scoped>
page {
	background-color: $default-bg-white;
}

.container {
	display: flex;
	flex-direction: column;
	align-items: center;
	margin-top: 42rpx;
	
	.input1, .input2 {
		display: flex;
		align-items: center;
		width: 580rpx;
		height: 78rpx;
		// line-height: 78rpx;
		border: solid 1px #CCCCCC;
		border-radius: 40rpx;
		font-size: 13px;
		color: #999999;
		text-align: center;
		padding: 0 10rpx;
		margin-bottom: 26rpx;
	}
	.yzm {
		width: 580rpx;
		height: 78rpx;
		margin-bottom: 26rpx;
		display: flex;
		.input2 {
			width: calc(580rpx - 136rpx);
			border-top-right-radius: 0;
			border-bottom-right-radius: 0;
			font-size: 13px;
			color: #999999;
		}
		.btnGet {
			width: 136rpx;
			height: 78rpx;
			line-height: 78rpx;
			text-align: center;
			color: $default-text-color-white;
			font-size: 13px;
			background-color: $default-bg-black;
			border-top-right-radius: 40rpx;
			border-bottom-right-radius: 40rpx;
		}
	}
	
	.btnSubmit {
		color: #FFFFFF;
		height: 78rpx;
		line-height: 78rpx;
		border-radius: 40rpx;
		font-size: 30rpx;
		width: 580rpx;
		background-color: #1B1B30;
		margin-top: 110rpx;
	}
}
</style>