<template>
	<view class="content">
		<!-- 顶部选项卡 -->
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<!-- nav-item -->
			<view 
			 v-for="(item,index) in tabList" :key="item.name"
				class="uni-tab-item"
				:class="{current: index === tabCurrentIndex}"
				:id="'tab'+index"
				@click="changeTab(index)"
				
			>
		<!-- 	{{item.name}} -->
			<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{item.name}}</text>
			<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
		</scroll-view>
		<view class="addTag" @tap="openCustom"></view>
		<!-- <scroll-view id="nav-bar" class="scroll-h" :show-scrollbar="false" scroll-with-animation scroll-x :scroll-left="scrollLeft">
			<view v-for="(item,index) in tabList" :key="index" class="uni-tab-item" :class="[index === tabList.length-1 ? 'lastOne' : '']" :data-current="index" @tap="tabSelect(index,$event)">
				<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{item.name}}</text>
				<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
			<view class="addTag" @tap="openCustom"></view>
		</scroll-view> -->
		
		
		
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="74" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<!-- 内容部分 -->
			<swiper 
				id="swiper"
				class="swiper-box" 
				:duration="300" 
				:current="tabCurrentIndex" 
				@change="changeTab"
			>
				<!-- key 取不到值 导致下一层循环点击事件不触发 ↓ -->
				<!-- <swiper-item v-for="tabItem in tabList" :key="tabItem.index"> -->
				<swiper-item v-for="(tabItem, cIndex) in tabList" :key="cIndex">
					<scroll-view 
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<!-- 
							* 新闻列表 
							* 和nvue的区别只是需要把uni标签转为weex标签而已
							* class 和 style的绑定限制了一些语法，其他并没有不同
						-->
						<!-- {{tabItem.data}} -->
						<!-- {{cIndex}} --> 
						<!-- <image :src="tabItem.data[0].images" mode=""></image> -->
						<block v-for="(item, index) in tabItem.data" :key="item.id">
							
							<!-- 广告位 -->
							<block v-if="AdList.length >= 1 && index  == (AdList[0].advertisementSort > tabItem.data.length ? tabItem.data.length-1 : AdList[0].advertisementSort) && $store.state.ADstatus.spAD1">
								<!-- :width="AdList[0].AdWidth" -->
								<bwAdvertising :AdName="'spAD1'" :AdList="AdList[0]"></bwAdvertising>
							</block>
							<block v-if="AdList.length >= 2 && index  == (AdList[1].advertisementSort > tabItem.data.length ? tabItem.data.length-1 : AdList[1].advertisementSort) && $store.state.ADstatus.spAD2">
								<!-- :width="AdList[1].AdWidth" -->
								<bwAdvertising :AdName="'spAD2'" :AdList="AdList[1]"></bwAdvertising>
							</block>
							
							<view class="list-item">
								<!-- <view class="videoInfo" @tap="navToVideo(item)"> -->
								<view class="videoInfo">
									<view class="item-title">{{item.title}}</view>
									
									<view v-if="videoCurrentIndex === index && tabCurrentIndex === cIndex">
										<!-- 
										*- playType: 播放类型：1、播放器，2、iframe，3、页面跳转播放
										*- addressType: 链接类型：1、(videoUrl)原链接，2、(onLineLive)解析链接（当onLineLive为空时，提示视频失效）-->
										<!-- 播放器 -->
										<view class="videoBox" v-if="item.playType == 1">
											<bwVideoPlayer
											:height='480'
											:isPlaySource="item.isPlaySource"
											:videoType='item.videoType'
											:isLive="false"
											:sourceUrl="item.addressType == 1 ? item.videoUrl : item.onLineLive"
											:poster="item.images"
											:isAutoplay="isAutoplay"
											:videoMsg="item.videoMsg"
											@calculationNum="calculationNum(item, index)"
											@videoError="videoErrorfun"
											ref="videoplay"
											></bwVideoPlayer>
										</view>
										
										<!-- iframe -->
										<view class="iframe-view" v-if="item.playType == 2">
											<view class="noiframeSrc" v-if="item.addressType == 2 && !item.onLineLive">
												<text class="noiframeSrcText">暂未获取信号,请观看其他视频</text>
											</view>
											<iframe
												v-else
												scrolling='no'
												frameborder=0
												:src="item.addressType == 1 ? item.videoUrl : item.onLineLive"
											></iframe>
										</view>
										
									</view>
									
									<image v-else class="item-cover"
									mode="aspectFit"
									:src="item.images != null ? item.images : '../../static/default_img.png'"></image>
									
									
									<view v-if="videoCurrentIndex !== index" class="playBtn" @tap="playVideo(item, index)"></view>
									<!-- <view class="item-widget"> -->
										<!-- <view :class="item.muted ? 'toneOff' : 'toneOn'" @tap.stop="modifyMuted(index)"></view> -->
										<!-- <view class="duration">02:09</view> -->
									<!-- </view> -->
								</view>
								<view class="bottomBar" @tap="navToVideo(item)">
									<!-- 播放数 -->
									<view class="views">
										<view class="icon"></view>
										<view class="text">{{item.playNumber == null ? 0 : item.playNumber}}人看过</view>
									</view>
									<!-- 评论数 -->
									<view class="comments">
										<view class="icon"></view>
										<view class="text">{{item.commentNumber == null ? 0 : item.commentNumber}}</view>
									</view>
								</view>
							</view>
							
						</block>
						
						
						<!-- 上滑加载更多组件 -->
						<mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more>
						
					</scroll-view>
				</swiper-item>
			</swiper>
		</mix-pulldown-refresh>
		
	</view>
</template>
 
<script>
	import mixAdvert from '@/components/mix-advert/vue/mix-advert';
	import json from '@/json'
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	import bwVideoPlayer from '../component/bw-videoPlayer.vue'
	let that, windowWidth = 0, scrollTimer = false, tabBar;
	export default {
		components: {
			mixPulldownRefresh,
			mixLoadMore,
			mixAdvert,
			bwVideoPlayer
		},
		data() {
			return {
				tabCurrentIndex: 0, //当前选项卡索引
				videoCurrentIndex: -1, //当前播放器索引
				scrollLeft: 0, //顶部选项卡左滑距离
				enableScroll: true,
				total:100,
				offset:1,
				cardCur: 0,
				tabIndex: 0,	// sweiper所在页
				tabList: [
					// {id:'',name:'热门',type:'3',isFocus:true},
					{id:'', name:'全部', type:'5', sort: 0},
					// {id:'',name:'完赛',type:'4',isFocus:true},
				],
				tabListNo:[],
				tabListAll:[],
				
				isPlaySource:false,				isVideoLive:false,				isAutoplay:true,				videoMsg:'',				sourceUrl:'',
				
				AdList: [], // 广告列表
			}
		},
		computed: {
			advertNavUrl(){
				let data = {
					title: '测试跳转新闻详情',
					author: '测试作者',
					time: '2019-04-26 21:21'
				}
				return `/pages/details/details?data=${JSON.stringify(data)}`;
			} 
		},
		//async
		onLoad() {
			that = this;
			// 获取屏幕宽度
			windowWidth = uni.getSystemInfoSync().windowWidth;
			
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'sp'})
			.then( res => {
				that.AdList = res
				if (that.AdList.length > 0) {
					that.AdList[0].AdWidth = that.AdList[1].AdWidth = '710rpx';
					console.log('视频广告：',that.AdList);
				}
			})
			.catch( err => {
				console.log('err：',err);
			})
			
			
			// uni.removeStorage({
			//     key: 'videoTabList',
			//     success: function (res) {
			//         console.log('success');
			//     }
			// });
			uni.getStorage({
			    key: 'videoTabList',
			    success: function (res) {
					// tlist = res.data
					// console.log("查看本地缓存tab"+res);
					that.loadTabbars();
			    },
				fail:function(res){
					that.getNavigationList()
					.then( res => {
						that.loadTabbars();
					})
				}
			});
			
			uni.$on('setVideoEventList',(res)=>{
				that.tabList = res.selTagArr;
				that.tabListNo = res.unSelTagArr;
				console.log(res,that.tabList,that.tabListNo);
				
				if(that.tabCurrentIndex > that.tabList.length-1){
					that.tabCurrentIndex = that.tabList.length-1;
				}
				uni.setStorage({
				    key: 'videoTabList',
				    data: {
							rd:that.tabListAll,
							rdarr:that.tabList,
							nordarr:that.tabListNo,
						},
				    success: function () {
				        console.log('缓存数据success');
				    }
				});
			})
			
		},
		onHide() {
			console.log('视频-页面隐藏');
			this.videoCurrentIndex = -1; // 隐藏播放器
		},
		onReady(){
			// this.loadTabbars();
		},
		methods: {
			// 获取导航
			getNavigationList(){
				return new Promise( (res,rel) => {
					this.$req.req.queryNavigationList({
						navigationKey:'app_navigation_video'
					})
					.then( resp => {
						console.log("视频导航",resp.data.data)
						let rd = [{id:'', name:'全部', type:'5', sort: 0},  ...resp.data.data] ;
						let rdarr = rd.filter(item => item.sort < 20),
							nordarr = rd.filter(item => item.sort >= 20);
						uni.setStorage({
						    key: 'videoTabList',
						    data: {
									rd:rd,
									rdarr:rdarr,
									nordarr:nordarr,
								},
						    success: function () {
						        console.log('缓存数据success');
										res();
						    }
						});
					})
				})
			},
			
			// 获取分类
			loadTabbars(){
				let that = this;
				uni.getStorage({
				    key: 'videoTabList',
				    success: function (res) {
						that.tabListAll =res.data.rd;
						that.tabList = [...res.data.rdarr];
						that.tabListNo = res.data.nordarr;
						let tabarr = that.tabList;
						tabarr.forEach(item=>{
							item.data = [];
							item.loadMoreStatus = 0; //加载更多 0加载前，1加载中，2没有更多了
							item.isLastPage = false; // 是否为末页
							item.refreshing = false;
							item.offset = 1;
							item.liveRefreshing = false;
							// that.tabList.push(item)
						})
						that.tabList = tabarr;
						that.loadNewsList('add');
					}
				});
			},
			
			//新闻列表
			loadNewsList(type){
				let tabItem = this.tabList[this.tabCurrentIndex];
				// console.log("选中",tabItem)
				//type add 加载更多 refresh下拉刷新
				if(type === 'refresh'){
					tabItem.data = []; // 刷新前清空数组
					tabItem.offset = 1;
				}
				if(type === 'add'){
					if(tabItem.loadMoreStatus === 2 || tabItem.isLastPage){
						return;
					}
					if(tabItem.data&&tabItem.data.length > 0){
						tabItem.offset++;
					}
					tabItem.loadMoreStatus = 1;
				}
				
				// #ifdef APP-PLUS
				else if(type === 'refresh'){
					tabItem.refreshing = true;
				}
				// #endif
				
				let datas = {
					"id": tabItem.id||'',
					"limit": 20,
					"offset": tabItem.offset,
					"livePlatform": 1, // 所属平台 0:pc、1:手机
					"type": tabItem.type,
				}
				this.$req.reqc.queryVideo(datas)
				.then( res => {
					// console.log("视频",res)
					tabItem.isLastPage = res.data.data.isLastPage; // *更新分页状态
					
					let list = res.data.data&&res.data.data.list || [];
					this.total = res.data.data.total;
					list.forEach((item,index) => {
						let items = {
							id: item.id, // 视频Id
							title: item.liveTitle,
							images: item.imgHref ? ('https://images.weserv.nl/?url='+item.imgHref) : '../../static/default_img.png',
							
							videoUrl: item.playLive, // 原视频链接
							onLineLive: item.onLineLive, // 解析视频链接
							addressType: item.addressType, // 链接类型：1、原链接，2、解析链接（当onLineLive为空时，提示视频失效）
							playType: (item.playType != '' && item.playType != null) ? item.playType : 1, // 播放类型：1、播放器，2、iframe，3、页面跳转播放
							
							time:item.updatedTime,
							eventId: item.eventId,
							eventName: item.eventName,
							likeType: item.likeType,
							likeNumber: item.likeNumber,
							likeType:item.likeType,
							playNumber: item.playNumber >= 10000 ? ((item.playNumber/10000).toFixed(2) + '万') : item.playNumber, // .toFixed(2)保留小数点后两位
							commentNumber: item.commentNumber,
							muted: false, // 是否静音播放
							
							isPlayed: false, // 是否已播放
							isPlaySource: item.playLive != '' && item.playLive != null ? true : false, // 是否有播放源
							videoMsg: '暂无播放源', // 无播放源提示
							videoType: that.getVideoType(item.playLive), // 播放源格式
						}
						tabItem.data.push(items);
					})
					if(type === 'refresh'){
						setTimeout(function() {
							that.$refs.mixPulldownRefresh && that.$refs.mixPulldownRefresh.endPulldownRefresh();
						}, 10000);
						
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;
					}
					
					// 上滑加载、下拉刷新 处理状态 (返回数据长度小于零/数据长度与总数据量相等 → '没有更多数据了')
					if(type === 'add' || type === 'refresh'){
						// tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2 : 0;
						// console.log('是否为末页：',tabItem.isLastPage);
						tabItem.loadMoreStatus = tabItem.isLastPage ? 2 : 0;
					}
					
					// this.tabList[this.tabCurrentIndex] = tabItem;
					// console.log("全部数据",this.tabList)
					console.log("全部数据:",tabItem);
					
					this.$forceUpdate();
				})
			
			},
			
			// 播放源格式
			getVideoType(url) {
				if (url == '' || url == null) {
					return '';
				}
				/*匹配路径以什么结尾*/				let index = url.lastIndexOf("\."),				str = url.substring((index+1),url.url),				str2 = url.match('[^.]+(?!.*.)')[0],
				type;
								switch (str2){					case 'm3u8':						type = 'application/x-mpegURL';					break;				case 'mp4':						type = 'video/mp4';					break;					default:						type = 'application/x-mpegURL';					break;				}
				return type;
			},
			
			// 播放视频
			playVideo(item, index) {
				if (item.playType == 3) { // 页面跳转播放
					let url = '/pages/webview/webview',
						data = {
							id: item.id,
							title: item.title,
							images: item.images,
							sourceName: item.title ? item.title : '视频',
							sourcePath: item.addressType == 1 ? item.videoUrl : item.onLineLive,
						}
					uni.navigateTo({
						url: url+'?data=' + encodeURIComponent(JSON.stringify(data))
					})
					return;
				}
				
				console.log(item, index);
				this.videoCurrentIndex = index;
				this.$forceUpdate()
				
				// setTimeout(function() {
				// 	that.$refs.videoplay.onPlayerPlay();
				// }, 0);
				// that.beginVideo({				// 	// liveSourceName: item.title,				// 	analysisPlayPathWeb: item.videoUrl,
				// 	poster: item.images,				// 	isLive:true,				// 	isAutoplay:true,
				// })
			},
			
			/*初始化播放器*/			beginVideo(res){				that.isPlaySource = true;				that.sourceUrl = res.analysisPlayPathWeb				that.isVideoLive = true;				that.videoMsg = res.liveSourceName;				that.resultMsg =  res.liveSourceName;				this.$forceUpdate();				setTimeout(function() {					that.$refs.videoplay.initVideo({						url:res.analysisPlayPathWeb,
						poster: res.images || '',						isLive:res.isLive,						isAutoplay:res.isAutoplay,					});				}, 10);			},
			
			calculationNum: function (item, index) {
				let tabItem = this.tabList[this.tabCurrentIndex];
				// console.log(tabItem.data[index].isPlayed);
				if (item.isPlayed) {
					console.log('视频已播放');
				} else {
					console.log('视频未播放');
					
					// 修改视频播放状态
					tabItem.data[index].isPlayed = true;
					// 修改视频播放次数
					tabItem.data[index].playNumber++;
					this.$forceUpdate();
					
					let datas = {
						"liveId": item.id
					}
					this.$req.reqc.queryLiveContent(datas, {noToken: true})
					.then(res => {
						/* if (res.data.resultCode === 1 && res.statusCode === 200) {
							let livePlayNumber = res.data.data.livePlayNumber;
							// 修改视频播放状态
							tabItem.data[index].isPlayed = true;
							// 修改视频播放次数
							tabItem.data[index].playNumber = livePlayNumber;
							// 二维数组 开启强制渲染
							this.$forceUpdate();
						} */
					})
				}
			},
			
			// 视频详情
			navToVideo(item){
				uni.navigateTo({
					url: '/pages/video/vDetail?id=' + item.id + '&muted=' + item.muted
				})
			},
			
			// 视频声音控制
			modifyMuted: function (e) {
				this.tabList[this.tabCurrentIndex].data[e].muted = !this.tabList[this.tabCurrentIndex].data[e].muted;
				this.$forceUpdate();
			},
			
			// 自定义标签页
			openCustom: function () {
				uni.navigateTo({
					url: '/pages/index/newCustomTag?pageType=3&data='+
						encodeURIComponent(JSON.stringify(this.tabList)) + 
						'&nodata=' + encodeURIComponent(JSON.stringify(this.tabListNo))
				})
			},
			
			// 下拉刷新
			onPulldownReresh(){
				this.loadNewsList('refresh');
			},
			// 上滑加载
			loadMore(){
				this.loadNewsList('add');
			},

			// tab切换
			async changeTab(e){
				if(scrollTimer){
					//多次切换只执行最后一次
					clearTimeout(scrollTimer);
					scrollTimer = false;
				}
				let index = e;
				//e=number为点击切换，e=object为swiper滑动切换
				if(typeof e === 'object'){
					index = e.detail.current
					// console.log('视频标签切换');
					this.videoCurrentIndex = -1; // 隐藏播放器
				}
				if(typeof tabBar !== 'object'){
					tabBar = await this.getElSize("nav-bar")
				}
				//计算宽度相关
				let tabBarScrollLeft = tabBar.scrollLeft;
				let width = 0; 
				let nowWidth = 0;
				//获取可滑动总宽度
				for (let i = 0; i <= index; i++) {
					let result = await this.getElSize('tab' + i);
					width += result.width;
					if(i === index){
						nowWidth = result.width;
					}
				}
				if(typeof e === 'number'){
					//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
					this.tabCurrentIndex = index; 
				}
				//延迟300ms,等待swiper动画结束再修改tabbar
				scrollTimer = setTimeout(()=>{
					if (width - nowWidth/2 > windowWidth / 2) {
						//如果当前项越过中心点，将其放在屏幕中心
						this.scrollLeft = width - nowWidth/2 - windowWidth / 2;
					}else{
						this.scrollLeft = 0;
					}
					if(typeof e === 'object'){
						this.tabCurrentIndex = index; 
					}
					this.tabCurrentIndex = index;
					
					//第一次切换tab，动画结束后需要加载数据
					let tabItem = this.tabList[this.tabCurrentIndex];
					if(this.tabCurrentIndex !== 0 && tabItem.loaded !== true){
						this.loadNewsList('add');
						tabItem.loaded = true;
					}
				}, 300)
				
			},
			// 获得元素的size
			getElSize(id) { 
				return new Promise((res, rej) => {
					let el = uni.createSelectorQuery().select('#' + id);
					el.fields({
						size: true,
						scrollOffset: true,
						rect: true
					}, (data) => {
						res(data);
					}).exec();
				});
			},
			// 设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			},
		}
	}
</script>

<style lang='scss' scoped>
	
	page, .content{
		background-color: #f8f8f8;
		height: 100%;
		overflow: hidden;
		width: 100vw;
	}

	/* 顶部tabbar */
	
	.addTag {
		position: absolute;
		top: 0;
		right: 0;
		width: 80rpx;
		height: 72rpx;
		background: linear-gradient(to right, rgba(255,255,255,0), rgba(255,255,255,1));
		background-size: cover;
		background-image: url(../../static/images/home_add.png);
		z-index: 11;
	}
	.nav-bar{
		/* 标签栏顶部固定 → 防止 iPhone端 出现下拉移位的问题 */
		position: fixed;
		top: 0;
		
		position: relative;
		z-index: 10;
		width: 100%;
		height: 74upx;
		box-sizing: border-box;
		flex-direction: row;
		white-space: nowrap;
		background-color: #FFFFFF;
		border-bottom: 1px solid #F2F2F2;
	}
	.nav-bar .uni-tab-item:last-child{
		margin-right: 80upx;
	}
	
	
	/* 视频项 */
	.list-item {
		height: 602rpx;
		margin: 12rpx 0;
		border-radius: 10rpx;
		box-shadow: 3px 2px 4px rgba(0, 0, 0, .2);
		overflow: hidden;
		position: relative;
		
		.videoInfo {
			width: 100%;
			height: 546rpx;
			position: relative;
			/* 封面图 */
			.item-cover{
				width: 100%;
				height: 480rpx;
				background-color: #000000;
			}
			
			/* 播放器 */
			.videoBox {
				width: 100%;
				height: 480rpx;
			}
			/* iframe */
			.iframe-view{
				width: 100%;
				height: 480rpx;
				/* background-color: #000000; */
				overflow: auto;
				/* -webkit-overflow-scrolling: touch; */
				/* -webkit-overflow-scrolling: touch; */
				/* -webkit-overflow:auto; */
				iframe{
					width: 100%;
					height: 100%;
					overflow: auto;
					/* -webkit-overflow-scrolling: touch; */
					/* -webkit-overflow-scrolling: touch; */
					/* -webkit-overflow:auto; */
				}
			}
			.noiframeSrc{
				width: 100%;
				height: 480rpx;
				background-color: #1B1B30;
				align-items: center;
				justify-content: center;
			}
			.noiframeSrcText{
				color: #FFFFFF;
			}
			
			
			/* 标题 */
			.item-title{
				/* position: absolute; */
				/* top: 0; */
				width: 100%;
				height: 66rpx;
				line-height: 66rpx;
				padding-left: 17rpx;
				background-color: rgba(27,27,48,.9);
				font-size: 15px;
				color: #FFFFFF;
				z-index: 99999;
				/* 超出1行时，隐藏并显示省略符 */
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				-webkit-line-clamp: 1; /* 行数控制 */
				-webkit-box-orient: vertical;
			}
			/* 播放按钮 */
			.playBtn {
				position: absolute;
				top: 55%;
				left: 50%;
				transform: translate(-50%,-50%);
				width: 160rpx;
				height: 160rpx;
				/* background-color: rgba(0,0,0,.2); */
				border-radius: 50%;
				background-size: cover;
				background-image: url(../../static/images/playButton.png);
			}
			/* 底部组件按钮 */
			.item-widget {
				position: absolute;
				bottom: 0;
				z-index: 100;
				display: flex;
				justify-content: space-between;
				align-items: center;
				width: 100%;
				height: 66rpx;
				box-sizing: border-box;
				padding: 0 30rpx;
				.toneOn {
					width: 30rpx;
					height: 28rpx;
					background-size: cover;
					background-image: url(../../static/images/video_sound_on.png);
				}
				.toneOff {
					width: 30rpx;
					height: 28rpx;
					background-size: cover;
					background-image: url(../../static/images/video_sound_off.png);
				}
				.duration {
					min-width: 70rpx;
					height: 26rpx;
					line-height: 26rpx;
					text-align: center;
					border-radius: 13rpx;
					font-size: 9px;
					background-color: rgba(255,255,255,.4);
				}
			}
		}
		/* 底部栏 */
		.bottomBar {
			display: flex;
			justify-content: space-between;
			align-items: center;
			width: 100%;
			height: 66rpx;
			box-sizing: border-box;
			padding: 0 24rpx;
			.views, .comments {
				display: flex;
				align-items: center;
			}
			.icon {
				height: 22rpx;
				background-size: cover;
			}
			.text {
				font-size: 11px;
				color: #666666;
				margin-left: 10rpx;
			}
			.views{
				.icon {
					/* 宽高比：(w)30 / (h)20 = 1.5 */
					width: 36rpx;
					height: 24rpx;
					background-size: 90% 90%;
					background-repeat: no-repeat;
					/* background-position: center; */
					background-image: url(../../static/images/video_eye.png);
				}
			}
			.comments{
				.icon {
					width: 24rpx;
					background-image: url(../../static/images/video_comment.png);
				}
			}
		}
	}
	
	
	/* 可滚动窗体高度（swiper外层刷新组件高度），100vh(相对于视窗的高度)  */
	/* calc(100vh - 38px - 50px)：100vh(整个浏览器窗口高度) - 38px(顶部标签滑动栏高度) - 50px(底部tabBar栏高度(固定)) 的大小 */
	/* .panel-content {
		height: calc(100vh - 38px - 50px) !important;
		max-height: calc(100vh - 38px - 50px) !important;
	} */
	
	.swiper-box{
		/* height: 100%; */
		height: calc(100vh - 74rpx - 100rpx - 88rpx);
		/* padding-bottom: 60rpx; */
	}

	.panel-scroll-box{
		height: 100%;
		padding: 0 20rpx;
	}
	
	.uni-tab-item {
		display: inline-block;
		flex-wrap: nowrap;
		padding-left: 14.5px;
		padding-right: 14.5px;
		/* border: 1px solid red; */
		position: relative;
	}
	
	/* 滚动tab 标签 */
	.uni-tab-item-title {
		color: #999999;
		font-size: 12px;
		height: 38px;
		line-height: 38px;
		flex-wrap: nowrap;
		white-space: nowrap;
	}
	.uni-tab-item-title-active {
		color: #000000;
	}
	/* 滚动tab 底部选中条 */
	.uni-tab-item-border {
		position: absolute;
		top: 85%;
		left: 50%;
		transform: translate(-50%,-50%);
	}
	.uni-tab-item-border-active {
		width: 14px;
		height: 2px;
		background-color: #000000;
	}
	
	.swiper {
		/* display: block; */
		height: 100%;
	}
	
	.swiper-item {
		display: flex;
		flex: 1;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
		box-sizing: border-box;
		
		.list {
			width: 100%;
			/* height: 100%; */
			/* 状态栏的高度为 var(--status-bar-height) 此变量为uni-app框架提供仅在在css生效 */
			/* 38px → 标签栏38px */
			height: calc(100% - 74rpx);
		}
	}
	
</style>
