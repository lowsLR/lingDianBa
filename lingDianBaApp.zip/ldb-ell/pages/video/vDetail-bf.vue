<template>
	<view class="container">
		<!-- vh and vw:相对于视口的高度和宽度,而不是父元素的(CSS百分比是相对于包含它的最近的父元素的高度和宽度) -->
		<scroll-view class="scroll" scroll-y @scrolltolower="loadMore">
			<view class="scroll-content">
				<view class="backButton" @tap="backButton"></view>
				<!-- 播放器 -->
				<!-- @error="videoErrorCallback"
					:poster="videoData.images"-->
				<!-- muted	false 是否静音播放 -->
				<!-- <video :src="videoData.sourceLive" controls="true" :poster="videoData.liveImg != null ? ('https://images.weserv.nl/?url='+videoData.liveImg) : 'static/default_img.png'" :muted="muteState"></video> -->
				
				<!-- <view class="videoBox">
					<view class="video-js" ref="video" :style="{width: '100vw',height: '210px'}"></view>
				</view> -->
				<!-- <videoPlayer
				:height="420"
				:isPlaySource="isPlaySource"
				:isLive="isVideoLive"
				:sourceUrl="sourceUrl"
				:isAutoplay="isAutoplay"
				:videoMsg="videoMsg"
				ref="videoplay"
				>
				</videoPlayer> -->
				
				<bwVideoPlayerShiPin
				:isPlaySource="isPlaySource"
				:isLive="isVideoLive"
				:sourceUrl="sourceUrl"
				:isAutoplay="isAutoplay"
				:videoMsg="videoMsg"
				:playSourcePathIndex="playSourcePathIndex"
				:playSourcePathTime="playSourcePathTime"
				@playTimeChange="playTimeChange"
				ref="videoplay"
				></bwVideoPlayerShiPin>
				
				<!-- 信号源 -->
				<!-- <view class="video-signal">
					<scroll-view class="signal-nav-bar" scroll-x="true" >
						<view class="video-signal-item"
							v-for="(item, index) in sourcePath" :key="index"
							:class="index === tabCurrentIndex ? 'active' : ''"
							@click="setSignal(item, index)">
							<text class="title">{{item.sourceName}}</text>
						</view>
					</scroll-view>
				</view> -->
				<!-- @videoError="videoErrorfun" -->
				<!-- 视频信息 -->
				<view class="videoInfo">
					<view class="title">{{videoData.liveTitle}}</view>
					<view class="info-item">
						<!-- .toFixed(2)保留小数点后两位 -->
						<text>{{videoData.createTime | filtersTime}} &emsp; {{videoData.livePlayNumber != null ? (videoData.livePlayNumber >= 10000 ? ((videoData.livePlayNumber/10000).toFixed(2) + '万') : videoData.livePlayNumber) : 0}}次播放</text>
						<view class="right">
							<view class="zan" @tap="dianZan(templikeType)">
								<!-- <view class="confirm-btn icon iconfont" :class="templikeType == 0 ? '' : 'like'">&#xe603;</view> -->
								<view class="icon zanIcon" :class="templikeType == 0 ? '' : 'like'"></view>
								<text>{{templikeNum != null ? templikeNum : 0}}</text>
							</view>
							<view class="comment">
								<view class="icon commentIcon"></view>
								<text>{{tempCommentNum}}</text>
								<!-- <text>{{videoData.liveContentNumber}}</text> -->
							</view>
						</view>
					</view>
				</view>
				
				<!-- 广告位 -->
				<block v-if="AdList.length >= 1 && $store.state.ADstatus.spxqAD">
					<view class="boxMargin"></view>
					<bwAdvertising :AdName="'spxqAD'" :AdList="AdList[0]"></bwAdvertising>
				</block>
				
				<!-- 评论区 -->
				<comments :cid="id" :comments="comments" :noToken="noToken" :type="ctype" :total="total"></comments>
				<!-- 加载更多 -->
				<mix-load-more :status="loadMoreStatus"></mix-load-more>
			</view>
		</scroll-view>
		
		<!-- 输入框 -->
		<view class="" style="width: 100%; height: 88rpx;"></view>
		<view class="inputBox">
			<input confirm-type="done" @confirm="search" class="multiline" v-model="commentsInput" @focus="focusTextArea" @blur="bindTextArea" value="" placeholder="发表评论..." @input="MonitorIn" placeholder-style="color: #333333;" />
			<view @tap="search" class="submit" v-if="submitBtn">提交</view>
			<!-- <view v-else @tap="dianZan(templikeType)"  class="confirm-btn icon iconfont" :class="templikeType==0?'':'like'">&#xe603;</view> -->
			<view v-else @tap="dianZan(templikeType)"  class="confirm-btn icon iconfont" :class="templikeType==0?'':'like'"></view>
		</view>
	</view>
</template>

<script>
	import json from '@/json';
	import comments from "../component/comments.vue"
	import bwAdvertising from "../component/bw-advertising.vue"
	 import mixLoadMore from '@/components/mix-load-more/mix-load-more'
	 // import videoPlayer from '../component/videoPlayer.vue'
	 import bwVideoPlayerShiPin from '../component/bw-videoPlayer-shipin.vue'
	let that;
	export default {
		components: {
			comments,
			mixLoadMore,
			// videoPlayer,
			bwVideoPlayerShiPin,
			bwAdvertising
		},
		data() {
			return {
				isPlaySource:false,
				isVideoLive:false,
				isAutoplay:true,
				videoMsg:'',
				sourceUrl:'',
				
				id: null,
				muteState: false,
				templikeType: null,
				templikeNum: null,
				tempCommentNum: null,
				videoData: {},
				ctype:2,
				comments: [],
				
				loading: true,
				loadMoreStatus:0,
				offset:1,//评论页
				total:0,//总条数
				commentsInput:'',
				submitBtn: false,
				
				noToken: false,
				
				AdList: [], // 广告列表
				
				playSourcePathIndex:0,//视频播放分段
				playSourcePathTime:0,//视频播放分段的时间
				videoCacheArr:[],//视频缓存数组
				tabCurrentIndex:0,
				sourcePath:[
					{sourceName:1},
						{sourceName:2},
							{sourceName:3},
				],
			};
		},
		onHide(){
				this.setVideoCache();
		},
		onLoad(options) {
			that = this;
			this.id = options.id;
			this.muteState = JSON.parse(options.muted);
			console.log('视频id：',this.id,' 静音🔕状态：',this.muteState);
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'spxq'})
			.then( res => {
				that.AdList = res
				console.log('视频详情广告：',that.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
			
			// token验证
			this.verifyToken().then( () => {
				console.log('noToken状态：',that.noToken);
				
				uni.getStorage({
				    key: 'videoCache',
				    success:  res => {
							if(res.data){
								this.videoCacheArr = res.data;
							}
							let i = this.videoCacheArr.findIndex(item=>item.videoId == 'videoId'+this.id)
							if(i != -1){
			
								this.playSourcePathIndex = this.videoCacheArr[i].value.index || 0;
								this.playSourcePathTime = this.videoCacheArr[i].value.time || 0;
							}
							
							// 查询视频内容
							this.queryVideoInfo(this.id);
				    }
				});
			});
			
			uni.$on('setComments',function(arr){
			  that.comments = arr;
			})
			
			uni.$on('modifyLoginStatus',() => {
				console.log('监听到事件来自 modifyLoginStatus ，修改登录状态');
				// token验证
				this.verifyToken().then(() => {
					console.log('**************************noToken状态：', that.noToken);
					this.queryVideoInfo(this.id);
				});
			})
			
		},
		onShow() {
			console.log('视频详情页面显示');
			
		},
		onUnload() {
			this.setVideoCache();
			
			try{
				that.$refs.videoplay.videoDispose();
			}catch(e){
				//TODO handle the exception
			}
			uni.$off('setComments')
		},
		onBackPress(options) {
			let page = getCurrentPages();
			// #ifdef H5
			if (options.from === 'navigateBack') {
				if(page.length < 2){
					window.history.back()
					// history.go(-1)
					// history.back(-1)
					// history.back()
					return true;
				}
				return false;
			}
			// #endif
			return false;
		},
		methods: {
			setSignal(item,index){   
			
			},
			/**
			 * 通知缓存
			 * @param {Object} e
			 */
			playTimeChange(e){
				this.playSourcePathIndex = e.index;
				this.playSourcePathTime = e.time;
			},
			/**
			 * 设置视频缓存
			 */
			setVideoCache(){
					let i = this.videoCacheArr.findIndex(item=>item.videoId == 'videoId'+this.id)
					let value = {
						index:this.playSourcePathIndex,
						time:this.playSourcePathTime,
					}
					if(i != -1){
						this.videoCacheArr[i].value = value;
					}else{
						let obj = {
							videoId:'videoId'+this.id,
							value:value
						}
						this.videoCacheArr.push(obj);
					}
				uni.setStorage({
						key: 'videoCache',
						data: this.videoCacheArr,
						success: function () {
								console.log('success');
						}
				});
			},
			
			// 验证token
			verifyToken() {
				return new Promise((resolve, reject) => {
				    // ... some code
					that.noToken = false;
					this.$req.reqc.verificationToken()
					.then( res => {
						if (res.statusCode === 200 && res.data.resultCode === 1) {
							console.log('token状态：',res.data.resultMsg);
						} else {
							console.log('token失效');
							that.noToken = true;
						}
						
						resolve();
					})
					.catch( err => {
						console.log('错误的err：',err);
						that.noToken = true;
						
						resolve();
					})
				})
			},
			
			// 查询视频内容
			queryVideoInfo: function (id){
				let that = this;
				let datas = {
					"liveId": this.id
				}
				// console.log(datas);
				this.$req.reqc.queryLiveContent(datas, {noToken: that.noToken})
				.then(res => {
					that.templikeType = res.data.data.likeType;
					that.templikeNum = res.data.data.liveLikeNumber;
					that.tempCommentNum = res.data.data.liveContentNumber;
					that.videoData = res.data.data;
					console.log('视频数据:',that.videoData)
					
					// // #ifdef H5
					// var video = document.createElement('video')  
					// video.id = 'video'  
					// video.style = 'width: 100vw;height: 210px;'  
					// video.controls = true  
					// video.poster = that.videoData.liveImg != null ? ('https://images.weserv.nl/?url='+that.videoData.liveImg) : 'static/default_img.png'
					// var source = document.createElement('source')  
					// source.src = that.videoData.sourceLive
					// // source.src = 'http://ivi.bupt.edu.cn/hls/hunantv.m3u8'
					// // source.src = 'http://ivi.bupt.edu.cn/hls/hunanhd.m3u8'
					// // source.src = 'https://media.w3.org/2010/05/sintel/trailer.mp4'
					// // source.src = 'http://yf.ugc.v.cztv.com/cztv/ugcvod/2018/04/14/A98CD7B26B06D94A5CEA56AA7D723572/h264_800k_mp4.mp4_playlist.m3u8'
					// video.appendChild(source)  
					// that.$refs.video.$el.appendChild(video)  
					// videojs('video')  
					// // #endif  
					
					that.isPlaySource = true;
					setTimeout(function() {
						that.$refs.videoplay.initVideo({
							url:that.videoData.sourceLive,
							isLive:false,
							isAutoplay:false,
							cover:that.videoData.liveImg != null ? ('https://images.weserv.nl/?url='+that.videoData.liveImg) : 'static/default_img.png'
						});
					}, 10);
					
					
					this.loadEvaList() // 获取数据后 加载评论列表
				})
			},
			// 点赞
			dianZan: function (type){
				let that = this;
				let datas = {
				    "liveCommentType": this.templikeType,
				    "liveId": this.videoData.id
				}
				// console.log(datas);
				this.$req.reqc.updateLivelike(datas)
				.then(res => {
					// console.log("点赞",res)
					if (res.data.resultCode === 1) {
						that.templikeType == 0 ? that.templikeType = 1 : that.templikeType = 0;
						that.templikeType == 1 ? that.templikeNum++ : that.templikeNum--;
					} else {
						uni.showToast({
							icon: 'none',
							title: res.data.resultMsg
						})
					}
				})
			},
			//上滑加载
			loadMore(){
				this.loadEvaList('add');
			},
			//获取评论列表
			async loadEvaList(type) {
				//this.evaList = await json.evaList;
				if(type === 'add'){
					if(that.loadMoreStatus === 2){
						return;
					}
					if(that.comments.length > 0){
						that.offset++;
					}
					that.loadMoreStatus = 1;
				}
				let datas = {
					    "id": this.videoData.id,
						"limit": 20,
						"offset": that.offset,
						"sortTypeId": 1,
					    "typeId": 2
				}
				this.$req.req.queryMainComment(datas, {noToken: that.noToken})
				.then( res => {
					console.log("评论列表",res);
					// that.comments = that.comments.concat(res.data.data.list)
					this.comments = res.data.data.list;
					console.log('arr',that.comments);
					that.total = res.data.data.total;
				})
				//上滑加载 处理状态
				// if(type === 'add'){
					that.loadMoreStatus = that.comments.length >= that.total ? 2 : 0;
				// }
			},
			
			// 发布评论
			search(){
				if(that.commentsInput == ''){
					uni.showToast({
						title:"请输入评论内容",
						icon:"none"
					})
					return;
				}
				let datas = {
						"commentContent": that.commentsInput,
						"id": that.id,
						"matchType": "2"
				}
				that.$req.req.createMainComment(datas)
				.then( res => {
					console.log(res)
					uni.showToast({
						title:"评论发送成功！",
						icon:"none"
					})
					that.commentsInput = '';
					that.submitBtn = false;
					that.loadEvaList();
				})
			},
			// 输入框聚焦
			focusTextArea: function (e) {
				this.bindStyle = true;
			},
			// 输入框失去焦点
			bindTextArea: function (e) {
				// console.log(e.detail.value,"长度："+e.detail.value.length)
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				// console.log(val)
				// 注释：indexOf() 方法对大小写敏感！
				// 注释：如果要检索的字符串值没有出现，则该方法返回 -1
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.bindStyle = false;
					this.submitBtn = false;
				}
			},
			// 输入监听
			MonitorIn: function (e) {
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.submitBtn = false;
				}
			},
			
			// videoErrorCallback: function(e) {
			// 	uni.showToast({
			// 		icon: "none",
			// 		title: '播放链接有误'
			// 	})
			// },
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				uni.navigateBack();
			},
		},
		filters: {
			filtersTime: function(value) {
				if (value) {
					 // 这里以 -，:，空格 来拆分字符串
					let time = value.split(/[-: ]/); // ["2019", "12", "04", "17", "00", "00"]
					time = time[1] + '-' + time[2] + '\xa0' + time[3] + ':' + time[4]
					// console.log('截取时间：',time);
					return time;
				}
			}
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
	}
	.video-signal{
		height: 88rpx;
		background-color: #FFFFFF;
		
		.signal-nav-bar{
			height: 88rpx;
			/* padding: 0 40rpx; */
			white-space: nowrap;
			
			.video-signal-item{
				min-width: 100rpx;
				/* max-width: 240rpx; */
				padding: 0 20rpx;
				overflow: hidden;
				height: 44rpx;
				margin: 22rpx 40rpx 0 0;
				display: inline-block;
				line-height: 44rpx;
				text-align: center;
				border-radius: 22rpx;
				border: 1px solid #1B1B30;
				font-size: 20rpx;
				color: #1B1B30;
			}
			.video-signal-item:first-child{
				margin-left: 40rpx;
			}
			.active {
				color: #FFFFFF;
				background-color: #1B1B30;
			}
		}
	}
	.container {
		width: 100%;
		// display: flex;
		// flex-direction: column;
		// align-items: center;
		// justify-content: center;
		overflow: hidden;
		background-color: #FFFFFF;
	}
	
	.scroll {
		flex: 1;
		position: relative;
		background-color: #f8f8f8;
		/* vh and vw:相对于视口的高度和宽度,而不是父元素的(CSS百分比是相对于包含它的最近的父元素的高度和宽度) */
		/* 用错地方，致使页面评论无法完成上拉显示(iPhone端) ↓ */
		/* height: 100vh; */
		height: 100%;
	}
	.scroll-content {
		display: flex;
		flex-direction: column;
	}
	
	.like{
		// color: #FF8400 !important;
		color: #007AFF !important;
	}
	
	/* 返回按钮 */
	.backButton {
		position: absolute;
		top: 66rpx;
		left: 36rpx;
		width: 44rpx;
		height: 44rpx;
		background-size: cover;
		background-image: url(../../static/images/video_back_w.png);
		z-index: 999;
	}
	
	/* 视频播放器 */
	.videoBox {
		width: 100%;
		height: 420rpx;
		video {
			width: 100%;
			height: 420rpx;
		}
	}
	/* 视频信息 */
	.videoInfo {
		height: auto;
		box-sizing: border-box;
		padding: 0 21rpx;
		overflow: hidden;
		
		.title {
			margin-top: 20rpx;
			font-size: 17px;
			line-height: 26px;
			color: #000000;
			
			/* 超出1行时，隐藏并显示省略符 */
			/* overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box; */
			/* -webkit-line-clamp: 1; */ /* 行数控制 */
			/* -webkit-box-orient: vertical; */
		}
		.info-item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 11px;
			color: #666666;
			padding-bottom: 12rpx;
			
			.right, .zan, .comment {
				display: flex;
				justify-content: space-between;
				align-items: center;
			}
			.zanIcon {
				width: 25rpx;
				height: 25rpx;
				margin: 0 8rpx 4rpx 26rpx;
				background-size: cover;
				background-image: url(../../static/iconSet/zan_def2.png);
			}
			.like {
				background-image: url(../../static/iconSet/zan_active.png);
			}
			.commentIcon {
				width: 24rpx;
				height: 22rpx;
				margin: 0 8rpx 4rpx 26rpx;
				background-size: cover;
				background-image: url(../../static/images/video_comment.png);
			}
		}
	}
	
	/* 底部 文本框 */
		.inputBox {
			// width: 100vw;
			width: 100%;
			min-height: 88rpx;
			box-sizing: border-box;
			padding: 14rpx 0;
			// box-shadow: 0 -1px 3px rgba(0, 0, 0, .04);
			background-color: #FFFFFF;
			// border-top: 1px solid #EAEAEA;
			position: relative;
			position: fixed;
			bottom: 0;
			z-index: 100;
			display: flex;
			align-items: center;
			/* justify-content: space-between; */
			.multiline {
				width: 80%;
				padding: 0px;
				margin: 0px;
				box-sizing: border-box;
				height: 68rpx;
				margin: 0 20rpx;
				padding: 12rpx 26rpx;
				border-radius: 12rpx;
				background-color: #F8F8F8;
				border: 1px solid #EAEAEA;
				font-size: 13px;
				color: #333333;
			}
			// 输入框底部 点赞按钮
			.confirm-btn {
				/* position: absolute;
				right: 30rpx; */
				width: 62rpx;
				height: 62rpx;
				background-size: cover;
				background-image: url(../../static/iconSet/zan_def2.png);
			}
			.like {
				background-image: url(../../static/iconSet/zan_active.png);
			}
			
			/* 提交按钮 */
			.submit {
				/* position: absolute;
				top: 50%;
				right: 10rpx;
				transform: translateY(-50%); */
				width: 100rpx;
				height: 55rpx;
				line-height: 55rpx;
				text-align: center;
				border-radius: 4rpx;
				color: #FFFFFF;
				background-color: #1B1B30;
			}
		}
</style>
