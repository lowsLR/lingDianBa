<template>
	<view class="container">
		<!-- vh and vw:相对于视口的高度和宽度,而不是父元素的(CSS百分比是相对于包含它的最近的父元素的高度和宽度) -->
		<scroll-view class="scroll" scroll-y @scrolltolower="loadMore">
			<view class="scroll-content">
				<view class="backButton" @tap="backButton"></view>
				<!-- 播放器 -->
				<!-- @error="videoErrorCallback"
					:poster="videoData.images"-->
				<!-- muted	false 是否静音播放 -->
				<!-- <video :src="videoData.sourceLive" controls="true" :poster="videoData.liveImg != null ? ('https://images.weserv.nl/?url='+videoData.liveImg) : 'static/default_img.png'" :muted="muteState"></video> -->
				
				<!-- <view class="videoBox">
					<view class="video-js" ref="video" :style="{width: '100vw',height: '210px'}"></view>
				</view> -->
				<!-- <videoPlayer
				:height="420"
				:isPlaySource="isPlaySource"
				:isLive="isVideoLive"
				:sourceUrl="sourceUrl"
				:isAutoplay="isAutoplay"
				:videoMsg="videoMsg"
				ref="videoplay"
				>
				</videoPlayer> -->
				
				<!-- 播放器 -->
				<bwVideoPlayer
				v-if="videoData.addressType == 1 || (videoData.addressType == 2 && videoData.playType == 1)"
				:isPlaySource="isPlaySource"				:isLive="isVideoLive"				:sourceUrl="sourceUrl"				:isAutoplay="isAutoplay"				:videoMsg="videoMsg"
				ref="videoplay"
				></bwVideoPlayer>
				
				<!-- iframe -->
				<view v-if="videoData.addressType == 2">
					<view v-if="videoData.onLineLive">
						<!-- iframe -->
						<iframe
							v-if="videoData.playType == 2"
							class="iframe-view"
							scrolling='no'
							frameborder=0
							:src="videoData.onLineLive"
						></iframe>
						
						<!-- 跳转 -->
						<view class="url-view" v-if="videoData.playType == 3">
							<image class="url-view-img" :src="videoData.liveImg" mode="aspectFit"></image>
							<view class="url-view-btn" @tap="playVideo">
								<text>跳转至视频播放页</text>
							</view>
						</view>
					</view>
					<view class="noiframeSrc" v-else>
						<text class="noiframeSrcText">暂未获取信号,请观看其他视频</text>
					</view>
				</view>
				
				
				<!-- @videoError="videoErrorfun" -->
				<!-- 视频信息 -->
				<view class="videoInfo">
					<view class="title">{{videoData.liveTitle}}</view>
					<view class="info-item">
						<!-- .toFixed(2)保留小数点后两位 -->
						<text>{{videoData.createTime | filtersTime}} &emsp; {{videoData.livePlayNumber != null ? (videoData.livePlayNumber >= 10000 ? ((videoData.livePlayNumber/10000).toFixed(2) + '万') : videoData.livePlayNumber) : 0}}次播放</text>
						<view class="right">
							<view class="zan" @tap="dianZan(templikeType)">
								<!-- <view class="confirm-btn icon iconfont" :class="templikeType == 0 ? '' : 'like'">&#xe603;</view> -->
								<view class="icon zanIcon" :class="templikeType == 0 ? '' : 'like'"></view>
								<text>{{templikeNum != null ? templikeNum : 0}}</text>
							</view>
							<view class="comment">
								<view class="icon commentIcon"></view>
								<text>{{tempCommentNum}}</text>
								<!-- <text>{{videoData.liveContentNumber}}</text> -->
							</view>
						</view>
					</view>
				</view>
				
				<!-- 广告位 -->
				<block v-if="AdList.length >= 1 && $store.state.ADstatus.spxqAD">
					<view class="boxMargin"></view>
					<bwAdvertising :AdName="'spxqAD'" :AdList="AdList[0]"></bwAdvertising>
				</block>
				
				<!-- 评论区 -->
				<comments :cid="id" :comments="comments" :noToken="noToken" :type="ctype" :total="total"></comments>
				<!-- 加载更多 -->
				<mix-load-more :status="loadMoreStatus"></mix-load-more>
			</view>
		</scroll-view>
		
		<!-- 输入框 -->
		<view class="" style="width: 100%; height: 88rpx;"></view>
		<view class="inputBox">
			<input confirm-type="done" @confirm="search" class="multiline" v-model="commentsInput" @focus="focusTextArea" @blur="bindTextArea" value="" placeholder="发表评论..." @input="MonitorIn" placeholder-style="color: #333333;" />
			<view @tap="search" class="submit" v-if="submitBtn">提交</view>
			<!-- <view v-else @tap="dianZan(templikeType)"  class="confirm-btn icon iconfont" :class="templikeType==0?'':'like'">&#xe603;</view> -->
			<view v-else @tap="dianZan(templikeType)"  class="confirm-btn icon iconfont" :class="templikeType==0?'':'like'"></view>
		</view>
	</view>
</template>

<script>
	import json from '@/json';
	import comments from "../component/comments.vue"
	import bwAdvertising from "../component/bw-advertising.vue"
	 import mixLoadMore from '@/components/mix-load-more/mix-load-more'
	 // import videoPlayer from '../component/videoPlayer.vue'
	 import bwVideoPlayer from '../component/bw-videoPlayer.vue'
	let that;
	export default {
		components: {
			comments,
			mixLoadMore,
			// videoPlayer,
			bwVideoPlayer,
			bwAdvertising
		},
		data() {
			return {
				isPlaySource:false,
				isVideoLive:false,
				isAutoplay:true,
				videoMsg:'',
				sourceUrl:'',
				
				id: null,
				muteState: false,
				templikeType: null,
				templikeNum: null,
				tempCommentNum: null,
				videoData: {},
				ctype:2,
				comments: [],
				
				loading: true,
				loadMoreStatus:0,
				offset:1,//评论页
				total:0,//总条数
				commentsInput:'',
				submitBtn: false,
				
				noToken: false,
				
				AdList: [], // 广告列表
			};
		},
		onLoad(options) {
			that = this;
			this.id = options.id;
			this.muteState = JSON.parse(options.muted);
			console.log('视频id：',this.id,' 静音🔕状态：',this.muteState);
			
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'spxq'})
			.then( res => {
				that.AdList = res
				console.log('视频详情广告：',that.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
			
			
			// token验证
			this.verifyToken().then( () => {
				console.log('noToken状态：',that.noToken);
				// 查询视频内容
				this.queryVideoInfo(this.id);
			});
			
			uni.$on('setComments',function(arr){
			  that.comments = arr;
			})
			
			uni.$on('modifyLoginStatus',() => {
				console.log('监听到事件来自 modifyLoginStatus ，修改登录状态');
				// token验证
				this.verifyToken().then(() => {
					console.log('**************************noToken状态：', that.noToken);
					this.queryVideoInfo(this.id);
				});
			})
			
		},
		onShow() {
			console.log('视频详情页面显示');
			
		},
		onUnload() {
			try{
				that.$refs.videoplay.videoDispose();
			}catch(e){
				//TODO handle the exception
			}
			uni.$off('setComments')
		},
		onBackPress(options) {
			let page = getCurrentPages();
			// #ifdef H5
			if (options.from === 'navigateBack') {
				if(page.length < 2){
					window.history.back()
					// history.go(-1)
					// history.back(-1)
					// history.back()
					return true;
				}
				return false;
			}
			// #endif
			return false;
		},
		methods: {
			// 验证token
			verifyToken() {
				return new Promise((resolve, reject) => {
				    // ... some code
					that.noToken = false;
					this.$req.reqc.verificationToken()
					.then( res => {
						if (res.statusCode === 200 && res.data.resultCode === 1) {
							// console.log('token状态：',res.data.resultMsg);
						} else {
							console.log('token失效');
							that.noToken = true;
						}
						
						resolve();
					})
					.catch( err => {
						console.log('错误的err：',err);
						that.noToken = true;
						
						resolve();
					})
				})
			},
			
			// 查询视频内容
			queryVideoInfo: function (id){
				let that = this;
				let datas = {
				    "liveId": ~~this.id,
					"livePlatform": 1, // 所属平台 0:pc、1:手机
				}
				// console.log(datas);
				this.$req.reqc.queryLiveContent(datas, {noToken: that.noToken})
				.then(res => {
					// console.log(res);
					that.templikeType = res.data.data.likeType;
					that.templikeNum = res.data.data.liveLikeNumber;
					that.tempCommentNum = res.data.data.liveContentNumber;
					that.videoData = res.data.data;
					that.videoData.playType = (!that.videoData.playType || that.videoData.playType == 0) ? 1 : that.videoData.playType; // 播放类型：1、播放器，2、iframe，3、页面跳转播放
					// that.videoData.playType = 3; // 播放类型：1、播放器，2、iframe，3、页面跳转播放
					console.log('视频数据:',that.videoData)
					
					if (that.videoData.addressType == 1 || (that.videoData.addressType == 2 && that.videoData.playType == 1)) {
						that.isPlaySource = true;
						setTimeout(function() {
							that.$refs.videoplay.initVideo({
								url: that.videoData.addressType == 1 ? that.videoData.sourceLive : that.videoData.onLineLive,
								isLive:false,
								isAutoplay:false,
								cover:that.videoData.liveImg != null ? ('https://images.weserv.nl/?url='+that.videoData.liveImg) : 'static/default_img.png'
							});
						}, 10);
					}
					
					this.loadEvaList() // 获取数据后 加载评论列表
				})
			},
			
			// 跳转播放
			playVideo() {
				let aa = this.videoData;
				let url = '/pages/webview/webview',
					data = {
						id: aa.id,
						title: aa.liveTitle,
						images: aa.liveImg,
						sourceName: aa.liveTitle ? aa.liveTitle : '视频',
						sourcePath: aa.addressType == 1 ? aa.sourceLive : aa.onLineLive,
					}
				uni.navigateTo({
					url: url+'?data=' + encodeURIComponent(JSON.stringify(data))
				})
			},
			
			// 点赞
			dianZan: function (type){
				let that = this;
				let datas = {
				    "liveCommentType": this.templikeType,
				    "liveId": this.videoData.id
				}
				// console.log(datas);
				this.$req.reqc.updateLivelike(datas)
				.then(res => {
					// console.log("点赞",res)
					if (res.data.resultCode === 1) {
						that.templikeType == 0 ? that.templikeType = 1 : that.templikeType = 0;
						that.templikeType == 1 ? that.templikeNum++ : that.templikeNum--;
					} else {
						uni.showToast({
							icon: 'none',
							title: res.data.resultMsg
						})
					}
				})
			},
			//上滑加载
			loadMore(){
				this.loadEvaList('add');
			},
			//获取评论列表
			async loadEvaList(type) {
				//this.evaList = await json.evaList;
				if(type === 'add'){
					if(that.loadMoreStatus === 2){
						return;
					}
					if(that.comments.length > 0){
						that.offset++;
					}
					that.loadMoreStatus = 1;
				}
				let datas = {
					    "id": this.videoData.id,
						"limit": 20,
						"offset": that.offset,
						"sortTypeId": 1,
					    "typeId": 2
				}
				this.$req.req.queryMainComment(datas, {noToken: that.noToken})
				.then( res => {
					// console.log("评论列表",res);
					// that.comments = that.comments.concat(res.data.data.list)
					this.comments = res.data.data.list;
					console.log('arr',that.comments);
					that.total = res.data.data.total;
				})
				//上滑加载 处理状态
				// if(type === 'add'){
					that.loadMoreStatus = that.comments.length >= that.total ? 2 : 0;
				// }
			},
			
			// 发布评论
			search(){
				if(that.commentsInput == ''){
					uni.showToast({
						title:"请输入评论内容",
						icon:"none"
					})
					return;
				}
				let datas = {
						"commentContent": that.commentsInput,
						"id": that.id,
						"matchType": "2"
				}
				that.$req.req.createMainComment(datas)
				.then( res => {
					console.log(res)
					uni.showToast({
						title:"评论发送成功！",
						icon:"none"
					})
					that.commentsInput = '';
					that.submitBtn = false;
					that.loadEvaList();
				})
			},
			// 输入框聚焦
			focusTextArea: function (e) {
				this.bindStyle = true;
			},
			// 输入框失去焦点
			bindTextArea: function (e) {
				// console.log(e.detail.value,"长度："+e.detail.value.length)
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				// console.log(val)
				// 注释：indexOf() 方法对大小写敏感！
				// 注释：如果要检索的字符串值没有出现，则该方法返回 -1
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.bindStyle = false;
					this.submitBtn = false;
				}
			},
			// 输入监听
			MonitorIn: function (e) {
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.submitBtn = false;
				}
			},
			
			// videoErrorCallback: function(e) {
			// 	uni.showToast({
			// 		icon: "none",
			// 		title: '播放链接有误'
			// 	})
			// },
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				uni.navigateBack();
			},
		},
		filters: {
			filtersTime: function(value) {
				if (value) {
					 // 这里以 -，:，空格 来拆分字符串
					let time = value.split(/[-: ]/); // ["2019", "12", "04", "17", "00", "00"]
					time = time[1] + '-' + time[2] + '\xa0' + time[3] + ':' + time[4]
					// console.log('截取时间：',time);
					return time;
				}
			}
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
	}
	
	.container {
		width: 100%;
		// display: flex;
		// flex-direction: column;
		// align-items: center;
		// justify-content: center;
		overflow: hidden;
		background-color: #FFFFFF;
	}
	
	.scroll {
		flex: 1;
		position: relative;
		background-color: #f8f8f8;
		/* vh and vw:相对于视口的高度和宽度,而不是父元素的(CSS百分比是相对于包含它的最近的父元素的高度和宽度) */
		/* 用错地方，致使页面评论无法完成上拉显示(iPhone端) ↓ */
		/* height: 100vh; */
		height: 100%;
	}
	.scroll-content {
		display: flex;
		flex-direction: column;
	}
	
	.like{
		// color: #FF8400 !important;
		color: #007AFF !important;
	}
	
	/* 返回按钮 */
	.backButton {
		position: absolute;
		top: 66rpx;
		left: 36rpx;
		width: 44rpx;
		height: 44rpx;
		background-size: cover;
		background-image: url(../../static/images/video_back_w.png);
		z-index: 999;
	}
	
	/* 视频播放器 */
	.videoBox {
		width: 100%;
		height: 420rpx;
		video {
			width: 100%;
			height: 420rpx;
		}
	}
	
	/* iframe */
	.iframe-view{
		width: 100%;
		height: 420rpx;
		// background-color: #000000;
		overflow: auto;
		/* -webkit-overflow-scrolling: touch; */
		/* -webkit-overflow-scrolling: touch; */
		/* -webkit-overflow:auto; */
		iframe{
			width: 100%;
			height: 100%;
			overflow: auto;
			/* -webkit-overflow-scrolling: touch; */
			/* -webkit-overflow-scrolling: touch; */
			/* -webkit-overflow:auto; */
		}
	}
	
	// 跳转播放框样式
	.url-view {
		width: 750rpx;
		height: 420rpx;
		overflow: hidden;
		background-color: #000000;
		position: relative;
	}
	.url-view-img {
		width: 750rpx;
		height: 420rpx;
		display: block;
	}
	.url-view-btn {
		width: 400rpx;
		height: 88rpx;
		box-sizing: border-box;
		line-height: 88rpx;
		font-size: 32rpx;
		color: #FFFFFF;
		border: 1px solid #FFFFFF;
		text-align: center;
		position: absolute;
		left: 175rpx;
		top: 166rpx;
	}
	
	
	.noiframeSrc{
		width: 100%;
		height: 420rpx;
		background-color: #1B1B30;
		align-items: center;
		justify-content: center;
	}
	.noiframeSrcText{
		color: #FFFFFF;
	}
	
	/* 视频信息 */
	.videoInfo {
		height: auto;
		box-sizing: border-box;
		padding: 0 21rpx;
		overflow: hidden;
		
		.title {
			margin-top: 20rpx;
			font-size: 17px;
			line-height: 26px;
			color: #000000;
			
			/* 超出1行时，隐藏并显示省略符 */
			/* overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box; */
			/* -webkit-line-clamp: 1; */ /* 行数控制 */
			/* -webkit-box-orient: vertical; */
		}
		.info-item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 11px;
			color: #666666;
			padding-bottom: 12rpx;
			
			.right, .zan, .comment {
				display: flex;
				justify-content: space-between;
				align-items: center;
			}
			.zanIcon {
				width: 25rpx;
				height: 25rpx;
				margin: 0 8rpx 4rpx 26rpx;
				background-size: cover;
				background-image: url(../../static/iconSet/zan_def2.png);
			}
			.like {
				background-image: url(../../static/iconSet/zan_active.png);
			}
			.commentIcon {
				width: 24rpx;
				height: 22rpx;
				margin: 0 8rpx 4rpx 26rpx;
				background-size: cover;
				background-image: url(../../static/images/video_comment.png);
			}
		}
	}
	
	/* 底部 文本框 */
		.inputBox {
			// width: 100vw;
			width: 100%;
			min-height: 88rpx;
			box-sizing: border-box;
			padding: 14rpx 0;
			// box-shadow: 0 -1px 3px rgba(0, 0, 0, .04);
			background-color: #FFFFFF;
			// border-top: 1px solid #EAEAEA;
			position: relative;
			position: fixed;
			bottom: 0;
			z-index: 100;
			display: flex;
			align-items: center;
			/* justify-content: space-between; */
			.multiline {
				width: 80%;
				padding: 0px;
				margin: 0px;
				box-sizing: border-box;
				height: 68rpx;
				margin: 0 20rpx;
				padding: 12rpx 26rpx;
				border-radius: 12rpx;
				background-color: #F8F8F8;
				border: 1px solid #EAEAEA;
				font-size: 13px;
				color: #333333;
			}
			// 输入框底部 点赞按钮
			.confirm-btn {
				/* position: absolute;
				right: 30rpx; */
				width: 62rpx;
				height: 62rpx;
				background-size: cover;
				background-image: url(../../static/iconSet/zan_def2.png);
			}
			.like {
				background-image: url(../../static/iconSet/zan_active.png);
			}
			
			/* 提交按钮 */
			.submit {
				/* position: absolute;
				top: 50%;
				right: 10rpx;
				transform: translateY(-50%); */
				width: 100rpx;
				height: 55rpx;
				line-height: 55rpx;
				text-align: center;
				border-radius: 4rpx;
				color: #FFFFFF;
				background-color: #1B1B30;
			}
		}
</style>
