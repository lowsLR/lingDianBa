<!-- 比分模块 -->
<template>
	<view class="vpage-top" v-if="homeTeamScore != '' && homeTeamScore != null && guestTeamSocre != '' && guestTeamSocre != null">
		<view class="vpage-team">
			<image v-if="homeTeamLogoPath" :src="('https://images.weserv.nl/?url='+homeTeamLogoPath)" mode=""></image>
			<image v-else src="../../static/assets/homeTeam.png" mode=""></image>
			<text class="textTeamName">{{homeTeamName | limitLength}}</text>
		</view>
		<view class="vpage-content">
			<view class="vpage-content-top">
				<!-- <view v-if="isScore && homeTeamScore != '' && guestTeamSocre != ''" class="vpage-score"> -->
				<block v-if="modulesType == 3 && !isScore">
					<view v-if="homeTeamScore != '' && guestTeamSocre != ''" class="show-but"
					@tap="setIsScore">
						显示比分
					</view>
					<view v-else class="vpage-score">
						<text style="color: #000000;">VS</text>
					</view>
				</block>
				<block v-else>
					<view v-if="homeTeamScore != '' && guestTeamSocre != ''" class="vpage-score">
						<text class="score-number">{{homeTeamScore}}</text>
						<text class="score-vs">VS</text>
						<text class="score-number">{{guestTeamSocre}}</text>
					</view>
					<view v-else class="vpage-score">
						<text class="score-vs">VS</text>
					</view>
				</block>
			</view>
			<text class="vpage-content-bottom">
				{{matchStartState==0?'进行中':matchStartState==1?'未开始':'已完赛'}}
			</text>
		</view>
		<view class="vpage-team">
			<image v-if="guestTeamLogoPath" :src="('https://images.weserv.nl/?url='+guestTeamLogoPath)" mode=""></image>
			<image v-else src="../../static/assets/guestTeam.png" mode=""></image>
			<text class="textTeamName">{{guestTeamName | limitLength}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'match-score',
		props: {
			modulesType:{
				type:String | Number,
				default:''
			},
			homeTeamLogoPath: {//主队图标
				type: String,
				default: ''
			},
			homeTeamName:{//主队名称
				type: String,
				default: ''
			},
			homeTeamScore: {//主队比分
				type: String,
				default: ''
			},
			guestTeamLogoPath: {//客队图标
				type: String,
				default: ''
			},
			guestTeamName:{//客队名称
				type: String,
				default: ''
			},
			guestTeamSocre:{	//客队比分
				type: String,
				default: ''
			},
			matchTitle:{//标题
				type: String,
				default: ''
			},
			isFinsh:{//是否结束 0true 1false
				type: String,
				default: ''
			},
			matchStartState:{//赛事进行状态 0进行中 1未开始 2已结束
				type: String,
				default: ''
			},
		},
		data() {
			return {
				isScore: false,
			}
		},
		// watch: {
		// 	homeTeamLogoPath: function (newVal,oldVal) {
		// 		console.log(newVal,oldVal);
		// 	},
		// },
		filters:{
			/*限制长度*/
			limitLength:function(v){
				return v&&v.length>8?v.substring(0,8):v;
			}
		},
		methods: {
			setIsScore(){
				this.isScore = !this.isScore;
			},
		},
	}
</script>

<style lang="scss" scoped>
	.vpage-top{
		// position: fixed;
		// top: 0;
		height:174rpx;
		width: 100%;
		border-bottom:1rpx solid rgba(225,225,225,1);
		display: flex;
		align-items: flex-end;
		z-index: 10;
		background-color: #FFFFFF;
		// margin-bottom: 24rpx;
		.vpage-team{
			flex: 1;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			height: 100%;
			
			image{
				width:88rpx;
				height:88rpx;
				border-radius: 88rpx;
			}
			.textTeamName{
				line-height: 1.8;
				overflow: hidden;
				white-space: nowrap;
			}
		}
		.vpage-content{
			flex: 1;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			.vpage-content-top{
				flex: 1;
				width: 100%;
				display: flex;
				flex-direction: column;
				align-items: center;
				.vpage-score{
					flex: 1;
					width: 100%;
					display: flex;
					justify-content: center;
					.score-number{
						flex: 1;
						font-weight:500;
						color:rgba(255,83,55,1);
					}
					.score-vs{
						flex: 1;
						font-weight:400;
						color:rgba(0,0,0,1);
						// padding: 0 60rpx;
					}
					text{
						font-size:36rpx;
						font-family:PingFang SC;
						line-height:60rpx;
						text-align: center;
					}
				}
				.show-but{
					width:140rpx;
					height:44rpx;
					background:rgba(27,27,48,1);
					border-radius:22rpx;
					font-size:22rpx;
					font-weight:400;
					color:rgba(255,255,255,1);
					// line-height:114rpx;
					display: flex;
					align-items: center;
					justify-content: center;
				}
			}
			.vpage-content-bottom{
					line-height: 70rpx;
					color: #666666;
					font-size: 18rpx;
			}
		}
	}
</style>
