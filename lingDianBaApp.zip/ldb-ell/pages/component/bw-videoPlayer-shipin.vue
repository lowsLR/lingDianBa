<template>
	<view>
		<view class="video-view"
		:style="{width:'100%',height:height+'rpx',
		'background-color':bgc,
		}">
			<view v-if="!isPlaySource" class="noPlayer"> 
			<text v-if="!istime">{{ videoMsg | filtersVideoMsg}}</text>
			<text >{{dtime||''}}</text>
				<!-- <view class="example-body">
					<uni-countdown :show-day="false" :second="1000" @timeup="timeup" />
				</view> -->
			</view>
			<!-- #ifdef H5 -->
			<view v-if="!isSourcePlay" class="refreshView" :style="{width:width+'rpx',height:height+'rpx'}">
								 <view class="refreshBut">
									 <text class="refreshText">正在刷新。。。</text>
								 </view>
			</view>
			<video-player v-if="isPlaySource && isSourcePlay" class="video-player vjs-custom-skin"
			  ref="videoPlayer" 
			  :playsinline="true" 
			  :options="playerOptions"
				@play="onPlayerPlay($event)"
				@pause="onPlayerPause($event)"
				@ended="onPlayerEnded($event)"
				@waiting="onPlayerWaiting($event)"
				@playing="onPlayerPlaying($event)"
				@loadeddata="onPlayerLoadeddata($event)"
				@timeupdate="onPlayerTimeupdate($event)"
				@canplay="onPlayerCanplay($event)"
				@canplaythrough="onPlayerCanplaythrough($event)"
				@statechanged="playerStateChanged($event)"
				@error="onPlayerError"
				@ready="playerReadied"  
			></video-player>
			<!-- #endif -->
			<!-- #ifdef APP-PLUS -->
			<view v-if="isPlaySource" class="video-app-class">
				<video 
				:src="sourceUrl" 
				:autoplay="isAutoplay"
				controls></video>
			</view>
			<!-- #endif -->
			
			
			<!-- v-if="isPlaySource" -->
			<!-- <view class="playerBut"  ></view>
			  <view v-if="isPlaySource&&isPlayPause"  @tap="setPlay" class="playBtn"></view>-->
			</view> 
	</view>
</template>

<script>
	// #ifdef H5
	import videojs from 'video.js'
	import {videoPlayer} from 'vue-video-player'
	import 'videojs-flash'
		// #endif
	var playVideo,	
	setStartTime;//设置剩余开始时间;
	export default {
		name:'bwVideoPlayer',
		props:{
			isLiveType:{
				type: Number,
				default: 2
			},
			isBeginAnalys:{
				type: Boolean,
				default: false
			},
			width: {//video宽度
				type: Number,
				default: 750
			},
			height:{//video高度
				type: Number,
				default: 450
			},
			videoMsg:{//提示
				type: String,
				default: ''
			},
			isPlaySource:{//是否有播放资源
				type: Boolean,
				default: false
			},
			isLive:{//是否是直播
				type: Boolean,
				default: true
			},
			sourceUrl:{//播放路径
				type: String,
				default: ''
			},
			poster:{//封面图路径
				type: String,
				default: ''
			},
			isAutoplay:{//是否自动播放
				type: Boolean,
				default: false
			},
			videoType:{//是否自动播放
				type: String,
				default: 'application/x-mpegURL'
			},
			bgc:{//背景色
				type: String,
				default: '#000000'
			},
			
			sourcePath:{//播放路径数组
				type: Array,
				default: () => []
			},
			playSourcePathIndex:{//当前段落
				type: Number,
				default: ''
			},
			playSourcePathTime:{//当前时间
				type: Number,
				default: ''
			},
		},
		data() {
			return {
				sourceIndex:0,//当前段落
				sourceTime:0,//当前时间
				initialTime:0,//进度时间
				
				isPlayPause:false,
				isSourcePlay:true,//是否能播放
				isPlayerPlay:false,//是否开始播放过
				dtime:'',
				t:0,
				istime:false,
				playerOptions : {
						live: this.isLive,
						autoplay: this.isAutoplay || true, // 如果true，浏览器准备好时开始播放
						muted: false, // 默认情况下将会消除任何音频
						loop: false, // 是否视频一结束就重新开始
						// preload: 'auto', // 建议浏览器在<video>加载元素后是否应该开始下载视频数据。auto浏览器选择最佳行为,立即开始加载视频（如果浏览器支持）
						
						// preload: 'none',
						preload:'meta',
						aspectRatio: '16:9', // 将播放器置于流畅模式，并在计算播放器的动态大小时使用该值。值应该代表一个比例 - 用冒号分隔的两个数字（例如"16:9"或"4:3"）
						fluid: true, // 当true时，Video.js player将拥有流体大小。换句话说，它将按比例缩放以适应其容器。
						sources: [
						  {
						    withCredentials: false,
						    // type: 'application/x-mpegURL',
						    src: this.sourceUrl,
						    type: this.videoType || 'video/mp4',
						  }//设置路径和 类型
						],
						hls:true,
						poster: this.poster,//封面
						// width:this.windowWidth,
						width:'100%',
						notSupportedMessage: '此视频暂无法播放，请稍后再试', // 允许覆盖Video.js无法播放媒体源时显示的默认信息。
						controlBar: {
						  timeDivider: false,
						  durationDisplay: false,
						  remainingTimeDisplay: false,
						  currentTimeDisplay: false, // 当前时间
						  volumeControl: false, // 声音控制键
						  playToggle: true, // 暂停和播放键
							
							currentTimeDisplay: !this.isLive, // 当前时间
							// timeDivider: this.isLive?false:true, // 时间分割线
							durationDisplay: !this.isLive, // 总时间
						  progressControl: !this.isLive, // 进度条
							
							// currentTimeDisplay: false, // 当前时间
							// durationDisplay: false, // 总时间
							// progressControl: false, // 进度条
							
						  fullscreenToggle: true // 全屏按钮
						},
						techOrder: ['html5', 'flash',], // 兼容顺序
						// techOrder: [ 'flash','html5',], // 兼容顺序
						flash: {
						  hls: {
						    withCredentials: false
						  },
						  html5: { hls: { withCredentials: false } },
						  swf: 'videojs-swf/dist/video-js.swf'
						},
						
				},
				beginAnalysNum:0,
			};
		},
		filters: {
		  filtersVideoMsg: function (value) {
		    return value.replace(/\,/g,"\n");
		  }
		},
		computed: {
		    player() {
		      return this.$refs.videoPlayer.player
		    },
		},
		methods:{
			/*视频播放完*/
			onPlayerEnded(p){
				console.log('视频播放完:',p)
				this.initialTime = 0;
				this.sourceIndex++;
				if(this.sourceIndex < this.sourcePath.length){
					// this.nextVideo();
				}
			},
			nextVideo(){
				this.sourceUrl = this.sourcePath[this.sourceIndex];
			},
			
			initNum(){
				this.beginAnalysNum = 0;
			},
			/*错误*/
			onPlayerError(){
				console.log("播放错误:")
				if(this.isLiveType == 1){
					if(this.isBeginAnalys && this.isPlayerPlay){
						this.isSourcePlay = false;
						try{
							this.$emit("beginAnalysisSource", true)
						}catch(e){
							//TODO handle the exception
						}
					}else{
						try{
							this.$emit("errorVideo")
						}catch(e){
							//TODO handle the exception
						}
					}
					// this.beginAnalysNum++;
					// 	if(this.beginAnalysNum < 2){
					// 		console.log("第一次报错")
					// 		try{
					// 			if(this.isBeginAnalys){
					// 				console.log("重新解析")
					// 				this.$emit("beginAnalysisSource")
					// 			}
					// 		}catch(e){
					// 			//TODO handle the exception
					// 		}
					// 	}else{
					// 		console.log("第二次报错")
					// 		try{
					// 			this.$emit("errorVideo")
					// 		}catch(e){
					// 			//TODO handle the exception
					// 		}
							
					// 	}
				}
				
			},
			/*播放*/
			onPlayerPlay(p){
				console.log("开始播放:",p)
				
			},
			/*暂停*/
			onPlayerPause(p){
				console.log('暂停:',p)
			},
			
			/*元素readyState更改导致播放停止*/
			onPlayerWaiting(p){
				console.log('元素readyState更改导致播放停止:',p)
				// p.error_.message = '无法加载媒体，可能是由于服务器或网络故障，也可能是由于不支持该格式。';
			},
			/*已开始播放*/
			onPlayerPlaying(p){
				console.log('已开始播放:',p)
				this.isPlayerPlay = true;
			},
			/*当播放器在当前播放位置下载数据时触发*/
			onPlayerLoadeddata(p){
				console.log('当播放器在当前播放位置下载数据时:',p)
				// console.log(this.$refs.videoPlayer)
			},
			/* 当前播放位置发生变化时触发*/
			onPlayerTimeupdate(p){
				// console.log('当前播放位置发生变化时触发',p)
			},
			/*媒体的readyState为HAVE_FUTURE_DATA或更高*/
			onPlayerCanplay(p) {
			  // console.log('player Canplay!', p)
			},
			/*媒体的readyState为HAVE_ENOUGH_DATA或更高。这意味着可以在不缓冲的情况下播放整个媒体文件。*/
			onPlayerCanplaythrough(p) {
			  // console.log('player Canplaythrough!', p)
			},
			/*播放状态改变回调*/
			playerStateChanged(p){
				// console.log('播放状态改变',p)
			},
			/*将侦听器绑定到组件的就绪状态。与事件监听器的不同之处在于，如果ready事件已经发生，它将立即触发该函数*/
			playerReadied(p){
				console.log('加载完成，准备播放',p)
				// this.$refs.videoPlayer.player;
				this.player;
				
				try{
					this.$emit('calculationNum');
				}catch(e){
					//TODO handle the exception
				}
			},
			getVideoData(){
				this.istime = false;
				console.log("isPlaySource是否有播放源",this.isPlaySource);
				console.log("是否有倒计时",this.istime);
				console.log("提示",this.videoMsg);
				// that.$forceUpdate();
			},
			
			timeup() {
				uni.showToast({
					title: '时间到'
				})
			},
			/*清空倒计时*/
			clearStartTime(){
				return new Promise((res,rel) => {
					if(setStartTime){
						clearInterval(setStartTime);
						setStartTime = null; 
						this.dtime = '';
					}
					res();
				})
				
			},
			 formatSeconds(t) {
				let mi = 60,hh = mi*60,dd = hh*24;
				// let d = this.formatBit( Math.floor(t/dd)),
				// 		h = this.formatBit( Math.floor((t - d*dd)/hh)),
				// 		m = this.formatBit( Math.floor((t - d*dd - h*hh)/mi)),
				// 		s = this.formatBit( Math.floor((t - d*dd - h*hh - m*mi)));
				let h = this.formatBit( Math.floor(t/hh)),
						m = this.formatBit( Math.floor((t - h*hh)/mi)),
						s = this.formatBit( Math.floor((t - h*hh - m*mi)));		
				// let tstr = d+'天'+h+'小时'+m+"分"+s+'秒';
				let tstr = '倒计时:'+ h+'小时'+m+"分"+s+'秒';
				return tstr;
				
				// let min = Math.floor(t % 3600);
				// let h = this.formatBit(Math.floor(t / 3600)),
				// 		m = this.formatBit(Math.floor(min/60)),
				// 		s = this.formatBit( Math.floor(t%60));
				// let tstr = h+':'+m+":"+s;
				// return tstr;
			},
			setDataTime(time){
				this.clearStartTime().then( res => {
					this.istime = true;
					this.t = Math.floor(time/1000);
					console.log(this.t);
					setStartTime = setInterval(() => {
						this.t--;
						// console.log(this.t)
						this.dtime = this.formatSeconds(this.t)
						if (this.t <= 0) {
							clearInterval(setStartTime)
							// setTimeout(function() {this.istime = false;},1000);
							// 倒计时结束 重新开始解析
							this.$emit('beginAnalysisSource');
						}
					}, 1000)
				})
			},
			formatBit(v){
				v = +v
				return v > 9 ? v : '0' + v
			},
			setPlay(){
				console.log("进入设置")
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
			},
			
			/*初始化播放器*/
			
			initVideo(pdata) {
				console.log('初始化',pdata)
				
				
				// this.$nextTick(()=>{
				// 	this.sourceIndex = this.playSourcePathIndex;
				// 	this.sourceTime = this.playSourcePathTime;
					
				// 	this.sourceUrl = pdata.url[this.sourceIndex];
				// 	if(~~this.sourceTime>0){
				// 		this.initialTime = ~~this.sourceTime;
				// 	}
				// })
				
				let _self = this;
				this.isPlayerPlay = false;
				this.isSourcePlay = true;
				_self.playerOptions['sources'][0]['src'] = '';
				// _self.beginAnalysNum = 0;
				/*匹配路径以什么结尾*/
				let url = pdata.url,
						index = url.lastIndexOf("\."),
						str = url.substring((index+1),url.url),
						str2 = url.match('[^.]+(?!.*.)')[0];
				// console.log("路径类型",str,str2);
				// #ifdef H5
				_self.playerOptions.poster = pdata.poster || '';
				_self.playerOptions.autoplay = pdata.isAutoplay||true;
				_self.playerOptions.live = pdata.isLive||true;
				if(pdata.isLive){
					_self.playerOptions.controlBar.currentTimeDisplay = false
					_self.playerOptions.controlBar.durationDisplay = false
					_self.playerOptions.controlBar.progressControl = false
				}
				switch (str2){
					case 'm3u8':
						_self.playerOptions['sources'][0]['type'] = 'application/x-mpegURL';
						break;
					case 'mp4':
						_self.playerOptions['sources'][0]['type'] = 'video/mp4';
						break;	
					default:
						_self.playerOptions['sources'][0]['type'] = 'application/x-mpegURL';
						break;
				}
				 _self.playerOptions['sources'][0]['src'] =pdata.url;
				// #endif
				// #ifdef APP-PLUS
				_self.sourceUrl = pdata.url;
				// #endif	 
				console.log('初始化结束',)
			},
			/*切换路径*/
			switchPath(){
				// #ifdef H5
				 _self.playerOptions['sources'][0]['src'] = this.sourceUrl;
				// #endif
				// #ifdef APP-PLUS
				_self.sourceUrl = this.sourceUrl;
				// #endif	 
			},
			/*销毁后重建*/
			videoDisposeRebuild(){
				// #ifdef H5
				this.videoDispose().then( res => {
							this.initVideo(pdata)
				})
				// #endif
				
			},
			/*销毁播放器*/
			videoDispose() {
				return new Promise( (res,rel) => {
					// #ifdef H5
					// if(playVideo){
						// playVideo.dispose();
						this.clearStartTime();
					// }
					// #endif
					res();
				})
			},
			play(){
				// #ifdef H5
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'pause'){
						playVideo.play();
					}
				}
				// #endif
			},
			pause(){
				// #ifdef H5
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'playing'){
						playVideo.pause();
					}
				}
				// #endif
			}	,
			/*切换播放暂停*/
			playPause (){
				// #ifdef H5
				if(playVideo){
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
				}
				// #endif
			},
		}
	}
</script>

<style lang="scss">
	/* #ifdef H5 */
	@import 'video.js/dist/video-js.css';
	@import 'vue-video-player/src/custom-theme.css';
	/* #endif */
	.example-body {
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: center;
		padding: 0;
		font-size: 14rpx;
		background-color: #ffffff;
	}
	
	.video-view {
			position: relative;
			// .playerBut{
			// 	width: 48rpx;
			// 	height: 48rpx;
			// 	position: absolute;
			// 	left: 20rpx;
			// 	bottom:16rpx ;
			// 	background-color: red;
			// 	z-index: 99;
			// }
			.video-app-class{
				width: 100%;
				height: 100%;
				video{
					width: 100%;
					height: 100%;
				}
			}
			.playBtn {
				position: absolute;
				top: 55%;
				left: 50%;
				transform: translate(-50%,-50%);
				width: 160rpx;
				height: 160rpx;
				/* background-color: rgba(0,0,0,.2); */
				border-radius: 50%;
				background-size: cover;
				background-image: url(../../static/images/playButton.png);
			}
			.playerSetView{
				position: absolute;
				width: 48rpx;
				height: 48rpx;
				left: 20rpx;
				bottom:16rpx;
				background-color: red;
				z-index: 99;
				
				
				.playerFullScreen{
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					right: 20rpx;
					bottom:16rpx ;
					background-color: red;
				}
			}
			
			.noPlayer{
				height: 450rpx;
				width: 100%;
				text-align: center;
				color: white;
				font-size: 40rpx;
				padding: 30rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				flex-direction: column;
			}
			.prism-player {}
		}
	
	
	
	
	// 播放器外层容器
	/deep/.video-player {
		width:100%;
		height:100%;
	}
	/deep/.video-player>div {
		width:100%;
		height:100%;
	}
	
	/* 播放器 播放按钮 */
	/deep/.vjs-big-play-button .vjs-icon-placeholder:before {
		color: #fff;
		// position: absolute;
		// top: 50%;
		// left: calc(50% + 25rpx);
		// transform: translate(-50%,-50%);
		// content: '';
		// width: 0;
		// height: 0;
		// border-top: 30rpx transparent dashed;
		// border-left: 50rpx #fff solid;
		// border-bottom: 30rpx transparent dashed;
		// border-right: 30rpx transparent dashed;
	}
	/deep/.vjs-modal-dialog .vjs-modal-dialog-content {
	   display: flex;
		 align-items: center;
		 justify-content: center;
	}
	/deep/.video-js.vjs-error .vjs-big-play-button{ /* 视频加载出错时隐藏播放按钮 */
	  display: none;
	}
	/deep/.vjs-error .vjs-error-display:before {
		display: none;
	    // color: #fff;
	    // content: 'X';
	    // font-family: Arial,Helvetica,sans-serif;
	    // font-size: 4em;
	    // left: 0;
	    // line-height: 1;
	    // margin-top: -.5em;
	    // position: absolute;
	    // text-shadow: 0.05em 0.05em 0.1em #000;
	    // text-align: center;
	    // top: 50%;
	    // vertical-align: middle;
	    // width: 100%;
	}
	// /deep/.vjs-big-play-button .vjs-control-text:before {
	// 	position: absolute !important;
	// 	top: 50%;
	// 	left: calc(50% + 25rpx);
	// 	transform: translate(-50%,-50%);
	// 	content: '';
	// 	width: 0;
	// 	height: 0;
	// 	border-top: 30rpx transparent dashed;
	// 	border-left: 50rpx #fff solid;
	// 	border-bottom: 30rpx transparent dashed;
	// 	border-right: 30rpx transparent dashed;
	// }
	
	// 状态栏 全屏按钮位置
	/deep/.vjs-custom-skin > .video-js .vjs-control-bar .vjs-fullscreen-control {
	    position: absolute;
	    right: 0;
	}
	// 状态栏 全屏按钮背景
	/deep/.video-js .vjs-fullscreen-control .vjs-icon-placeholder:before {
		content: "\f108";
		color: #fff;
	}
	// 状态栏 暂停背景
	/deep/.video-js .vjs-play-control .vjs-icon-placeholder:before {
	    content: "\f101";
	    color: #fff;
	}
	// 状态栏 播放背景
	/deep/.video-js .vjs-play-control.vjs-playing .vjs-icon-placeholder:before {
	    content: "\f103";
	    color: #fff;
	}
	// 状态栏 声音背景
	/deep/.video-js .vjs-mute-control .vjs-icon-placeholder:before{
	    // content: "\f107";
		color: #fff;
	}
	/deep/.video-js .vjs-duration {
	    display: none;
			position: absolute;
			right: 3em;
	}
	
	// 状态栏按钮背景
	/deep/.vjs-custom-skin > .video-js .vjs-control-bar .vjs-play-control {
	    background: initial;
	    border: 0px;
		box-sizing: border-box;
	}
	/deep/.vjs-custom-skin > .video-js .vjs-control {
		background: initial;		border: 0px;		box-sizing: border-box;
	}
	
	
	/deep/.video-js .vjs-progress-control {
	    margin-right: 6em;
			width: auto;
	}
	
	
// 	/deep/.video-js .vjs-control.vjs-live-control {
//     width: 4em;
    
// }
	/deep/.vjs-button>.vjs-icon-placeholder:before {
	    font-size: 1.8em;
	    line-height: 1.8;
	}
	/deep/.video-js .vjs-control-bar .vjs-time-control{
		
	}
	
	/deep/.video-js .vjs-big-play-button{
	   display: none;
	}
</style>
