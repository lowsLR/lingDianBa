<template>
	<view class="content">
		<view class="flex-cb">
			<view class="s-header">
				<text class="title">全部评论 <text v-if="total>0">({{total}})</text> </text>
			</view>
			<view v-if="total>0" class="remen" @tap="getRemen()">
				{{sortTypeId == 1 ? '最新评论' : '热门评论'}}
				<image src="../../static/images/video_sort.png" mode=""></image>
			</view>
		</view>
		<!-- <view class="uni-padding-wrap"> -->
			<view class="evalution">
				<view v-for="(item, idx) in comments" :key="idx" class="eva-item" @tap="toComDet(item.id)">
					<image :src="item.imageUrl?item.imageUrl:'/static/assets/user_default.png'" mode="aspectFill"></image>
					<view class="eva-right">
						<view class="eva-right-top">
							<text>{{item.nickName||'新用户'}}</text>
							<view class="zan-box" @tap.stop="likeType(idx,item.id,item.likeType)">
								<view class="icon zanIcon" >
									<image v-if="item.likeType==0" src="../../static/iconSet/zan_def2.png" mode="aspectFit"></image>
									<image v-else src="../../static/iconSet/zan_active.png" mode="aspectFit"></image>
								</view>
								<text class="likeNum">{{item.number | listNumber}}</text>
							</view>
						</view>
						
						<text class="time-view">{{item.createdTime}}</text>
						
						<text class="content">{{item.content}}</text>
						<view v-if="item.sportMatchCommentChildDO" class="uni-comment-list">
							<image :src="item.sportMatchCommentChildDO.imageUrl?item.sportMatchCommentChildDO.imageUrl:'/static/assets/user_default.png'" mode="aspectFill"></image>
							<view class="eva-right ">
								<view class="eva-right-top">
									<text>{{item.sportMatchCommentChildDO.nickName||'新用户'}}</text>
									<view class="zan-box" @tap.stop="likeTypeChi(idx,item.sportMatchCommentChildDO.id,item.sportMatchCommentChildDO.likeType)">
										<!-- <text class="icon iconfont" :class="item.sportMatchCommentChildDO.likeType==0?'':'like'">&#xe603;</text> -->
										<!-- <view class="icon zanIcon" :class="item.sportMatchCommentChildDO.likeType == 0 ? '' : 'like'"></view> -->
										<view class="icon zanIcon" >
											<image v-if="item.sportMatchCommentChildDO.likeType == 0" src="../../static/iconSet/zan_def2.png" mode="aspectFit"></image>
											<image v-else src="../../static/iconSet/zan_active.png" mode="aspectFit"></image>
										</view>
										<text class="likeNum">{{item.sportMatchCommentChildDO.number | listNumber}}</text>
									</view>
								</view>
								<text class="time-view">{{item.sportMatchCommentChildDO.createdTime}}</text>
								<text class="content">{{item.sportMatchCommentChildDO.content}}</text>
							</view>
						</view>
					</view>
				</view>
			<!-- </view> -->
		</view>
	</view>
</template>

<script>
	// let that;
	export default {
		props: {
			cid: {
				type: String | Number,
			},
			comments: {
				type: Array,
			},
			type: {
				type: Number,
			},
			total: {
				type: Number
			},
			noToken: {
				type: Boolean,
				default: false,
			}
		},
		data() {
			return {
				title: "评论",
				index: 0,
				sortTypeId: 1, //热门  1是时间排序 2是点赞排序
				// comments:[],
			}
		},
		onLoad() {
			// that = this;
			// that.loadEvaList();
		},
		filters: {
		  listNumber: function (v) {
		    return Number(v)>0?Number(v)<1000?v:'999+':'';
		  }
		},
		methods: {
			//获取热门评论
			getRemen() {
				this.sortTypeId = this.sortTypeId == 1 ? 2 : 1;
				this.loadEvaList();
			},
			//获取评论列表
			loadEvaList() {
				uni.showLoading({
					title: '加载中...',
					mask: true
				});
				//this.evaList = await json.evaList;
				let datas = {
					"id": this.cid,
					"limit": 20,
					"offset": 1,
					"sortTypeId": this.sortTypeId,
					"typeId": this.type
				}
				// this.$req.req.queryMainComment(datas)
				this.$req.req.queryMainComment(datas, {
						noToken: this.noToken
					})
					.then(res => {
						// this.$emit("setComments",res.data.data.list);
						// this.comments = res.data.data.list;
						// this.$set(this.comments, res.data.data.list);
						console.log('评论排序：', res.data.data.list)
						uni.hideLoading();
						uni.$emit('setComments', res.data.data.list);
					})

			},
			// 更新评论一级列表点赞
			likeType(idx, id, commentType) {
				// commentType(操作类型)：0 点赞 1 取消
				// "commentType": commentType == 0 ? 1 : 0,
				let datas = {
					"commentType": commentType,
					"id": id
				};
				console.log(datas)
				this.$req.req.updateMainCommentlike(datas)
					.then(res => {
						console.log("点赞", res)
						if (res.data.resultCode === 1) {
							this.comments[idx].likeType = commentType == 0 ? 1 : 0;
							// if(commentType){
							if (!commentType) {
								this.comments[idx].number++;
							} else {
								this.comments[idx].number--;
							}
							// this.$emit('setLikeType', {id,cType});
						}
					})
			},
			// 更新评论二级列表点赞
			likeTypeChi(idx, id, commentType) {
				// commentType(操作类型)：0 点赞 1 取消
				// "commentType": commentType == 0 ? 1 : 0,
				let datas = {
					"commentType": commentType,
					"id": id
				};
				console.log(datas)
				this.$req.req.updateCommentlikeChi(datas)
					.then(res => {
						console.log("点赞", res)
						this.comments[idx].sportMatchCommentChildDO.likeType = commentType == 0 ? 1 : 0;
						// if(commentType){
						if (!commentType) {
							this.comments[idx].sportMatchCommentChildDO.number++;
						} else {
							this.comments[idx].sportMatchCommentChildDO.number--;
						}
						// this.$emit('setLikeType', {id,cType});
					})
			},

			tapReply(e, idx) {
				if (this.index != idx) {
					this.index = idx
					// console.log(e)
				} else {
					this.index = null
				}
			},
			toComDet(id) {
				if (!this.noToken) {
					uni.navigateTo({
						url: '/pages/component/commentsDetail?commentId=' + id + '&type=' + this.type,
						success: res => {},
						fail: () => {},
						complete: () => {}
					});
				}
				else {
					uni.showToast({
					    icon: 'none',
					    title: "请先登录!"
					});
					setTimeout(function() {
						uni.navigateTo({
							url: '/pages/login/login'
						})
					}, 1000);
				}
			},
		}
	}
</script>

<style lang="scss" > 
	.content{
		display: flex;
		flex-direction: column;
		// height: 100%;
		background: #fff;
		width: 100%;
	}
	.uni-padding-wrap {
		// width: calc(750rpx - 56rpx);
		width: 100%;
		padding: 0 28upx;
		background: #fff;
		display: flex;
		flex-direction: column;
		flex: 1;
		
	}

	.iconfont {
		// font-size: 15upx;
		color: #999999;
	}

	/* 全部评论标题 */
	.flex-cb {
		display: flex;
		justify-content: space-between;
		align-items: center;
		background-color: #FFFFFF;
		border-bottom: 1px solid #F7F7F7;

		.s-header {
			padding: 20upx 30upx;
			font-size: 14px;
			color: #303133;
			background: #fff;
			border-bottom: 1px solid #F7F7F7;

			&:before {
				content: '';
				width: 0;
				height: 40upx;
				margin-right: 24upx;
				border-left: 6upx solid #ec706b;
			}
		}

		.remen {
			display: flex;
			justify-content: center;
			align-items: center;

			padding-right: 20upx;
			font-size: 14px;
			color: rgba(153, 153, 153, 1);
			line-height: 41upx;
		}

		.remen image {
			width: 36rpx;
			height: 36rpx;
		}
	}

	.uni-comment-list {

		/*    background:rgba(0,0,0,0.1);
    padding:0 10upx; */
	}

	.uni-comment-body {
		/* background: rgb(240, 240, 240); */
		padding: 20upx;
		display: flex;
		flex-direction: column;

		/* padding: 20upx 0; */
		/* width: 100%; */

	}

	.time-view {
		font-size: 11px;
		color: #999999;
	}

	.uni-comment-face {
		background: #FFFFFF;
	}

	.uni-comment-content {
		/*    background: #EEEEEE;
    padding:0 10upx; */
	}


	/* 评论 */
	.evalution {
		display: flex;
		flex-direction: column;
		background: #fff;
		padding: 20rpx 28rpx;
		width:100%;
		/* #ifdef H5 */
		/* #endif */
		/* #ifndef H5 */
		// width: calc(100% - 56rpx);
		/* #endif */
		// 
		
		// background: #fff;
	}

	.eva-item {
		display: flex;
		padding: 20upx 0;
		position: relative;

		image {
			width: 82upx;
			height: 82upx;
			border-radius: 50px;
			flex-shrink: 0;
			margin-right: 24upx;
		}

		&:after {
			content: '';
			position: absolute;
			left: 30upx;
			bottom: 0;
			right: 0;
			height: 0;
			border-bottom: 1px solid #eee;
			transform: translateY(50%);
		}

		&:last-child:after {
			border: 0;
		}
	}

	.eva-right {
		display: flex;
		flex-direction: column;
		flex: 1;
		font-size: 13px;
		color: #000000;
		position: relative;

		
	}
	.eva-right-top{
		display: flex;
		flex: 1;
		justify-content: space-between;
		align-items: center;
		// background-color: #00BFFF;
	}
.zan-box {
	// display: flex;
	// align-items: base-line;
	position: relative;
	// top: 10upx;
	// right: 10upx;
	display: flex;
	align-items: flex-end;
	justify-content: center;
	// width: 110rpx;
	// background-color: red;
		// background-color: #09BB07;
		// flex: 1;
		z-index: 99;
}
		.zanIcon {
			// background-color: #C8C7CC;
			width: 30rpx;
			height: 30rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			// background-color: red;
			// position: relative;
			// top: -2rpx;
			// right: -4rpx;
			// margin: 0 8rpx 0 26rpx;
			// background-size: cover;
			// background-image: url(../../static/iconSet/zan_def2.png);
			image{
				width: 25rpx;
				height: 25rpx;
				margin: 0;
				border-radius: 0;
			}
		}
		.likeNum {
			font-size: 11px;
			font-weight: 400;
			color: #999999;
			line-height: 22rpx;
			// margin-left: 11rpx;
			width: 50rpx;
			// background-color: yellow;
			// text-align: center;
			white-space: nowrap;
			z-index: 9;
			display: flex;
			// justify-content: flex-end;
			align-items: flex-end;
			height: 30rpx;
		}
		.content {
			font-size: 12px;
			padding-top: 11rpx;
			height: auto;
		}
	
	.like {
		// background-image: url(../../static/iconSet/zan_active.png) !important;
	}
</style>
