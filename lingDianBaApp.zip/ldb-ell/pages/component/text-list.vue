<template>
	<view class="content">
		<view class="text-list-view">
			<view class="text-list-item"
			v-for="i in 20"
			:key="i"
			>
				<view class="item-left">
					<text>解说</text>
					<text>尼利基纳带球推进！！</text>
				</view>
				<view class="item-right">
					<text>91-117</text>
					<text>第4节</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'text-list',
		data() {
			return {
				
			}
		},
		props: {
			bgColor: {
				type: String,
				default: ''
			},
			isBack: {
				type: [Boolean, String],
				default: false
			},
			bgImage: {
				type: String,
				default: ''
			},
		},
		onLoad() {
			this.loadData('add');
		},
		
		onReachBottom(){
			
		},
		methods: {
			
		}
	}
</script>

<style lang="scss" scoped>
	p:first-child{
		
	}
	page, .content{
		background-color: #FFFFFF;
		.text-list-view{
			height: 100%;
			padding: 0 24rpx;
			.text-list-item{
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 68rpx;
				border-bottom:1rpx solid rgba(225,225,225,1);
				
				font-size:22rpx;
				font-weight:400;
				color:rgba(102,102,102,1);
				line-height:46rpx;
				.item-left{
					flex: 1;
					overflow: hidden; /*自动隐藏文字*/
					text-overflow: ellipsis;/*文字隐藏后添加省略号*/
					white-space: nowrap;/*强制不换行*/
					text:first-child{
						margin-right: 17rpx;
					}
					
				}
				.item-right{
					white-space: nowrap;
					text:first-child{
						margin-right: 12rpx;
					}
				}
			}
		}
		
	}

	
</style>
