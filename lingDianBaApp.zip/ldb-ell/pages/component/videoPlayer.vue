<!-- 视频播放模板 -->
<template>
	<view>
		<view class="video-view"
		:style="{width:width+'rpx',height:height+'rpx',
		'background-color':bgc,
		}">
			<view v-if="!isPlaySource" class="noPlayer"> 
			<text v-if="!istime">{{ videoMsg | filtersVideoMsg}}</text>
			<text >{{dtime||''}}</text>
				<!-- <view class="example-body">
					<uni-countdown :show-day="false" :second="1000" @timeup="timeup" />
				</view> -->
			</view>
			
			<!-- #ifdef H5 -->
			<div v-if="isPlaySource" class="prism-player" id="J_prismPlayer"></div>
			<!-- #endif -->
			<!-- #ifdef APP-PLUS -->
			<view v-if="isPlaySource" class="video-app-class">
				<video 
				:src="sourceUrl" 
				:autoplay="isAutoplay"
				controls></video>
			</view>
			<!-- #endif -->
			
			
			<!-- v-if="isPlaySource" -->
			<view class="playerBut"  ></view>
			<!-- <view   class="playerSetView" >
				
			 </view> -->
			  <view v-if="isPlaySource&&isPlayPause"  @tap="setPlay" class="playBtn"></view>
			<!-- <view  class="playerSetView"  >
				v-if="isPlayPause" 
				
				<view class="playerFullScreen" @click="setPlayerFullScreen"></view>
			</view> -->
		</view>
	</view>
</template>

<script>
	import uniCountdown from '@/components/uni-countdown/uni-countdown.vue'
	var playVideo,	
	setStartTime;//设置剩余开始时间;
	export default {
		props:{
			width: {//video宽度
				type: Number,
				default: 750
			},
			height:{//video高度
				type: Number,
				default: 450
			},
			videoMsg:{//提示
				type: String,
				default: ''
			},
			isPlaySource:{//是否有播放资源
				type: Boolean,
				default: false
			},
			isLive:{//是否是直播
				type: Boolean,
				default: false
			},
			sourceUrl:{//播放路径
				type: String,
				default: ''
			},
			isAutoplay:{//是否自动播放
				type: Boolean,
				default: false
			},
			bgc:{//背景色
				type: String,
				default: '#000000'
			}
		},
		data() {
			return {
				isPlayPause:false,
				dtime:'',
				t:0,
				istime:false,
			};
		},
		filters: {
		  filtersVideoMsg: function (value) {
		    return value.replace(/\,/g,"\n");
		  }
		},
		methods:{
			getVideoData(){
				this.istime = false;
				console.log("isPlaySource是否有播放源",this.isPlaySource);
				console.log("是否有倒计时",this.istime);
				console.log("提示",this.videoMsg);
				// that.$forceUpdate();
			},
			
			timeup() {
				uni.showToast({
					title: '时间到'
				})
			},
			/*清空倒计时*/
			clearStartTime(){
				return new Promise((res,rel) => {
					if(setStartTime){
						clearInterval(setStartTime);
						setStartTime = null; 
						this.dtime = '';
					}
					res();
				})
				
			},
			 formatSeconds(t) {
				let mi = 60,hh = mi*60,dd = hh*24;
				// let d = this.formatBit( Math.floor(t/dd)),
				// 		h = this.formatBit( Math.floor((t - d*dd)/hh)),
				// 		m = this.formatBit( Math.floor((t - d*dd - h*hh)/mi)),
				// 		s = this.formatBit( Math.floor((t - d*dd - h*hh - m*mi)));
				let h = this.formatBit( Math.floor(t/hh)),
						m = this.formatBit( Math.floor((t - h*hh)/mi)),
						s = this.formatBit( Math.floor((t - h*hh - m*mi)));		
				// let tstr = d+'天'+h+'小时'+m+"分"+s+'秒';
				let tstr = '倒计时:'+ h+'小时'+m+"分"+s+'秒';
				return tstr;
				
				// let min = Math.floor(t % 3600);
				// let h = this.formatBit(Math.floor(t / 3600)),
				// 		m = this.formatBit(Math.floor(min/60)),
				// 		s = this.formatBit( Math.floor(t%60));
				// let tstr = h+':'+m+":"+s;
				// return tstr;
			},
			setDataTime(time){
				this.clearStartTime().then( res => {
					this.istime = true;
					this.t = Math.floor(time/1000);
					console.log(this.t);
					setStartTime = setInterval(() => {
						this.t--;
						// console.log(this.t)
						this.dtime = this.formatSeconds(this.t)
						if (this.t <= 0) {
							clearInterval(setStartTime)
							// setTimeout(function() {this.istime = false;},1000);
							this.$emit('beginAnalysisSource');
						}
					}, 1000)
				})
			},
			formatBit(v){
				v = +v
				return v > 9 ? v : '0' + v
			},
			setPlay(){
				console.log("进入设置")
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
			},
			
			/*初始化播放器*/
			
			initVideo(pdata) {
				console.log('初始化',pdata)
				let _self = this;
				// #ifdef H5
				playVideo = new Aliplayer({
					id: 'J_prismPlayer',
					width: '100%',
					height: '100%',
					preload: true, //自动加载
					useFlashPrism:pdata.isFlash,
					useH5Prism: !pdata.isFlash,
					//支持播放地址播放,此播放优先级最高
					//http://yf.ugc.v.cztv.com/cztv/ugcvod/2018/04/14/A98CD7B26B06D94A5CEA56AA7D723572/h264_800k_mp4.mp4_playlist.m3u8
					source: pdata.url,
					isLive: pdata.isLive, //是否是直播
					// isLive: true, //是否是直播
					autoplay: pdata.isAutoplay||true, //自动播放
					cover:pdata.cover,
					skinLayout:[
						 {name: "bigPlayButton", align: "blabs", x: 30, y: 80},
						    {
						      name: "H5Loading", align: "cc"
						    },
						    {name: "errorDisplay", align: "tlabs", x: 0, y: 0},
						    {name: "infoDisplay"},
						    {name:"tooltip", align:"blabs",x: 0, y: 56},
						    {name: "thumbnail"},
						    {
						      name: "controlBar", align: "blabs", x: 0, y: 0,
						      children: [
						        {name: "progress", align: "blabs", x: 0, y: 44},
						        {name: "playButton", align: "tl", x: 15, y: 12},
						        {name: "timeDisplay", align: "tl", x: 10, y: 7},
						        {name: "fullScreenButton", align: "tr", x: 10, y: 12},
						        // {name:"subtitle", align:"tr",x:15, y:12},
						        // {name:"setting", align:"tr",x:15, y:12},
						        {name: "volume", align: "tr", x: 5, y: 10}
						      ]
						    }
					],
					// skinLayout:false,
				}, function(player) {
					console.log('播放器创建好了。')
					/*控制栏显示隐藏*/
					player.on('hideBar',function(){
						// that.isShowBar = false;
					});
					 player.on('showBar',function(){
						 // that.isShowBar = true;
						 
					 });
					 player.on('play',function(){
						 if(pdata.isLive){
							 _self.isPlayPause = false
						 }
					 })
					 player.on('pause',function(){
						 if(pdata.isLive){
							 _self.isPlayPause = true
						 }
					 })
					 player.on('error',function(){
							console.log("errr")
							_self.$emit('videoError');
					 })
					
				});			
					 console.log('初始化结束',)
				// #endif
				// #ifdef APP-PLUS
				
				// #endif	 
			},
			/*切换路径*/
			switchPath(){
				// #ifdef H5
				playVideo.loadByUrl(this.sourceUrl);
				// #endif	 
			},
			/*销毁后重建*/
			videoDisposeRebuild(){
				// #ifdef H5
				this.videoDispose().then( res => {
							this.initVideo(pdata)
				})
				// #endif
				
			},
			/*销毁播放器*/
			videoDispose() {
				return new Promise( (res,rel) => {
					// #ifdef H5
					if(playVideo){
						playVideo.dispose();
						this.clearStartTime();
					}
					// #endif
					res();
				})
			},
			play(){
				// #ifdef H5
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'pause'){
						playVideo.play();
					}
				}
				// #endif
			},
			pause(){
				// #ifdef H5
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'playing'){
						playVideo.pause();
					}
				}
				// #endif
			}	,
			/*切换播放暂停*/
			playPause (){
				// #ifdef H5
				if(playVideo){
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
				}
				// #endif
			},
		}
	}
</script>

<style lang="scss">
	.example-body {
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: center;
		padding: 0;
		font-size: 14rpx;
		background-color: #ffffff;
	}
	
.video-view {
			position: relative;
			// .playerBut{
			// 	width: 48rpx;
			// 	height: 48rpx;
			// 	position: absolute;
			// 	left: 20rpx;
			// 	bottom:16rpx ;
			// 	background-color: red;
			// 	z-index: 99;
			// }
			.video-app-class{
				width: 100%;
				height: 100%;
				video{
					width: 100%;
					height: 100%;
				}
			}
			.playBtn {
				position: absolute;
				top: 55%;
				left: 50%;
				transform: translate(-50%,-50%);
				width: 160rpx;
				height: 160rpx;
				/* background-color: rgba(0,0,0,.2); */
				border-radius: 50%;
				background-size: cover;
				background-image: url(../../static/images/playButton.png);
			}
			.playerSetView{
				position: absolute;
				width: 48rpx;
				height: 48rpx;
				left: 20rpx;
				bottom:16rpx;
				background-color: red;
				z-index: 99;
				
				
				.playerFullScreen{
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					right: 20rpx;
					bottom:16rpx ;
					background-color: red;
				}
			}
			
			.noPlayer{
				height: 450rpx;
				width: 100%;
				text-align: center;
				color: white;
				font-size: 40rpx;
				padding: 30rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				flex-direction: column;
			}
			.prism-player {}
		}
</style>
