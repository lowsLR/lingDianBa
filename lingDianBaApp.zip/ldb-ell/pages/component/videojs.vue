<template>
	<view>
		<view class="video-view"
		:style="{width:width+'rpx',height:height+'rpx',
		'background-color':bgc,
		}">
			<view v-if="!isPlaySource" class="noPlayer">
			<text v-if="!istime">{{ videoMsg | filtersVideoMsg}}</text>
			<text >{{dtime||''}}</text>
				<!-- <view class="example-body">
					<uni-countdown :show-day="false" :second="1000" @timeup="timeup" />
				</view> -->
			</view>
			
			<!-- #ifdef H5 -->
			<view class="video-main">
				<!-- <video id="playVideoId" class="video-js vjs-default-skin vjs-big-play-centered"
				  poster="http://video-js.zencoder.com/oceans-clip.png"
				 >
				</video> -->
				<view class="video-js vjs-big-play-centered" ref="video">
				
				</view>
			</view>
			<!-- #endif -->
			<!-- #ifdef APP-PLUS -->
			<video src="" controls></video>
			<!-- #endif -->
			
			
			<!-- v-if="isPlaySource" -->
			<view class="playerBut"  ></view>
			<!-- <view   class="playerSetView" >
				
			 </view> -->
			  <view v-if="isPlaySource&&isPlayPause"  @tap="setPlay" class="playBtn"></view>
			
		</view>
	</view>
</template>

<script>
	
	var playVideo,
	setStartTime;//设置剩余开始时间;
	export default {
		props:{
			width: {//video宽度
				type: Number,
				default: 750
			},
			height:{//video高度
				type: Number,
				default: 450
			},
			videoMsg:{//提示
				type: String,
				default: ''
			},
			isPlaySource:{//是否有播放资源
				type: Boolean,
				default: false
			},
			isLive:{//是否是直播
				type: Boolean,
				default: false
			},
			sourceUrl:{//播放路径
				type: String,
				default: ''
			},
			isAutoplay:{//是否自动播放
				type: Boolean,
				default: false
			},
			bgc:{//背景色
				type: String,
				default: '#000000'
			}
		},
		data() {
			return {
				isPlayPause:false,
				dtime:'',
				t:0,
				istime:false,
			}
		},
		filters: {
		  filtersVideoMsg: function (value) {
		    return value.replace(/\,/g,"\n");
		  }
		},
		methods:{
			setPlay(){
				console.log("进入设置")
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
			},
			/*初始化播放器*/
			
			initVideo(pdata) {
				console.log('初始化',pdata)
				var video = document.createElement('video')
				video.id = 'video'
				video.style = 'width: 100%;height: 100%;'
				video.controls = true
				// video.crossorigin = '*';
				// video.crossorigin = 'anonymous';
				var source = document.createElement('source')
				// source.src = '/loc/live/cctv1_2/index.m3u8';
				source.src = pdata.url;
				video.appendChild(source)
				// console.log(this.$refs.video);
				this.$refs.video.$el.appendChild(video)
				this.$forceUpdate();
				let option = {
					muted: false,
					controls: true,
					loop: false,
					preload: 'none',
					language: 'zh-CN',
					controlBar: {
						volumePanel: {
							inline: false
						},
						pictureInPictureToggle: false,
					}
					// techOrder: ["html5","flash"],
					// autoplay :  false,
					// controls : true,
					// preload: 'auto',
					// width:"100%", 
					// height:"100%",
					// children: [
					//     'bigPlayButton',
					//     'controlBar'
					//   ],
					// sources: [{
					//     src: 'http://yf.ugc.v.cztv.com/cztv/ugcvod/2018/04/14/A98CD7B26B06D94A5CEA56AA7D723572/h264_800k_mp4.mp4_playlist.m3u8',
					//     type: 'application/x-mpegURL'
					//   }]
				}
				// muted: false,
				// controls: true,
				// loop: false,
				// preload: 'none',
				// language: 'zh-CN',
				// controlBar: {
				// 	volumePanel: {
				// 		inline: false
				// 	},
				// 	pictureInPictureToggle: false,
				// }
				playVideo = videojs('video',{},function(){
					console.log("播放器创建完成");
					let pt = this;
					pt.on('error', function() { //请求数据时遇到错误 
						console.log("请求数据时遇到错误")
					});
					pt.on('stalled', function() { //网速失速 
						console.log("网速失速")
					});
					pt.on('play', function() { //开始播放 
						console.log("开始播放")
					});
					pt.on('pause', function() { //暂停 
						console.log("暂停")
					});
					pt.on('timeupdate', function() {
						// console.log(this.currentTime())
					})
					
				})
				
				
			},
			/*切换路径*/
			switchPath(){
				playVideo.loadByUrl(this.sourceUrl);
			},
			/*销毁后重建*/
			videoDisposeRebuild(){
				this.videoDispose().then( res => {
							this.initVideo(pdata)
				})
			},
			/*销毁播放器*/
			videoDispose() {
				return new Promise( (res,rel) => {
					if(playVideo){
						playVideo.dispose();
						this.clearStartTime();
					}
					res();
				})
			},
			play(){
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'pause'){
						playVideo.play();
					}
				}
			},
			pause(){
				if(playVideo){
					let sta = playVideo.getStatus();
					if(sta == 'playing'){
						playVideo.pause();
					}
				}
			}	,
			/*切换播放暂停*/
			playPause (){
				if(playVideo){
					let sta = playVideo.getStatus();
					console.log(sta);
					if(sta == 'playing'){
						playVideo.pause();
					}
					if(sta == 'pause'){
						playVideo.play();
					}
				}
			},
			
			getVideoData(){
				this.istime = false;
				console.log("isPlaySource是否有播放源",this.isPlaySource);
				console.log("是否有倒计时",this.istime);
				console.log("提示",this.videoMsg);
				// that.$forceUpdate();
			},
			timeup() {
				uni.showToast({
					title: '时间到'
				})
			},
			/*清空倒计时*/
			clearStartTime(){
				return new Promise((res,rel) => {
					if(setStartTime){
						clearInterval(setStartTime);
						setStartTime = null; 
						this.dtime = '';
					}
					res();
				})
				
			},
			 formatSeconds(t) {
				let mi = 60,hh = mi*60,dd = hh*24;
				// let d = this.formatBit( Math.floor(t/dd)),
				// 		h = this.formatBit( Math.floor((t - d*dd)/hh)),
				// 		m = this.formatBit( Math.floor((t - d*dd - h*hh)/mi)),
				// 		s = this.formatBit( Math.floor((t - d*dd - h*hh - m*mi)));
				let h = this.formatBit( Math.floor(t/hh)),
						m = this.formatBit( Math.floor((t - h*hh)/mi)),
						s = this.formatBit( Math.floor((t - h*hh - m*mi)));		
				// let tstr = d+'天'+h+'小时'+m+"分"+s+'秒';
				let tstr = '倒计时:'+ h+'小时'+m+"分"+s+'秒';
				return tstr;
				
				// let min = Math.floor(t % 3600);
				// let h = this.formatBit(Math.floor(t / 3600)),
				// 		m = this.formatBit(Math.floor(min/60)),
				// 		s = this.formatBit( Math.floor(t%60));
				// let tstr = h+':'+m+":"+s;
				// return tstr;
			},
			setDataTime(time){
				this.clearStartTime().then( res => {
					this.istime = true;
					this.t = Math.floor(time/1000);
					console.log(this.t);
					setStartTime = setInterval(() => {
						this.t--;
						// console.log(this.t)
						this.dtime = this.formatSeconds(this.t)
						if (this.t <= 0) {
							clearInterval(setStartTime)
							// setTimeout(function() {this.istime = false;},1000);
							this.$emit('beginAnalysisSource');
						}
					}, 1000)
				})
			},
			formatBit(v){
				v = +v
				return v > 9 ? v : '0' + v
			},
		}
	}
</script>

<style lang="scss">
.video-view {
			position: relative;
			
			width: 750rpx;
			height: 500rpx;
			display: flex;
			.video-main{
				width: 100%;
				height: 100%;
				.video-js{
					flex: 1;
					width: 100%;
					height: 100%;
					video{
						width: 100%;
						height: 450rpx;
					}
				}
			}
			
			// .playerBut{
			// 	width: 48rpx;
			// 	height: 48rpx;
			// 	position: absolute;
			// 	left: 20rpx;
			// 	bottom:16rpx ;
			// 	background-color: red;
			// 	z-index: 99;
			// }
			// .playBtn {
			// 	position: absolute;
			// 	top: 55%;
			// 	left: 50%;
			// 	transform: translate(-50%,-50%);
			// 	width: 160rpx;
			// 	height: 160rpx;
			// 	/* background-color: rgba(0,0,0,.2); */
			// 	border-radius: 50%;
			// 	background-size: cover;
			// 	background-image: url(../../static/images/playButton.png);
			// }
			.playerSetView{
				position: absolute;
				width: 48rpx;
				height: 48rpx;
				left: 20rpx;
				bottom:16rpx;
				background-color: red;
				z-index: 99;
				
				
				.playerFullScreen{
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					right: 20rpx;
					bottom:16rpx ;
					background-color: red;
				}
			}
			
			.noPlayer{
				height: 450rpx;
				width: 100%;
				text-align: center;
				color: white;
				font-size: 40rpx;
				padding: 30rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				flex-direction: column;
			}
			
		}
		
		
		.video-js .vjs-big-play-button{
		    font-size: 2.5em;
		    line-height: 2.3em;
		    height: 2.5em;
		    width: 2.5em;
		    -webkit-border-radius: 2.5em;
		    -moz-border-radius: 2.5em;
		    border-radius: 2.5em;
		    background-color: #73859f;
		    background-color: rgba(115,133,159,.5);
		    border-width: 0.15em;
		    margin-top: -1.25em;
		    margin-left: -1.75em;
		}
		/* 中间的播放箭头 */
		.vjs-big-play-button .vjs-icon-placeholder {
		    font-size: 1.63em;
		}
		/* 加载圆圈 */
		.vjs-loading-spinner {
		    font-size: 2.5em;
		    width: 2em;
		    height: 2em;
		    border-radius: 1em;
		    margin-top: -1em;
		    margin-left: -1.5em;
		}
</style>
