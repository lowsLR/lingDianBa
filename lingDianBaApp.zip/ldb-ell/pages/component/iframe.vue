<template>
	<view class="iframe-mian">
		<iframe
		frameborder=0
		:src="iframeSrc"
		scrolling="no"
		></iframe>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		props: {
			iframeSrc: {
				type: String,
				default: ''
			},
		},
		onLoad() {
			console.log("iframe的数据",iframeSrc);
		},
		onReachBottom(){
			
		},
		methods: {
			
		}
	}
</script>

<style>
	/* .iframe-mian{
		width: 100%;
		height: 100%;
		overflow: auto;
		-webkit-overflow-scrolling: touch; 
		-webkit-overflow-scrolling: touch;
		-webkit-overflow:auto;
		
	} */
	iframe{
		width: 100%;
		height: 100%;
		overflow: auto;
		-webkit-overflow-scrolling: touch; 
		-webkit-overflow-scrolling: touch;
		-webkit-overflow:auto;
	}
</style>
