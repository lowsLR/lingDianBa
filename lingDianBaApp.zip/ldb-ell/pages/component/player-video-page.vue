<!-- 录像模板  -->
<template>
	<view class="content">
		<scroll-view scroll-y="true" class="lx-scroll-view">
		<view class="vpage-main">
			<match-score
			modulesType="3"
			:guestTeamLogoPath="guestTeamLogoPath"
			:guestTeamName="guestTeamName"
			:guestTeamSocre="guestTeamSocre"
			:homeTeamLogoPath="homeTeamLogoPath"
			:homeTeamName="homeTeamName"
			:homeTeamScore="homeTeamScore"
			:isFinsh="isFinsh"
			:matchStartState="matchStartState"
			:matchTitle="matchTitle"
			></match-score>
			
			<view class="vpage-list">
				<view class="" v-if="matchLiveSourceDOS.length > 0">
					<view class="vpage-list-item"

						v-for="(item,index) in matchLiveSourceDOS"
						:key="item.updetedTime + index"
						@tap="openExternalPage(item,index)"

					>
						<view class="item-left">
							<!-- @error="imageError(cindex,index, xindex, 0)"  -->
							<image v-if="bigEventTypePath != '' && bigEventTypePath != null" :src="bigEventTypePath" mode="aspectFit"></image>
							<image v-else-if="bigEventLogoPath != '' && bigEventLogoPath != null" :src="bigEventLogoPath" mode="aspectFit"></image>
							<image v-else src="/static/assets/default.png" mode=""></image>
						</view>
						<view class="item-right">
							<view class="item item-one" v-if="homeTeamName || guestTeamName">
								{{homeTeamName}} {{homeTeamName&&guestTeamName?' - ':'' }} {{guestTeamName}}
							</view>
							<view class="item item-one" v-else>
								{{matchTitle}}
							</view>
							<view class="item item-two">
								<text style="color: red;" v-if="item.matchSourcePathShortName">
									[{{item.matchSourcePathShortName}}]
								</text>
								{{item.liveSourceName}} <!-- {{item.liveSourceName&&item.liveNarrator?' / ':'' }}{{item.liveNarrator}} -->
							</view>
						</view>
					</view>
				</view>
				<view v-else>
					<view class="nodata">
						<!-- 暂无数据 -->
					</view>
				</view>
			</view>
		</view>
			</scroll-view>
	</view>
</template>

<script>
	import matchScore from '../component/match-score.vue';
	export default {
		name: 'player-video-page',
		components: {
			matchScore,
		},
		props: {
			// 赛事类型（专题）大图标
			bigEventTypePath: {
				type: String,
				default: ''
			},
			// 项目(运动)类型 大图标
			bigEventLogoPath: {
				type: String,
				default: ''
			},
			
			homeTeamLogoPath: {//主队图标
				type: String,
				default: ''
			},
			// matchSourcePathShortName:{//播放器简称
			// 	type:String,
			// 	default:'',
			// },
			homeTeamName:{//主队名称
				type: String,
				default: ''
			},
			homeTeamScore: {//主队比分
				type: String,
				default: ''
			},
			guestTeamLogoPath: {//客队图标
				type: String,
				default: ''
			},
			guestTeamName:{//客队名称
				type: String,
				default: ''
			},
			guestTeamSocre:{	//客队比分
				type: String,
				default: ''
			},
			matchTitle:{//标题
				type: String,
				default: ''
			},
			isFinsh:{//是否结束 0true 1false
				type: String,
				default: ''
			},
			isHot:{//是否热门
				type: String,
				default: ''
			},
			isRecommend:{//是否推荐
				type: String,
				default: ''
			},
			isTop:{//是否置顶
				type: String,
				default: ''
			},
			matchStartState:{//赛事进行状态 0进行中 1未开始 2已结束
				type: String,
				default: ''
			},
			matchBeginTime:{//开始时间
				type: String,
				default: ''
			},
			matchEndTime:{//结束时间
				type: String,
				default: ''
			},
			matchLiveSourceDOS: {//录像数组
				type: Array,
				default: () => {
				  return []
				}
			},
		},
		data() {
			return {
				isScore: false,
				analysisSourceNumber:0,//解析次数
				timeOutAnalys:null,//延迟解析对象
				
				allowClick: true, // 是否允许列表项点击（避免多次打开页面）
			}
		},
		watch: {
			'matchLiveSourceDOS.length': function(newVal,oldVal){
				console.log('录像列表：',this.matchLiveSourceDOS);
			},
		},
		filters:{
			/*限制长度*/
			limitLength:function(v){
				return v.length>8?v.substring(0,8):v;
			}
		},
		methods: {
			// 跳转外部录像链接
			openExternalPage: function (lxitem,index) {
				if (!this.allowClick) return;
				this.allowClick = false;
				
				let that = this,
					newPath,
					item = that.matchLiveSourceDOS[index];
				console.log(item);
				if(that.timeOutAnalys){
					clearTimeout(that.timeOutAnalys);
					that.timeOutAnalys = null;
				}
				that.analysisMatchLiveSource(item,index)
			},
			
			analysisMatchLiveSource(item,index){
				let that = this;
				// uni.hideLoading();
				uni.showLoading()
				let datas = {
					"sourcePathId": item.sourceId
				}
				console.log('解析直播源参数(id)：',datas);
				// 解析直播源
				that.analysisSourceNumber = 0;
				that.reqAnalysisMatchLiveSource(item,datas,index);
				
			},
			reqAnalysisMatchLiveSource(item,datas,index){
				let that = this;
				that.analysisSourceNumber++;
				that.$req.reqc.analysisMatchLiveSource(datas)
				.then(res => {
					console.log("解析直播信息",res)
					if (res.data.resultCode == 1 && res.statusCode == 200) {
						uni.hideLoading();
						let data = res.data.data;
						item.valid = '0';
						that.matchLiveSourceDOS[index].valid = '0';
						that.matchLiveSourceDOS[index].analysisPlayPathWeb = data.analysisPlayPathWeb;
						that.matchLiveSourceDOS[index].notAnalysisPlayPath = data.notAnalysisPlayPath;
						that.matchLiveSourceDOS[index].webLink = data.webLink;
						that.merge(item)
					}else if (res.data.resultCode != 1 && res.statusCode == 200) {
						if(res.data.resultCode == -199){
							// setTimeout(function() {
							// 	that.reqAnalysisMatchLiveSource(item,datas,index);
							// }, 1000);
							if(that.analysisSourceNumber < 10){
								that.timeOutAnalys = setTimeout(function() {
									that.reqAnalysisMatchLiveSource(item,datas,index);
								}, 1000);
							}else{
								uni.hideLoading();
								// uni.showToast({
								// 	icon: 'none',
								// 	title: '暂未获取信号,请选择其他播放源观看'
								// })
								that.shibai();
							}
						}else{
							uni.hideLoading();
							that.shibai(res)
						}
					}
				}).catch(err => {
					that.allowClick = true; // 修改列表项允许点击状态
					
					uni.hideLoading();
					uni.showToast({
						icon: 'none',
						title: '请稍后再试'
					})
					console.log(err);
				})
			},
			
			merge (item,index) {
				let that = this;
				let url = '/pages/webview/webview',
					temp = {
						matchId: item.matchId,
						sourceId: item.sourceId,
						sourcePath: item.notAnalysisPlayPath ,
						usable: 1,
						title: item.liveSourceName
					};
				switch (item.isAnalysis){
					case '0':
					case '2':
						if (item.analysisPlayPathWeb) {
							url = '/pages/index/videoPlay',
							temp.sourcePath = item.analysisPlayPathWeb;
						} else {
							// 判断信号源播放类型（linkPlayType：解析方式 2iframe 3url跳转）
							if (item.linkPlayType == 2) {
								url = '/pages/index/videoPlay'
							}
							temp.sourcePath = item.webLink;
						}
						break;
					case '1':
					case '3':
						temp.sourcePath = item.notAnalysisPlayPath;
						break;
					default:
						break;
				}
				that.navigateTo(url,temp);
			},
			
			// 页面跳转
			navigateTo(url,data){
				setTimeout(()=> {
					this.allowClick = true; // 修改列表项允许点击状态
				}, 300);
				
				uni.navigateTo({
					url: url+'?data=' + encodeURIComponent(JSON.stringify(data))
				})
			},
			
			shibai(res){
				setTimeout(()=> {
					this.allowClick = true; // 修改列表项允许点击状态
				}, 300);
				
				uni.showToast({
					icon: 'none',
					title: res.data.resultMsg||'当前播放源不可用'
				})
			},
			
			setIsScore(){
				this.isScore = !this.isScore;
			},
		}
	}
</script>

<style lang="scss" scoped>
	.lx-scroll-view{
		// height: 100%;
		// height: 750rpx;
		height: calc(100vh - 90rpx - 90rpx - var(--status-bar-height));
	}
.content{
	min-height: 100%;
	height: auto;
	// width: 100%;
	background:rgba(255,255,255,1);
	// position: relative;
	.vpage-main{
		// position: relative;
		.vpage-list{
			// padding-top: 174rpx;
			.vpage-list-item{
				display: flex;
				align-items: center;
				justify-content: flex-start;
				padding: 24rpx 20rpx;
				border-bottom:1rpx solid rgba(225,225,225,1);
				.item-left{
					image{
						width:206rpx;
						height:136rpx;
						border-radius:6rpx;
					}
				}
				.item-right{
					padding-left: 26rpx;
					height:136rpx;
					display: flex;
					flex-direction: column;
					font-size:26rpx;
					font-family:PingFang SC;
					font-weight:400;
					color:rgba(0,0,0,1);
					// align-items: center;
					flex: 1;
					.item {
						line-height: 44rpx;
					}
					.item-one{
						font-size: 20rpx;
						color: #666666;
					}
					.item-two{
						
					}
				}
			}
			
		}
		.vpage-top{
			// position: fixed;
			// top: 0;
			height:174rpx;
			width: 100%;
			border-bottom:1rpx solid rgba(225,225,225,1);
			display: flex;
			align-items: flex-end;
			z-index: 10;
			background-color: #FFFFFF;
			// padding-bottom: 23rpx;
			.vpage-team{
				flex: 1;
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				image{
					width:88rpx;
					height:88rpx;
					border-radius: 88rpx;
				}
				.textTeamName{
					// word-wrap: normal;
					line-height: 70rpx;
					overflow: hidden;
					white-space: nowrap;
				}
				
			}
			.vpage-content{
				flex: 1;
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				.vpage-content-top{
					.vpage-score{
						text{
							font-size:36rpx;
							font-family:PingFang SC;
							line-height:60rpx;
						}
						text:nth-child(odd){
							font-weight:500;
							color:rgba(255,83,55,1);
						}
						text:nth-child(even){
							font-weight:400;
							color:rgba(0,0,0,1);
							padding: 0 70rpx;
						}
					}
					.show-but{
						width:140rpx;
						height:44rpx;
						background:rgba(27,27,48,1);
						border-radius:22rpx;
						font-size:22rpx;
						font-weight:400;
						color:rgba(255,255,255,1);
						// line-height:114rpx;
						display: flex;
						align-items: center;
						justify-content: center;
					}
				}
				.vpage-content-bottom{
						line-height: 70rpx;
						color: #666666;
						font-size: 18rpx;
				}
			}
		}
		
	}
	
}
</style>
