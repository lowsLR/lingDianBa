<template>
	<view class="content">

		<scroll-view class="scroll" scroll-y>
			<view class="scroll-content">
				<view class="evalution">
					<view class="eva-item">
						<image :src="dlist.imageUrl?dlist.imageUrl:'/static/assets/user_default.png'" mode="aspectFill"></image>
						<view class="eva-right">
							<text style="color: #000000;">{{dlist.nickName||'新用户'}}</text>
							<text class="time-view">{{dlist.createdTime}}</text>
							<view class="zan-box" @tap.stop="likeType(dlist.id,dlist.likeType)">
								<!-- <text class="icon iconfont" :class="dlist.likeType==0?'':'like'">&#xe603;</text> -->
								<view class="icon zanIcon" :class="dlist.likeType==0?'':'like'"></view>
								<text class="likeNum">{{dlist.number||''}}</text>
								<text class="yticon icon-shoucang"></text>
							</view> 
						
							<text style="color: #000000;" class="content-view">{{dlist.content}}</text>
								<view class="uni-comment-list border-b" v-for="(item,idx) in clist" :key="idx">
										<image :src="item.imageUrl?item.imageUrl:'/static/assets/user_default.png'" mode="aspectFill"></image>
										<view class="eva-right ">
											<text style="color: #000000;">{{item.nickName||'新用户'}}</text>
											<text class="time-view">{{item.createdTime}}</text>
											<view class="zan-box" @tap.stop="likeTypeChi(idx,item.id,item.likeType)">
												<!-- <text class="icon iconfont" :class="item.likeType==0?'':'like'">&#xe603;</text> -->
												<view class="icon zanIcon" :class="item.likeType == 0 ? '' : 'like'"></view>
												<text class="likeNum">{{item.number||''}}</text>
												<text class="yticon icon-shoucang"></text>
											</view>
										
											<text style="color: #000000;" class="content-view">{{item.content}}</text>
										</view>
								</view>
						</view>
					</view>
				</view>
				
			</view>
		</scroll-view>
		
		<!-- 输入框 -->
		<view class="bottom">
			<view class="inputBox">
				<!-- :class="[bindStyle ? (submitBtn ? 'notNull' : 'bindBg') : '']" -->
				<input confirm-type="search" @confirm="search" class="multiline" v-model="commentsInput" @focus="focusTextArea" @blur="bindTextArea" value="" placeholder="发表评论..." @input="MonitorIn" placeholder-style="color: #999999;"  />
				<view @tap="search" class="submit" v-if="submitBtn">提交</view>
				<view v-else @tap="likeType(dlist.id,dlist.likeType)"  class="confirm-btn icon iconfont" :class="dlist.likeType==0?'':'like'"></view>
			</view>
		</view>
		
		<!-- <view class="bottom">
			<view class="input-box">
				<text class="yticon icon-huifu"></text>
				<input confirm-type="search" @confirm="search" class="input" type="text" placeholder="点评一下把.." placeholder-style="color:#adb1b9;" />
			</view>
			<text @tap="likeType(dlist.id,dlist.likeType)"  class="confirm-btn icon iconfont" :class="dlist.likeType==0?'':'like'">&#xe603;</text>
		</view> -->
	</view>
</template>

<script>
	let that;
	export default {
		components: {
			
		},
		data() {
			return {
				title: "评论",
				index: 0,
				commentId:0,
				comment:[],
				clist:[],
				dlist:{},
				type:1,
				commentsInput:'',
				bindStyle: false,
				submitBtn: false,
			}
		},
		onLoad(op) {
			console.log(op)
			that = this;
			that.commentId = op.commentId;
			that.type = op.type;
		},
		onReady() {
			that.getCom();
		},
		methods: {
			likeType(id,commentType){
				let datas = {
					"commentType": commentType,
					"id": id
				};
				console.log(datas)
				that.$req.req.updateMainCommentlike(datas)
				.then(res => {
					console.log("点赞",res)
					that.dlist.likeType = commentType==0?1:0;
					if(!commentType){
						that.dlist.number++;
					}else{
						that.dlist.number--;
					}
					
					// this.$emit('setLikeType', {id,cType});
				})
			},
			likeTypeChi(idx,id,commentType){
				let datas = {
					"commentType": commentType,
					"id": id
				};
				console.log(datas)
				that.$req.req.updateCommentlikeChi(datas)
				.then(res => {
					console.log("点赞",res)
					that.clist[idx].likeType = commentType==0?1:0;
					if(!commentType){
						that.clist[idx].number++;
					}else{
						that.clist[idx].number--;
					}
					// this.$emit('setLikeType', {id,cType});
				})
			},
			
			search(e){
				if(that.commentsInput == ''){
					uni.showToast({
						title:"请输入评论内容",
						icon:"none"
					})
					return;
				}
				let datas = {
						"commentContent": that.commentsInput,
						"mainCommentId": that.dlist.id,
						"matchType": that.type
				}
				that.$req.req.createCommentChi(datas)
				.then( res => {
					console.log(res)
					uni.showToast({
						title:"评论发送成功！",
						icon:"none"
					})
					that.commentsInput = '';
					that.submitBtn = false;
					that.getCom();
				})
			},
				getCom(){
					let datas = {
						"commentId": that.commentId,
						"matchType":that.type,
						"limit": 20,
						"offset": 1,
						"sortTypeId": 1
					}
					that.$req.req.queryCommentChild(datas)
					.then( res => {
						console.log("二级评论",res);
						that.dlist = res.data.data.list[0].sportMatchCommentDO;
						that.clist = res.data.data.list[0].sportMatchCommentChildDOS;
						console.log('主评论',that.dlist);
					})
					
				},
				// 输入框聚焦
				focusTextArea: function (e) {
					that.bindStyle = true;
				},
				// 输入框失去焦点
				bindTextArea: function (e) {
					// console.log(e.detail.value,"长度："+e.detail.value.length)
					var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
					// console.log(val)
					// 注释：indexOf() 方法对大小写敏感！
					// 注释：如果要检索的字符串值没有出现，则该方法返回 -1
					if (val != '' && val != null) {
						that.submitBtn = true;
					} else {
						that.bindStyle = false;
						that.submitBtn = false;
					}
				},
				// 输入监听
				MonitorIn: function (e) {
					var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
					if (val != '' && val != null) {
						that.submitBtn = true;
					} else {
						that.submitBtn = false;
					}
				}
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
	}
.like{
			color: #007AFF !important;
		}
		.likeNum{
			font-size:22upx;
			font-weight:400;
			color:rgba(102,102,102,1);
			line-height: 45upx;
		}
	.content {
		display: flex;
		flex-direction: column;
		height: 100%;
		background: #fff;
		width: 100vw;
	}

	.scroll {
		flex: 1;
		position: relative;
		background-color: #f8f8f8;
		height: 0;
	}

	.scroll-content {
		display: flex;
		flex-direction: column;
	}

	/* 评论 */
	.evalution {
		display: flex;
		flex-direction: column;
		background: #fff;
		width: 100%;
	}

	.eva-item {
		display: flex;
		padding: 20upx;
		position: relative;

		image {
			width: 82upx;
			height: 82upx;
			border-radius: 50px;
			flex-shrink: 0;
			margin-right: 24upx;
		}

		&:after {
			content: '';
			position: absolute;
			left: 30upx;
			bottom: 0;
			right: 0;
			height: 0;
			border-bottom: 1px solid #eee;
			transform: translateY(50%);
		}

		&:last-child:after {
			border: 0;
		}
	}

	.eva-right {
		display: flex;
		flex-direction: column;
		flex: 1;
		font-size: 26upx;
		color: #909399;
		position: relative;

		.zan-box {
			display: flex;
			align-items: base-line;
			position: absolute;
			top: 10upx;
			right: 10upx;
			// justify-content: center;
			// align-items: flex-end;
			
			.zanIcon {
				position: absolute;
				top: 8rpx;
				right: 20rpx;
				
				width: 25rpx;
				height: 25rpx;
				margin: 0 8rpx 0 26rpx;
				background-size: cover;
				background-image: url(../../static/iconSet/zan_def2.png);
			}
			.like {
				background-image: url(../../static/iconSet/zan_active.png);
			}
			
			.yticon {
				margin-left: 8upx;
			}
		}

		.content {
			font-size: 28upx;
			color: #333;
			padding-top: 20upx;
		}
	}

	/* 底部 */
	.bottom {
		flex-shrink: 0;
		display: flex;
		align-items: center;
		height: 90upx;
		// padding: 0 30upx;
		box-shadow: 0 -1px 3px rgba(0, 0, 0, .04);
		position: relative;
		z-index: 1;
	
		
		/* 文本框 */
		.inputBox {
			// width: 100vw;
			width: 100%;
			min-height: 88rpx;
			box-sizing: border-box;
			padding: 14rpx 0;
			background-color: #FFFFFF;
			// border-top: 1px solid #EAEAEA;
			position: relative;
			position: fixed;
			bottom: 0;
			display: flex;
			align-items: center;
			justify-content: space-between;
			.multiline {
				width: 80%;
				padding: 0px;
				margin: 0px;
				box-sizing: border-box;
				height: 68rpx;
				margin: 0 20rpx;
				padding: 12rpx 26rpx;
				border-radius: 12rpx;
				background-color: #F8F8F8;
				border: 1px solid #EAEAEA;
				font-size: 13px;
				color: #333333;
			}
			// 输入框底部 点赞按钮
			.confirm-btn {
				position: absolute;
				right: 30rpx;
				width: 62rpx;
				height: 62rpx;
				background-size: cover;
				background-image: url(../../static/iconSet/zan_def2.png);
			}
			.like {
				background-image: url(../../static/iconSet/zan_active.png);
			}
			/* 提交按钮 */
			.submit {
				position: absolute;
				top: 50%;
				right: 10rpx;
				transform: translateY(-50%);
				width: 100rpx;
				height: 55rpx;
				line-height: 55rpx;
				text-align: center;
				border-radius: 4rpx;
				color: #FFFFFF;
				background-color: #1B1B30;
			}
		}
	
	}
</style>
