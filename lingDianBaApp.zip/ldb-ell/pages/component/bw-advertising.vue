<template>
	<view class="advertis" v-if="showAD" :style="{width: AdList.AdWidth, height: AdList.AdHeight}">
		<!-- 图片广告 -->
		<image
			v-if="this.AdList.advertisementShowType == 0"
			class="advertis-image" 
			:style="{width: AdList.AdWidth, height: AdList.AdHeight}" 
			:src="AdList.advertisementPath ? ('https://images.weserv.nl/?url='+AdList.advertisementPath) : '../../static/default_tv.png'" 
			mode=""
			@tap="openAd"
		></image>
		
		<!-- 文字广告 -->
		<view class=""
			v-if="this.AdList.advertisementShowType == 1"
		>
			{{AdList.advertisementText}}
		</view>
		
		<!-- 代码广告 -->
		<view class=""
			v-if="this.AdList.advertisementShowType == 2"
		>
			{{AdList.advertisementCode}}
		</view>
		
		<!-- 关闭按钮 -->
		<view class="advertis-close" @tap="close">
			<uni-icons type="closeempty" color="#FFFFFF" size="12" />
			<text class="closeText">关闭广告</text>
		</view>
	</view>
</template>

<script>
	export default {
		props: {
			// 指定的广告名称
			AdName: {
				type: String
			},
			// 广告列表数据
			AdList: {
				type: Object,
				default: () => {
					return {}
				}
			}
			/* AdStatus: {
				type: Boolean,
				default: true
			} */
		},
		data() {
			return {
				showAD: true
			}
		},
		created: function() {
			// console.log('广告数据：',this.AdList);
			// console.log('广告展示方式 0图片1文字2代码：',this.AdList.advertisementShowType);
		},
		methods: {
			// 打开广告
			openAd() {
				if (this.AdList.advertisementLinkAddress) {
					let obj = {
						link: this.AdList.advertisementLinkAddress,
					}
					uni.navigateTo({
						url: '/pages/webview/adWebview?data='+ encodeURIComponent(JSON.stringify(obj))
					})
				} else {
					uni.showToast({
						icon: 'none',
						title: '暂无跳转链接'
					})
				}
			},
			
			close(){
				this.showAD = !this.showAD;
				
				// this.$emit('closeAD');
				// this.$emit('update:AdStatus', false);
				
				// 修改指定广告状态
				let opt = {
					name: this.AdName
				}
				this.$store.commit('modifyAdStatus', opt);
			}
		}
	}
</script>

<style scoped>
.advertis {
	width:750rpx;
	height:120rpx;
	overflow: hidden;
	/* background-color: #000000; */
	position: relative;
	margin-top: 4rpx;
	margin-bottom: 4rpx;
}
/* 广告图 */
.advertis-image {
	width:750rpx;
	height:120rpx;
}
/* 关闭按钮 */
.advertis-close {
	/* #ifndef APP-NVUE */
	display: flex;
	flex-direction: row;
	white-space: nowrap;
	/* #endif */
	
	/* #ifdef APP-NVUE */
	flex-direction: row;
	/* #endif */
	
	justify-content: center;
	align-items: center;
	
	position: absolute;
	right: 0;
	top: 0;
	
	width: 102rpx;
	height: 24rpx;
	/* height: 100rpx; */
	background-color: #999999;
	opacity: .6;
	font-size: 9px;
	overflow: hidden;
}

.closeText {
	color: #FFFFFF;
	/* #ifdef APP-NVUE */
	font-size: 9px;
	/* #endif */
}
</style>
