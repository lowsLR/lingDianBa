<template>
	<view class="downloadBuoy">
		<view class="buoy-main" @click="open">
			<view class="buoy-left">
				<image class="buoy-img" src="./logo.jpg" mode=""></image>
				<view class="buoy-text">
						<text>零点吧</text>
						<text>零点吧是国内最好最全面的nba直播吧</text>
				</view>
			</view>
			<view class="buoy-btn">
				立即下载
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			open(){
				uni.navigateTo({
					url: "/pages/mine/downloadApp"
				})
			},
		}
	}
</script>

<style>
.downloadBuoy{
		width: 750rpx;
		height: 100rpx;
		position: fixed;
		z-index: 999999;
		bottom: 100rpx;
		background-color: rgba(0,0,0,0.4);
		display: flex;
}
.buoy-main{
	flex: 1;
	display: flex;
	align-items: center;
	justify-content: space-around;
	
}

.buoy-left{
	display: flex;
	align-items: center;
	justify-content: center;
}
.buoy-text{
	display: flex;
	align-items: flex-start;
	justify-content: flex-start;
	flex-direction: column;
	padding-left: 10rpx;
	color: white;
}
.buoy-text text:first-child{
	font-size: 30rpx;
}
.buoy-text text:nth-child(2){
	font-size: 16rpx;
}
.buoy-img{
	width: 80rpx;
	height: 80rpx;
	border-radius: 10rpx;
}
.buoy-btn{
	display: flex;
	align-items: center;
	justify-content: center;
	width: 150rpx;
	height: 65rpx;
	border-radius: 9999rpx;
	background-color: red;
	color: white;
	font-size: 30rpx;
}
</style>
