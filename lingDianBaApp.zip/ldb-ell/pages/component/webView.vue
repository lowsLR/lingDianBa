<template>
	<view class="iframe-mian">
		<web-view :src="iframeSrc"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		props: {
			iframeSrc: {
				type: String,
				default: ''
			},
		},
		onLoad() {
			
		},
		onReachBottom(){
			
		},
		methods: {
			
		}
	}
</script>

<style>
	.iframe-mian{
		width: 100%;
		height: 100%;
		overflow: auto;
		-webkit-overflow-scrolling: touch; 
		-webkit-overflow-scrolling: touch;
		-webkit-overflow:auto;
		web-view{
			width: 100%;
			height: 100%;
		}
	}
</style>
