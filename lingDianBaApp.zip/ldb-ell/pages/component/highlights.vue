<!-- 集锦模块 -->
<template>
	<view class="content">
		<scroll-view scroll-y="true" class="jj-scroll-view">
			
		
		<view class="highlights-main">
			<match-score
			modulesType="4"
			:guestTeamLogoPath="guestTeamLogoPath"
			:guestTeamName="guestTeamName"
			:guestTeamSocre="guestTeamSocre"
			:homeTeamLogoPath="homeTeamLogoPath"
			:homeTeamName="homeTeamName"
			:homeTeamScore="homeTeamScore"
			:isFinsh="isFinsh"
			:matchStartState="matchStartState"
			:matchTitle="matchTitle"
			></match-score>
			
			<!-- <view class="highlights-top">
				<view class="highlights-team">
					<image v-if="homeTeamLogoPath" :src="homeTeamLogoPath" mode=""></image>
					<image v-else src="../../static/default.png" mode=""></image>
					<text class="textTeamName">{{homeTeamName | limitLength}}</text>
				</view>
				<view class="highlights-content">
					<view class="highlights-content-top">
						<view class="highlights-score">
							<text>{{homeTeamScore}}</text>
							<text>VS</text>
							<text>{{guestTeamSocre}}</text>
						</view>
					</view>
					<text class="highlights-content-bottom">
						{{matchStartState==0?'进行中':matchStartState==1?'未开始':'已完赛'}}
					</text>
				</view>
				<view class="highlights-team">
					<image v-if="guestTeamLogoPath" :src="guestTeamLogoPath" mode=""></image>
					<image v-else src="../../static/default.png" mode=""></image>
					<text class="textTeamName">{{guestTeamName | limitLength}}</text>
				</view>
			</view> -->
			<view class="hig-title" v-if="matchLiveSourceDOS.length == 1">
				{{matchLiveSourceDOS[0].liveSourceName}}
			</view>
			<view class="highlights-video">
				<view class="vpage-list">
					
					<!-- 当信号源条数 = 1时，使用iframe渲染链接 -->
					<block v-if="matchLiveSourceDOS.length === 1 && tabIndexId == 4">
						<view
						class="noiframeSrc"
						v-if="srcType == 0">
							<text class="noiframeSrcText">暂未获取信号,请选择其他播放源观看</text>
						</view>
						<iframe v-if="srcType == 1" :src="iframeSrc" width="100%" height="" frameborder="0" ></iframe>
						<bwVideoPlayer v-if="srcType == 2"  class="video-player vjs-custom-skin"
							:isPlaySource="true"
							:isLive="false"
							:sourceUrl="iframeSrc"
							:isAutoplay="true"
							ref="hvideoplay"
						></bwVideoPlayer>
						
						<!-- 广告位 -->
						<view v-if="AdList.length >= 1 && $store.state.ADstatus.zbsjjAD">
							<view class="boxMargin"></view>
							<bwAdvertising :AdName="'zbsjjAD'" :AdList="AdList[0]"></bwAdvertising>
						</view>
						
					</block>
					<!-- 当信号源条数 > 1时，显示列表 -->
					<view class="" v-if="matchLiveSourceDOS.length > 1">
						<view class="vpage-list-item"
				
							v-for="(item,index) in matchLiveSourceDOS"
							:key="item.updetedTime+index"
							@tap="openExternalPage(item,index)"
				
						>
							<view class="item-left">
								<!-- @error="imageError(cindex,index, xindex, 0)"  -->
								<image v-if="bigEventTypePath != '' && bigEventTypePath != null" :src="bigEventTypePath" mode="aspectFit"></image>
								<image v-else-if="bigEventLogoPath != '' && bigEventLogoPath != null" :src="bigEventLogoPath" mode="aspectFit"></image>
								<image v-else src="/static/assets/default.png" mode=""></image>
							</view>
							<view class="item-right">
								<!-- <view class="item">
									{{item.updetedTime}} - {{item.liveSourceName}}
								</view>
								<view class="item">
									{{homeTeamName}} - {{guestTeamName}}
								</view> -->
								
								<view class="item item-one" v-if="homeTeamName || guestTeamName">
									{{homeTeamName}} {{homeTeamName&&guestTeamName?' - ':'' }} {{guestTeamName}}
								</view>
								<view class="item item-one" v-else>
									{{matchTitle}}
								</view>
								<view class="item item-two">
									<text style="color: red;" v-if="item.matchSourcePathShortName">
										[{{item.matchSourcePathShortName}}]
									</text>
									{{item.liveSourceName}} <!-- {{item.liveSourceName&&item.liveNarrator?' / ':'' }}{{item.liveNarrator}} -->
								</view>
								
							</view>
						</view>
					</view>
					<view v-if="matchLiveSourceDOS.length < 1">
						<view class="nodata">
							<!-- 暂无数据 -->
						</view>
					</view>
				</view>
				
				
				<!-- <view class="video-view">
					<view v-if="!isVideo" class="noPlayer">
					暂无集锦
					</view>
					<div class="prism-player" id="hig_prismPlayer"></div>
				</view> -->
			</view>
		</view>
		</scroll-view>
	</view>
</template>

<script>
	import matchScore from '../component/match-score.vue';
	import bwVideoPlayer from '@/pages/component/bw-videoPlayer.vue'
	var higPlayer;
	export default {
		name: 'highlights',
		components: {
			matchScore,
			bwVideoPlayer
		},
		props: {
			// 赛事类型（专题）大图标
			bigEventTypePath: {
				type: String,
				default: ''
			},
			// 项目(运动)类型 大图标
			bigEventLogoPath: {
				type: String,
				default: ''
			},
			
			// matchId:{
			// 	type: String,
			// 	default: ''
			// },
			// matchSourcePathShortName:{//播放器简称
			// 	type:String,
			// 	default:'',
			// },
			tabIndexId:{
				type: String | Number,
				default: '1'
			},
			homeTeamLogoPath: {//主队图标
				type: String,
				default: ''
			},
			homeTeamName:{//主队名称
				type: String,
				default: ''
			},
			homeTeamScore: {//主队比分
				type: String,
				default: ''
			},
			guestTeamLogoPath: {//客队图标
				type: String,
				default: ''
			},
			guestTeamName:{//客队名称
				type: String,
				default: ''
			},
			guestTeamSocre:{	//客队比分
				type: String,
				default: ''
			},
			matchTitle:{//标题
				type: String,
				default: ''
			},
			isFinsh:{//是否结束 0true 1false
				type: String,
				default: ''
			},
			isHot:{//是否热门
				type: String,
				default: ''
			},
			isRecommend:{//是否推荐
				type: String,
				default: ''
			},
			isTop:{//是否置顶
				type: String,
				default: ''
			},
			matchStartState:{//赛事进行状态 0进行中 1未开始 2已结束
				type: String,
				default: ''
			},
			matchBeginTime:{//开始时间
				type: String,
				default: ''
			},
			matchEndTime:{//结束时间
				type: String,
				default: ''
			},
			matchLiveSourceDOS: {//录像数组
				type: Array,
				default: () => {
				  return []
				}
			},
		},
		data() {
			return {
				isVideo:false,
				iframeSrc: '',
				srcType:1,		//0失败  1 iframe  2 播放器
				analysisSourceNumber:0,//解析次数
				timeOutAnalys:null,//延迟解析对象
				
				AdList: [], // 广告列表
				
				allowClick: true, // 是否允许列表项点击（避免多次打开页面）
			}
		},
		created() {
			// 获取页面广告列表
			this.utils.getAdvertiseList({locationKey: 'jjbfq'})
			.then( res => {
				this.AdList = res
				console.log('集锦播放器广告：',this.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
		},
		filters:{
			/*限制长度*/
			limitLength:function(v){
				return v.length>8?v.substring(0,8):v;
			}
		},
		watch: {
			'matchLiveSourceDOS.length': function(newVal,oldVal){
				console.log('集锦列表：',this.matchLiveSourceDOS);
				let that = this,
					item = that.matchLiveSourceDOS[0];
					
				console.log(item);
				// 判断链接解析状态
				
					// uni.hideLoading();
					uni.showLoading()
					let datas = {
						"sourcePathId": item.sourceId
					}
					that.analysisSourceNumber = 0;
					
					reqAnalysisMatchLiveSource(item,datas)
				// if (item.valid == 1) {
				// }else {
				// 	that.setSrc(item);
				// 	if(that.srcType == 1){
				// 		that.$nextTick(function(){
				// 			that.initLoading();
				// 		})
				// 	}
				// }
				function reqAnalysisMatchLiveSource(item,datas){
					that.analysisSourceNumber++;
					that.$req.reqc.analysisMatchLiveSource(datas)
					.then(res => {
						console.log("解析直播信息",res)
						if (res.data.resultCode == 1 && res.statusCode == 200) {
							uni.hideLoading();
							// 覆盖原数据，解析状态值'valid'为 → 0:已解析
							item = res.data.data;
							that.setSrc(item);
							if (that.iframeSrc == '' || that.iframeSrc == null) {
								uni.showToast({
									icon: 'none',
									title: '当前播放源不可用'
								})
								return;
							}
							if(that.srcType == 1){
								that.$nextTick(function(){
									that.initLoading();
								})
							}
						}
						else if (res.data.resultCode != 1 && res.statusCode == 200) {
							if(res.data.resultCode == -199){
								
								// setTimeout(function() {
								// 	reqAnalysisMatchLiveSource(datas);
								// }, 1000);
								if(that.analysisSourceNumber < 10){
									that.timeOutAnalys = setTimeout(function() {
										reqAnalysisMatchLiveSource(item,datas);
									}, 1000);
								}else{
									uni.hideLoading();
									// uni.showToast({
									// 	icon: 'none',
									// 	title: '暂未获取信号,请选择其他播放源观看'
									// })
									that.shibai();
								}
							}else{
								uni.hideLoading();
								// uni.showToast({
								// 	icon: 'none',
								// 	title: res.data.resultMsg,
								// })
								that.shibai(res);
							}
						}
					}).catch(err => {
						uni.hideLoading();
						uni.showToast({
							icon: 'none',
							title: '请稍后再试'
						})
						console.log(err);
					})
					
				}
				
				
				
			},
		},
		methods: {
			// 跳转外部录像链接
			openExternalPage: function (lxitem,index) {
				if (!this.allowClick) return;
				this.allowClick = false;
				
				let that = this,
					newPath,
					item = that.matchLiveSourceDOS[index];
				console.log(item);
					if(that.timeOutAnalys){
						clearTimeout(that.timeOutAnalys);
						that.timeOutAnalys = null;
					}
					that.analysisMatchLiveSource(item,index)
				// if (item.valid == 1) {
				// } else {
				// 	that.merge(item)
				// }
			},
			analysisMatchLiveSource(item,index){
				let that = this;
				// uni.hideLoading();
				uni.showLoading()
				let datas = {
					"sourcePathId": item.sourceId
				}
				that.analysisSourceNumber = 0;
				
				that.reqAnalysisMatchLiveSource(item,datas,index)
				
			},
				// 解析直播源
			reqAnalysisMatchLiveSource(item,datas,index){
				let that = this;
				that.analysisSourceNumber++;
				that.$req.reqc.analysisMatchLiveSource(datas)
				.then(res => {
					console.log("解析直播信息",res)
					if (res.data.resultCode == 1 && res.statusCode == 200) {
						uni.hideLoading();
						let data = res.data.data;
						// 修改当前的解析解析状态值'valid'为 → 0:已解析
						item.valid = '0';
						that.matchLiveSourceDOS[index].valid = '0';
						that.matchLiveSourceDOS[index].analysisPlayPathWeb = data.analysisPlayPathWeb;
						that.matchLiveSourceDOS[index].notAnalysisPlayPath = data.notAnalysisPlayPath;
						that.matchLiveSourceDOS[index].webLink = data.webLink;
						that.merge(item)
					}
					else if (res.data.resultCode != 1 && res.statusCode == 200) {
						if(res.data.resultCode == -199){
							// setTimeout(function() {
							// 	that.reqAnalysisMatchLiveSource(item,datas,index);
							// }, 1000);
							if(that.analysisSourceNumber < 10){
								that.timeOutAnalys = setTimeout(function() {
									that.reqAnalysisMatchLiveSource(item,datas,index);
								}, 1000);
							}else{
								uni.hideLoading();
								// uni.showToast({
								// 	icon: 'none',
								// 	title: '暂未获取信号,请选择其他播放源观看'
								// })
								that.shibai();
							}
						}else{
							uni.hideLoading();
							// that.merge(item)
							that.shibai(res);
						}
					}
				}).catch(err => {
					that.allowClick = true; // 修改列表项允许点击状态
					
					uni.hideLoading();
					uni.showToast({
						icon: 'none',
						title: '请稍后再试'
					})
					console.log(err);
				})
				
			},
			
			merge (item,index) {
				let that = this;
				let url = '/pages/webview/webview',
					temp = {
						matchId: item.matchId,
						sourceId: item.sourceId,
						sourcePath: item.notAnalysisPlayPath ,
						usable: 1,
						title: item.liveSourceName
					};
				switch (item.isAnalysis){
					case '0':
					case '2':
						if (item.analysisPlayPathWeb) {
							url = '/pages/index/videoPlay',
							temp.sourcePath = item.analysisPlayPathWeb;
						} else {
							// 判断信号源播放类型（linkPlayType：解析方式 2iframe 3url跳转）
							if (item.linkPlayType == 2) {
								url = '/pages/index/videoPlay'
							}
							temp.sourcePath = item.webLink;
						}
						break;
					case '1':
					case '3':
						temp.sourcePath = item.notAnalysisPlayPath;
						break;
					default:
						break;
				}
				that.navigateTo(url,temp);
			},
			
			// 页面跳转
			navigateTo(url,data){
				setTimeout(()=> {
					this.allowClick = true; // 修改列表项允许点击状态
				}, 300);
				
				uni.navigateTo({
					url: url+'?data=' + encodeURIComponent(JSON.stringify(data))
				})
			},
			
			shibai(res){
				setTimeout(()=> {
					this.allowClick = true; // 修改列表项允许点击状态
				}, 300);
				
				this.srcType = 0;
				uni.showToast({
					icon: 'none',
					title: res.data.resultMsg||'暂未获取信号,请选择其他播放源观看'
				})
			},
			
			setSrc(item){
				console.log("查看item", item)
				let that = this;
				switch (item.isAnalysis){
					case '0':
						that.srcType = 2;
						that.iframeSrc = item.analysisPlayPathWeb
						break;
					case '1':
						that.srcType = 1;
						that.iframeSrc = item.notAnalysisPlayPath
						break;
					case '2':
						that.srcType = 2;
						that.iframeSrc = item.analysisPlayPathWeb;
						break;
					case '3':
						that.srcType = 1;
						that.iframeSrc = item.notAnalysisPlayPath;	
						break;			
					default:
						break;
				}
				
			},
			// 初始化加载loading
			initLoading: function () {
				uni.showLoading({
					title: '请稍后...',
					mask: true
				})
				let timer = setTimeout(function() {
					clearTimeout(timer);
					uni.hideLoading();
				}, 1500);
			},
			
			
			
			higPause(){
				higPlayer.pause();
			},
			/*销毁播放器*/
			higPlayerDispose() {
				higPlayer.dispose();
			},
			newHigVideo(){
				return;
				console.log("初始化")
				if(this.matchLiveSourceDOS.length == 0){
					
					return;
				}
				this.isVideo = true;
				if(this.matchLiveSourceDOS[0].valid == 1){
					console.log("准备解析")
					this.analysisSourceHighlights(this.matchLiveSourceDOS[0].sourceId)
				}else{
					let pdata = {
						source: this.matchLiveSourceDOS[0].analysisPlayPathWeb,
						isLive: false,
						autoplay: false
					}
					this.initHighlightsPlayer(pdata);
				}
				
				
			
				// higPlayer = new Aliplayer({
				// 	id: 'hig_prismPlayer',
				// 	width: '100%',
				// 	height:'100%',
				// 	preload:false,//自动加载
				// 	autoplay:false,//自动播放
				// 	useH5Prism:true,
				//    //支持播放地址播放,此播放优先级最高
				//    source : 'http://yf.ugc.v.cztv.com/cztv/ugcvod/2018/04/14/A98CD7B26B06D94A5CEA56AA7D723572/h264_800k_mp4.mp4_playlist.m3u8',
				  
				//    },function(player){
				// 	   console.log('播放器创建好了222。')
				//   });
			},
			initHighlightsPlayer(pdata){
				higPlayer = new Aliplayer({
					id: 'hig_prismPlayer',
					width: '100%',
					height: '100%',
					preload: false, //自动加载
					useH5Prism: true,
					//支持播放地址播放,此播放优先级最高
					//http://yf.ugc.v.cztv.com/cztv/ugcvod/2018/04/14/A98CD7B26B06D94A5CEA56AA7D723572/h264_800k_mp4.mp4_playlist.m3u8
					source: pdata.source,
					isLive: pdata.isLive || false, //是否是直播
					// isLive: true, //是否是直播
					autoplay: pdata.autoplay || false, //自动播放
					skinLayout:[
						 {name: "bigPlayButton", align: "blabs", x: 30, y: 80},
						    {
						      name: "H5Loading", align: "cc"
						    },
						    {name: "errorDisplay", align: "tlabs", x: 0, y: 0},
						    {name: "infoDisplay"},
						    {name:"tooltip", align:"blabs",x: 0, y: 56},
						    {name: "thumbnail"},
						    {
						      name: "controlBar", align: "blabs", x: 0, y: 0,
						      children: [
						        {name: "progress", align: "blabs", x: 0, y: 44},
						        {name: "playButton", align: "tl", x: 15, y: 12},
						        {name: "timeDisplay", align: "tl", x: 10, y: 7},
						        {name: "fullScreenButton", align: "tr", x: 10, y: 12},
						        // {name:"subtitle", align:"tr",x:15, y:12},
						        // {name:"setting", align:"tr",x:15, y:12},
						        {name: "volume", align: "tr", x: 5, y: 10}
						      ]
						    }
					],
					// skinLayout:false,
				}, function(player) {
					console.log('播放器创建好了。')
					/*控制栏显示隐藏*/
					player.on('hideBar',function(){
						// this.isShowBar = false;
					});
					 player.on('showBar',function(){
						 // this.isShowBar = true;
						 
					 });
				});		
			},
			/*解析*/
			analysisSourceHighlights(sid) {
				console.log("开始解析,",sid)
				let datas = {
					"sourcePathId": sid
				}
			  uni.showLoading();
				// 解析直播源
				this.$req.reqc.analysisMatchLiveSource(datas)
					.then(res => {
						console.log("解析直播信息", res)
						let data = res.data.data;
						uni.hideLoading();
						if (res.data.resultCode === 1 && res.statusCode == 200) {
							this.playerType = true;
							let pdata = {
								source: data.analysisPlayPathWeb,
								isLive: true,
								autoplay: true
							}
							this.initHighlightsPlayer(pdata)
							// this.resultMsg = data.liveSourceName;
						} else if (res.data.resultCode !== 1 && res.statusCode == 200) {
							// this.playerType = false;
							// this.resultMsg = res.data.resultMsg;
						}
					}).catch(err => {
						uni.hideLoading();
						uni.showToast({
							icon: 'none',
							title: '请稍后再试'
						})
						console.log(err);
					})
			
			},
		}
	}
</script>

<style lang="scss" scoped>
	.jj-scroll-view{
		// height: 100%;
		// height: 750rpx;
		height: calc(100vh - 90rpx - 90rpx - var(--status-bar-height));
	}
	.noiframeSrc{
		width: 750rpx;
		height: 450rpx;
		background-color: #1B1B30;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.noiframeSrcText{
		color: #FFFFFF;
	}
.content{
	height: 100%;
	background:rgba(255,255,255,1);
	// position: relative;
	.highlights-main{
		// position: relative;
		
		.hig-title{
			width:750rpx;
			height:69rpx;
			background:rgba(255,255,255,1);
			font-size:22rpx;
			font-family:PingFang SC;
			font-weight:400;
			color:rgba(51,51,51,1);
			line-height:69rpx;
			// display: flex;
			// justify-content: center;
			// align-items: center;
			text-align: center;
			padding: 0 20rpx;
			overflow: hidden; /*自动隐藏文字*/
			text-overflow: ellipsis;/*文字隐藏后添加省略号*/
			white-space: nowrap;/*强制不换行*/
		}
		
		.highlights-video{
			.vpage-list{
				
				iframe {
					// height: calc(100vh - 211px);
					height: 100vh;
				}
				
				// padding-top: 174rpx;
				.vpage-list-item{
					display: flex;
					align-items: center;
					justify-content: flex-start;
					padding: 24rpx 20rpx;
					border-bottom:1rpx solid rgba(225,225,225,1);
					.item-left{
						image{
							width:206rpx;
							height:136rpx;
							border-radius:6rpx;
						}
					}
					.item-right{
						padding-left: 26rpx;
						height:136rpx;
						display: flex;
						flex-direction: column;
						font-size:26rpx;
						font-family:PingFang SC;
						font-weight:400;
						color:rgba(0,0,0,1);
						// align-items: center;
						flex: 1;
						.item {
							line-height: 44rpx;
						}
						.item-one{
							font-size: 20rpx;
							color: #666666;
						}
						.item-two{
							
						}
					}
				}
				
			}
			.video-view{
				width: 750rpx;
				height: 450rpx;
				background-color: #000000;
				.noPlayer{
					height: 450rpx;
					width: 100%;
					text-align: center;
					color: white;
					font-size: 40rpx;
					padding: 30rpx;
					display: flex;
					align-items: center;
					justify-content: center;
				}
			}
			
		}
		.highlights-top{
			// position: fixed;
			// top: 0;
			height:174rpx;
			width: 100%;
			border-bottom:1rpx solid rgba(225,225,225,1);
			display: flex;
			align-items: flex-end;
			z-index: 10;
			background-color: #FFFFFF;
			// padding-bottom: 23rpx;
			.highlights-team{
				flex: 1;
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				image{
					width:88rpx;
					height:88rpx;
					border-radius: 88rpx;
				}
				text{
					line-height: 70rpx;
				}
			}
			.highlights-content{
				flex: 1;
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				.highlights-content-top{
					.highlights-score{
						text{
							font-size:36rpx;
							font-family:PingFang SC;
							line-height:60rpx;
						}
						text:nth-child(odd){
							font-weight:500;
							color:rgba(255,83,55,1);
						}
						text:nth-child(even){
							font-weight:400;
							color:rgba(0,0,0,1);
							padding: 0 70rpx;
						}
					}
					.show-but{
						width:140rpx;
						height:44rpx;
						background:rgba(27,27,48,1);
						border-radius:22rpx;
						font-size:22rpx;
						font-weight:400;
						color:rgba(255,255,255,1);
						// line-height:114rpx;
						display: flex;
						align-items: center;
						justify-content: center;
					}
				}
				.highlights-content-bottom{
						line-height: 70rpx;
						color: #666666;
						font-size: 18rpx;
				}
			}
		}
		
	}
	
}
	.video-player{
		width: 750rpx;
		height: 450rpx;
		
	}
</style>
