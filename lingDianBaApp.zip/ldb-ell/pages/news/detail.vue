<template>
	<view class="content">

		<scroll-view class="scroll" scroll-y @scrolltolower="loadMore">
			<!-- 新闻详情 -->
			<view class="scroll-content">
				<view class="introduce-section">
					<text class="title">{{detailData.title}}</text>
					<view class="introduce">
						<view class="leftBox">
							<view class="icon zanIcon" :class="detailData.likeType==1?'like':''"></view>
							<text>{{newsLikeNumber||''}}</text>
							<text>{{detailData.time}}</text>
						</view>
						<view class="">
							<text>阅读{{newsPlayNumber}}</text>
						</view>
					</view>
					<rich-text :nodes="detailData.flow"></rich-text>
				</view>
				
				<view class="container" v-show="loading === false">
					<!-- 评论 -->
					<comments :cid="id" :comments="comments" :noToken="noToken" :type="ctype" :total="total"></comments>
				</view> 
				<!-- 加载更多 -->
				<mix-load-more :status="loadMoreStatus"></mix-load-more>
			</view>
		</scroll-view>
		
		<!-- 输入框 -->
		<!-- adjust-position	true	键盘弹起时，是否自动上推页面 -->
		<!-- hold-keyboard		false	focus时，点击页面的时候不收起键盘 -->
		<view class="inputBox" v-if="platform == 'android'" :style="{'bottom': inputBottom+'px'}">
			<!-- @focus="focusTextArea" -->
			<input class="multiline" 
				type="text" 
				confirm-type="done"
				v-model="commentsInput" 
				@blur="bindTextArea" 
				@input="MonitorIn"
				@confirm="search" 
				@keyboardheightchange="inputHeightChange"
				:adjust-position="false" 
				:hold-keyboard="true"
				placeholder="发表评论..." 
				placeholder-style="color: #333333;" 
			/>
			<view @tap="search" class="submit" v-if="submitBtn">提交</view>
			<view v-else @tap="likeNews(detailData.likeType)" class="confirm-btn icon iconfont" :class="detailData.likeType==1?'like':''"></view>
		</view>
		
		<view v-else class="inputBox">
			<input class="multiline" 
				type="text" 
				confirm-type="done"
				v-model="commentsInput" 
				@blur="bindTextArea" 
				@input="MonitorIn"
				@confirm="search" 
				:adjust-position="false" 
				:hold-keyboard="true"
				placeholder="发表评论..." 
				placeholder-style="color: #333333;" 
			/>
			<view @tap="search" class="submit" v-if="submitBtn">提交</view>
			<view v-else @tap="likeNews(detailData.likeType)" class="confirm-btn icon iconfont" :class="detailData.likeType==1?'like':''"></view>
		</view>
		
	</view>
</template>

<script>
	import json from '@/json';
	 import comments from "../component/comments.vue"
	 import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	let that;
	export default {
		components: {
			mixLoadMore,
			comments
		},
		data() {
			return {
				id:0,
				loading: true,
				ctype:1,
				detailData: {},
				newsList: [],
				comments: [],
				newsContentNumber: 0,	//总评论数
				newsLikeNumber: 0,
				newsPlayNumber: 0,
				commentsInput:'',
				submitBtn: false,		// 提交按钮/点赞按钮状态
				loadMoreStatus:0,
				offset:1,//评论页
				total:0,//总条数
				
				noToken: false,
				
				inputBottom: 0,
				statusBarHeight:0,
				windowHeight:0,
				inputHeightPackUp: 0,
				StatusBar: 0,
			}
		},
		onBackPress(options) {
			// 隐藏软键盘
			uni.hideKeyboard();
		},
		onLoad(op) {
			that = this;
			that.id = op.id;
			// this.detailData = JSON.parse(options.data);
			// console.log("detailData",this.detailData);
			
			uni.getSystemInfo({
				success: function (e) {
					that.statusBarHeight = e.statusBarHeight;
					that.inputHeightPackUp = e.statusBarHeight;
					that.windowHeight = e.windowHeight;
					that.StatusBar = e.statusBarHeight;
				}
			});
			
			// token验证
			this.verifyToken().then( () => {
				console.log('noToken状态：',that.noToken);
				// 查询新闻内容
				that.loadNewsList();
				that.loadEvaList();
			});
			
			uni.$on('setComments',function(arr){
			  that.comments = arr;
			})
			
			uni.$on('modifyLoginStatus',() => {
				console.log('监听到事件来自 modifyLoginStatus ，修改登录状态');
				// token验证
				this.verifyToken().then(() => {
					console.log('**************************noToken状态：', that.noToken);
					// 查询新闻内容
					that.loadNewsList();
					that.loadEvaList();
				});
			})
			
			
			//键盘高度改变
			if (that.platform == 'android') {
				uni.onKeyboardHeightChange(res => {
					if(res.height > 0){
						that.inputBottom = res.height;
					}else{
						that.inputBottom = 0;
					}
					// console.log('onKeyboardHeightChange',res.height)
				})
			}
		},
		onShow() {
			console.log('视频详情页面显示');
			
		},
		onUnload() {
			uni.$off('setComments')
		},
		methods: {
			clickMask() {
				try{
					uni.hideKeyboard()
				}catch(e){
					//TODO handle the exception
				}
			},
			
			// 验证token
			verifyToken() {
				return new Promise((resolve, reject) => {
				    // ... some code
					that.noToken = false;
					this.$req.reqc.verificationToken()
					.then( res => {
						if (res.statusCode === 200 && res.data.resultCode === 1) {
							console.log('token状态：',res.data.resultMsg);
						} else {
							console.log('token失效');
							that.noToken = true;
						}
						
						resolve();
					})
					.catch( err => {
						console.log('错误的err：',err);
						that.noToken = true;
						
						resolve();
					})
				})
			},
			
			setComments(arr){
				that.comments = arr;
			},
			
			async likeNews(type){
				// if(!type){type = 0}
				let datas = {
					"newsCommentType": type,
					"newsId": that.id
				}
				console.log(datas);
				that.$req.req.updateNewslike(datas, {noToken: that.noToken})
				.then(res => {
					console.log("点赞",res)
					if (res.data.resultCode === 1) {
						that.detailData.likeType = type==0?1:0;
						if(!type){
							that.newsLikeNumber++;
						}else{
							that.newsLikeNumber--;
						}
					} else {
						uni.showToast({
							icon: 'none',
							title: res.data.resultMsg
						})
					}
				})
			},
			setLikeType(id,type){
				that.tabBars[that.tabBars.findIndex(item => item.id === id)].likeType = type
			},
			search(){
				if(that.commentsInput == ''){
					uni.showToast({
						title:"请输入评论内容",
						icon:"none"
					})
					return;
				}
				let datas = {
						"commentContent": that.commentsInput,
						"id": that.id,
						"matchType": "1"
				}
				that.$req.req.createMainComment(datas)
				.then( res => {
					console.log(res)
					uni.showToast({
						title:"评论发送成功！",
						icon:"none"
					})
					that.commentsInput = '';
					that.submitBtn = false;
					that.loadEvaList();
				})
				
				
			},
			
			//获取推荐列表
			loadNewsList() {
				// let list = await json.newsList;
				let list = json.newsList;
				let datas = {
					newsId:that.id
				}
				console.log('****noToken:',this.noToken);
				that.$req.req.queryNewsContent(datas, {noToken: that.noToken})
				.then( res => {
					console.log("新闻内容",res);
					let detailData = {
						flow : res.data.data.newsContent,
						likeType : res.data.data.likeType,
						title: res.data.data.newsTitle,
						time: res.data.data.createTime,
						likeType:res.data.data.likeType
					}
					that.newsContentNumber = res.data.data.newsContentNumber;
					that.newsLikeNumber =  res.data.data.newsLikeNumber;
					that.newsPlayNumber =  res.data.data.newsPlayNumber;
					that.loading = false;
					that.detailData = detailData;
				})
				
			},
			//上滑加载
			loadMore(){
				this.loadEvaList('add');
			},
			//获取评论列表
			async loadEvaList(type) {
				if(type === 'add'){
					if(that.loadMoreStatus === 2){
						return;
					}
					if(comments.length > 0){
						that.offset++;
					}
					that.loadMoreStatus = 1;
				}
				let datas = {
					    "id": that.id,
					    "limit": 20,
					    "offset": that.offset,
					    "sortTypeId": 1,
					    "typeId": 1
				}
				that.$req.req.queryMainComment(datas, {noToken: that.noToken})
				.then( res => {
					console.log("评论列表",res);
					that.total = res.data.data.total;
					that.comments = res.data.data.list;
				})
				//上滑加载 处理状态
				if(type === 'add'){
					that.loadMoreStatus = that.comments.length >= that.total ? 2: 0;
				}
				
			},
			
			
			inputHeightChange(e) {
				console.log('keyboardheightchange:',e);
			},
			
			// 输入框聚焦
			focusTextArea: function (e) {
				console.log('聚焦',e);
				
				/* if(e.detail.height > 0){
					if(that.inputHeightPackUp > 0 && that.statusBarHeight > 24){
						that.inputBottom = e.detail.height + that.inputHeightPackUp;
					}else{
						that.inputBottom = e.detail.height;
					}
				}else{
					if(e.detail.height < 0){
						that.inputHeightPackUp = Math.abs(e.detail.height);
					}
					that.inputBottom = 0
				} */
			},
			// 输入框失去焦点
			bindTextArea: function (e) {
				console.log('失去焦点:',e);
				
				// console.log(e.detail.value,"长度："+e.detail.value.length)
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				// console.log(val)
				
				
				// 注释：indexOf() 方法对大小写敏感
				// 注释：如果要检索的字符串值没有出现，则该方法返回 -1
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.submitBtn = false;
				}
			},
			// 输入监听
			MonitorIn: function (e) {
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.submitBtn = false;
				}
			}
		}
	}
</script>

<style lang="scss">
	page {
		height: 100%;
	}
	
.like{
			color: #007AFF !important;
		}
	.content {
		display: flex;
		flex-direction: column;
		height: 100%;
		background: #fff;
		width: 100vw;
	}
.container{
	background: #fff;
	margin-top: 10upx;
}
	.iconfont{
		// font-size: 15upx;
	}
	.content-view{
		
	}
	.video-wrapper {
		height: 422upx;

		.video {
			width: 100%;
			height: 100%;
		}
	}

	.scroll {
		/* #ifdef H5 */
		flex: 1;
		/* #endif */
		
		position: relative;
		background-color: #f8f8f8;
		
		/* #ifndef H5 */
		height: calc(100% - 88rpx);
		/* #endif */
	}

	.scroll-content {
		display: flex;
		flex-direction: column;
	}

	/* 简介 */
	.introduce-section {
		display: flex;
		flex-direction: column;
		padding: 20upx 30upx;
		background: #fff;
		line-height: 1.5;
		
		.leftBox {
			display: flex;
			align-items: center;
		}
		
		.title {
			font-size: 36upx;
			color: #303133;
			margin-bottom: 16upx;
		}

		.introduce {
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 26upx;
			color: #909399;
			align-items: center;
			
			.zanIcon {
				width: 25rpx;
				height: 25rpx;
				margin: 0 8rpx 4rpx 0;
				background-size: cover;
				background-image: url(../../static/iconSet/zan_def2.png);
			}
			.like {
				background-image: url(../../static/iconSet/zan_active.png);
			}
			
			text {
				margin-right: 16upx;
			}
		}
		
		
	}

	/* 点赞等操作 */
	.actions {
		display: flex;
		justify-content: space-around;
		align-items: center;
		line-height: 1.3;
		padding: 10upx 40upx 20upx;

		.action-item {
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			font-size: 24upx;
			color: #999;
		}

		.yticon {
			display: flex;
			align-items: center;
			justify-content: center;
			width: 60upx;
			height: 60upx;
			font-size: 52upx;

			&.reverse {
				position: relative;
				top: 6upx;
				transform: scaleY(-1);
			}

			&.active {
				color: #ec706b;
			}
		}

		.icon-fenxiang2 {
			font-weight: bold;
			font-size: 36upx;
		}

		.icon-shoucang {
			font-size: 44upx;
		}
	}



	/* 推荐列表 */
	.rec-section {
		background-color: #fff;

		.rec-item {
			display: flex;
			padding: 20upx 30upx;
			position: relative;

			&:after {
				content: '';
				position: absolute;
				left: 30upx;
				right: 0;
				bottom: 0;
				height: 0;
				border-bottom: 1px solid #eee;
				transform: scaleY(50%);
			}
		}

		.left {
			flex: 1;
			padding-right: 10upx;
			overflow: hidden;
			position: relative;
			padding-bottom: 52upx;

			.title {
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 2;
				overflow: hidden;
				font-size: 32upx;
				color: #303133;
				line-height: 44upx;
			}

			.bot {
				position: absolute;
				left: 0;
				bottom: 4upx;
				font-size: 26upx;
				color: #909399;
			}

			.time {
				margin-left: 20upx;
			}
		}

		.right {
			width: 220upx;
			height: 140upx;
			flex-shrink: 0;
			position: relative;

			.img {
				width: 100%;
				height: 100%;
			}

		}
	}

	/* 评论 */
	.evalution {
		display: flex;
		flex-direction: column;
		background: #fff;
		padding: 20upx 0;
		width: 100%;
	}

	.eva-item {
		display: flex;
		padding: 20upx 30upx;
		position: relative;

		image {
			width: 60upx;
			height: 60upx;
			border-radius: 50px;
			flex-shrink: 0;
			margin-right: 24upx;
		}

		&:after {
			content: '';
			position: absolute;
			left: 30upx;
			bottom: 0;
			right: 0;
			height: 0;
			border-bottom: 1px solid #eee;
			transform: translateY(50%);
		}

		&:last-child:after {
			border: 0;
		}
	}

	.eva-right {
		display: flex;
		flex-direction: column;
		flex: 1;
		font-size: 26upx;
		color: #909399;
		position: relative;

		.zan-box {
			display: flex;
			align-items: base-line;
			position: absolute;
			top: 10upx;
			right: 10upx;

			.yticon {
				margin-left: 8upx;
			}
		}

		.content {
			font-size: 28upx;
			color: #333;
			padding-top: 20upx;
		}
	}
	
	
	/* 文本框 */
	.inputBox {
		width: 100%;
		min-height: 88rpx;
		box-sizing: border-box;
		padding: 14rpx 0;
		background-color: #FFFFFF;
		border-top: 1px solid #EAEAEA;
		position: fixed;
		bottom: 0;
		display: flex;
		align-items: center;
		/* justify-content: space-between; */
		.multiline {
			width: 80%;
			padding: 0px;
			margin: 0px;
			box-sizing: border-box;
			height: 68rpx;
			margin: 0 20rpx;
			padding: 12rpx 26rpx;
			border-radius: 12rpx;
			background-color: #F8F8F8;
			border: 1px solid #EAEAEA;
			font-size: 13px;
			color: #333333;
		}
		// 输入框底部 点赞按钮
		.confirm-btn {
			/* position: absolute;
			right: 30rpx; */
			width: 62rpx;
			height: 62rpx;
			background-size: cover;
			background-image: url(../../static/iconSet/zan_def2.png);
		}
		.like {
			background-image: url(../../static/iconSet/zan_active.png);
		}
		
		/* 提交按钮 */
		.submit {
			/* position: absolute;
			top: 50%;
			right: 10rpx;
			transform: translateY(-50%); */
			width: 100rpx;
			height: 55rpx;
			line-height: 55rpx;
			text-align: center;
			border-radius: 4rpx;
			color: #FFFFFF;
			background-color: #1B1B30;
		}
	}
	
</style>
