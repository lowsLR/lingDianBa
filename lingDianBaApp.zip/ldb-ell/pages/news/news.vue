<template>
	<view class="content">
		<!-- 顶部选项卡 -->
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<!-- nav-item -->
			<view
				v-for="(item, index) in tabList"
				:key="item.name"
				class="uni-tab-item"
				:class="{ current: index === tabCurrentIndex }"
				:id="'tab' + index"
				@click="changeTab(index)"
			>
				<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{ item.name }}</text>
				<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
		</scroll-view>
		<view class="addTag" @tap="openNewCustom"></view>
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="74" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<!-- 内容部分 -->
			<!-- @scrolltolower="loadMore" -->
			<!-- <scroll-view
				class="panel-scroll-box-wai" 
				:scroll-y="true" 
				:scroll-top="scrollTop"
				> -->

			<swiper id="swiper" class="swiper-box" :duration="300" :current="tabCurrentIndex" @change="changeTab">
				<!-- <swiper-item v-for="tabItem in tabList" :key="tabItem.index"> -->
				<swiper-item v-for="(tabItem, cIndex) in tabList" :key="cIndex">
					<!-- {{cIndex}} -->
					<scroll-view class="panel-scroll-box" :scroll-y="enableScroll" @scrolltolower="loadMore" @scroll="scrollnews">
						<!-- 轮播  interval="5000" duration="500"-->
						<swiper
							v-if="cIndex == 0 && networkStatus && swiperList.length"
							class="card-swiper"
							:circular="true"
							:autoplay="true"
							interval="50000000"
							duration="500"
							@change="cardSwiper"
							indicator-color="#8799a3"
							indicator-active-color="#0081ff"
						>
							<swiper-item v-for="(item, index) in swiperList" :key="item.title" :class="cardCur == index ? 'cur' : ''">
								<view class="swiper-item-img" @click="navToDetails(item.id)">
									<image @error="imageError(cIndex, index, 0)" :src="item.imgUrl" mode="aspectFill"></image>
									<view class="swiper-item-foot-text">{{ item.title }}</view>
								</view>
							</swiper-item>
						</swiper>
						
						<block v-for="(item, index) in tabItem.newsList" :key="item.id">
							
							<!-- 广告位 -->
							<block v-if="AdList.length >= 1 && index  == (AdList[0].advertisementSort > tabItem.newsList.length ? tabItem.newsList.length-1 : AdList[0].advertisementSort) && $store.state.ADstatus.xwAD1">
								<bwAdvertising :AdName="'xwAD1'" :AdList="AdList[0]"></bwAdvertising>
							</block>
							<block v-if="AdList.length >= 2 && index  == (AdList[1].advertisementSort > tabItem.newsList.length ? tabItem.newsList.length-1 : AdList[1].advertisementSort) && $store.state.ADstatus.xwAD2">
								<bwAdvertising :AdName="'xwAD2'" :AdList="AdList[1]"></bwAdvertising>
							</block>
							
							<!-- 新闻列表 -->
							<view class="news-item" @click="navToDetails(item.id)">
								<text class="title title1">{{ item.title }}</text>
								<view class="img-list img-list1">
									<view class="img-wrapper img-wrapper1">
										<image @error="imageError(cIndex, index, 1)" :lazy-load="true" class="img" :src="item.imgUrl" mode="aspectFill"></image>
									</view>
								</view>
								<view class="bot bot1 flex-cb">
									<text class="time">{{ item.time | filtersTime }}</text>
									<view class="rightComment">
										<view class="time icon commentIcon"></view>
										<text class="time icon commentNum" v-if="item.commentNumber">{{ item.commentNumber }}</text>
									</view>
								</view>
							</view>
							
						</block>
						
						<!-- 上滑加载更多组件 -->
						<mix-load-more v-if="networkStatus" :status="tabItem.loadMoreStatus"></mix-load-more>
						<netWorkErr
							:height="windowHeight - StatusBar - 44 - 37 - 50 - 44"
							:newWorlErrMsg="newWorlErrMsg"
							:networkStatus="networkStatus"
							@netWorkButTap="netButClick"
						></netWorkErr>
					</scroll-view>
				</swiper-item>
			</swiper>
			<!-- </scroll-view> -->
		</mix-pulldown-refresh>
	</view>
</template>

<script>
import mixAdvert from '@/components/mix-advert/vue/mix-advert';
import json from '@/json';
import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
import mixLoadMore from '@/components/mix-load-more/mix-load-more';
import netWorkErr from '../component/netWorkErr';
let windowWidth = 0,
	scrollTimer = false,
	tabBar;
let that;
export default {
	components: {
		mixPulldownRefresh,
		mixLoadMore,
		mixAdvert,
		netWorkErr
	},
	data() {
		return {
			newWorlErrMsg: '网络链接中断,请检查网络链接...',
			networkStatus: true,
			tabCurrentIndex: 0, //当前选项卡索引
			scrollLeft: 0, //顶部选项卡左滑距离
			enableScroll: true,
			total: 100,
			offset: 1,
			cardCur: 0,
			tabIndex: 0, // sweiper所在页
			tabList: [{ id: '', name: '全部', type: '5', sort: 0 }],
			tabListNo: [],
			tabListAll: [],
			swiperList: [],
			dotStyle: false,
			scrollTop: 0,
			currentDay: 0,
			//禁止双击跳转页面
			click: false,
			
			AdList: [], // 广告列表
			
			defaultImage: '../../static/default_img.png', // 默认图
		};
	},
	computed: {
		advertNavUrl() {
			let data = {
				title: '测试跳转新闻详情',
				author: '测试作者',
				time: '2019-04-26 21:21'
			};
			return `/pages/details/details?data=${JSON.stringify(data)}`;
		}
	},
	//async
	onLoad() {
		that = this;
		// 获取当前日期
		let date = new Date();
		this.currentDay = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
		// 获取屏幕宽度
		windowWidth = uni.getSystemInfoSync().windowWidth;
		
		// 获取页面广告列表
		that.utils.getAdvertiseList({locationKey: 'xw'})
		.then( res => {
			that.AdList = res
			console.log('新闻广告：',that.AdList);
		})
		.catch( err => {
			console.log('err：',err);
		})
		
		
		/* uni.removeStorage({
			key: 'newsTabList',
			success: function (res) {
				console.log('success');
			}
		}); */
		uni.getStorage({
			key: 'newsTabList',
			success: function(res) {
				that.getban();
				that.loadtabList();
			},
			fail: function(res) {
				that.getNavigationList().then(res => {
					that.getban();
					that.loadtabList();
				});
			}
		});

		uni.$on('setNewsEventList', res => {
			that.tabList = res.selTagArr;
			that.tabListNo = res.unSelTagArr;
			// console.log(res,that.tabList,that.tabListNo);

			if (that.tabCurrentIndex > that.tabList.length - 1) {
				that.tabCurrentIndex = that.tabList.length - 1;
			}
			uni.setStorage({
				key: 'newsTabList',
				data: {
					rd: that.tabListAll,
					rdarr: that.tabList,
					nordarr: that.tabListNo
				},
				success: function() {
					console.log('缓存数据success');
				}
			});
		});
	},
	methods: {
		netButClick() {
			if (that.tabListAll.length < 4) {
				that.getNavigationList().then(res => {
					that.getban();
					that.loadtabList();
				});
			} else {
				that.getban();
				that.loadNewsList('refresh');
			}
		},
		
		/*监听图片出错*/
		imageError(cindex, index, type) {
			// console.log(cindex, index, type)
			if (type) {
				// 列表缩略图
				that.tabList[cindex].newsList[index].imgUrl = that.defaultImage;
			} else {
				// 轮播图
				that.swiperList[index].imgUrl = that.defaultImage;
			}
			that.$forceUpdate();
		},

		getNavigationList() {
			return new Promise((res, rel) => {
				this.$req.req
					.queryNavigationList({
						navigationKey: 'app_navigation_new'
					})
					.then(resp => {
						let rd = [{ id: '', name: '全部', type: '5', sort: 0 }, ...resp.data.data];
						let rdarr = rd.filter(item => item.sort < 20),
							nordarr = rd.filter(item => item.sort >= 20);
						uni.setStorage({
							key: 'newsTabList',
							data: {
								rd: rd,
								rdarr: rdarr,
								nordarr: nordarr
							},
							success: function() {
								console.log('缓存数据success');
								res();
							}
						});
					});
			});
		},
		//下拉刷新
		onPulldownReresh() {
			this.loadNewsList('refresh');
		},
		scrollnews(e) {
			if (e.detail.scrollTop > 300) {
				return;
			}
			this.scrollTop = e.detail.scrollTop;
		},

		getban() {
			this.$req.req.queryRotationChart().then(res => {
				console.log('轮播', res);
				res.data.data.list.forEach((item, index) => {
					// 'https://images.weserv.nl/?url='+
					let json = {
						id: item.id,
						imgUrl: item.imgUrl ? ('https://images.weserv.nl/?url=' + item.imgUrl) : '../../static/default_img.png',
						title: item.newsTitle,
						author: '',
						time: item.updatedTime,
						likeType: item.likeType || 0,
						type: 1,
						commentNumber: item.commentNumber || ''
					};
					this.swiperList.push(json);
				});
			});
		},
		//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
		setEnableScroll(enable) {
			if (this.enableScroll !== enable) {
				this.enableScroll = enable;
			}
		},
		getEventList() {
			// console.log('getEventList')
			let that = this;
			uni.getStorage({
				key: 'eventList',
				success: function(res) {
					// console.log("数据",res.data);
					// that.tabList = res.data;
				}
			});
			// console.log("缓存数据",that.tabList);
		},
		// 自定义标签页
		openCustom: function() {
			uni.navigateTo({
				url: '/pages/index/customTag'
			});
		},
		// 自定义标签页
		openNewCustom: function() {
			uni.navigateTo({
				// url: '/pages/index/newCustomTag?data='+JSON.stringify(that.tabList)+'&nodata='+JSON.stringify(that.tabListNo)
				// url: '/pages/index/newCustomTag?pageType=4&data='+JSON.stringify(that.tabList)+'&nodata='+JSON.stringify(that.tabListNo)
				url:
					'/pages/index/newCustomTag?pageType=4&data=' +
					encodeURIComponent(JSON.stringify(this.tabList)) +
					'&nodata=' +
					encodeURIComponent(JSON.stringify(this.tabListNo))
			});
		},
		cardSwiper(e) {
			this.cardCur = e.detail.current;
		},
		/**
		 * 数据处理方法在vue和nvue中通用，可以直接用mixin混合
		 * 这里直接写的
		 * mixin使用方法看index.nuve
		 */
		//获取分类
		loadtabList() {
			let that = this;
			uni.getStorage({
				key: 'newsTabList',
				success: function(res) {
					that.tabListAll = res.data.rd;
					that.tabList = [...res.data.rdarr];
					that.tabListNo = res.data.nordarr;
					let tabarr = that.tabList;
					tabarr.forEach(item => {
						item.newsList = [];
						item.loadMoreStatus = 0; //加载更多 0加载前，1加载中，2没有更多了
						item.refreshing = false;
						item.offset = 1;
						item.liveRefreshing = false;
						item.loaded = false;
						// that.tabList.push(item)
					});
					that.tabList = tabarr;
					that.loadNewsList('add');
				}
			});
		},

		//新闻列表
		loadNewsList(type) {
			let tabItem = this.tabList[this.tabCurrentIndex];
			// console.log("选中",tabItem)
			//type add 加载更多 refresh下拉刷新
			if (type === 'add') {
				if (tabItem.loadMoreStatus === 2) {
					return;
				}
				if (tabItem.newsList && tabItem.newsList.length > 0) {
					tabItem.offset++;
				}
				tabItem.loadMoreStatus = 1;
			}
			if (type === 'refresh') {
				tabItem.refreshing = true;
				tabItem.offset = 1;
			}
			
			let datas = {
				id: tabItem.id || '',
				limit: 20,
				offset: tabItem.offset,
				type: tabItem.type
			};
			this.$req.req
				.queryNewsTitle(datas)
				.then(res => {
					// console.log("新闻",res)
					if (type === 'refresh') {
						tabItem.newsList = []; //刷新前清空数组
					}
					if (type === 'add') {
						tabItem.loaded = true;
					}
					that.networkStatus = true;
					let list = res.data.data.list;
					this.total = res.data.data.total;
					list.forEach((item, index) => {
						let items = {
							id: item.id,
							title: item.newsTitle,
							author: '',
							imgUrl: item.imgUrl ? ('https://images.weserv.nl/?url=' + item.imgUrl) : '../../static/default_img.png',
							time: item.createdTime,
							type: 1,
							commentNumber: item.commentNumber || '',
							likeType: item.likeType || 0
						};
						tabItem.newsList.push(items);
					});
					if (type === 'refresh') {
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						tabItem.refreshing = false;
						tabItem.loadMoreStatus = 0;
					}
					//上滑加载 处理状态
					if (type === 'add' || type === 'refresh') {
						let leng = (tabItem.newsList && tabItem.newsList.length) || 0;
						tabItem.loadMoreStatus = leng >= this.total ? 2 : 0;
					}
					// this.tabList[this.tabCurrentIndex] = tabItem;
					// console.log("全部数据",this.tabList)
					this.$forceUpdate();
				})
				.catch(err => {
					console.log('请求错误的处理', err);
					if (type === 'refresh') {
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						tabItem.refreshing = false;
						tabItem.loadMoreStatus = 0;
					}
					// 上滑加载、下拉刷新 处理状态 (返回数据长度小于零/数据长度与总数据量相等 → '没有更多数据了')
					if (type === 'add' || type === 'refresh') {
						tabItem.loadMoreStatus = tabItem.isLastPage ? 2 : 0;
					}
					uni.hideLoading();
					console.log('网络中断');
					that.networkStatus = false;
					this.$forceUpdate();
				});
		},
		//新闻详情
		navToDetails(id) {
			// console.log("新闻详情参数",item)
			// let data = {
			// 	id: item.id,
			// 	title: item.title,
			// 	author: item.author,
			// 	time: item.time,
			// 	likeType:item.likeType
			// }
			// console.log("新闻详情参数2",data);
			//let url = item.videoSrc ? 'videoDetails' : 'details';
			// return;
			if (!this.click) {
				uni.navigateTo({
					url: 'detail?id=' + id,
					success: () => {
						this.click = false;

						// #ifdef H5

						setTimeout(() => {
							this.click = false;
						}, 10);

						// #endif
					}
				});
				this.click = true;
			}
			// uni.navigateTo({
			// 	url: `detail?id=${item.id}`
			// })
			// uni.navigateTo({
			// 	url: `detail?data=${JSON.stringify(data)}`
			// })
		},
		//上滑加载
		loadMore() {
			this.loadNewsList('add');
		},

		//tab切换
		async changeTab(e) {
			if (scrollTimer) {
				//多次切换只执行最后一次
				clearTimeout(scrollTimer);
				scrollTimer = false;
			}
			let index = e;
			//e=number为点击切换，e=object为swiper滑动切换
			if (typeof e === 'object') {
				index = e.detail.current;
			}
			if (typeof tabBar !== 'object') {
				tabBar = await this.getElSize('nav-bar');
			}
			//计算宽度相关
			let tabListcrollLeft = tabBar.scrollLeft;
			let width = 0;
			let nowWidth = 0;
			//获取可滑动总宽度
			for (let i = 0; i <= index; i++) {
				let result = await this.getElSize('tab' + i);
				width += result.width;
				if (i === index) {
					nowWidth = result.width;
				}
			}
			// if(typeof e === 'number'){
			// 	//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
			// 	this.tabCurrentIndex = index;
			// }

			//延迟300ms,等待swiper动画结束再修改tabbar
			scrollTimer = setTimeout(() => {
				if (width - nowWidth / 2 > windowWidth / 2) {
					//如果当前项越过中心点，将其放在屏幕中心
					this.scrollLeft = width - nowWidth / 2 - windowWidth / 2;
				} else {
					this.scrollLeft = 0;
				}
				this.tabCurrentIndex = index;
				//第一次切换tab，动画结束后需要加载数据
				let tabItem = this.tabList[this.tabCurrentIndex];
				if (this.tabCurrentIndex !== 0 && tabItem.loaded !== true) {
					this.loadNewsList('add');
				}
			}, 300);
		},
		//获得元素的size
		getElSize(id) {
			return new Promise((res, rej) => {
				let el = uni.createSelectorQuery().select('#' + id);
				el.fields(
					{
						size: true,
						scrollOffset: true,
						rect: true
					},
					data => {
						res(data);
					}
				).exec();
			});
		}
	},
	filters: {
		filtersTime: function(value) {
			if (value) {
				// 这里以 -，:，空格 来拆分字符串
				let time = value.split(/[-: ]/); // ["2019", "12", "04", "17", "00", "00"]
				if (that.currentDay == time[2]) {
					time = time[3] + ':' + time[4];
				} else {
					time = time[0] + '-' + time[1] + '-' + time[2] + '\xa0' + time[3] + ':' + time[4];
				}
				// console.log('截取时间：',time);
				return time;
			}
		}
	}
};
</script>

<style lang="scss">
page,
.content {
	background-color: #f8f8f8;
	height: 100%;
	overflow: hidden;
	width: 100vw;
}
.content {
	background-color: #f8f8f8;
}
.page-header {
	position: fixed;
	z-index: 99;
}


.card-swiper {
	height: 300rpx !important;
	
	/* 轮播图宽度 */
	swiper-item {
		width: 250px !important;
		left: 17%;
		/* width: 80%;
		left: 9.9%; */
		margin: 10upx 0;
		box-sizing: border-box;
		padding: 0 20upx;
		overflow: initial;
		position: relative;
		
		.swiper-item {
			width: 100%;
			display: block;
			height: 100%;
			border-radius: 10upx;
			transform: scale(0.9);
			transition: all 0.2s ease-in 0s;
			overflow: hidden;
		}
	}
}

.swiper-item-img {
	height: 280upx;
	width: 100%;

	image {
		border-radius: 10upx;
		width: 100%;
		height: 100%;
	}

	.swiper-item-foot-text {
		position: absolute;
		bottom: 20upx;
		width: calc(100% - 40upx);
		height: 50rpx;
		line-height: 50rpx;
		padding: 0 19rpx;
		background-color: rgba(0, 0, 0, 0.7);
		border-bottom-left-radius: 10upx;
		border-bottom-right-radius: 10upx;

		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 1;
		-webkit-box-orient: vertical;

		color: #ffffff;
		font-size: 14px;
	}
}

/* 顶部tabbar */

.addTag {
	position: absolute;
	top: 0;
	right: 0;
	width: 80rpx;
	height: 72rpx;
	background: linear-gradient(to right, rgba(255, 255, 255, 0), rgba(255, 255, 255, 1));
	background-size: cover;
	background-image: url(../../static/images/home_add.png);
	z-index: 11;
}
.nav-bar {
	/* 标签栏顶部固定 → 防止 iPhone端 出现下拉移位的问题 */
	position: fixed;
	top: 0;

	position: relative;
	z-index: 10;
	width: 100%;
	height: 74upx;
	box-sizing: border-box;
	flex-direction: row;
	white-space: nowrap;
	background-color: #ffffff;
	border-bottom: 1px solid #f2f2f2;
}
.nav-bar .uni-tab-item:last-child {
	margin-right: 80upx;
}

/* 可滚动窗体高度（swiper外层刷新组件高度），100vh(相对于视窗的高度)  */
/* calc(100vh - 38px - 50px)：100vh(整个浏览器窗口高度) - 38px(顶部标签滑动栏高度) - 50px(底部tabBar栏高度(固定)) 的大小 */
.panel-content {
	/* height: calc(100vh - 38px - 50px) !important;
		max-height: calc(100vh - 38px - 50px) !important; */
	/* background-color: red; */
}

.swiper-box {
	height: 100%;
	/* height: calc(100vh - 74rpx - 100rpx - 88rpx - var(--status-bar-height) + 300rpx); */
	/* height: auto; */
}

.panel-scroll-box-wai {
	height: 100%;
}
.panel-scroll-box {
	height: 100%;
	/* padding-bottom: 88rpx; */
	.panel-item {
		background: #fff;
		padding: 30px 0;
		border-bottom: 2px solid #000;
	}
}

/**
	 * 新闻列表 直接拿的nvue样式修改，,
	 * 一共需要修改不到10行代码, 另外px需要直接修改为upx，只有单位不一样，计算都是一样的
	 * 吐槽：难道不能在编译的时候把nuve中的upx转为px? 这样就不用修改单位了
	 */
.video-wrapper {
	width: 100%;
	height: 440upx;
	.video {
		width: 100%;
	}
}

view {
	display: flex;
	flex-direction: column;
}
.img {
	width: 100%;
	height: 100%;
}
.news-item {
	position: relative;
	border: 1upx solid rgba(0, 0, 0, 0.3);
	min-height: 190upx;
}
/* 修改结束 */

/* 新闻列表  emmm 仅供参考 */
.news-item {
	width: 750upx;
	padding: 24upx 30upx;
	border-bottom-width: 1px;
	border-color: #eee;
	background-color: #fff;
}
.title {
	font-size: 32upx;
	color: #303133;
	line-height: 46upx;
}
.bot {
	flex-direction: row;
}
.author {
	font-size: 26upx;
	color: #aaa;
}
.time {
	font-size: 26upx;
	color: #aaa;
	/* margin-left: 20upx; */
}
.img-list {
	flex-shrink: 0;
	flex-direction: row;
	background-color: #fff;
	width: 220upx;
	height: 140upx;
}
.img-wrapper {
	flex: 1;
	flex-direction: row;
	height: 140upx;
	position: relative;
	overflow: hidden;
}
.img-wrapper image {
	border-radius: 10upx;
}
.img {
	flex: 1;
}
.img-empty {
	height: 20upx;
}

/* 图在左 */
.img-list1 {
	position: absolute;
	left: 30upx;
	top: 24upx;
}
.title1 {
	padding-left: 240upx;
}
.bot1 {
	padding-left: 240upx;
	margin-top: 20upx;
}
/* 图在右 */
.img-list2 {
	position: absolute;
	right: 30upx;
	top: 24upx;
}
.title2 {
	padding-right: 210upx;
}
.bot2 {
	margin-top: 20upx;
}
/* 底部3图 */
.img-list3 {
	width: 700upx;
	margin: 16upx 0upx;
}
.img-wrapper3 {
	margin-right: 4upx;
}
/* 底部大图 */
.img-list-single {
	width: 690upx;
	height: 240upx;
	margin: 16upx 0upx;
}
.img-wrapper-single {
	height: 240upx;
	margin-right: 0upx;
}

.video-tip {
	position: absolute;
	left: 0;
	top: 0;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
	height: 100%;
	background-color: rgba(0, 0, 0, 0.3);
}
.video-tip-icon {
	width: 60upx;
	height: 60upx;
}

.uni-tab-item {
	display: inline-block;
	flex-wrap: nowrap;
	padding-left: 14.5px;
	padding-right: 14.5px;
	/* border: 1px solid red; */
	position: relative;
}

// 滚动tab 标签
.uni-tab-item-title {
	color: #999999;
	font-size: 12px;
	height: 38px;
	line-height: 38px;
	flex-wrap: nowrap;
	white-space: nowrap;
}
.uni-tab-item-title-active {
	color: #000000;
}
// 滚动tab 底部选中条
.uni-tab-item-border {
	position: absolute;
	top: 85%;
	left: 50%;
	transform: translate(-50%, -50%);
}
.uni-tab-item-border-active {
	width: 14px;
	height: 2px;
	background-color: #000000;
}

.swiper {
	// display: block;
	height: 100%;
}

.swiper-item {
	display: flex;
	flex: 1;
	flex-direction: column;
	overflow: hidden;
	height: 100%;
	box-sizing: border-box;

	.list {
		width: 100%;
		// height: 100%;
		/* 状态栏的高度为 var(--status-bar-height) 此变量为uni-app框架提供仅在在css生效 */
		/* 38px → 标签栏38px */
		height: calc(100% - 38px);
	}
}

/* 评论图标 */
.rightComment {
	display: flex;
	flex-direction: row;
	align-items: center;

	.commentIcon {
		width: 24rpx;
		height: 22rpx;
		background-size: cover;
		background-image: url(../../static/images/video_comment.png);
	}

	.commentNum {
		margin-left: 10rpx;
	}
}
</style>
