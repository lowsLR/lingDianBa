<template>
	<view class="container">
		
		<view class="header-wrap">
			<view class="btn comeBack" @tap="backButton"></view>
			<input class="uni-input" v-model="searchText" @input="MonitorIn" confirm-type="search" maxlength="10" focus placeholder="请输入关键词" @confirm="confirm" />
			<view class="search" @tap="confirm">零点搜索</view>
		</view>
		
		<!-- 顶部选项卡 -->
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<view 
				v-for="(item,index) in tabBars" :key="item.id"
				class="nav-item"
				:class="{current: index === tabCurrentIndex}"
				:id="'tab'+index"
				@click="changeTab(index)"
			>{{item.name}}</view>
		</scroll-view>
		
		<view class="initial" v-show="searchStatus === 0">
			<view class="top">
				<text>搜索历史</text>
				<text @tap="clearHistory">清空</text>
			</view>
			<block v-for="(item, index) in searchHistory" :key="index">
				<view class="item" @tap="clickHistory(item)">{{item}}</view>
			</block>
		</view>
		
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" 
			v-show="searchStatus === 1"
			class="panel-content" 
			:top="74" 
			:isCustomBar="true"
			@refresh="onPulldownReresh" 
			@setEnableScroll="setEnableScroll"
		>
			<!-- 内容部分 -->
			<swiper 
				id="swiper"
				class="swiper-box"
				:style="{height:swiperHeight}"
				:duration="300" 
				:current="tabCurrentIndex" 
				@change="changeTab"
			>
			<!-- v-for="tabItem in tabBars" :key="tabItem.id" -->
				<!-- 综合 -->
				<swiper-item >
					<scroll-view
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<!-- 综合列表 -->
						<view class="zh-main">
							<!-- 综合模块 - 直播 -->
							<view class="module" v-if="tabBars[tabCurrentIndex].data.sportMatchVO2s && tabBars[tabCurrentIndex].data.sportMatchVO2s.length > 0">
								<view class="moduleTitle">直播</view>
								
								<view class="live-main zh-live-main">
									<block v-for="(tabItem, tabIndex) in tabBars[tabCurrentIndex].data.sportMatchVO2s" :key="tabIndex">
										<view class="matchDate" :id="'active'+tabIndex">
											{{tabItem.dateString}}
										</view>
										<view class="list-item" v-for="(xitem, xindex) in tabItem.sportMatchVOS" :key="xindex" @tap="openLive(xitem)">
											<view class="gameTitle">
												<!-- matchState(比赛状态) ==2：时间待定，!=2：显示时间 -->
												<view class="time" v-if="xitem.matchState != 2">{{xitem.matchBeginTime | CaptureTime}}</view>
												<view class="time" v-else>{{xitem.matchIntroduction}}</view>
												<!-- 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题 -->
												<view class="matchTitle" v-html="filterLiveTitle(xitem)"></view>
												
											</view>
											<view class="gameInfo">
												<view class="leftTeam">
													<image v-if="xitem.homeTeamId != null" :src="xitem.homeTeamLogoPath != null && xitem.homeTeamLogoPath != '' ? ('https://images.weserv.nl/?url='+xitem.homeTeamLogoPath) : '../../static/assets/homeTeam.png'" mode=""></image>
													<!-- <text class="teamName">{{xitem.homeTeamName}}</text> -->
													<text class="teamName" v-html="xitem.homeTeamName"></text>
												</view>
												
												<view class="liveBtn" :class="xitem.matchState != 0 ? 'disable' : ''" v-if="xitem.matchLiveSourceDOS.length > 0">视频直播</view>
												<view class="liveBtn disable" v-else-if="xitem.matchLiveSourceDOS.length <= 0">暂无信号</view>
												
												<view class="rightTeam">
													<image v-if="xitem.guestTeamId != null" :src="xitem.guestTeamLogoPath != null && xitem.guestTeamLogoPath != '' ? ('https://images.weserv.nl/?url='+xitem.guestTeamLogoPath) : '../../static/assets/guestTeam.png'" mode=""></image>
													<!-- <text class="teamName">{{xitem.guestTeamName}}</text> -->
													<text class="teamName" v-html="xitem.guestTeamName"></text>
												</view>
											</view>
											<!-- matchState(比赛状态)：0正常 1延期 2时间待定 -->
											<view class="prompt" v-if="xitem.matchIntroduction != null && xitem.matchIntroduction != '' && xitem.matchState != 2">{{xitem.matchIntroduction}}</view>
										</view>
									</block>
								</view>
								
								<view @tap="readMore(1)" v-if="tabBars[tabCurrentIndex].data.sportMatchVO2s && tabBars[tabCurrentIndex].data.sportMatchVO2s.length > 0" class="viewMore">查看更多直播</view>
								<view v-else class="noMore">暂无相关数据</view>
							</view>
							
							<!-- 综合模块 - 录像 -->
							<view class="module" v-if="tabBars[tabCurrentIndex].data.sportMatchVideoVOS && tabBars[tabCurrentIndex].data.sportMatchVideoVOS.length > 0">
								<view class="moduleTitle">录像</view>
								
								<view class="lx-main zh-lx-main">
									<!-- 录像列表 -->
									<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data.sportMatchVideoVOS" :key="index" @tap="navToVideo(1, item)">
										<image class="eventLogo" :src="item.eventLogo" mode=""></image>
										<view v-if="tabCurrentIndex == 0" class="time">{{item.matchBeginTime | getCovTime}}</view>
										<view v-if="tabCurrentIndex == 0" class="content" v-html="$options.filters.getCombinationTitle(item)"></view>
									</view>
								</view>
								
								<view @tap="readMore(2)" v-if="tabBars[tabCurrentIndex].data.sportMatchVideoVOS && tabBars[tabCurrentIndex].data.sportMatchVideoVOS.length > 0" class="viewMore">查看更多录像</view>
								<view v-else class="noMore">暂无相关数据</view>
							</view>
							
							<!-- 综合模块 - 视频 -->
							<view class="module" v-if="tabBars[tabCurrentIndex].data.sportMatchLiveDOS && tabBars[tabCurrentIndex].data.sportMatchLiveDOS.length > 0">
								<view class="moduleTitle">视频</view>
								
								<view class="video-main">
									<!-- #ifndef H5 -->
									<!-- 视频列表 -->
									<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data.sportMatchLiveDOS" :key="index">
										<view class="videoInfo" @tap="navToVideo(0, item)">
											<image class="item-cover" :src="item.imgHref != null ? item.imgHref : '../../static/default_img.png'"></image>
											<!-- <view class="item-title">{{item.liveTitle}}</view> -->
											<view class="item-title" v-html="item.liveTitle"></view>
											<view class="playBtn"></view>
										</view>
										<view class="bottomBar">
											<!-- 播放数 -->
											<view class="views">
												<view class="icon"></view>
												<view class="text">{{item.playNumber == null ? 0 : item.playNumber}}人看过</view>
											</view>
											<!-- 评论数 -->
											<view class="comments">
												<view class="icon"></view>
												<view class="text">{{item.commentNumber == null ? 0 : item.commentNumber}}</view>
											</view>
										</view>
									</view>
									<!-- #endif -->
									
									<!-- #ifdef H5 -->
									<!-- 视频列表 -->
									<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data.sportMatchLiveDOS" :key="index">
										<view class="videoInfo">
											<view class="item-title" v-html="item.liveTitle"></view>
											<view class="videoBox" v-if="videoCurrentIndex === index && tabCurrentIndex === 0">
												<bwVideoPlayer
												:height='480'
												:isPlaySource="item.isPlaySource"
												:videoType='item.videoType'
												:isLive="false"
												:sourceUrl="item.playLive"
												:poster="item.imgHref != null ? item.imgHref : '../../static/default_img.png'"
												:isAutoplay="isAutoplay"
												:videoMsg="item.videoMsg"
												@calculationNum="calculationNum(item, index, 0)"
												@videoError="videoErrorfun"
												ref="videoplay"
												></bwVideoPlayer>
											</view>
											<image v-else class="item-cover"
											mode="aspectFit"
											:src="item.imgHref != null ? item.imgHref : '../../static/default_img.png'"></image>
											<view v-if="videoCurrentIndex !== index" class="playBtn" @tap="playVideo(item, index)"></view>
										</view>
										<view class="bottomBar" @tap="navToVideo(0, item)">
											<!-- 播放数 -->
											<view class="views">
												<view class="icon"></view>
												<view class="text">{{item.playNumber == null ? 0 : item.playNumber}}人看过</view>
											</view>
											<!-- 评论数 -->
											<view class="comments">
												<view class="icon"></view>
												<view class="text">{{item.commentNumber == null ? 0 : item.commentNumber}}</view>
											</view>
										</view>
									</view>
									<!-- #endif -->
								</view>
								
								<view @tap="readMore(3)" v-if="tabBars[tabCurrentIndex].data.sportMatchLiveDOS && tabBars[tabCurrentIndex].data.sportMatchLiveDOS.length > 0" class="viewMore">查看更多视频</view>
								<view v-else class="noMore">暂无相关数据</view>
							</view>
							
							<!-- 综合模块 - 新闻 -->
							<view class="module" v-if="tabBars[tabCurrentIndex].data.sportMatchNewsDOS && tabBars[tabCurrentIndex].data.sportMatchNewsDOS.length > 0">
								<view class="moduleTitle">新闻</view>
								
								<view class="news-main">
									<!-- 新闻列表 -->
									<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data.sportMatchNewsDOS" :key="index" @tap="navToNews(item.id)">
										<image :src="item.imgUrl != null ? 'https://images.weserv.nl/?url='+item.imgUrl : '../../static/default_img.png'" mode="aspectFill"></image>
										<view class="right-view">
											<!-- <view class="title">{{item.newsTitle}}</view> -->
											<view class="title" v-html="item.newsTitle"></view>
											<view class="bottom">
												<text class="time">{{item.createdTime | filtersTime}}</text>
												<!-- <text class="icon iconfont">&#xe642;&nbsp;{{item.commentNumber == null ? 0 : item.commentNumber}}</text> -->
												<view class="rightComment">
													<view class="commentIcon"></view>
													<text class="commentNum" v-if="item.commentNumber">{{item.commentNumber}}</text>
												</view>
											</view>
										</view>
									</view>
								</view>
								
								<view @tap="readMore(4)" v-if="tabBars[tabCurrentIndex].data.sportMatchNewsDOS && tabBars[tabCurrentIndex].data.sportMatchNewsDOS.length > 0" class="viewMore">查看更多新闻</view>
								<view v-else class="noMore">暂无相关数据</view>
							</view>
							
							<!-- 综合模块 - 电视 -->
							<view class="module" v-if="tabBars[tabCurrentIndex].data.webTvInfoDOS && tabBars[tabCurrentIndex].data.webTvInfoDOS.length > 0">
								<view class="moduleTitle">电视</view>
								
								<view class="tv-main">
									<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data.webTvInfoDOS" :key="index" @tap="playTv(item.id, item.tvName)">
										<image class="imgLog" :src="item.imgLog != null && item.imgLog != '' ? item.imgLog : '../../static/default_tv.png'" mode=""></image>
										<!-- <view class="title">{{item.tvNameCov}}</view> -->
										<view class="title" v-html="item.tvNameCov"></view>
									</view>
								</view>
								
								<view @tap="readMore(5)" v-if="tabBars[tabCurrentIndex].data.webTvInfoDOS && tabBars[tabCurrentIndex].data.webTvInfoDOS.length > 0" class="viewMore">查看更多电视</view>
								<view v-else class="noMore">暂无相关数据</view>
							</view>
							
						</view>
						
						<view class="zhNoMore" 
							v-if="(tabBars[tabCurrentIndex].data.sportMatchVO2s && tabBars[tabCurrentIndex].data.sportMatchVO2s.length <= 0) && tabBars[tabCurrentIndex].data.sportMatchVideoVOS.length <= 0 && tabBars[tabCurrentIndex].data.sportMatchLiveDOS.length <= 0 && tabBars[tabCurrentIndex].data.sportMatchNewsDOS.length <= 0 && tabBars[tabCurrentIndex].data.webTvInfoDOS.length <= 0"
						>
							没有更多数据了
						</view>
						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabBars[tabCurrentIndex].loadMoreStatus"></mix-load-more> -->
					</scroll-view>
				</swiper-item>
				
				<!-- 直播 -->
				<swiper-item >
					<scroll-view 
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<view class="live-main">
							<!-- 直播列表 -->
							<block v-for="(tabItem, tabIndex) in tabBars[tabCurrentIndex].data" :key="tabIndex">
								<view class="matchDate" :id="'active'+tabIndex">
									{{tabItem.dateString}}
								</view>
								<view class="list-item" v-for="(xitem, xindex) in tabItem.sportMatchVOS" :key="xindex" @tap="openLive(xitem)">
									<view class="gameTitle">
										<!-- matchState(比赛状态) ==2：时间待定，!=2：显示时间 -->
										<view class="time" v-if="xitem.matchState != 2">{{xitem.matchBeginTime | CaptureTime}}</view>
										<view class="time" v-else>{{xitem.matchIntroduction}}</view>
										<!-- 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题 -->
										<view class="matchTitle" v-html="filterLiveTitle(xitem)"></view>
										
									</view>
									<view class="gameInfo">
										<view class="leftTeam">
											<image v-if="xitem.homeTeamId != null" :src="xitem.homeTeamLogoPath != null && xitem.homeTeamLogoPath != '' ? ('https://images.weserv.nl/?url='+xitem.homeTeamLogoPath) : '../../static/assets/homeTeam.png'" mode=""></image>
											<!-- <text class="teamName">{{xitem.homeTeamName}}</text> -->
											<text class="teamName" v-html="xitem.homeTeamName"></text>
										</view>
										
										<view class="liveBtn" :class="xitem.matchState != 0 ? 'disable' : ''" v-if="xitem.matchLiveSourceDOS.length > 0">视频直播</view>
										<view class="liveBtn disable" v-else-if="xitem.matchLiveSourceDOS.length <= 0">暂无信号</view>
										
										<view class="rightTeam">
											<image v-if="xitem.guestTeamId != null" :src="xitem.guestTeamLogoPath != null && xitem.guestTeamLogoPath != '' ? ('https://images.weserv.nl/?url='+xitem.guestTeamLogoPath) : '../../static/assets/guestTeam.png'" mode=""></image>
											<!-- <text class="teamName">{{xitem.guestTeamName}}</text> -->
											<text class="teamName" v-html="xitem.guestTeamName"></text>
										</view>
									</view>
									<!-- matchState(比赛状态)：0正常 1延期 2时间待定 -->
									<view class="prompt" v-if="xitem.matchIntroduction != null && xitem.matchIntroduction != '' && xitem.matchState != 2">{{xitem.matchIntroduction}}</view>
								</view>
							</block>
						</view>
						<!-- 上滑加载更多组件 -->
						<mix-load-more :status="tabBars[tabCurrentIndex].loadMoreStatus"></mix-load-more>
					</scroll-view>
				</swiper-item>
				
				<!-- 录像 -->
				<swiper-item >
					<scroll-view
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<view class="lx-main">
							<!-- 录像列表 -->
							<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data" :key="index" @tap="navToVideo(1, item)">
								<image class="eventLogo" :src="item.eventLogo" mode=""></image>
								<view v-if="tabCurrentIndex == 2" class="time">{{item.matchBeginTime | getCovTime}}</view>
								<view v-if="tabCurrentIndex == 2" class="content" v-html="$options.filters.getCombinationTitle(item)"></view>
							</view>
						</view>
						<!-- 上滑加载更多组件 -->
						<mix-load-more :status="tabBars[tabCurrentIndex].loadMoreStatus"></mix-load-more>
					</scroll-view>
				</swiper-item>
				
				<!-- 视频 -->
				<swiper-item >
					<scroll-view
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<view class="video-main">
							<!-- #ifndef H5 -->
							<!-- 视频列表 -->
							<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data" :key="index">
								<view class="videoInfo" @tap="navToVideo(0, item)">
									<image class="item-cover" :src="item.imgHref != null ? item.imgHref : '../../static/default_img.png'"></image>
									<!-- <view class="item-title">{{item.liveTitle}}</view> -->
									<view class="item-title" v-html="item.liveTitle"></view>
									<view class="playBtn"></view>
								</view>
								<view class="bottomBar">
									<!-- 播放数 -->
									<view class="views">
										<view class="icon"></view>
										<view class="text">{{item.playNumber == null ? 0 : item.playNumber}}人看过</view>
									</view>
									<!-- 评论数 -->
									<view class="comments">
										<view class="icon"></view>
										<view class="text">{{item.commentNumber == null ? 0 : item.commentNumber}}</view>
									</view>
								</view>
							</view>
							<!-- #endif -->
							
							<!-- #ifdef H5 -->
							<!-- 视频列表 -->
							<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data" :key="index">
								<view class="videoInfo">
									<view class="item-title" v-html="item.liveTitle"></view>
									<view class="videoBox" v-if="videoCurrentIndex === index && tabCurrentIndex === 3">
										<bwVideoPlayer
										:height='480'
										:isPlaySource="item.isPlaySource"
										:videoType='item.videoType'
										:isLive="false"
										:sourceUrl="item.playLive"
										:poster="item.imgHref != null ? item.imgHref : '../../static/default_img.png'"
										:isAutoplay="isAutoplay"
										:videoMsg="item.videoMsg"
										@calculationNum="calculationNum(item, index, 1)"
										@videoError="videoErrorfun"
										ref="videoplay"
										></bwVideoPlayer>
									</view>
									<image v-else class="item-cover"
									mode="aspectFit"
									:src="item.imgHref != null ? item.imgHref : '../../static/default_img.png'"></image>
									<view v-if="videoCurrentIndex !== index" class="playBtn" @tap="playVideo(item, index)"></view>
								</view>
								<view class="bottomBar" @tap="navToVideo(0, item)">
									<!-- 播放数 -->
									<view class="views">
										<view class="icon"></view>
										<view class="text">{{item.playNumber == null ? 0 : item.playNumber}}人看过</view>
									</view>
									<!-- 评论数 -->
									<view class="comments">
										<view class="icon"></view>
										<view class="text">{{item.commentNumber == null ? 0 : item.commentNumber}}</view>
									</view>
								</view>
							</view>
							<!-- #endif -->
						</view>
						<!-- 上滑加载更多组件 -->
						<mix-load-more :status="tabBars[tabCurrentIndex].loadMoreStatus"></mix-load-more>
					</scroll-view>
				</swiper-item>
				
				<!-- 新闻 -->
				<swiper-item >	
					<scroll-view
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<view class="news-main">
							<!-- 新闻列表 -->
							<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data" :key="index" @tap="navToNews(item.id)">
								<image :src="item.imgUrl != null ? 'https://images.weserv.nl/?url='+item.imgUrl : '../../static/default_img.png'" mode="aspectFill"></image>
								<view class="right-view">
									<!-- <view class="title">{{item.newsTitle}}</view> -->
									<view class="title" v-html="item.newsTitle"></view>
									<view class="bottom">
										<text class="time">{{item.createdTime | filtersTime}}</text>
										<!-- <text class="icon iconfont">&#xe642;&nbsp;{{item.commentNumber == null ? 0 : item.commentNumber}}</text> -->
										<view class="rightComment">
											<view class="commentIcon"></view>
											<text class="commentNum" v-if="item.commentNumber">{{item.commentNumber}}</text>
										</view>
									</view>
								</view>
							</view>
						</view>
						<!-- 上滑加载更多组件 -->
						<mix-load-more :status="tabBars[tabCurrentIndex].loadMoreStatus"></mix-load-more>
					</scroll-view>
				</swiper-item>
				
				<!-- 电视 -->
				<swiper-item >	
					<scroll-view
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<view class="tv-main">
							<view class="list-item" v-for="(item, index) in tabBars[tabCurrentIndex].data" :key="index" @tap="playTv(item.id, item.tvName)">
								<image class="imgLog" :src="item.imgLog != null && item.imgLog != '' ? item.imgLog : '../../static/default_tv.png'" mode=""></image>
								<!-- <view class="title">{{item.tvNameCov}}</view> -->
								<view class="title" v-html="item.tvNameCov"></view>
							</view>
						</view>
						<!-- 上滑加载更多组件 -->
						<mix-load-more :status="tabBars[tabCurrentIndex].loadMoreStatus"></mix-load-more>
					</scroll-view>
				</swiper-item>
			</swiper>
		</mix-pulldown-refresh>
		
	</view>
</template>

<script>
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	import bwVideoPlayer from '../component/bw-videoPlayer.vue';
	
	let windowWidth = 0, scrollTimer = false, tabBar,player,that;
	export default {
		components: {
			mixPulldownRefresh,
			mixLoadMore,
			bwVideoPlayer,
		},
		data() {
			return {
				tabCurrentIndex: 0, // 当前选项卡索引
				searchTabIndex: 0,	// 点击搜索时选项卡所在索引(避免来回切换时重复请求数据)
				searchText: '',		// 输入框内容
				searchkeyWord: '',	// 搜索关键词
				searchStatus: 0,	// 显示内容 → 0：搜索历史，1：搜索结果
				searchHistory: [],	// 搜索历史
				total: 100,	// 请求返回数据总条数(变量)，限制最大条数
				tabBars: [],
				tabList: [{
						name: '综合',
						id: '0',
					}, {
						name: '直播',
						id: '1',
					}, {
						name: '录像',
						id: '2'
					}, {
						name: '视频',
						id: '3'
					}, {
						name: '新闻',
						id: '4'
					}, {
						name: '电视',
						id: '5'
					}],
				currentDay: 0, // 当前日期
				
				scrollLeft: 0, //顶部选项卡左滑距离
				enableScroll: true,
				swiperHeight: '',//滑块高度
				
				/* 视频模块参数 */
				videoCurrentIndex: -1,	// 当前播放器索引
				isAutoplay: true,		// 是否自动播放
			}
		},
		// 计算属性
		computed: {
			// 控制显示的内容
			/* computedTxt() {
				return function(value) {
					return this.methodGetByteLen(value, 20)
				}
			} */
			
			// 直播标题
			filterLiveTitle: function() {
				// `this` points to the vm instance
				return function (xitem) {
					// console.log(this);
					// console.log(xitem);
					let title = xitem.eventTypeName == '' || xitem.eventTypeName == null ? xitem.specialName + (xitem.matchTitle == '' || xitem.matchTitle == null ? '' : ' ') + xitem.matchTitle : (xitem.eventTypeName == '其他' ? (xitem.eventName + (xitem.matchTitle == '' || xitem.matchTitle == null ? '' : ' ') + xitem.matchTitle) : (xitem.eventTypeName + xitem.matchTitle))
					// return title
					return this.ModifyTextColor(title)
				}
			}
			
		},
		async onLoad() {
			that = this;
			// 获取屏幕宽度
			windowWidth = uni.getSystemInfoSync().windowWidth;
			
			// 获取当前日期
			let date = new Date();
			that.currentDay = date.getDate() < 10 ? ('0'+date.getDate()) : date.getDate();
			
			// 获取搜索历史
			uni.getStorage({
				key: 'searchHistory',
				success: function (res) {
					console.log("搜索历史：",res.data);
					that.searchHistory = res.data;
				},
				fail: function (err) {
					console.log("---------------------暂无搜索历史---------------------");
				}
			});
			
			that.loadTabbars();
		},
		onHide() {
			console.log('搜索 页面隐藏');
			this.videoCurrentIndex = -1; // 隐藏播放器
		},
		methods: {
			ModifyTextColor: function (text) {
				// console.log(text);
				// let str = text.replace(that.searchkeyWord, `<span style='color:red'>${that.searchkeyWord}</span>`)
				
				// 'ig'	忽略大小写在全文中查找指定字符串
				let regExp = new RegExp(`${that.searchkeyWord}`, 'ig');
				
				// 方法一：
				if (text == '' || text == null) {
					return '';
				}
				let str = text.replace(regExp, function(txt){
					// console.log(txt);
					// return "<i>"+txt+"</i>";
					return `<span style='color:red'>${txt}</span>`;
				})
				
				// 方法二：
				/* let initText = text.match(new RegExp(`${that.searchkeyWord}`, 'i')) || '';
				let str = text.replace(regExp, `<span style='color:red'>${initText}</span>`);
				// console.log(text.match(new RegExp(`${that.searchkeyWord}`, 'i'))); */
				
				return str
			},
			
			// 初始化分类列表
			loadTabbars(){
				// let that = this;
				let tabarr = that.tabList;
				tabarr.forEach((item, index)=>{
					// console.log('收藏的标签：',index);
					item.data = [];
					item.loadMoreStatus = 0; //加载更多 0加载前，1加载中，2没有更多了
					item.refreshing = 0;
					item.offset = 1;
					item.loaded = false; // 判断是否已首次加载当前tab
					item.isLastPage = false;
					that.tabBars.push(item)
				})
				console.log(that.tabBars);
				// this.loadNewsList('add');
			},
			
			// 获取搜索数据
			loadNewsList(type){
				
				let tabItem = this.tabBars[this.tabCurrentIndex];
				// console.log("选中",tabItem)
				
				// type add 加载更多 refresh下拉刷新
				if(type === 'add'){
					if(tabItem.loadMoreStatus === 2 || tabItem.isLastPage){
						console.log("末页状态：",tabItem.isLastPage)
						return;
					}
					if(tabItem.data&&tabItem.data.length > 0){
						tabItem.offset++;
					}
					console.log('---------------------加载---------------------');
					tabItem.loadMoreStatus = 1;
				}
				
				// #ifdef APP-PLUS
				if(type === 'refresh'){
					tabItem.refreshing = true;
				}
				// #endif
				if(type === 'refresh'){
					tabItem.offset = 1;
					console.log('---------------------刷新---------------------');
					tabItem.loadMoreStatus = 1;
				}
				
				uni.showLoading({
					title: '加载中...'
				})
				let datas = {
					"searchKey": that.searchText,
					"limit": 10,
					"offset": tabItem.offset,
				}
				// console.log('请求参数：', datas);
				let request;
				switch (that.tabCurrentIndex){
					case 0:
						console.log('综合--请求参数：', datas);
						request = this.$req.reqc.searchAll(datas);
						break;
					case 1:
						console.log('直播--请求参数：', datas);
						request = this.$req.reqc.searchMatch(datas);
						break;
					case 2:
						console.log('录像--请求参数：', datas);
						request = this.$req.reqc.searchMatchListByVideo(datas);
						break;
					case 3:
						console.log('视频--请求参数：', datas);
						request = this.$req.reqc.searchLiveTitle(datas);
						break;
					case 4:
						console.log('新闻--请求参数：', datas);
						request = this.$req.reqc.searchNewsTitle(datas);
						break;
					case 5:
						datas = {
							"tvName": that.searchText,
							"limit": 20,
							"offset": tabItem.offset,
						}
						console.log('电视--请求参数：', datas);
						request = this.$req.reqc.queryLikeTvName(datas);
						break;
					default:
						uni.hideLoading();return;
						break;
				}
				request.then( res => {
					uni.hideLoading();
					// console.log("返回结果：",res)
					if(type === 'refresh'){
						tabItem.data = []; // 刷新前清空数组
					}
					
					console.log("数据列表", res.data.data)
					// 更新分页状态 与 总页数
					tabItem.isLastPage = res.data.data.isLastPage;
					this.total = res.data.data.total;
					
					let list;
					// 模块数据处理
					if (that.tabCurrentIndex === 0) {
						tabItem.data = res.data.data || [];
					}
					else if (that.tabCurrentIndex === 1) {
						list = res.data.data&&res.data.data.list[0] || [];
						
						// 赛事日期相同的数据合并
						if (tabItem.data.length > 0) {
							let TempArr = tabItem.data[tabItem.data.length-1]
							// console.log(TempArr, tabItem.data.length);
							let date = TempArr.dateString
							list.forEach ((item, index) => {
								if (item.dateString == date) {
									// 在数组合并前，匹配与搜索内容一致的列表数据 并高亮显示
									item.sportMatchVOS.forEach ((citem, cindex) => {
										// console.log(citem.homeTeamName, citem.guestTeamName);
										citem.homeTeamName = that.ModifyTextColor(citem.homeTeamName)
										citem.guestTeamName = that.ModifyTextColor(citem.guestTeamName)
									})
									
									tabItem.data[tabItem.data.length-1].sportMatchVOS = TempArr.sportMatchVOS.concat(list[index].sportMatchVOS)
									list.splice(index, 1);
									console.log('相同：', tabItem.data[tabItem.data.length-1].sportMatchVOS);
								}
							})
						}
					} else {
						list = res.data.data&&res.data.data.list || [];
					}
					
					
					if (that.tabCurrentIndex === 0) {
						// 直播
						tabItem.data.sportMatchVO2s.forEach ((item,index) => {
							item.sportMatchVOS.forEach ((citem, cindex) => {
								citem.homeTeamName = that.ModifyTextColor(citem.homeTeamName)
								citem.guestTeamName = that.ModifyTextColor(citem.guestTeamName)
							})
						})
						// 录像
						tabItem.data.sportMatchVideoVOS.forEach ((item, index) => {
							item.homeTeamName = that.ModifyTextColor(item.homeTeamName)
							item.guestTeamName = that.ModifyTextColor(item.guestTeamName)
							item.matchTitle = that.ModifyTextColor(item.matchTitle)
						})
						// 视频
						tabItem.data.sportMatchLiveDOS.forEach ((item, index) => {
							item.liveTitle = that.ModifyTextColor(item.liveTitle)
							
							// #ifdef H5
							item.isPlayed = false; // 是否已观看
							item.isPlaySource = item.playLive != '' && item.playLive != null ? true : false; // 是否有播放源
							item.videoMsg = '暂无播放源'; // 无播放源提示
							item.videoType = that.getVideoType(item.playLive); // 播放源格式
							// #endif
						})
						// 新闻
						tabItem.data.sportMatchNewsDOS.forEach ((item, index) => {
							item.newsTitle = that.ModifyTextColor(item.newsTitle)
						})
						// 电视
						tabItem.data.webTvInfoDOS.forEach ((item, index) => {
							item.tvNameCov = that.ModifyTextColor(item.tvName)
						})
						// console.log(tabItem.data.sportMatchVO2s);
						// console.log(tabItem.data.sportMatchVideoVOS);
						// console.log(tabItem.data.sportMatchLiveDOS);
						// console.log(tabItem.data.sportMatchNewsDOS);
						// console.log(tabItem.data.webTvInfoDOS);
					} else {
						list.forEach((item,index) => {
							// let items = {id: item.id,}
							// tabItem.data.push(items);
							switch (that.tabCurrentIndex){
								case 1:
									item.sportMatchVOS.forEach ((citem, cindex) => {
										// console.log(citem.homeTeamName, citem.guestTeamName);
										citem.homeTeamName = that.ModifyTextColor(citem.homeTeamName)
										citem.guestTeamName = that.ModifyTextColor(citem.guestTeamName)
									})
									break;
								case 2:
									item.homeTeamName = that.ModifyTextColor(item.homeTeamName)
									item.guestTeamName = that.ModifyTextColor(item.guestTeamName)
									item.matchTitle = that.ModifyTextColor(item.matchTitle)
									break;
								case 3:
									item.liveTitle = that.ModifyTextColor(item.liveTitle)
									
									// #ifdef H5
									item.isPlayed = false; // 是否已观看
									item.isPlaySource = item.playLive != '' && item.playLive != null ? true : false; // 是否有播放源
									item.videoMsg = '暂无播放源'; // 无播放源提示
									item.videoType = that.getVideoType(item.playLive); // 播放源格式
									// #endif
									break;
								case 4:
									item.newsTitle = that.ModifyTextColor(item.newsTitle)
									break;
								case 5:
									item.tvNameCov = that.ModifyTextColor(item.tvName)
									break;
								default:
									break;
							}
							
							tabItem.data.push(item);
						})
					}
					
					
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						// tabItem.loadMoreStatus = 0;
					}
					// 上滑加载、下拉刷新 处理状态 (返回数据长度小于零/数据长度与总数据量相等 → '没有更多数据了')
					if(type === 'add' || type === 'refresh'){
						// tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2 : 0;
						console.log('是否为末页：',tabItem.isLastPage);
						tabItem.loadMoreStatus = tabItem.isLastPage ? 2 : 0;
					}
					
					console.log("全部数据",tabItem);
					
					this.$forceUpdate();
				})
				.catch(err => {
					console.log(err);
					uni.hideLoading();
				})
			},
			
			//下拉刷新
			onPulldownReresh(){
				this.loadNewsList('refresh');
			},
			//上滑加载
			loadMore(){
				// 综合搜索无分页
				if (that.tabCurrentIndex === 0) {
					return;
				}
				this.loadNewsList('add');
			},
			
			
			// 输入监听
			MonitorIn: function (e) {
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				if (val == '') {
					// 无内容 显示搜索历史
					console.log('无内容');
					that.searchStatus = 0;
					// that.searchText = ''
				}
			},
			
			// 搜索/回车查询
			confirm: function () {
				let val = that.searchText.replace(/(^\s*)|(\s*$)/g, "");
				if (val != '' && val != null) {
					that.searchStatus = 1;
					
					// 保存搜索记录(设置本地存储)
					let arr = [], isAdd = true;
					if (that.searchHistory.length > 0) {
						that.searchHistory.forEach((item, index) => {
							// 如果当前搜索内容在历史记录中存在，不进行本地存储
							if (item == val) {
								isAdd = false;
							}
						})
						if (isAdd) {
							arr = [
								val,
								...that.searchHistory
							]
							save(arr)
						}
					} else {
						arr.push(val)
						save(arr)
					}
					
					// 保存当前搜索关键词
					that.searchkeyWord = that.searchText = val;
					// 记录当前选项卡索引
					that.searchTabIndex = that.tabCurrentIndex;
					// 搜索新数据时，重置标签数据，并初始化标签
					// this.tabBars[this.tabCurrentIndex].loadMoreStatus = 0;
					// this.tabBars[this.tabCurrentIndex].isLastPage = false;
					// this.tabBars[this.tabCurrentIndex].data = [];
					that.tabBars = [];
					that.loadTabbars();
					
					this.loadNewsList('add');
				} else {
					uni.showToast({
						title: '请输入要查询的内容',
						icon: 'none'
					})
				}
				
				function save (arr) {
					try {
						uni.setStorageSync('searchHistory', arr);
						that.searchHistory = arr;
						console.log('已保存：', that.searchHistory);
					} catch (e) {
						// error
						console.log(e);
					}
				}
			},
			
			// 点击历史记录
			clickHistory: function (item) {
				that.searchText = item;
				that.confirm();
			},
			// 清除搜索历史
			clearHistory: function () {
				uni.removeStorage({
					key: 'searchHistory',
					success: function (res) {
						console.log('搜索历史清除成功');
						that.searchHistory = [];
					}
				});
			},
			
			
			// 直播详情
			openLive: function (e) {
				// console.log('传递参数：', e);return;
				// matchState：比赛状态 0正常 1延期 2时间待定	↓
				if (e.matchLiveSourceDOS.length <= 0 || e.matchState != 0) {
					let msg = '';
					switch (e.matchState){
						case 1:
						case 2:
							msg = e.matchIntroduction
							break;
						default:
							msg = '当前项没有直播源'
							break;
					}
					uni.showToast({
						icon: 'none',
						title: msg
					})
				} else {
					// #ifdef APP-PLUS
					this.uniSkip.navigateTo({
						url: '/pages/index/player',
						data: {
							matchId:e.matchId,
							livePlatform:this.livePlatform
						}
					});
					// #endif					
					// #ifndef APP-PLUS
					uni.navigateTo({
						url: '/pages/index/player?matchId=' + e.matchId + '&livePlatform=' + this.livePlatform
						// url: '/pages/index/player?matchId=' + e.matchId
					})
				// #endif
				}
			},
			
			// 进入录像详情/视频详情
			navToVideo: function (type,item) {
				if (type) {
					this.openVideo(item.matchId)
					// uni.navigateTo({
					// 	url: '/pages/lx/lxDetail?matchId='+ item.matchId +'&viedoType='+ 0
					// });
				} else {
					uni.navigateTo({
						url: '/pages/video/vDetail?id=' + item.id + '&muted=' + false
					})
				}
			},
			
			// 进入录像详情页
			// 判断对象是否存在某个字段：obj.hasOwnProperty("key")
			openVideo: function (matchId) {
				// #ifdef APP-PLUS
				this.uniSkip.navigateTo({
					url: '/pages/index/player',
					data: {
						matchId:matchId,
						tabIndex:3
					}
				});
				// #endif					
				// #ifndef APP-PLUS
				uni.navigateTo({
					// url: 'lxDetail?matchId='+ matchId +'&viedoType='+ 0
					url: '/pages/index/player?matchId='+ matchId +'&tabIndex='+ 3
				});
				// #endif
			},
			
			// 进入新闻详情
			navToNews: function (id) {
				uni.navigateTo({
					url: '/pages/news/detail?id='+id
				})
			},
			
			// 进入电视详情
			// playTv: function (id) {
			playTv: function (id, name) {
				/* uni.navigateTo({
					url: '/pages/tv/playTv-iframe?id='+id
				}) */
				
				// #ifdef APP-PLUS
				this.uniSkip.navigateTo({
					url: '/pages/tv/playTv-iframe',
					data: {
						id:id,
						name:name
					}
				});
				// #endif					
				// #ifndef APP-PLUS
				uni.navigateTo({
					// url: '/pages/tv/playTv?id='+id
					url: '/pages/tv/playTv-iframe?id='+id+'&name='+name
				})
				// #endif
				
			},
			
			// 综合 查看更多(标签切换)
			readMore: function (index) {
				that.tabCurrentIndex = index;
			},
			
			
			
			// #ifdef H5
			
			// 播放视频
			playVideo(item, index) {
				console.log(item, index);
				this.videoCurrentIndex = index;
				this.$forceUpdate()
			},
			// 视频观看计数（视频项信息、视频项下标、标签类型(0 综合，1 视频)）
			calculationNum: function (item, index, type) {
				let tabItem = this.tabBars[this.tabCurrentIndex];
				// console.log(tabItem.data[index].isPlayed);
				if (item.isPlayed) {
					console.log('视频已播放');
				} else {
					console.log('视频未播放');
					
					if (type === 1) {
						// 修改视频播放状态
						tabItem.data[index].isPlayed = true;
						// 修改视频播放次数
						tabItem.data[index].playNumber++;
					} else {
						tabItem.data.sportMatchLiveDOS[index].isPlayed = true;
						tabItem.data.sportMatchLiveDOS[index].playNumber++;
					}
					
					this.$forceUpdate();
					
					let datas = {
						"liveId": item.id
					}
					this.$req.reqc.queryLiveContent(datas, {noToken: true})
					.then(res => {
						/* if (res.data.resultCode === 1 && res.statusCode === 200) {
							let livePlayNumber = res.data.data.livePlayNumber;
							// 修改视频播放状态
							tabItem.data[index].isPlayed = true;
							// 修改视频播放次数
							tabItem.data[index].playNumber = livePlayNumber;
							// 二维数组 开启强制渲染
							this.$forceUpdate();
						} */
					})
				}
			},
			// 播放源格式
			getVideoType(url) {
				/*匹配路径以什么结尾*/
				let index = url.lastIndexOf("\."),
				str = url.substring((index+1),url.url),
				str2 = url.match('[^.]+(?!.*.)')[0],
				type;
				
				switch (str2){
					case 'm3u8':
						type = 'application/x-mpegURL';
					break;
				case 'mp4':
						type = 'video/mp4';
					break;	
				default:
						type = 'application/x-mpegURL';
					break;
				}
				return type;
			},
			
			// #endif
			
			
			
			//tab切换
			async changeTab(e){
				if(scrollTimer){
					//多次切换只执行最后一次
					clearTimeout(scrollTimer);
					scrollTimer = false;
				}
				let index = e;
				//e=number为点击切换，e=object为swiper滑动切换
				if(typeof e === 'object'){
					index = e.detail.current
					// console.log('视频标签切换');
					this.videoCurrentIndex = -1; // 隐藏播放器
				}
				if(typeof tabBar !== 'object'){
					tabBar = await this.getElSize("nav-bar")
				}
				//计算宽度相关
				let tabBarScrollLeft = tabBar.scrollLeft;
				let width = 0; 
				let nowWidth = 0;
				//获取可滑动总宽度
				for (let i = 0; i <= index; i++) {
					let result = await this.getElSize('tab' + i);
					width += result.width;
					if(i === index){
						nowWidth = result.width;
					}
				}
				if(typeof e === 'number'){
					//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
					this.tabCurrentIndex = index; 
				}
				//延迟300ms,等待swiper动画结束再修改tabbar
				
				scrollTimer = setTimeout(()=>{
					if (width - nowWidth/2 > windowWidth / 2) {
						//如果当前项越过中心点，将其放在屏幕中心
						this.scrollLeft = width - nowWidth/2 - windowWidth / 2;
					}else{
						this.scrollLeft = 0;
					}
					if(typeof e === 'object'){
						this.tabCurrentIndex = index; 
					}
					this.tabCurrentIndex = index; 
					
					
					// 第一次切换tab，动画结束后需要加载数据(tabItem.loaded：判断是否已加载)
					let tabItem = this.tabBars[this.tabCurrentIndex];
					// if(this.tabCurrentIndex !== 0 && tabItem.loaded !== true && that.searchText != '' && that.searchText != null){
					if(this.tabCurrentIndex !== that.searchTabIndex && tabItem.loaded !== true && that.searchText != '' && that.searchText != null){
						this.loadNewsList('add');
						tabItem.loaded = true;
					}
				}, 300)
				
			},
			//获得元素的size
			getElSize(id) {
				return new Promise((res, rej) => {
					let el = uni.createSelectorQuery().select('#' + id);
					el.fields({
						size: true,
						scrollOffset: true,
						rect: true
					}, (data) => {
						res(data);
					}).exec();
				});
			},
			
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			},
			
			// 回到上一页
			backButton: function() {
				// uni.navigateBack({ delta: 1 })
				if (that.searchStatus === 1) {
					that.searchStatus = 0;
					that.searchText = ''
				} else {
					let page = getCurrentPages();
					if(page.length < 2){
						// #ifdef H5
						window.history.back()
						// #endif
						// #ifndef H5
						uni.navigateBack();
						// #endif
					} else {
						uni.navigateBack();
					}
				}
			},
		},
		// 过滤器
		filters: {
			// (直播)时间截取
			CaptureTime: function (str) {
				// return str.trim().split(/\s+/)[1];
				let time = str.trim().split(/\s+/)[1];
				let hour = time.split(/:/)[0] + ':' + time.split(/:/)[1]
				return hour;
			},
			// (新闻)时间截取
			filtersTime: function(value) {
				if (value) {
					// 这里以 -，:，空格 来拆分字符串
					let time = value.split(/[-: ]/); // ["2019", "12", "04", "17", "00", "00"]
					if (that.currentDay == time[2]) {
						time = time[3] + ':' + time[4]
					} else{
						time = time[0] + '-' + time[1] + '-' + time[2] + '\xa0' + time[3] + ':' + time[4]
					}
					// console.log('截取时间：',time);
					return time;
				}
			},
			// (录像)转换比赛时间
			getCovTime: function (times) {
				if (typeof times == "string") {
					let time = times.trim().split(/\s+|:|-/g);
					return time[1] + '-' + time[2];
				}
				else {
					return times;
				}
			},
			// (录像)获取组合标题
			getCombinationTitle: function (item) {
				let date, title, topLine, bottomLine;
				// 日期
				let time = item.matchBeginTime.trim().split(/\s+|:|-/g);
				date = time[1] + '-' + time[2];
				if (item.homeTeamName != '' && item.homeTeamName != null && item.guestTeamName != '' && item.guestTeamName != null) {
					// 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题
					if (item.eventTypeName == '' || item.eventTypeName == null) {
						title = item.specialName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle
					} else if (item.eventTypeName == '其他') {
						title = item.eventName + (item.matchTitle == '' || item.matchTitle == null ? '' : ' ') + item.matchTitle
					} else {
						title = item.eventTypeName + item.matchTitle
					}
					// topLine = "<div class='typeName'>"+ date + '&emsp;' + title +"</div>"
					topLine = "<div class='typeName'>"+ title +"</div>"
					bottomLine = "<div class='matchTitle'>"+ item.homeTeamName + ' - ' + item.guestTeamName +"</div>"
				}
				else {
					title = (item.eventTypeName == '' || item.eventTypeName == null) ? item.specialName : (item.eventTypeName == '其他' ? item.eventName : item.eventTypeName)
					topLine = "<div class='typeName'>"+ title +"</div>"
					bottomLine = "<div class='matchTitle'>"+ item.matchTitle +"</div>"
				}
				// js空格符：'\xa0'
				return topLine + bottomLine
			},
		}
	}
</script>

<style lang='scss' scoped>
	
	page, .container{
		/* #ifdef H5 */
		height: 100%;
		/* #endif */
		/* #ifndef H5 */
		height: 100vh;
		/* #endif */
		overflow: hidden;
		background-color: #F7F7F7;
	}
	
	/* 头部导航栏 */
	.header-wrap {
		width: 100%;
		
		/* #ifdef H5 */
		height: 88rpx;
		/* #endif */
		
		/* #ifndef H5 */
		height: calc(88rpx + var(--status-bar-height));
		padding-top: var(--status-bar-height);
		/* #endif */
		
		background-color: #1B1B30;
		display: flex;
		justify-content: space-between;
		align-items: center;
		
		.comeBack {
			width: 80rpx;
			height: 100%;
			background-size: cover;
			background-size: 40rpx 40rpx;
			background-position:center center;
			background-repeat: no-repeat;
			background-image: url(../../static/images/video_back_w.png);
		}
		.uni-input {
			height: 56rpx;
			line-height: 28rpx;
			padding: 0;
			border-radius: 28rpx;
			font-size: 13px;
			padding-left: 80rpx;
			position: relative;
			
			.uni-input-placeholder {
				color: #999999;
			}
		}
		.uni-input:before{
			content: '';
			/* background: #F5F5F5 url(../../static/images/nav_search.png) no-repeat; */
			background: url(../../static/images/nav_search.png) no-repeat;
			background-size: cover;
			position: absolute;
			top: 50%;
			left: 15px;
			transform: translateY(-50%);
			width: 22px;
			height: 22px;
			/* display: inline-block;
			margin-right: 28rpx;
			vertical-align: middle;
			margin-top: -2px; */
		}
		.search {
			width: 176rpx;
			text-align: center;
			font-size: 15px;
			color: #FFFFFF;
		}
	}
	
	
	/* 综合 */
	.zh-main {
		background-color: #F7F7F7;
		
		.module {
			background-color: #FFFFFF;
			margin-bottom: 44rpx;
			
			&:last-child {
				margin-bottom: 0;
			}
		}
		.moduleTitle, .viewMore, .noMore {
			height: 80rpx;
			line-height: 80rpx;
			box-sizing: border-box;
			font-size: 14px;
			color: #999999;
			border-bottom: 1px solid #F2F2F2;
		}
		.moduleTitle {
			padding-left: 44rpx;
		}
		.viewMore {
			text-align: center;
			
			&:after {
				content: '';
				background-image: url(../../static/images/order_right.png);
				background-size: cover;
				background-repeat: no-repeat;
				/* background-color: red; */
				/* background-position: center center; */
				width: 30rpx;
				height: 30rpx;
				display: inline-block;
				margin-left: 12rpx;
				vertical-align: middle;
				margin-top: -4px;
			}
			/* :before 选择器在被选元素的内容前面插入内容 */
			/* &:before {} */
		}
		
		.noMore {
			text-align: center;
		}
	}
	/* 综合 无数据 */
	.zhNoMore {
		display: flex;
		align-items: center;
		justify-content: center;
		height: 45px;
		padding-top: 5px;
		color: #888888;
	}
	
	
	/* 直播 */
	.live-main{
		/* padding-bottom: 88rpx; */
		
		/* 赛事日期 */
		.matchDate {
			height: 58rpx;
			line-height: 58rpx;
			text-align: center;
			font-size: 13px;
			font-weight: bold;
			background-color: #F7F7F7;
			position: relative;
		}
		
		/* 列表项 */
		.list-item {
			display: flex;
			flex-direction: column;
			/* height: 226rpx; */
			max-height: 246rpx;
			box-sizing: border-box;
			/* padding: 0 106rpx; */
			padding-bottom: 20rpx;
			/* border-bottom: 1px solid #F2F2F2; */
			border-bottom: 1px solid #EDEDED;
			overflow: hidden;
			position: relative;
			
			/* 标题 */
			.gameTitle {
				margin: 0 106rpx;
				text-align: center;
				height: 55rpx;
				
				.time, .matchTitle {
					font-size: 11px;
				}
				.time {
					position: absolute;
					top: 5px;
					left: 10px;
				}
				.matchTitle {
					margin-top: 14rpx;
					line-height: 30rpx;
					
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					/* 文本内容超出1行 显示省略符 */
					-webkit-line-clamp: 1;
					-webkit-box-orient: vertical;
				}
			}
			/* 比赛信息 */
			.gameInfo {
				display: flex;
				align-items: center;
				justify-content: space-between;
				min-height: 88rpx;
				padding: 0 80rpx;
				
				image {
					width: 88rpx;
					height: 88rpx;
					border-radius: 50%;
				}
				.leftTeam, .rightTeam {
					display: flex;
					flex-direction: column;
					align-items: center;
					/* 赋值宽度，使中间按钮在flex布局下始终保持在中间 */
					width: 200rpx;
				}
				.teamName {
					width: 200rpx;
					height: 40rpx;
					line-height: 40rpx;
					text-align: center;
					font-size: 12px;
					overflow: hidden;
				}
				.liveBtn {
					min-width: 150rpx;
					max-width: 150rpx;
					height: 44rpx;
					line-height: 44rpx;
					/* margin-bottom: 20rpx; */
					text-align: center;
					font-size: 11px;
					color: #FFFFFF;
					border-radius: 25rpx;
					background-color: #1B1B30;
				}
				.disable {
					background-color: #CCCCCC;
				}
			}
			.prompt {
				margin: 0 106rpx;
				text-align: center;
				font-size: 10px;
				line-height: 14px;
				color: #666666;
				/* 超出宽度后就隐藏 */
				overflow: hidden;
				/* 规定段落中的文本不换行 */
				white-space:nowrap;
				/* 当文本内容溢出时显示省略标记 */
				text-overflow: ellipsis;
			}
		}
	}
	
	
	/* 录像 */
	.lx-main {
		display: flex;
		flex-direction: column;
		width: 100%;
		padding: 0 20rpx;
		/* padding-bottom: 88rpx; */
		
		/* 列表项 */
		.list-item {
			display: flex;
			align-items: center;
			height: 88rpx;
			border-bottom: 1px solid #E1E1E1;
			overflow: hidden;
			
			.eventLogo {
				min-width: 60rpx;
				max-width: 60rpx;
				height: 60rpx;
				/*min-width: 16px;
				height: 16px; */
				display: block;
				/* margin-right: 28rpx; */
			}
			
			.time {
				min-width: 90rpx;
				max-width: 90rpx;
				text-align: center;
				font-size: 11px;
				color: #999999;
			}
			
			/deep/.content {
				height: 100%;
				display: flex;
				flex-direction: column;
				justify-content: center;
				
				.typeName {
					height: 30rpx;
					line-height: 30rpx;
					font-size: 11px;
					color: #999999;
				}
				.matchTitle {
					height: 40rpx;
					line-height: 40rpx;
					font-size: 14px;
					font-family: PingFang SC;
					font-weight: 500;
				}
				.typeName, .matchTitle {
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					/* 文本内容超出1行 显示省略符 */
					-webkit-line-clamp: 1;
					-webkit-box-orient: vertical;
				}
			}
			/* .content:before{
				content: '';
				background: #F5F5F5 url(../../static/sport/basketball.png) no-repeat;
				background-size: cover;
				width: 16px;
				height: 16px;
				display: inline-block;
				margin-right: 28rpx;
				vertical-align: middle;
				margin-top: -2px;
			} */
		}
	}
	
	
	/* 视频 */
	.video-main {
		padding: 0 20rpx;
		/* padding-bottom: 88rpx; */
		
		/* 视频项 */
		.list-item {
			/* #ifdef H5 */
			height: 602rpx;
			/* #endif */
			/* #ifndef H5 */
			height: 546rpx;
			/* #endif */
			margin: 12rpx 0;
			border-radius: 10rpx;
			box-shadow: 3px 2px 4px rgba(0, 0, 0, .2);
			overflow: hidden;
			position: relative;
			
			.videoInfo {
				width: 100%;
				/* #ifdef H5 */
				height: 546rpx;
				/* #endif */
				/* #ifndef H5 */
				height: 480rpx;
				/* #endif */
				position: relative;
				/* 封面图 */
				.item-cover{
					width: 100%;
					height: 480rpx;
					background-color: #000000;
				}
				
				/* 播放器 */
				.videoBox {
					width: 100%;
					height: 480rpx;
				}
				
				/* 标题 */
				.item-title{
					/* #ifndef H5 */
					position: absolute;
					top: 0;
					/* #endif */
					width: 100%;
					height: 66rpx;
					line-height: 66rpx;
					padding-left: 17rpx;
					background-color: rgba(27,27,48,.9);
					font-size: 15px;
					color: #FFFFFF;
					z-index: 99999;
					/* 超出1行时，隐藏并显示省略符 */
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 1; /* 行数控制 */
					-webkit-box-orient: vertical;
				}
				/* 播放按钮 */
				.playBtn {
					position: absolute;
					top: 55%;
					left: 50%;
					transform: translate(-50%,-50%);
					width: 160rpx;
					height: 160rpx;
					/* background-color: rgba(0,0,0,.2); */
					border-radius: 50%;
					background-size: cover;
					background-image: url(../../static/images/playButton.png);
				}
			}
			/* 底部栏 */
			.bottomBar {
				display: flex;
				justify-content: space-between;
				align-items: center;
				width: 100%;
				height: 66rpx;
				box-sizing: border-box;
				padding: 0 24rpx;
				.views, .comments {
					display: flex;
					align-items: center;
				}
				.icon {
					height: 22rpx;
					background-size: cover;
				}
				.text {
					font-size: 11px;
					color: #666666;
					margin-left: 10rpx;
				}
				.views{
					.icon {
						/* 宽高比：(w)30 / (h)20 = 1.5 */
						width: 36rpx;
						height: 24rpx;
						background-size: 90% 90%;
						background-repeat: no-repeat;
						/* background-position: center; */
						background-image: url(../../static/images/video_eye.png);
					}
				}
				.comments{
					.icon {
						width: 24rpx;
						background-image: url(../../static/images/video_comment.png);
					}
				}
			}
		}
	}
	
	
	/* 新闻 */
	.news-main {
		/* padding-bottom: 88rpx; */
		
		.list-item {
			display: flex;
			align-items: center;
			height: 184rpx;
			padding: 0 20rpx;
			overflow: hidden;
			/* background-color: #FFFFFF; */
			border-bottom: 1px solid #E1E1E1;
			
			image {
				min-width: 210rpx;
				max-width: 210rpx;
				height: 136rpx;
				border-radius: 6rpx;
				margin-right: 20rpx;
				display: block;
			}
			.right-view {
				height: 136rpx;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
			}
			.bottom {
				display: flex;
				align-items: center;
				justify-content: space-between;
				line-height: 26rpx;
				font-size: 11px;
				color: #676767;
				
				/* 评论图标 */
				.rightComment {
					display: flex;
					flex-direction: row;
					align-items: center;
					
					.commentIcon {
						width: 24rpx;
						height: 22rpx;
						background-size: cover;
						background-image: url(../../static/images/video_comment.png);
					}
					
					.commentNum {
						font-size: 11px;
						color: #676767;
						margin-left: 10rpx;
					}
				}
			}
			.title{
				font-size: 13px;
				line-height: 38rpx;
			}
		}
	}
	
	
	/* 电视 */
	.tv-main {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		width: 100%;
		padding: 0 20rpx;
		/* padding-bottom: 88rpx; */
		
		/* 父级加上after伪类，解决最后一排数量不够两端分布的情况(仅三列布局适用) */
		&:after{
			content: '';
			width: 200rpx;
		}
		
		/* 列表项 */
		.list-item {
			width: 200rpx;
			height: 200rpx;
			line-height: 26rpx;
			margin: 20rpx 0;
			padding: 10rpx 16rpx 0 16rpx;
			border-radius: 10rpx;
			box-shadow: 0 0 10px rgba(0, 0, 0, .2);
			overflow: hidden;
			text-align: center;
			background-color: #FFFFFF;
			
			.imgLog {
				min-height: 110rpx;
				max-height: 110rpx;
			}
			
			.title {
				font-size: 13px;
				line-height: 36rpx;
			}
		}
	}
	
	
	/* 搜索历史(初始页面状态) */
	.initial {
		padding: 0 20rpx;
		display: flex;
		flex-wrap: wrap;
		color: #666666;
		
		.top {
			width: 100%;
			display: flex;
			justify-content: space-between;
			margin: 26rpx 16rpx;
			font-size: 13px;
		}
		.item {
			padding: 0 42rpx;
			margin: 0 16rpx 24rpx 16rpx;
			height: 44rpx;
			border-radius: 22rpx;
			background-color: #EDEDED;
			font-size: 13px;
		}
	}
	
	
	/* 顶部tabbar */
	.nav-bar{
		position: relative;
		z-index: 10;
		height: 90rpx;
		white-space: nowrap;
		box-sizing: border-box;
		/* box-shadow: 0 2upx 8upx rgba(0,0,0,.06); */
		border-bottom: 1px solid #F2F2F2;
		background-color: #FFFFFF;
		.nav-item{
			display: inline-block;
			width: 125rpx;
			/* width: 150upx; */
			height: 90upx;
			text-align: center;
			line-height: 90upx;
			font-size: 30upx;
			color: #999999;
			position: relative;
			/* &:after{
				content: '';
				width: 0;
				height: 0;
				border-bottom: 4upx solid #007aff;
				position: absolute;
				left: 50%;
				bottom: 0;
				transform: translateX(-50%);
				transition: .3s;
			} */
		}
		.current{
			color: #1B1B30;
			/* &:after{
				width: 50%;
			} */
		}
	}

	.swiper-box {
		height: 100%;
	}
	
	.panel-scroll-box {
		/* #ifdef H5 */
		height: 100%;
		/* #endif */
		/* #ifndef H5 */
		height: calc(100vh - 90rpx - 88rpx - var(--status-bar-height));
		/* #endif */
		
		background-color: #FFFFFF;
	}
	
</style>
