<template>
	<view class="container">
		<!-- <scroll-view scroll-y="true" > -->
		<view class="subhead">
			已选择<text>可长按并拖拽调整顺序</text>
			<!-- 已选择<text></text> -->
		</view>
		
		<view class="selected immobile">
			<block v-for="(item,index) in immobileArr" :key="index">
				<view  class="item">
					<view class="title">{{item.name}}</view>
				</view>
			</block>
		</view>
		
		<HM-dragSorts :list="selTagArr" @confirm="confirm" @TapsetEvent="setEvent"></HM-dragSorts>
		
		
		
		<!-- <movable-area class="selected drag-sort" :style="{height: selTagArrLength + 'px'}" id="drag"></movable-area> -->
		<!-- <view class="selected">
			<block v-for="(item,index) in selTagArr" :key="index">
				<view  class="item">
					<view class="leftBox">
						<view @tap="setEvent(item,index,false)" :class="[index > 0 ? 'round lIcon' : '']"></view>
						<view class="title">{{item.name}}</view>
					</view>
					<view class="sortBtn" v-if="index > 0"></view>
				</view>
			</block>
		</view> -->
		
		<view class="subhead">未选择</view>
		<view class="unselected">
			<block v-for="(item,index) in unSelTagArr" :key="index">
				<view  class="item">
					<view class="leftBox">
						<view class="title">{{item.name}}</view>
					</view>
					<view @tap="setEvent(item,index,true)" class="round rIcon"></view>
				</view>
			</block>
		</view>
		<!-- </scroll-view> -->
	</view> 
</template>


<script>
	import dragSorts from '@/components/HM-dragSorts/HM-dragSorts.vue'
	export default {
		components: {
			'HM-dragSorts': dragSorts
		},
		data() {
			return {
				pageType: 1,
				eventList:[], // 本地存储全部标签
				immobileArr: [], // 固定标签
				selTagArr: [], // 已选中标签
				unSelTagArr: [], // 未选中标签
				mergeArr: [], // 合并后数据
				height: 44, // 高度
				
				/* list: [{
						"name": "花呗", //必填，名称
						"icon": "/static/img/1.png", //选填，不填则不显示图标
					},
					{
						"name": "余额宝",
						"icon": "/static/img/2.png"
					},
					{
						"name": "账户余额",
						"icon": "/static/img/3.png"
					},
					{
						"name": "交通银行信用卡(0001)",
						"icon": "/static/img/4.png"
					},
					{
						"name": "中国建设银行信用卡(4401)",
						"icon": "/static/img/5.png"
					},
					{
						"name": "网商储蓄卡(7223)",
						"icon": "/static/img/6.png"
					}
				] */
			}
		},
		onLoad: function (op) {
			let that = this;
			// console.log(JSON.parse(op.data));
			let data = JSON.parse(decodeURIComponent(op.data)),
				nodata = JSON.parse(decodeURIComponent(op.nodata));
			that.pageType = op.pageType;
			// that.eventList = data;
			// data.forEach((item,index)=> {
			// 	item.data = [];
			// })
			
			// (排序前) 数组拆分
			data.forEach((item, index) => {
				if (item.type == "5") {
					// 添加到固定数组，并删除列表对应项
					this.immobileArr.push(item);
					
					data.splice(index, 1);
				}
			})
			
			that.selTagArr = data
			that.unSelTagArr = nodata;
			// console.log("已选中",JSON.stringify(that.selTagArr))
			console.log("页面类型："+op.pageType );
			console.log("未选中",JSON.stringify(that.unSelTagArr))
			// nodata
			// data.forEach((item,index) => {
			// 		if (item.sort < 20) {
			// 			// console.log(item);
			// 			that.selTagArr.push(item)
			// 		}else{
			// 			that.unSelTagArr.push(item)
			// 		}
			// })
			// that.selTagArr = data;
			// uni.getStorage({
			// 	key: 'eventList',
			// 	success: function (res) {
			// 		console.log("全部标签数据：",res.data);
			// 		that.eventList = res.data;
			// 		that.eventList.forEach((item, index) => {
			// 			if (item.sortNum != null) {
			// 				// console.log(item);
			// 				that.selTagArr.push(item)
			// 			}
			// 		})
			// 		console.log(that.selTagArr.length, that.selTagArr);
			// 	}
			// });
		},
		computed: {
			selTagArrLength (){
				return this.selTagArr.length * this.height
			}
		},
		methods: {
			confirm(e) {
				console.log("e: " + JSON.stringify(e.list));
				this.selTagArr = e.list;
				this.setPageData();
			},
			
			setPageData() {
				// (排序后) 数组合并
				// console.log('合并前',this.selTagArr);
				this.mergeArr = [...this.immobileArr, ...this.selTagArr]
				// console.log('合并后',this.mergeArr);
				
				// 首页/视频/新闻 页面
				let temp = {
					selTagArr: this.mergeArr,
					unSelTagArr: this.unSelTagArr,
				}
				console.log(this.pageType);
				switch (parseInt(this.pageType)){
					case 1:
						uni.$emit('setIndexEventList',temp);
						break;
					case 2:
						uni.$emit('setLxEventList',temp);
						break;
					case 3:
						uni.$emit('setVideoEventList',temp);
						break;
					case 4:
						uni.$emit('setNewsEventList',temp);
						break;
					case 5:
						// uni.$emit('setEventList',temp);
						break;
					default:
						break;
				}
				
				// 触发标签更新事件
				// uni.$emit('setEventList',temp);
				//由上面的打印，显而易见，e里面的list，就是返回来的排序过的数据
			},
			
			// 根据"sortNum"进行数组排序
			// that.selTagArr.sort(that.compare('sortNum'));
			// 数组对象比较函数
			compare: function (type) {
				return function(m,n){
					let a = m[type];
					let b = n[type];
					return a - b; // 升序，(b-a：降序)
				}
			},
			setEvent(item,index,type){
				console.log("准备修改的item"+JSON.stringify(item))
				console.log("准备修改！"+index + '++++++++++++++++++++' + type);
				let that = this;
				if(type){
						// that.selTagArr.push(that.unSelTagArr[index]);
						that.selTagArr.push(item);
						that.unSelTagArr.splice(index,1);
				}else{
						// that.unSelTagArr.push(that.selTagArr[index]);
						that.unSelTagArr.push(item);
						that.selTagArr.splice(index,1);
				}
				that.$forceUpdate();
				// uni.setStorage({
				//     key: 'eventList',
				//     data: that.eventList
				// });
				this.$nextTick(function(){
					that.setPageData();
				})
			}
			
		}
		
	}
</script>

<style lang="scss" scoped>
	.container {
		flex: 1;
		flex-direction: column;
		// align-items: center;
		// justify-content: center;
		overflow: hidden;
		background-color: #F7F7F7;
		///* #ifdef H5 */
		// height: 100%;
		// /* #endif */
		// /* #ifndef H5 */
		// height: 100vh;
		// /* #endif */
	}
	
	.container {
		color: #000000;
	}
	/* 副标题 */
	.subhead {
		height: 58rpx;
		line-height: 58rpx;
		padding-left: 38rpx;
		font-size: 13px;
		text {
			font-size: 11px;
			color: #999999;
			margin-left: 14rpx;
		}
	}
	/* 列表 */
	.selected, .unselected {
		box-sizing: border-box;
		padding-left: 20rpx;
		background-color: #FFFFFF;
			
		.item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 88rpx;
			box-sizing: border-box;
			border-bottom: 1px solid #E8E8E8;
			/* 左侧框 */
			.leftBox {
				display: flex;
				align-items: center;
				.title {
					font-size: 15px;
				}
			}
			/* 排序按钮 */
			.sortBtn {
				width: 80rpx;
				height: 80%;
				// width: 38rpx;
				// height: 22rpx;
				background-size: 38rpx 22rpx;
				background-position: center;
				background-image: url(../../static/images/custom_sort.png);
				background-repeat: no-repeat;
				border: 1px solid red;
			}
			/* 圆形图标 */
			.round {
				width: 38rpx;
				height: 38rpx;
				background-size: cover;
			}
			.lIcon {
				margin-right: 17rpx;
				background-image: url(../../static/images/custom_remove.png);
			}
			.rIcon {
				margin-right: 20rpx;
				background-image: url(../../static/images/custom_add.png);
			}
		}
	}
	
	/* 固定列表 */
	.immobile {
		.item {
			border: 0;
			border-bottom: 0.5px #c8c7cb solid;
			
		}
		.title {
			font-size: 13px;
		}
	}
</style>
