<template>
	<view class="container">
		<!-- 比赛详情 -->
		<view class="main">
			<view class="matchInfo">
				<view class="teamInfo">
					<image :src="liveData.homeTeamLogoPath"></image>
					<text class="teamName">{{liveData.homeTeamName}}</text>
				</view>
				<!-- <view class="middle" v-if="liveData.liveInfo.length > 0"> -->
				<view class="middle" v-if="LiveSourceNum > 0">
					<view class="matchStatus">已开赛</view>
					<view class="vs">VS</view>
					<view class="liveVideo" v-if="upState === 1" @tap="viewLive">观看直播</view>
					<view class="initialize" v-if="upState === 0"></view>
				</view>
				<view class="middle" v-else>
					<view class="matchStatus">未开赛</view>
					<view class="vs">VS</view>
				</view>
				<view class="teamInfo">
					<image :src="liveData.guestTeamLogoPath"></image>
					<text class="teamName">{{liveData.guestTeamName}}</text>
				</view>
			</view>
			<view class="likeBox">
				<!-- 主队：1，客队：2 -->
				<view class="likeItem" :class="support === 1 ? 'active' : ''" @tap="liveZan(1)">
					<view class="zanIcon"></view>
					<text>{{HLikes}}</text>
				</view>
				<view class="likeItem" :class="support === 2 ? 'active' : ''" @tap="liveZan(2)">
					<view class="zanIcon"></view>
					<text>{{GLikes}}</text>
				</view>
			</view>
			<view class="scaleBar">
				<view class="left" :style="{width: ''+ HWidth +'', backgroundColor: ''+(support === 1 ? '#FF8400' : '#1B1B30')+''}"></view>
				<view class="right" :style="{width: ''+ GWidth +'', backgroundColor: ''+(support === 2 ? '#FF8400' : '#1B1B30')+''}"></view>
			</view>
		</view>
		<!-- 聊天内容 -->
		<!-- ,'height':solHeight + 'px' -->
		<scroll-view  :style="[{'top':listTopHeight + 'px'}]" class="msg-list" scroll-y="true" :scroll-with-animation="scrollAnimation" :scroll-into-view="scrollToView" @scroll="toScroll" upper-threshold="50">
		<view class="chatBox">
			
				<view class="chatItem"
				v-for="(item,index) in msgList" :key="index" :id="item.msgId">
					<block v-if="userId == item.userId">
						<view class="flex1 itemInfo">
							<view class="nickName right">{{item.nickName}}</view>
							<view class="right-view">
								<view class="sendMsg right"><text>{{item.content}}</text></view>
							</view>
						</view>
						<image v-if="item.icon" class="avatar" :src="item.icon"></image>
						<image v-else class="avatar" src="../../static/assets/user_default.png"></image>
					</block>
					<block v-else>
						<image v-if="item.icon" class="avatar" :src="item.icon"></image>
						<image v-else class="avatar" src="../../static/assets/user_default.png"></image>
						<view class="itemInfo">
							<view class="nickName">{{item.nickName}}</view>
							<view class="sendMsg">{{item.content}}</view>
						</view>
					</block>
				</view>
		</view>
		</scroll-view>
		<!-- 输入框 -->
		<view class="inputBox" @tap="toSpeak" v-if="isChatRoom">
			<input class="multiline uni-input"  disabled="true" @focus="focusTextArea" @blur="bindTextArea" v-model="textMsg" value="" placeholder="点击发言" @input="MonitorIn" placeholder-style="color: #999999;" :class="[bindStyle ? (submitBtn ? 'notNull' : 'bindBg') : '']" />
			<view class="submit" v-if="submitBtn" @tap="sendText">提交</view>
		</view>
	</view>
</template>

<script>
	import strophe from '@/node_modules/strophe.js/src/strophe.js'
	var that;
	export default {
		data() {
			return {
				liveData: [],
				LiveSourceNum: 0, // 直播源数，0：未开赛、!=0：已开赛
				upState: 1, // 直播按钮状态，0：加载中，1：可用
				support: 0, // 点赞队伍
				HWidth: 0, // 主队宽度
				GWidth: 0, // 客队宽度
				HLikes: 0,
				GLikes: 0,
				bindStyle: false,
				submitBtn: false,
				textMsg:'',	//输入框
				connection :null ,	//xmpp链接
				connected : false,	//链接状态
				typeMessage1:1,
				bosh:'',
				roomService:'',
				email:'',				
				password:'',		//密码
				historyUrl:'',
				nickname:'',		//昵称
				atName:'',
				isVisitor:true,
				mtBackArray:[],
				imageUrl:'',		//用户头像
				msgList:[],			//消息数组
				delMarks:[],
				preLastMsgTime:0,
				userId:'',				//用户uid
				scrollToView:'',	//滚动到消息的id
				scrollAnimation:false,
				listTopHeight:0,
				scrollBottom:true,
				heartSec:0,
				sendSec:0,
				heartInterval:null,
				inPage:false,
				isFirst:true,
				unReadCounts:0,
				solHeight:0,
				stanzaId:0,		//历史记录id（最后一条）
				inputbottom:0,
				isChatRoom:true,
			}
		},
		onLoad: function (option) {
			that = this;
			try {
			    let value = uni.getStorageSync('user');
			    if (value) {
			        console.log("本地缓存数据",value);
							that.userId = value.userId;
							that.imageUrl = value.imageUrl;
			    }
			} catch (e) {
			    // error
			}
			
			// this.liveData = JSON.parse(option.data);
			// console.log(this.liveData,'直播聊天室数据')
			let mid = JSON.parse(option.mid)
			// console.log(JSON.parse(option.mid))
			let datas = {
				"matchId": mid
			}
			this.$req.reqc.queryMatchById(datas)
			.then(res => {
				if (res.statusCode === 200 && res.data.resultCode === 1) {
					// console.log(res.data.data);
					let val = res.data.data;
					let tempData = {
						liveId: val.matchId,
						matchTitle: val.matchTitle,
						homeTeamLogoPath: val.homeTeamLogoPath != null ? ('https://images.weserv.nl/?url='+val.homeTeamLogoPath) : '../../static/assets/teamLogo_default.png',
						homeTeamName: val.homeTeamName,
						guestTeamLogoPath: val.guestTeamLogoPath != null ? ('https://images.weserv.nl/?url='+val.guestTeamLogoPath) : '../../static/assets/teamLogo_default.png',
						guestTeamName: val.guestTeamName,
						liveInfo: val.matchLiveSourceDOS
					}
					that.liveData = tempData;
					that.LiveSourceNum = tempData.liveInfo.length;
					console.log('0：未开赛、!=0：已开赛，直播源数：',that.LiveSourceNum);

					
					// 设置状态栏标题
					uni.setNavigationBarTitle({
						title: that.liveData.matchTitle == '' || that.liveData.matchTitle == null ? '常规赛' : that.liveData.matchTitle
					});
					
					// 查询直播点赞
					that.queryMatchLike();
					
					/* let pass = false;
					for (let i = 0; i < that.liveData.liveInfo.length; i++) {
						// valid："0" → 有效链接，valid = 1 :初始化直播源，
						console.log('0：有效链接、1：初始化直播源，valid = ',that.liveData.liveInfo[i].valid)
						if (that.liveData.liveInfo[i].valid == "1") {
							console.log('------------初始化直播源------------')
							pass = true;
							that.upState = 0;
							// this.$forceUpdate() //二维数组，开启强制渲染
						}
					}
					if (pass) {
						let datas = {
							"matchId": that.liveData.liveId
						}
						console.log('赛事初始化参数：',datas);
						// ***初始化直播源
						that.$req.reqc.initMatchLiveSource(datas)
						.then(res => {
							// console.log("列表",res.data.matchLiveSourceList)
							that.liveData.liveInfo = res.data.matchLiveSourceList
							console.log("直播源列表已更新：",that.liveData.liveInfo)
							that.upState = 1;
						})
					} */
					
					
					// that.getqueryMatch();
					that.getaddChatRoom();
					
					uni.getSystemInfo({
						success: (e) => {
							let h = e.screenHeight;
							that.solHeight = h - 101 + 44;
						}
					})
					// that.$mysocket.connectserver(that.liveData.liveId);
					
					
				}
			})
		},
		onShow() {
			// that.inPage = true
			// that.toHeartInterval()
		},
		onHide() {
			// that.inPage = false
		},
		onUnload() {
			that.setPreLastMsgTime(new Date().getTime())
			if(that.connection) {
				that.connection.disconnect("退出聊天室");
			}
		},
		methods: {
			setmsg(val){
				that.textMsg = val;
				that.sendText();
			},
			toSpeak(e){
				uni.navigateTo({
					url:'/pages/index/speak'
				})
			},
			/*获取历史消息*/
			getHistory(hideLoading) {
				let msgId
				let stanzaId = 0
				if(this.msgList.length>0) {
					msgId = this.msgList[0].msgId
					stanzaId = this.msgList[0].stanzaId
				}
				uni.request({
					url: that.historyUrl,
					method: 'GET',
					data: {
						count:20,
						stanzaId:that.stanzaId,
					},
					header: {
					'custom-header': 'hello' //自定义请求头信息
					},
					success: res => {
						console.log("历史记录：",res)
						
						if(res.data && res.data.length>0) {
							let dataArray = that.bindMsgList(res.data)
							// console.log("返回数组",dataArray);
							that.msgList.splice(0,0,...dataArray)
							
							that.$nextTick(function() {
								if(msgId) {
									that.scrollToView = msgId
								}else {
									that.scrollToBottom()
								}
								that.$nextTick(function() {
									that.scrollAnimation = true
								})
							})
							
							// console.log("返回后的数组",that.msgList)
						}else {
							if(!hideLoading) {
								uni.showToast({
									title:'加載完成',
									icon:'none'
								})
							}
						}
					},
					fail: () => {},
					complete: () => {}
				});
				
				
			},
			bindMsgList(historyMsg) {
				let dataArray = []
				historyMsg.forEach(function(item,index) {
					let msg = that.parseMsg(that.string2XML(item).children[0])
					// console.log("消息：",msg);
					if(msg) {
						let msgContent = msg.content
						if(msgContent.indexOf(that.atName)!=-1) {
							// 拿最上层的msgId   (that.msgList.length==0 && index==0):排除如果是在底部的
							if(msg.timeTs>that.preLastMsgTime && !(that.msgList.length==0 && index==0)) {
								that.atMsgId = msg.msgId
							}
						}
						dataArray.unshift(msg)
					}
				})
				return dataArray
			},
			string2XML(xmlString) {
				var parser = new DOMParser();
				var xmlObject = parser.parseFromString(xmlString, "text/xml");
				return xmlObject;
			},
			setPreLastMsgTime(ts) {
				if(that.userId) {
					uni.setStorage({
						key:that.getLastMsgTimeKey(),
						data:ts
					})
				}
			},
			/*发送消息*/
			sendText(){
				if(that.connected) {
						let mtext = this.textMsg.trim().replace(new RegExp('\n', 'gm'), '<br/>');
						
						if(mtext) {
							let hcObject = {
								// roles:that.roles,
								uid:that.userId,
								nn:that.nickname,
								fmt:that.typeMessage1,
								xmlns:"hc:client"
							}
							if(that.imageUrl) {
								hcObject['icon'] = that.imageUrl
							}
							// if(that.userProfessorTitle) {
							// 	hcObject['upt'] = JSON.stringify(that.userProfessorTitle)
							// }
							
							// crypto.requestChatEncrypt(mtext)
							var msg = strophe.$msg({
								to: that.roomService, 
								from: that.email, 
								type: "groupchat",
								id:that.uuid(5,16)
							}).c("body", null, mtext).c("hc", hcObject);
							that.connection.send(msg.tree())
							that.textMsg = ''
							that.sendSec = 0
						}else {
							uni.showToast({
								title:'發送內容不能為空',
								icon:'none'
							})
						}
				}else {
					that.getRoomDetailError()
				}
			},
			
			getqueryMatch(){
				that.$req.req.queryMatch({matchId:parseInt(that.liveData.liveId)})
				// that.$req.req.chratChatRoom({roomId:that.liveData.liveId})
				.then(res => {
					console.log("查询赛事结果",res);
					
				})
				
			},
			getaddChatRoom(){
				that.$req.req.addChatRoom({
					roomId:parseInt(that.liveData.liveId),
					userId:that.userId||'',
					count:50,
					stanzaId:0,
				})
				// that.$req.req.chratChatRoom({roomId:that.liveData.liveId})
				.then(res => {
					console.log("获取结果",JSON.stringify(res));
					let resp = res.data.data;
					if(resp) {
						that.isChatRoom = true;
						that.bosh = resp.bosh
						that.roomService = resp.roomService
						that.email = resp.email
						that.password = resp.password
						that.historyUrl = resp.historyUrl
						that.nickname = resp.nickname
						that.isVisitor = resp.isVisitor
						that.atName = '@'+resp.nickname
						that.mtBackArray = resp.mt.toString().split(",")
						that.toConnectLiveRoom()
					}else {
						that.getRoomDetailError(res.data.resultMsg)
					}
					
				})
			},
			toConnectLiveRoom() {
				if(!that.connected) {
					uni.showToast({
						title:'正在連接...',
						icon:'none'
					})
					that.getPreLastMsgTime()
					that.msgList.splice(0, that.msgList.length)
					if(!that.connection) {
						that.connection = new strophe.Strophe.Connection(that.bosh)
					}
					that.connection.connect(that.email, that.password, that.onConnect)
				}
			},
			getRoomDetailError(msg) {
				that.isChatRoom = false;
				uni.showToast({
					title:msg||'加入失败',
					icon:'none'
				})
				return;
				uni.showModal({
					title:'提示',
					cancelText:'取消',
					confirmText:'刷新',
					content:msg||'加入失败',
					success:function(res){
						if(res.confirm) {
							that.getaddChatRoom()
						}else {
							// uni.navigateBack({
							// 	delta:1
							// })
						}
					}
				})
			},
			getPreLastMsgTime() {
				if(that.userId) {
					try{
						let preLastMsgTime = uni.getStorageSync(that.getLastMsgTimeKey())
						if(preLastMsgTime) {
							that.preLastMsgTime = preLastMsgTime
						}
					}catch(e){}
				}
			},
			getLastMsgTimeKey() {
				return that.roomId+'_'+that.userId
			},
			/*链接状态*/
			onConnect(status) {
				switch(status) {
					case Strophe.Status.ERROR:
						console.log('ERROR')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'链接错误',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
						
					case Strophe.Status.CONNECTING:
						console.log('链接中。。。')
						break;
					
					case Strophe.Status.CONNFAIL:
						console.log('链接失败。。')
						that.connected = false
						break;
						
					case Strophe.Status.AUTHENTICATING:
						console.log("正在授權");
						break;
						
					case Strophe.Status.AUTHFAIL:
						console.log('身份验证失败')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'授权失败或账号在其他地方登录',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									// uni.navigateBack({
									// 	delta:1
									// })
								}
							}
						})
						break;
						
					case Strophe.Status.CONNECTED:
						console.log("連接成功");
						that.connectSuccess();
						break;
						
					case Strophe.Status.DISCONNECTED:
						console.log('链接断开')
						that.connected = false
						break;
						
					case Strophe.Status.DISCONNECTING:
						console.log("斷開連接中");
						break;
						
					case Strophe.Status.ATTACHED:
						console.log("連接已附加");
						break;
						
					case Strophe.Status.REDIRECT:
						console.log('REDIRECT')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'链接被拒绝',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
						
					case Strophe.Status.CONNTIMEOUT:
						console.log('链接超时。。。')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'聊天室链接超时',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									// uni.navigateBack({
									// 	delta:1
									// })
								}
							}
						})
						break;
				}
			},
			onMessage(msg) {
				console.log("消息",msg);
				console.log(msg.parentNode.innerHTML)
				var resultMsg = this.parseMsg(msg)
				console.log(resultMsg);
				if(resultMsg) {
					console.log("添加消息")
					that.bindMsg(resultMsg)
					if(resultMsg.userId == 0 && resultMsg.content == '关闭聊天室'){
						that.isChatRoom = false;
						that.setPreLastMsgTime(new Date().getTime())
						if(that.connection) {
							that.connection.disconnect("退出聊天室");
						}
						that.getRoomDetailError('聊天室已关闭');
						// uni.showToast({
						// 	title:'',
						// 	icon:'none'
						// })
						// return false;
					}
				}
				return true
			},
			bindMsg(msg) {
				// if(msg.delMsg==that.isDelete) {
				// 	const delContent = msg.content
				// 	if(that.delMarks.indexOf(delContent)==-1) {
				// 		that.delMarks.push(delContent)
				// 	}
				// }else if(that.mtBackArray.indexOf(msg.bmt)!=-1 || that.mtFrontArray.indexOf(msg.fmt)!=-1) {
					// console.log("消息带入数组");
					let msgContent = msg.content
					if(msgContent.indexOf(that.atName)!=-1) {
						msg.content = msgContent.replace(new RegExp(that.atName, 'gm'), "<text style=\"color:#F0AD4E;margin-right: 8px;\">"+that.atName+"</text>")
						// 拿at的上一個id
						if(!that.atMsgId && this.msgList.length>0 && msg.timeTs>that.preLastMsgTime) {
							that.atMsgId = that.msgList[that.msgList.length-1].msgId
						}
					}
					// console.log("msg",msg);
					that.msgList.push(msg)
					
					if(that.scrollBottom || msg.userId==that.userId) {
						// console.log("滚动");
						that.$nextTick(function() {
							that.scrollToBottom();
							that.$nextTick(function() {
								that.scrollAnimation = true
							})
						})
					}else {
						that.unReadCounts++
					}
					
				// }
			},
			connectSuccess() {
				if(that.connection) {
					if(that.msgList.length > 0){
						that.msgList.splice(0,that.msgList.length)
					}
					if(that.delMarks.length > 0){
						that.delMarks.splice(0,that.delMarks.length)
					}
					
					that.connected = true;
					try{
						that.getHistory(true)
					}catch(e){
						//TODO handle the exception
					}
					
					
					
					that.connection.addHandler(that.onMessage, null, 'message');
					that.connection.send(strophe.$pres().tree());
					
					var pres = strophe.$pres({
						from: that.email,
						to: that.roomService + "/" + that.email.substring(0,that.email.indexOf("@"))
					}).c('x',{xmlns: 'http://jabber.org/protocol/muc'}).c("history", {
						maxchars:0
					}).tree()
					that.connection.send(pres)
					
					setTimeout(function() {
						uni.showToast({
							title:'加入聊天室成功',
							icon:'none'
						})
					}, 500)
				}
			},
			sendmsg(){
				// 创建一个<message>元素并发送
				var msg = $msg({
				    to: toJid, 
				    from: fromJid, 
				    type: 'chat'
				}).c("body", null, that.textMsg);
				that.connection.send(msg.tree());
			},
			scrollToBottom() {
				if(this.msgList.length>0) {
					const msgId = this.msgList[this.msgList.length-1].msgId
					this.scrollToView = msgId
					console.log(this.scrollToView);
				}
			},
			toScroll(e) {
				let eDetail = e.detail
				const h = eDetail.scrollHeight-eDetail.scrollTop-that.scrollViewHeight
				if(h>that.distanceBottomMaxHeight) {
					that.scrollBottom = false
				}else {
					that.scrollBottom = true
				}
				if(h<10) {
					that.unReadCounts = 0
				}
			},
			// 显示视频源
			viewLive: function () {
				let liveObj = {
					nameArr: [],
					pathArr: [],
					ways: [], // "1"：嵌套新页面，"0"：打开播放链接
					valid: [], // 是否重新解析 0：否，1：是
					sidArr: [] // 播放源id
				}
				// console.log(this.liveData.liveInfo);return;
				this.liveData.liveInfo.forEach(item=>{
					console.log(item);
					// console.log(item.analysisPlayPathPc, item.analysisPlayPathWeb, item.notAnalysisPlayPath);
					// 播放平台不能为空
					if (item.livePlatform == null) {
						return;
					}
					let arr = JSON.parse(item.livePlatform);
					/* * 
					 * livePlatform：播放平台(0:pc、1:安卓、2:苹果、3:h5)
					 * isAnalysis： 0：解析(analysisPlayPathWeb、analysisPlayPathPc)，1：不解析(notAnalysisPlayPath)
					 * */
					// livePlatform 对长度为1，且值为0 和直播源名称为空 的链接进行过滤 ↓
					if ((arr.length > 1 || (arr.length == 1 && arr[0] != 0)) && item.liveSourceName != '' && item.liveSourceName != null) 
					{
						// 播放地址不能为空
						if (liveObj.pathArr.push != '' && liveObj.pathArr.push != null) {
						// if (item.analysisPlayPathPc != null || item.analysisPlayPathWeb != null || item.notAnalysisPlayPath != null) {
							liveObj.nameArr.push(item.liveSourceName)
							// console.log('播放方式解析标识',item.isAnalysis);
							// 1、匹配播放地址(0：解析，1：不解析)
							if (item.isAnalysis == 0) {
								// 2、播放平台判断，不同平台匹配不同链接(未完成)
								liveObj.pathArr.push(item.analysisPlayPathWeb)
							}
							if (item.isAnalysis == 1) {
								liveObj.pathArr.push(item.notAnalysisPlayPath)
							}
							liveObj.ways.push(item.isAnalysis)
							liveObj.valid.push(item.valid)
							liveObj.sidArr.push(item.sourceId)
						}
					}
				})
				if (liveObj.pathArr.length <= 0) {
					uni.showToast({
						title: '没有匹配的播放链接',
						icon: 'none'
					})
					return false;
				}
				// 显示播放菜单
				uni.showActionSheet({
					itemList: liveObj.nameArr,
					success: function (val) {
						// console.log('选中了第' + (val.tapIndex + 1) + '个按钮');
						// console.log(liveObj.pathArr[val.tapIndex]);return;
						let temp = {
							path: liveObj.pathArr[val.tapIndex],
							name: liveObj.nameArr[val.tapIndex],
							ways: liveObj.ways[val.tapIndex],
							valid: liveObj.valid[val.tapIndex],
							sourceId: liveObj.sidArr[val.tapIndex]
						}
						// console.log(temp.path);
						// if (temp.path == null || temp.path == '') {
						// 	uni.showToast({
						// 		icon: 'none',
						// 		title: '当前播放源不可用'
						// 	})
						// 	return;
						// }
						
						// 判断是否重新解析播放源(0：不解析，1：解析)
						if (temp.valid == 1) {
							uni.showLoading({
								title: '请稍后...'
							})
							let datas = {
								"sourcePathId": temp.sourceId
							}
							console.log('解析直播源参数(id)：',datas);
							// 解析直播源
							that.$req.reqc.analysisMatchLiveSource(datas)
							.then(res => {
								uni.hideLoading();
								if (res.data.resultCode === 1 && res.statusCode == 200) {
									console.log("列表已更新", res.data.data)
									// 解析成功后 修改 当前播放源的 解析标识(→ 0：不解析)
									that.liveData.liveInfo.forEach(item => {
										if (temp.sourceId === item.sourceId) {
											item.valid = '0'
										}
									})
									
									let item = res.data.data, newPath;
									// 1、匹配播放地址(0：解析，1：不解析)
									if (item.isAnalysis == 0) {
										// 2、播放平台判断，不同平台匹配不同链接(未完成)
										newPath = item.analysisPlayPathWeb
									}
									if (item.isAnalysis == 1) {
										newPath = item.notAnalysisPlayPath
									}
									
									if (newPath == '' || newPath == null) {
										uni.showToast({
											icon: 'none',
											title: '当前播放源不可用'
										})
										return;
									}
									let val = {
										matchId: that.liveData.liveId,
										sourceId: temp.sourceId,
										sourcePath: newPath,
										usable: 1
									}
									uni.navigateTo({
										url: '/pages/webview/webview?data=' + encodeURIComponent(JSON.stringify(val))
									})
								}
								else if (res.data.resultCode !== 1 && res.statusCode == 200) {
									uni.showToast({
										icon: 'none',
										title: res.data.resultMsg,
									})
								}
							})
						}
						else {
							console.log('直播源id：',temp.sourceId);
							// 匹配播放地址(0：解析(使用播放器播放)，1：不解析(外部网址 跳转到webview并传递链接))
							// if (temp.ways == 1) {
								console.log(`/pages/webview/webview?url=${temp.path}`);
								if (temp.path == '' || temp.path == null) {
									uni.showToast({
										icon: 'none',
										title: '当前播放源不可用'
									})
									return;
								}
								let val = {
									matchId: that.liveData.liveId,
									sourceId: temp.sourceId,
									sourcePath: temp.path,
									usable: 1
								}
								uni.navigateTo({
									url: '/pages/webview/webview?data=' + encodeURIComponent(JSON.stringify(val))
								})
							/* } else {
								console.log('/pages/index/liveStudio?data=' + encodeURIComponent(JSON.stringify(temp)));
								uni.navigateTo({
									url: '/pages/index/liveStudio?data=' + encodeURIComponent(JSON.stringify(temp))
								})
							} */
						}
						
					},
					fail: function (res) {
						console.log(res.errMsg);
					}
				});
			},
			// 输入框聚焦
			focusTextArea: function (e) {
				console.log(e);
				
				this.bindStyle = true;
				this.inputbottom = e.detail.height;
			},
			// 输入框失去焦点
			bindTextArea: function (e) {
				// console.log(e.detail.value,"长度："+e.detail.value.length)
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				// console.log(val)
				// 注释：indexOf() 方法对大小写敏感！
				// 注释：如果要检索的字符串值没有出现，则该方法返回 -1
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.bindStyle = false;
					this.submitBtn = false;
				}
			},
			// 输入监听
			MonitorIn: function (e) {
				var val = e.detail.value.replace(/(^\s*)|(\s*$)/g, "");
				// console.log(val)
				if (val != '' && val != null) {
					this.submitBtn = true;
				} else {
					this.submitBtn = false;
				}
			},
			
			// 查询直播点赞
			queryMatchLike: function () {
				let datas = {
					"matchId": this.liveData.liveId,
				}
				// console.log(datas);return;
				this.$req.reqc.queryMatchLike(datas)
				.then( res => {
					this.support = res.data.data.likeType
					this.HLikes = res.data.data.homeTeamCount
					this.GLikes = res.data.data.visitingTeamCount
					let total = this.HLikes + this.GLikes;
					// console.log(this.HLikes, this.GLikes, total);
					if (total) {
						this.HWidth = this.HLikes / total * 100 + '%'
						this.GWidth = this.GLikes / total * 100 + '%'
						this.$forceUpdate() //二维数组，开启强制渲染
					} else{
						return
					}
					console.log(this.HWidth, this.GWidth);
				})
			},
			
			// 直播点赞
			liveZan: function (team) {
				let datas = {
					"matchId": this.liveData.liveId,
					"typeId": team // 主队：1，客队：2
				}
				// console.log(datas);return;
				this.$req.reqc.createMatchLike(datas)
				.then( res => {
					if (res.statusCode === 200) {
						let msg = '成功'
						switch (res.data.resultCode){
							case 1:
								msg = '已为该队伍助力'
								break;
							default:
								msg = res.data.resultMsg
								break;
						}
						uni.showToast({
							icon: 'none',
							title: msg
						})
						this.queryMatchLike();
					} else {
						uni.showToast({
							icon: 'none',
							title: '请稍后再试！'
						})
					}
				})
			},
			parseMsg(msg) {
				try{
					if(msg.children.length==1 && msg.getElementsByTagName("body").length>0) {
						console.log("有body");
						var tipContent = strophe.Strophe.getText(msg.getElementsByTagName("body")[0]).replace(/'/g, "\"");
						if(tipContent && tipContent!=this.$COMMON.CHAT_ROOM_HEART_PONG) {
							var msgContent = {
								msgId:that.uuid(5,16),
								fmt:that.typeMessage3,
								center:that.messageCenterYes,
								content:tipContent
							}
							return msgContent;
						}
					}else {
						var typeMsg = msg.getAttribute("type");
						console.log(typeMsg)
						if(typeMsg=="groupchat") {
							var bodyEles = msg.getElementsByTagName("body");
							// console.log("bodyEles",bodyEles);
							if(bodyEles.length>0) {
								// var content = crypto.resultChatDecrypt(strophe.Strophe.getText(bodyEles[0])).replace(/'/g, "\"");
								var content = strophe.Strophe.getText(bodyEles[0]).replace(/'/g, "\"");
								var msgName = "";
								var roles = "";
								var ut = "";
								var iconUrl = "";
								var userId = "";
								var admin = "";
								var reject = "";
								var hidden = "";
								var center = "";
								var delMsg = "";
								var fmt = "";
								var bmt = "";
								var ir = "";
								var userProfessorTitle = null;
								var timeTs = 0
								var msgId = msg.getAttribute("id")
								
								var hcEles = msg.getElementsByTagName("hc");
								if(hcEles.length>0) {
									var hcEle = hcEles[0];
									msgName = hcEle.getAttribute("nn");
									userId = hcEle.getAttribute("uid");
									roles = hcEle.getAttribute("roles");
									ut = hcEle.getAttribute("ut");
									iconUrl = hcEle.getAttribute("icon");
									admin = hcEle.getAttribute("admin");
									reject = hcEle.getAttribute("reject");
									hidden = hcEle.getAttribute("hidden");
									center = hcEle.getAttribute("center");
									delMsg = hcEle.getAttribute("delMsg");
									fmt = hcEle.getAttribute("fmt");
									bmt = hcEle.getAttribute("mt");
									ir = hcEle.getAttribute("ir");
									timeTs = hcEle.getAttribute("ts");
									const upt = hcEle.getAttribute("upt")
									if(upt) {
										userProfessorTitle = JSON.parse(upt)
									}
									if(timeTs) {
										timeTs = parseInt(timeTs)
									}else {
										var delayEles = msg.getElementsByTagName("delay");
										if(delayEles.length>0) {
											var delayValue = delayEles[0].getAttribute("stamp");
											timeTs = new Date(delayValue).getTime();
										}
									}
								}
								
								
								var stanzaId = ""
								var stanzaIdEles = msg.getElementsByTagName("stanza-id");
								if(stanzaIdEles && stanzaIdEles.length>0) {
									stanzaId = stanzaIdEles[0].getAttribute("id");
								}
								
								if(content) {
									let redpacketId
									if(content.indexOf("[==红包==:")!=-1) {
										redpacketId = content.split(":")[1].split("]")[0]
									}else if((that.roomId!=that.room_id_lh && that.chatroomInfos[that.room_id_lh] && content.indexOf(that.room_flag_lh)!=-1) || (that.roomId!=that.room_id_ssc && that.chatroomInfos[that.room_id_ssc] && content.indexOf(that.room_flag_ssc)!=-1)) {
										content = "<text style=\"color: #3498db;\">"+content+"</text>";
									}
									content = content.replace(/0.12rem/g,'26rpx')
									
									return {
										nickName: msgName,
										content: that.escape2Html(content),
										timeTs: timeTs,
										roles: roles,
										icon: iconUrl,
										userId: userId,
										msgId: msgId,
										ut:ut,
										admin:admin,
										reject:reject,
										hidden:hidden,
										center:center,
										delMsg:delMsg,
										fmt:fmt,
										bmt:bmt,
										ir:ir,
										stanzaId:stanzaId,
										redpacketId:redpacketId,
										upt:userProfessorTitle
									}
								}
							}
						}else{
							
							
						}
					}
				}catch(e) {}
			},
			escape2Html(str) {
				var arrEntities={'lt':'<','gt':'>','nbsp':' ','amp':'&','quot':'"'};
				return str.replace(/&(lt|gt|nbsp|amp|quot);/ig,function(all,t){return arrEntities[t];});
			},
			uuid(len, radix) {
			    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
			    var uuid = [], i;
			    radix = radix || chars.length;
			 
			    if (len) {
					for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
			    } else {
					var r;
					uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
					uuid[14] = '4';
					for (i = 0; i < 36; i++) {
						if (!uuid[i]) {
						  r = 0 | Math.random()*16;
						  uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
						}
					}
				}
			    return 'msg'+uuid.join('');
			},
		}
	}
</script>

<style lang="scss" scoped>
	
	.msg-list{
		height: calc(100vh - 202rpx - 88rpx);
		margin-top: 202rpx;
	}
	
	.container {
		flex: 1;
		flex-direction: column;
		// align-items: center;
		// justify-content: center;
		overflow: hidden;
		background-color: #F7F7F7;
		height: 100vh;
		position: relative;
	}
	
	.container {
		color: #000000;
	}
	/* 比赛信息 */
	.main {
		position: relative;
		position: fixed;
		
		/* #ifdef APP-PLUS */
			top: 0;
		/* #endif */
		
		/* #ifdef H5 */
			top: 88rpx;
		/* #endif */
		
		z-index: 100;
		width: 100vw;
		height: 202rpx;
		overflow: hidden;
		background-color: #FFFFFF;
		/* 比赛信息 */
		.matchInfo {
			display: flex;
			justify-content: space-between;
			height: 160rpx;
			box-sizing: border-box;
			padding: 0 106rpx;
			
			image {
				width: 88rpx;
				height: 88rpx;
				border-radius: 50%;
				margin: 18rpx 0 9rpx 0;
			}
			.teamInfo {
				display: flex;
				flex-direction: column;
				align-items: center;
				.teamName {
					width: 120rpx;
					height: 40rpx;
					line-height: 40rpx;
					text-align: center;
					font-size: 12px;
					
					/* 超出1行时，隐藏并显示省略符 */
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 1; /* 行数控制 */
					-webkit-box-orient: vertical;
				}
			}
			.middle {
				display: flex;
				flex-direction: column;
				align-items: center;
				color: #666666;
				.matchStatus {
					font-size: 11px;
					margin-top: 10rpx;
				}
				.vs {
					font-size: 18px;
					margin: 2rpx 0;
				}
				.liveVideo {
					width: 118rpx;
					height: 40rpx;
					line-height: 40rpx;
					text-align: center;
					border-radius: 20rpx;
					background-color: #1B1B30;
					font-size: 10px;
					color: #FFFFFF;
				}
				/* 等待播放列表初始化 */
				.initialize {
					width: 40rpx;
					height: 40rpx;
					background-size: cover;
					background-image: url(../../static/loading.gif);
				}
			}
		}
		/* 点赞图标 */
		.likeBox{
			display: flex;
			justify-content: space-between;
			padding: 0 20rpx;
			.likeItem {
				display: flex;
				align-items: center;
				font-size: 11px;
				color: #1B1B30;
				.zanIcon{
					width: 28rpx;
					height: 28rpx;
					background-size: cover;
					background-image: url(../../static/images/ld_Zan.png);
					margin: 0 10rpx 10rpx 0;
				}
			}
			.active{
				color: #FF8400;
				.zanIcon {
					background-image: url(../../static/images/ld_activeZan.png);
				}
			}
		}
		
		/* 点赞比率条 */
		.scaleBar {
			position: absolute;
			bottom: 0;
			width: 100%;
			height: 8rpx;
			background-color: #EEEEEE;
			display: flex;
			justify-content: space-between;
			.left, .right {
				height: 8rpx;
			}
			.left {
				// width: 65%;
				// background-color: #FF8400;
			}
			.right {
				// width: 35%;
				// background-color: #1B1B30;
			}
		}
	}

	/* 聊天内容 */
	.chatBox{
		/* 202rpx 比赛信息框高度 */
		padding: 20rpx 20rpx 88rpx 20rpx;
		min-height: calc(100vh - 202rpx - 88rpx - 44rpx) ;
		/* 聊天项 */
		.chatItem{
			display: flex;
			margin-bottom: 20rpx;
			.right{
				text-align: right;
			}
			.right-view{
				display: flex;
				justify-content: flex-end;
			}
			.avatar{
				width: 80rpx;
				height: 80rpx;
				min-width: 80rpx;
				min-height: 80rpx;
				border-radius: 50%;
			}
			.itemInfo{
				flex: 1;
				margin-left: 14rpx;
				.nickName{
					font-size: 11px;
					color: #1E95DC;
					margin-bottom: 6rpx;
				}
				.sendMsg{
					width: fit-content;
					min-height: 56rpx;
					line-height: 56rpx;
					border-radius: 8rpx;
					box-sizing: border-box;
					padding: 0 14rpx;
					font-size: 14px;
					background-color: #FFFFFF;
					border: 1px solid #C3C3C3;
					word-wrap:break-word;
					/* 超出3行时，隐藏并显示省略符 */
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 3; /* 行数控制 */
					-webkit-box-orient: vertical;
					
				}
			}
		}
	}
	
	/* 文本框 */
	.inputBox {
		// width: 100vw;
		width: 100%;
		min-height: 88rpx;
		box-sizing: border-box;
		padding: 14rpx 0;
		background-color: #FFFFFF;
		// border-top: 1px solid #EAEAEA;
		// position: relative;
		position: fixed;
		// position: absolute;
		bottom: 0;
		
		.multiline {
			padding: 0px;
			margin: 0px;
			box-sizing: border-box;
			width: auto;
			height: 60rpx;
			margin: 0 20rpx;
			padding: 12rpx 26rpx;
			border-radius: 30rpx;
			background-color: #F7F7F7;
			font-size: 14px;
			color: #999999;
		}
		/* 文本框聚焦样式 */
		.bindBg, .notNull {
			padding: 10rpx 24rpx;
			border: 1px solid #1B1B30;
			background-color: #FFFFFF;
			// margin: 0 120rpx 0 20rpx;
		}
		/* 文本框内容不为空时样式 */
		.notNull {
			margin: 0 120rpx 0 20rpx;
		}
		/* 提交按钮 */
		.submit {
			position: absolute;
			top: 50%;
			right: 10rpx;
			transform: translateY(-50%);
			width: 100rpx;
			height: 55rpx;
			line-height: 55rpx;
			text-align: center;
			border-radius: 4rpx;
			color: #FFFFFF;
			background-color: #1B1B30;
		}
	}
</style>
