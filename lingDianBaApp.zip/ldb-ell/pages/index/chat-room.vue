<template>
	<view>
		<cu-custom bgColor="bg-navigation" :isBack="true" :chatRoom="true" :hb="HBopen=='1'&&token" @tapHb="tapHb" @tapChatRule="tapChatRule">
			<block slot="content">{{titleName}}</block>
		</cu-custom>
		<view class="topLayout">
			<uni-notice-bar class="unb"  :scrollable="true" :text="notificationText" />
			<view class="adLayout">
				<block v-for="(item,index) in ad" :key="index">
					<view class="adView" @tap="tapAd(item)" :style="[{'color':item.fontColor}]">
						{{item.title}}
					</view>
					<view class="line" v-if="index<(ad.length-1)"></view>
				</block>
				
			</view>
		</view>
		
		<view class="content">
			<scroll-view  :style="[{'top':listTopHeight + 'px'}]" class="msg-list" scroll-y="true" 
			:scroll-with-animation="scrollAnimation" 
			:scroll-into-view="scrollToView" 
			@scroll="toScroll" 
			upper-threshold="50">
				<view class="row" v-for="(row,index) in msgList" :key="index" :id="row.msgId" v-if="delMarks.indexOf(row.stanzaId)==-1">
					<block v-if="row.center==messageCenterYes" >
						<view class="system">
							<view class="text" v-html="row.content"></view>
						</view>
					</block>
					<view class="my" v-else-if="row.userId==userId">
						<!-- 左-消息 -->
						<view class="left">
							<view class="username">
								<view class="time">{{getDateDiff(row.timeTs)}}</view>
								<view class="identity" v-if="row.upt" :style="[{'background-color':row.upt.bgColor,'color':row.upt.textColor}]">{{row.upt.title}}</view>
								<view class="identity" v-else-if="row.roles && row.roles.indexOf(r_professor)!=-1">專家</view>
								<view class="name">我</view>
							</view>
							<!-- 文字消息 -->
							<view v-if="row.redpacketId" class="bubble img" @tap="tapRedPacket(row.redpacketId)">
								<image src="/static/chat_room_hb.png" style="width: 200rpx;height: 259rpx;"></image>
							</view>
							<view v-else class="bubble" v-html="row.content">
								<!-- <rich-text :nodes="row.content"></rich-text> -->
							</view>
						</view>
						<!-- 右-头像 -->
						<view class="right">
							<image :src="imageUrl?imageUrl:iconDefault"></image>
						</view>
					</view>
					<!-- 别人发出的消息 -->
					<view class="other" :class="row.admin==isAdmin?'isAdmin':''" v-else>
						<!-- 左-头像 -->
						<view class="left">
							<image :src="row.icon?row.icon:iconDefault"></image>
						</view>
						<!-- 右-用户名称-时间-消息 -->
						<view class="right">
							<view class="username">
								<view class="name">{{row.nickName}}</view>
								<view class="identity" v-if="row.upt" :style="[{'background-color':row.upt.bgColor,'color':row.upt.textColor}]">{{row.upt.title}}</view>
								<view class="identity" v-else-if="row.roles && row.roles.indexOf(r_professor)!=-1">專家</view>
								<view class="time" style="margin-left: 20rpx;">{{getDateDiff(row.timeTs)}}</view>
							</view>
							<view v-if="row.ir==IR_FESTIVAL" class="bubble img" @tap="tapHbFQ(row)">
								<image class="iconHb" src="/static/chat_hb_festival.png"></image>
							</view>
							<view v-else-if="row.ir==IR_QW" class="bubble img" @tap="tapHbFQ(row)">
								<image class="iconHb" src="/static/chat_hb_quwei.png"></image>
							</view>
							<view v-else-if="row.redpacketId" class="bubble img" @tap="tapRedPacket(row.redpacketId)">
								<image class="iconHb" src="/static/chat_room_hb.png"></image>
							</view>
							<!-- 文字消息 -->
							<view @tap="tapContent(row)" v-else class="bubble chatText" v-html="row.content">
								<!-- <rich-text :nodes="row.content"></rich-text> -->
							</view>
						</view>
					</view>
				</view>
			</scroll-view>
			<view @tap="scrollToBottom" v-if="unReadCounts>0" style="height: 50rpx; line-height: 50rpx; text-align: center; background-color: #FDA9AD; border-radius: 25rpx; position: absolute; bottom: 0; padding: 0 10px; margin-left: 50%; -webkit-transform: translateX(-50%); -moz-transform: translateX(-50%); -ms-transform: translateX(-50%); transform: translateX(-50%);bottom: 120rpx;color: #FFFFFF;font-size: 26rpx;">您有{{unReadCounts}}條消息未讀</view>
			<view @tap="scrollToAt" v-if="atMsgId" style="height: 50rpx; line-height: 50rpx; text-align: center; background-color: #FC6066; border-radius: 25rpx; position: absolute; bottom: 120rpx; padding: 0 20rpx; right: 20rpx;color: #FFFFFF;font-size: 26rpx;">有人@我</view>
		</view>
		
		<!-- 底部输入栏 -->
		<view class="input-box">
			<view class="textbox">
				<view class="text-mode">
					<view class="box">
						<textarea auto-height="true" v-model="textMsg" @focus="scrollToBottom"/>
					</view>
				</view>
			</view>
			<view class="send" @tap="sendText">
				<view class="btn">发送</view>
			</view>
		</view>
		
		<uni-popup :ref="refHbFestival" type="center" :custom="true" :mask-click="true">
			<view class="hbFestival">
				<image @tap="closeHbFQ" class="close" src="/static/chat_hb_close.png"></image>
				<view class="title">金色節目紅包，快來搶答</view>
				<view class="question">{{hbInfo.question}}</view>
				<view class="answers">
					<view v-for="(item,index) in hbInfo.answers" :key="index" class="answer isEllipsis" :class="item.anwserId==hbInfo.answerId?'isActive':''" @tap="tapHbFQAnswer(item.anwserId)">{{answerIndex[index]}}{{item.anwser}}</view>
				</view>
			</view>
		</uni-popup>
		
		<uni-popup :ref="refHbQw" type="center" :custom="true" :mask-click="true">
			<view class="hbQw">
				<image @tap="closeHbFQ" class="close" src="/static/chat_hb_close.png"></image>
				<view class="title">趣味問答，搶紅包</view>
				<view class="question">{{hbInfo.question}}</view>
				<view class="answers">
					<view v-for="(item,index) in hbInfo.answers" :key="index" class="answer isEllipsis" :class="item.anwserId==hbInfo.answerId?'isActive':''" @tap="tapHbFQAnswer(item.anwserId)">{{answerIndex[index]}}{{item.anwser}}</view>
				</view>
			</view>
		</uni-popup>
		
	</view>
</template>
<script>
	import {mapState} from 'vuex'
	import uniNoticeBar from '@/components/uni-notice-bar/uni-notice-bar.vue'
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import strophe from '@/node_modules/strophe.js/src/strophe.js'
	import crypto from '@/common/chat-crypto.js'
	var _self
	
	export default {
		components: {
			uniNoticeBar,
			uniPopup
		},
		data() {
			return {
				//文字消息
				textMsg:'',
				scrollAnimation:false,
				scrollToView:'',
				listTopHeight:0,
				page:1,
				data:[],
				messageId:1,
				pushType1:1,
				pushType2:2,
				pushType3:3,
				kefuArray:null,
				iconDefault:'/static/touxiang_default.png',
				bosh:'',
				roomService:'',
				email:'',
				password:'',
				historyUrl:'',
				nickname:'',
				atName:'',
				connection:null,
				connected:false,
				roomId:'',
				chatroomInfos:null,
				msgList:[],
				isVisitor:true,
				typeMessage1:1,
				typeMessage2:2,
				typeMessage3:3,
				messageCenterYes:"1",
				messageCenterNo:0,
				mtFrontArray:["1","2","3"],
				mtBackArray:[],
				isAdmin:"1",
				isDelete:"1",
				isReject:"1",
				distanceBottomMaxHeight:200,
				scrollViewHeight:0,
				scrollBottom:true,
				unReadCounts:0,
				r_professor:'',
				atMsgId:'',
				delMarks:[],
				HBopen:'',
				room_id_lh:'lh',
				room_id_ssc:'ssc',
				room_flag_lh:'烈火大厅',
				room_flag_ssc:'上上城大厅',
				titleName:'',
				preLastMsgTime:0,
				heartSec:0,
				sendSec:0,
				heartInterval:null,
				inPage:false,
				isFirst:true,
				notificationText:'本聊天室只限聊碼，禁止發布任何聯繫方式和廣告，一經發現將禁言和封號！',
				ad:[],
				refHbFestival:'refHbFestival',
				refHbQw:'refHbQw',
				hbInfo:{
					question:'',
					answers:[],
					answerId:-1,
					redpacketId:'',
					ir:''
				},
				answerIndex:['A.  ','B.  ','C.  ','D.  ','E.  '],
				IR_FESTIVAL:'1',
				IR_QW:'2'
			}
		},
		computed: mapState(['imageUrl','roles','userId','token','userProfessorTitle']),
		onLoad(option) {
			_self = this
			
			const d = JSON.parse(decodeURIComponent(option.d))
			this.roomId = d.i
			this.chatroomInfos = d.d
			this.listTopHeight = this.CustomBar+uni.upx2px(100)
			this.r_professor = this.$COMMON.ROLE_PROFESSOR
			this.titleName = d.d[d.i].roomName
			this.getPreLastMsgTime()
			
			try {
			    const res = uni.getSystemInfoSync();
			    _self.scrollViewHeight = res.windowHeight-_self.CustomBar-uni.upx2px(100+100)
			} catch (e) {}
		},
		onUnload() {
			_self.setPreLastMsgTime(new Date().getTime())
			if(_self.connection) {
				_self.connection.disconnect("退出聊天室");
			}
			_self.toClearHeartInterval()
		},
		onShow() {
			_self.inPage = true
			_self.toHeartInterval()
			
			if(_self.isFirst) {
				_self.isFirst = false
			}else {  
				if(_self.isVisitor && _self.token) {
					_self.reloadPage()
				}else if(!_self.connected) {
					_self.ajaxDetail()
				}
			}
		},
		onHide() {
			_self.inPage = false
			_self.toClearHeartInterval()
		},
		created() {
			this.$nextTick(function () {
				this.ajaxText()
				this.ajaxDetail()
			})
		},
		onPullDownRefresh() {
			if(_self.connected) {
				this.scrollAnimation = false
				this.ajaxHistory()
			}else {
				this.ajaxDetail()
			}
			if(_self.ad.length==0) {
				this.ajaxText()
			}
		},
		methods:{
			closeHbFQ() {
				switch(_self.hbInfo.ir) {
					case _self.IR_FESTIVAL:
						_self.$refs[_self.refHbFestival].close()
						break;
						
					case _self.IR_QW:
						_self.$refs[_self.refHbQw].close()
						break;
				}
			},
			tapAd(item) {
				window.open(item.url)
			},
			toClearHeartInterval() {
				if(_self.heartInterval) {
					clearInterval(_self.heartInterval)
					_self.heartInterval = null
				}
			},
			toHeartInterval() {
				if(!_self.heartInterval) {
					_self.heartInterval = setInterval(function() {
						_self.heartSec++
						if(_self.heartSec%240==0 && _self.inPage && !_self.connected) {
							_self.ajaxDetail()
						}
						
						_self.sendSec++
						if(_self.sendSec%240==0 && _self.connected && _self.inPage) {
							var msg = strophe.$msg({
								to: _self.roomService, 
								from: _self.email, 
								type: "groupchat",
							}).c("body", null, crypto.requestChatEncrypt("1")).c("hc", {
								xmlns:"hc:client",
								reject:_self.isReject
							})
							_self.connection.send(msg.tree())
						}
					}, 1000)
				}
			},
			getLastMsgTimeKey() {
				return _self.roomId+'_'+_self.userId
			},
			setPreLastMsgTime(ts) {
				if(_self.userId) {
					uni.setStorage({
						key:_self.getLastMsgTimeKey(),
						data:ts
					})
				}
			},
			getPreLastMsgTime() {
				if(_self.userId) {
					try{
						let preLastMsgTime = uni.getStorageSync(_self.getLastMsgTimeKey())
						if(preLastMsgTime) {
							_self.preLastMsgTime = preLastMsgTime
						}
					}catch(e){}
				}
			},
			tapContent(row) {
				const roomId = this.roomId
				const chatroomInfos = this.chatroomInfos
				if(roomId!=_self.room_id_lh && chatroomInfos[_self.room_id_lh] && row.content.indexOf(_self.room_flag_lh)!=-1) {
					// 进入lh的
					const d = {
						d:chatroomInfos,
						i:_self.room_id_lh
					}
					uni.redirectTo({
						url:'/pages/menu/chat-room/chat-room?d='+encodeURIComponent(JSON.stringify(d))
					})
				}else if(roomId!=_self.room_id_ssc && chatroomInfos[_self.room_id_ssc] && row.content.indexOf(_self.room_flag_ssc)!=-1) {
					// 进入ssc的
					const d = {
						d:chatroomInfos,
						i:_self.room_id_ssc
					}
					uni.redirectTo({
						url:'/pages/menu/chat-room/chat-room?d='+encodeURIComponent(JSON.stringify(d))
					})
				}else if(row.roles) {
					if(_self.$util.isLogin(_self)) {
						const roles = row.roles
						let funcList = ['心水帖子','舉報']
						if(roles.indexOf(_self.r_professor)!=-1) {
							funcList = ['心水帖子','查看專家資料','打賞','舉報']
						}
						
						uni.showActionSheet({
							itemList: funcList,
							success: function (res) {
								setTimeout(function() {
									const tapIndex = res.tapIndex
									if(roles.indexOf(_self.r_professor)!=-1) {
										switch(tapIndex) {
											case 0:
												_self.ajaxPostState(row.userId,row.nickName)
												break;
												
											case 1:
												const d1 = {
													t:_self.$COMMON.EXPERT_CENTER_TYPE_1,
													i:row.userId
												}
												uni.navigateTo({
													url:'/pages/module/expert-center/expert-center?d='+encodeURIComponent(JSON.stringify(d1))
												})
												break;
												
											case 2:
												const d2 = {
													n:row.nickName,
													i:row.userId
												}
												uni.navigateTo({
													url:'/pages/module/reward-money/reward-money?d='+encodeURIComponent(JSON.stringify(d2))
												})
												break;
											
											case 3:
												_self.toReport(row)
												break;
										}
									}else {
										switch(tapIndex) {
											case 0:
												_self.ajaxPostState(row.userId,row.nickName)
												break;
												
											case 1:
												_self.toReport(row)
												break;
										}
									}
								},100)
							}
						})
					}
					console.log(JSON.stringify(row))
				}
			},
			toReport(row) {
				uni.showModal({
					title:'舉報內容',
					content:row.content,
					confirmText:'舉報',
					success(res) {
						if(res.confirm) {
							_self.ajaxReport(row.userId,row.content)
						}
					}
				})
			},
			scrollToAt() {
				if(_self.atMsgId) {
					_self.scrollToView = _self.atMsgId
					_self.atMsgId = ''
					_self.preLastMsgTime = new Date().getTime()
					_self.setPreLastMsgTime(_self.preLastMsgTime)
				}
			},
			toScroll(e) {
				let eDetail = e.detail
				const h = eDetail.scrollHeight-eDetail.scrollTop-_self.scrollViewHeight
				if(h>_self.distanceBottomMaxHeight) {
					_self.scrollBottom = false
				}else {
					_self.scrollBottom = true
				}
				if(h<10) {
					_self.unReadCounts = 0
				}
			},
			tapHbFQAnswer(answerId) {
				_self.hbInfo.answerId = answerId
				setTimeout(function() {
					switch(_self.hbInfo.ir) {
						case _self.IR_FESTIVAL:
							_self.$refs[_self.refHbFestival].close()
							break;
							
						case _self.IR_QW:
							_self.$refs[_self.refHbQw].close()
							break;
					}
					
					const d = {
						t:_self.$COMMON.CHAT_FQ_PICK_TYPE_1,
						i:_self.hbInfo.redpacketId,
						a:answerId
					}
					uni.navigateTo({
						url:'/pages/menu/chat-room/chat-fq-pick?d='+encodeURIComponent(JSON.stringify(d))
					})
					
				},200)
			},
			tapHbFQ(row) {
				if(this.$util.isLogin(this)) {
					this.ajaxHbFQ(row)
				}
			},
			tapHb() {
				if(this.$util.isLogin(this)) {
					uni.navigateTo({
						url:'/pages/menu/chat-room/chat-envelope-release?i='+this.roomId
					})
				}
			},
			tapChatRule() {
				const content = '聊友可對有違反規則的其他聊友進行舉報，點擊用戶頭像即可舉報。以下情況一經發現將直接“封號”處理。\n\n1. 禁止發佈任何性質的廣告和個人聯繫方式；\n\n2. 禁止使用帶有商業廣告、網頁廣告成份、帶個人聯繫信息的昵稱；\n\n3.不得發佈違反社會公共道德，帶有人身侵犯、攻擊、淫穢、恐怖、敵對、性別歧視、種族歧視、個人侮辱、自我侮辱、猥褻或不雅觀的內容；\n\n4.不得故意使用甚至惡意雷同仿冒管理員、或其他聊友的昵稱，禁止使用任何類似聊天系統用詞的昵稱（系統、註意、警告、公告等）；'
				uni.showModal({
					title:'聊天室規則',
					content:content,
					showCancel:false,
					confirmText:'好的'
				})
			},
			tapRedPacket(redpacketId) {
				if(_self.isVisitor) {
					_self.toRegisterPage('您與紅包的距離就差壹個註冊，馬上註冊吧！')
				}else {
					uni.navigateTo({
						url:'/pages/menu/chat-room/chat-envelope-pick?i='+redpacketId
					})
				}
			},
			getDateDiff(ts) {
				return this.$util.getDateByTs(ts)
			},
			uuid(len, radix) {
			    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
			    var uuid = [], i;
			    radix = radix || chars.length;
			 
			    if (len) {
					for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
			    } else {
					var r;
					uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
					uuid[14] = '4';
					for (i = 0; i < 36; i++) {
						if (!uuid[i]) {
						  r = 0 | Math.random()*16;
						  uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
						}
					}
				}
			    return 'msg'+uuid.join('');
			},
			toRegisterPage(content) {
				uni.showModal({
					title:'提示',
					content:content,
					confirmText:'註冊',
					success(res) {
						if(res.confirm) {
							setTimeout(function() {
								uni.navigateTo({
									url:'/pages/module/reigster/register'
								})
							},200)
						}
					}
				})
			},
			sendText(){
				if(_self.connected) {
					if(_self.isVisitor) {
						_self.toRegisterPage('您沒有發言權限，註冊為“篮球”會員即可參與互動和搶紅包')
					}else {
						let textMsg = this.textMsg.trim().replace(new RegExp('\n', 'gm'), '<br/>')
						if(textMsg) {
							let hcObject = {
								roles:_self.roles,
								uid:_self.userId,
								nn:_self.nickname,
								fmt:_self.typeMessage1,
								xmlns:"hc:client"
							}
							if(_self.imageUrl) {
								hcObject['icon'] = _self.imageUrl
							}
							if(_self.userProfessorTitle) {
								hcObject['upt'] = JSON.stringify(_self.userProfessorTitle)
							}
							
							var msg = strophe.$msg({
								to: _self.roomService, 
								from: _self.email, 
								type: "groupchat",
								id:_self.uuid(5,16)
							}).c("body", null, crypto.requestChatEncrypt(textMsg)).c("hc", hcObject);
							_self.connection.send(msg.tree())
							_self.textMsg = ''
							_self.sendSec = 0
						}else {
							uni.showToast({
								title:'發送內容不能為空',
								icon:'none'
							})
						}
					}
				}else {
					_self.getRoomDetailError()
				}
			},
			scrollToBottom() {
				if(this.msgList.length>0) {
					const msgId = this.msgList[this.msgList.length-1].msgId
					this.scrollToView = msgId
				}
			},
			getDateTsByStr(dateStr) {
				return Date.parse(dateStr.replace(/-/gi,"/"))
			},
			getMsgUuid() {
				const msgUuid = _self.messageId++
				return 'msg'+msgUuid
			},
			ajaxHbFQ(row) {
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = this.$COMMON.API.irQueryIRQuestions
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					redpacketId:row.content
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					if(dataContent) {
						_self.hbInfo.answers = dataContent['1']
						_self.hbInfo.question = dataContent.q
						_self.hbInfo.answerId = -1
						_self.hbInfo.ir = row.ir
						_self.hbInfo.redpacketId = row.content
						
						switch(row.ir) {
							case _self.IR_FESTIVAL:
								_self.$refs[_self.refHbFestival].open()
								break;
								
							case _self.IR_QW:
								_self.$refs[_self.refHbQw].open()
								break;
						}
					}
				}
				optionData[this.$COMMON.REQUEST.OPTION_CHAT_ROOM_GRAB] = function(resData) {
					const d = {
						t:_self.$COMMON.CHAT_FQ_PICK_TYPE_2,
						d:resData,
						i:row.content
					}
					uni.navigateTo({
						url:'/pages/menu/chat-room/chat-fq-pick?d='+encodeURIComponent(JSON.stringify(d))
					})
				}
				this.$util.handleRequest(optionData, this)
			},
			ajaxReport(toUserId,reportContent) {
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = this.$COMMON.API.complaintAdd
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					toUserId:toUserId,
					content:reportContent
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					uni.showToast({
						title:'已舉報',
						icon:'none'
					})
				}
				this.$util.handleRequest(optionData, this)
			},
			ajaxPostState(userId,nickName) {
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = this.$COMMON.API.bbsQueryPostState
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					userId:userId
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					if(dataContent) {
						const postId = dataContent.postId
						if(postId) {
							const d = {
								n:nickName,
								p:postId
							}
							uni.navigateTo({
								url:'/pages/menu/forum/forum-detail?d='+encodeURIComponent(JSON.stringify(d))
							})
						}else {
							uni.showToast({
								title:'該用戶還沒發佈心水帖子',
								icon:'none'
							})
						}
					}
				}
				this.$util.handleRequest(optionData, this)
			},
			ajaxText() {
				const theThis = this
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = this.$COMMON.API.textQueryText
				optionData[this.$COMMON.REQUEST.OPTION_LOADING_HIDE] = true
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					type:"100"
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					if(dataContent) {
						const contentObject = JSON.parse(dataContent.content)
						_self.HBopen = contentObject.HBopen
						_self.notificationText = contentObject.message.title
						_self.ad = contentObject.ad
					}
				}
				this.$util.handleRequest(optionData, this)
			},
			ajaxSend(msgContent) {
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = this.$COMMON.API.messageSendMessage
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					content:msgContent
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					_self.textMsg = ''
					const msgUuid = _self.getMsgUuid()
					_self.data.push({
						content:msgContent,
						pushType:_self.pushType3,
						uuid:msgUuid,
						timeText:_self.$util.getDateByTs(new Date().getTime())
					})
					_self.$nextTick(function() {
						_self.scrollToView = msgUuid
					})
				}
				this.$util.handleRequest(optionData, this)
			},
			ajaxData(uuidFlag) {
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = this.$COMMON.API.pushGetHistoryPush
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					page:this.page
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					if(_self.page==1) {
						_self.data.splice(0, _self.data.length)
					}
					if(dataContent && dataContent.length>0) {
						let dataArray = []
						dataContent.forEach(function(item) {
							item.uuid = _self.getMsgUuid()
							item.timeText = _self.$util.getDateByTs(_self.getDateTsByStr(item.pushTime))
							dataArray.splice(0,0,item)
						})
						
						_self.page++
						if(uuidFlag) {
							_self.data.splice(0,0,...dataArray)
							_self.$nextTick(function() {
								_self.scrollToView = uuidFlag
								_self.$nextTick(function() {
									_self.scrollAnimation = true;//恢复滚动动画
								})
							})
						}else {
							_self.data = _self.data.concat(dataArray)
							_self.$nextTick(function() {
								//进入页面滚动到底部
								_self.scrollToBottom()
								_self.$nextTick(function() {
									_self.scrollAnimation = true
								})
							})
						}
					}else {
						uni.showToast({
							title:'加載完成',
							icon:'none'
						})
					}
					uni.stopPullDownRefresh()
				}
				optionData[this.$COMMON.REQUEST.OPTION_ERROR] = function() {
					uni.stopPullDownRefresh()
				}
				this.$util.handleRequest(optionData, this)
			},
			toConnectLiveRoom() {
				if(!_self.connected) {
					uni.showToast({
						title:'正在連接...',
						icon:'none'
					})
					_self.getPreLastMsgTime()
					_self.msgList.splice(0, _self.msgList.length)
					if(!_self.connection) {
						_self.connection = new strophe.Strophe.Connection(_self.bosh)
					}
					_self.connection.connect(_self.email, _self.password, _self.onConnect)
				}
			},
			ajaxDetail() {
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = this.$COMMON.API.chatroomV2GetChatRoom
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					roomId:this.roomId
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					if(dataContent) {
						_self.bosh = dataContent.bosh
						_self.roomService = dataContent.roomService
						_self.email = dataContent.email
						_self.password = dataContent.password
						_self.historyUrl = dataContent.historyUrl
						_self.nickname = dataContent.nickname
						_self.isVisitor = dataContent.isVisitor
						_self.atName = '@'+dataContent.nickname
						_self.mtBackArray = dataContent.mt.toString().split(",")
						_self.toConnectLiveRoom()
					}else {
						_self.getRoomDetailError()
					}
				}
				optionData[this.$COMMON.REQUEST.OPTION_ERROR] = function() {
					_self.getRoomDetailError()
				}
				this.$util.handleRequest(optionData, this)
			},
			reloadPage() {
				const d = {
					d:_self.chatroomInfos,
					i:_self.roomId
				}
				uni.redirectTo({
					url:'/pages/menu/chat-room/chat-room?d='+encodeURIComponent(JSON.stringify(d))
				})
			},
			getRoomDetailError() {
				uni.showModal({
					title:'提示',
					cancelText:'退出',
					confirmText:'刷新',
					content:'加載聊天室數據失敗',
					success:function(res){
						if(res.confirm) {
							_self.ajaxDetail()
						}else {
							uni.navigateBack({
								delta:1
							})
						}
					}
				})
			},
			connectSuccess() {
				if(_self.connection) {
					_self.msgList.splice(0,_self.msgList.length)
					_self.delMarks.splice(0,_self.delMarks.length)
					_self.connected = true
					_self.ajaxHistory(true)
					
					_self.connection.addHandler(_self.onMessage, null, 'message');
					_self.connection.send(strophe.$pres().tree());
					
					var pres = strophe.$pres({
						from: _self.email,
						to: _self.roomService + "/" + _self.email.substring(0,_self.email.indexOf("@"))
					}).c('x',{xmlns: 'http://jabber.org/protocol/muc'}).c("history", {
						maxchars:0
					}).tree()
					_self.connection.send(pres)
					
					setTimeout(function() {
						uni.showToast({
							title:'加入聊天室成功',
							icon:'none'
						})
					}, 500)
				}
			},
			bindMsgList(historyMsg) {
				let dataArray = []
				historyMsg.forEach(function(item,index) {
					const msg = _self.parseMsg(_self.string2XML(item).children[0])
					if(msg) {
						if(msg.delMsg==_self.isDelete) {
							const delContent = msg.content
							if(_self.delMarks.indexOf(delContent)==-1) {
								_self.delMarks.push(delContent)
							}
						}else if(_self.mtBackArray.indexOf(msg.bmt)!=-1 || _self.mtFrontArray.indexOf(msg.fmt)!=-1) {
							let msgContent = msg.content
							if(msgContent.indexOf(_self.atName)!=-1) {
								msg.content = msgContent.replace(new RegExp(_self.atName, 'gm'), "<text style=\"color:#F0AD4E;margin-right: 8px;\">"+_self.atName+"</text>")
								// 拿最上层的msgId   (_self.msgList.length==0 && index==0):排除如果是在底部的
								if(msg.timeTs>_self.preLastMsgTime && !(_self.msgList.length==0 && index==0)) {
									_self.atMsgId = msg.msgId
								}
							}
							dataArray.unshift(msg)
						}
					}
				})
				return dataArray
			},
			bindMsg(msg) {
				if(msg.delMsg==_self.isDelete) {
					const delContent = msg.content
					if(_self.delMarks.indexOf(delContent)==-1) {
						_self.delMarks.push(delContent)
					}
				}else if(_self.mtBackArray.indexOf(msg.bmt)!=-1 || _self.mtFrontArray.indexOf(msg.fmt)!=-1) {
					let msgContent = msg.content
					if(msgContent.indexOf(_self.atName)!=-1) {
						msg.content = msgContent.replace(new RegExp(_self.atName, 'gm'), "<text style=\"color:#F0AD4E;margin-right: 8px;\">"+_self.atName+"</text>")
						// 拿at的上一個id
						if(!_self.atMsgId && this.msgList.length>0 && msg.timeTs>_self.preLastMsgTime) {
							_self.atMsgId = _self.msgList[_self.msgList.length-1].msgId
						}
					}
					_self.msgList.push(msg)
					
					if(_self.scrollBottom || msg.userId==_self.userId) {
						_self.$nextTick(function() {
							_self.scrollToBottom()
							_self.$nextTick(function() {
								_self.scrollAnimation = true
							})
						})
					}else {
						_self.unReadCounts++
					}
					
				}
			},
			onMessage(msg) {
				console.log(msg.parentNode.innerHTML)
				var resultMsg = this.parseMsg(msg)
				if(resultMsg) {
					_self.bindMsg(resultMsg)
				}
				return true
			},
			onConnect(status) {
				switch(status) {
					case Strophe.Status.ERROR:
						console.log('ERROR')
						_self.connected = false
						uni.showModal({
							title:'提示',
							content:'鏈接錯誤',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
						
					case Strophe.Status.CONNECTING:
						console.log('CONNECTING')
						break;
					
					case Strophe.Status.CONNFAIL:
						console.log('CONNFAIL')
						_self.connected = false
						break;
						
					case Strophe.Status.AUTHENTICATING:
						console.log("正在授權");
						break;
						
					case Strophe.Status.AUTHFAIL:
						console.log('AUTHFAIL')
						_self.connected = false
						uni.showModal({
							title:'提示',
							content:'授權失敗或賬號在其他地方登陸',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
						
					case Strophe.Status.CONNECTED:
						console.log("連接成功");
						_self.connectSuccess();
						break;
						
					case Strophe.Status.DISCONNECTED:
						console.log('DISCONNECTED')
						_self.connected = false
						break;
						
					case Strophe.Status.DISCONNECTING:
						console.log("斷開連接中");
						break;
						
					case Strophe.Status.ATTACHED:
						console.log("連接已附加");
						break;
						
					case Strophe.Status.REDIRECT:
						console.log('REDIRECT')
						_self.connected = false
						uni.showModal({
							title:'提示',
							content:'連接被拒絕',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
						
					case Strophe.Status.CONNTIMEOUT:
						console.log('CONNTIMEOUT')
						_self.connected = false
						uni.showModal({
							title:'提示',
							content:'連接超時',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
				}
			},
			string2XML(xmlString) {
				var parser = new DOMParser();
				var xmlObject = parser.parseFromString(xmlString, "text/xml");
				return xmlObject;
			},
			escape2Html(str) {
				var arrEntities={'lt':'<','gt':'>','nbsp':' ','amp':'&','quot':'"'};
				return str.replace(/&(lt|gt|nbsp|amp|quot);/ig,function(all,t){return arrEntities[t];});
			},
			parseMsg(msg) {
				try{
					if(msg.children.length==1 && msg.getElementsByTagName("body").length>0) {
						var tipContent = strophe.Strophe.getText(msg.getElementsByTagName("body")[0]).replace(/'/g, "\"");
						if(tipContent && tipContent!=this.$COMMON.CHAT_ROOM_HEART_PONG) {
							var msgContent = {
								msgId:_self.uuid(5,16),
								fmt:_self.typeMessage3,
								center:_self.messageCenterYes,
								content:tipContent
							}
							return msgContent;
						}
					}else {
						var typeMsg = msg.getAttribute("type");
						if(typeMsg=="groupchat") {
							var bodyEles = msg.getElementsByTagName("body");
							if(bodyEles.length>0) {
								var content = crypto.resultChatDecrypt(strophe.Strophe.getText(bodyEles[0])).replace(/'/g, "\"");
								var msgName = "";
								var roles = "";
								var ut = "";
								var iconUrl = "";
								var userId = "";
								var admin = "";
								var reject = "";
								var hidden = "";
								var center = "";
								var delMsg = "";
								var fmt = "";
								var bmt = "";
								var ir = "";
								var userProfessorTitle = null;
								var timeTs = 0
								var msgId = msg.getAttribute("id")
								
								var hcEles = msg.getElementsByTagName("hc");
								if(hcEles.length>0) {
									var hcEle = hcEles[0];
									msgName = hcEle.getAttribute("nn");
									userId = hcEle.getAttribute("uid");
									roles = hcEle.getAttribute("roles");
									ut = hcEle.getAttribute("ut");
									iconUrl = hcEle.getAttribute("icon");
									admin = hcEle.getAttribute("admin");
									reject = hcEle.getAttribute("reject");
									hidden = hcEle.getAttribute("hidden");
									center = hcEle.getAttribute("center");
									delMsg = hcEle.getAttribute("delMsg");
									fmt = hcEle.getAttribute("fmt");
									bmt = hcEle.getAttribute("mt");
									ir = hcEle.getAttribute("ir");
									timeTs = hcEle.getAttribute("ts");
									const upt = hcEle.getAttribute("upt")
									if(upt) {
										userProfessorTitle = JSON.parse(upt)
									}
									if(timeTs) {
										timeTs = parseInt(timeTs)
									}else {
										var delayEles = msg.getElementsByTagName("delay");
										if(delayEles.length>0) {
											var delayValue = delayEles[0].getAttribute("stamp");
											timeTs = new Date(delayValue).getTime();
										}
									}
								}
								
								
								var stanzaId = ""
								var stanzaIdEles = msg.getElementsByTagName("stanza-id");
								if(stanzaIdEles && stanzaIdEles.length>0) {
									stanzaId = stanzaIdEles[0].getAttribute("id");
								}
								
								if(content) {
									let redpacketId
									if(content.indexOf("[==红包==:")!=-1) {
										redpacketId = content.split(":")[1].split("]")[0]
									}else if((_self.roomId!=_self.room_id_lh && _self.chatroomInfos[_self.room_id_lh] && content.indexOf(_self.room_flag_lh)!=-1) || (_self.roomId!=_self.room_id_ssc && _self.chatroomInfos[_self.room_id_ssc] && content.indexOf(_self.room_flag_ssc)!=-1)) {
										content = "<text style=\"color: #3498db;\">"+content+"</text>";
									}
									content = content.replace(/0.12rem/g,'26rpx')
									
									return {
										nickName: msgName,
										content: _self.escape2Html(content),
										timeTs: timeTs,
										roles: roles,
										icon: iconUrl,
										userId: userId,
										msgId: msgId,
										ut:ut,
										admin:admin,
										reject:reject,
										hidden:hidden,
										center:center,
										delMsg:delMsg,
										fmt:fmt,
										bmt:bmt,
										ir:ir,
										stanzaId:stanzaId,
										redpacketId:redpacketId,
										upt:userProfessorTitle
									}
								}
							}
						}
					}
				}catch(e) {}
			},
			ajaxHistory(hideLoading) {
				let msgId
				let stanzaId = 0
				if(this.msgList.length>0) {
					msgId = this.msgList[0].msgId
					stanzaId = this.msgList[0].stanzaId
				}
				
				var optionData = {}
				optionData[this.$COMMON.REQUEST.OPTION_URL] = _self.historyUrl
				optionData[this.$COMMON.REQUEST.OPTION_LOADING_HIDE] = hideLoading
				optionData[this.$COMMON.REQUEST.OPTION_PARAMETER] = {
					fromid:stanzaId,
					count:50
				}
				optionData[this.$COMMON.REQUEST.OPTION_SUCCESS] = function(dataContent) {
					if(dataContent && dataContent.length>0) {
						let dataArray = _self.bindMsgList(dataContent)
						_self.msgList.splice(0,0,...dataArray)
						
						_self.$nextTick(function() {
							if(msgId) {
								_self.scrollToView = msgId
							}else {
								_self.scrollToBottom()
							}
							_self.$nextTick(function() {
								_self.scrollAnimation = true
							})
						})
					}else {
						if(!hideLoading) {
							uni.showToast({
								title:'加載完成',
								icon:'none'
							})
						}
					}
					uni.stopPullDownRefresh()
				}
				optionData[this.$COMMON.REQUEST.OPTION_ERROR] = function() {
					uni.stopPullDownRefresh()
				}
				this.$util.handleRequestGet(optionData, this)
			},
		}
	}
</script>
<style lang="scss">
	@import "@/common/station.scss";
	
	.isAdmin .chatText {
		background-color: #F9444E!important;
		color: #FFFFFF!important;
	}
	
	.isAdmin .name {
		color: #F9444E!important;
	}
	
	.topLayout {
		position: fixed;
		z-index: 998;
		width: 100%;
		background-color: #FFFFFF;
	}
	
	.topLayout .unb {
		color: #828283;
		font-size: 22rpx;
		height: 50rpx;
		line-height: 50rpx;
		border-bottom: solid 1px #EEEEEE;
	}
	
	.topLayout .adLayout {
		display: flex;
		flex-direction: row;
		height: 50rpx;
	}
	
	.topLayout .adLayout .adView {
		flex: 1;
		font-size: 28rpx;
		line-height: 50rpx;
		text-align: center;
	}
	
	.topLayout .adLayout .line {
		width: 1px;
		background-color: #EEEEEE;
		height: 30rpx;
		margin-top: 10rpx;
	}
	
	.iconHb {
		width: 200rpx;
		height: 259rpx;
	}
	
	.hbFestival {
		width: 650rpx;
		border: solid 8rpx #EFC52C;
		border-radius: 16rpx;
		background-color: #FFFFFF;
	}
	
	.hbFestival .close, .hbQw .close {
		width: 36rpx;
		height: 36rpx;
		position: absolute;
		right: 24rpx;
		margin-top: 16rpx;
	}
	
	.hbFestival .title {
		color: #EFC52C;
		font-size: 30rpx;
		height: 70rpx;
		line-height: 70rpx;
		text-align: center;
		padding-top: 20rpx;
	}
	
	.hbFestival .question, .hbQw .question {
		width: 594rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		font-weight: bold;
		font-size: 38rpx;
		height: 152rpx;
		margin-left: 20rpx;
		line-height: 56rpx;
		color: #000000;
	}
	
	.hbFestival .answers, .hbQw .answers {
		display: flex;
		flex-direction: column;
		width: 574rpx;
		margin-left: 30rpx;
	}
	
	.hbFestival .answers .answer, .hbQw .answers .answer {
		-moz-box-shadow:0px 0px 3px #666666;
		-webkit-box-shadow:0px 0px 3px #666666;
		box-shadow:0px 0px 3px #666666;
		height: 80rpx;
		border-radius: 40rpx;
		line-height: 80rpx;
		text-align: left;
		font-size: 34rpx;
		padding-left: 40rpx;
		margin-bottom: 36rpx;
		padding-right: 20rpx;
		color: #333333;
	}
	
	.hbFestival .answers .answer.isActive {
		color: #FFFFFF;
		background-color: #EFC52C;
	}
	
	.hbQw {
		width: 650rpx;
		border: solid 8rpx #9D23EC;
		border-radius: 16rpx;
		background-color: #FFFFFF;
	}
	
	.hbQw .title {
		color: #9D23EC;
		font-size: 30rpx;
		height: 70rpx;
		line-height: 70rpx;
		text-align: center;
		padding-top: 20rpx;
	}
	
	.hbQw .answers .answer.isActive {
		color: #FFFFFF;
		background-color: #9D23EC;
	}
	
	
</style>