<template>
	<view class="content">

		<cuCustom bgColor="bg-black" :isBack="true">
			<block slot="backText"></block>
			<block slot="content">
				<view class="header-content"> 
					<text>{{eventTypeName}} {{playerTitle}} {{(mHomeTeamName != null && mHomeTeamName != '') && (mGuestTeamName != null && mGuestTeamName != '') ? (mHomeTeamName +' - '+mGuestTeamName) : ''}}</text>
					<text>{{timeStr}}</text>
				</view>
			</block>
		</cuCustom>

		<!-- 顶部选项卡 -->
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<view 
		
			v-for="(item,index) in tabBars" 
				v-if="item.isShow"
			:key="item.id" class="nav-item" 
			:class="{current: index === tabCurrentIndex}"
			 :id="'tab'+index" @click="changeTab(index)">{{item.name}}</view>
		</scroll-view>

		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="mixTop" :isCustomBar="true" @refresh="onPulldownReresh"
		 @setEnableScroll="setEnableScroll">
			<!-- 内容部分 -->
			<swiper id="swiper"
				class="swiper-box"
				:style="{height:swiperHeight}"
				:duration="300"
				:current="tabCurrentIndex"
				@change="changeTab"
			>
				<!-- v-for="tabItem in tabBars" :key="tabItem.id" -->
				<!-- 直播 -->
				
				<swiper-item v-if="isChatView">
					<scroll-view class="panel-scroll-box" :scroll-y="enableScroll" @scrolltolower="loadMore">
						<view class="live-main">
							<view v-if="matchStartState!=2 || !isOverHours">
							<view class="video-title" v-if="isMatchIntroduction">
								提醒：{{matchIntroduction}}
							</view>
							<view class="video-view" >
								<view class="video-player" v-if="videoPlayerType == 1">
									<bwVideoPlayer  class="video-player vjs-custom-skin"
										:isLiveType="1"
										:isPlaySource="isPlaySource"
										:isLive="isVideoLive"
										:sourceUrl="sourceUrl"
										:isAutoplay="isAutoplay"
										:videoMsg="videoMsg"
										:dataTime="dataTime"
										:isBeginAnalys="isBeginAnalys"
										@beginAnalysisSource="beginAnalysisSource"
										ref="videoplay"
									></bwVideoPlayer>
								</view>
								<view class="iframe-view" v-if="(videoPlayerType == 2 || videoPlayerType == 3) && tabIndexId == 1">
									<!-- <scroll-view scroll-y="true" class="scroll-view-iframe"> -->
										<!-- <view class="scroll-view-iframe-view"> -->
											<iframe
											v-if="isWebView"
											scrolling='no'
											frameborder=0
											:src="iframeSrc"
											></iframe>
										<!-- </view> -->
									<!-- </scroll-view> -->
									<button v-else class="navToText" @tap.prevent.stop="navToIframe">
										<text class="navToPrompt">点击此处观看 </text>
										<text class="navToPrompt sourceTitle">{{matchLiveList[matchLiveListIndex].liveSourceName}}</text>
									</button>
								</view>
							</view>
							<view class="video-signal">
								<scroll-view class="signal-nav-bar" scroll-x="true">
									<!-- <view class="signal-nav-main"> -->
									<view 
									v-for="(item,index) in matchLiveList"
									:key="item.liveSourceName+index"
									class="video-signal-item" 
									@click="setSignal(item,index)">
										<view class="signal-item-name ">
											<view class="signal-item-but "
											:class="[matchLiveListIndex == index?'current-signal-item':'']">
												{{item.liveSourceName}}
												</view>
										</view>
									</view>
								</scroll-view>
							</view>
							</view>
							<view class="room-view">
								
								<!-- 广告位 -->
								<view v-if="AdList.length >= 1 && $store.state.ADstatus.zbszbAD" class="gg-view-mian">
									<bwAdvertising :AdName="'zbszbAD'" :AdList="AdList[0]"></bwAdvertising>
								</view>
								
								<scroll-view 
								:class="[matchStartState==2&&isOverHours?'msg-list2':'msg-list',!isMatchIntroduction&&!isOverHours?'isIntroduction-msg':'']" 
								
								scroll-y="true" :scroll-with-animation="scrollAnimation" :scroll-into-view="scrollToView"
								 @scroll="toScroll" upper-threshold="50">
									<view style="width: 100%;height: 12rpx;"></view>
									<view class="chatBox cu-chat">
										
										
										<view class="atMsgList" v-if="atMsgList.length > 0">
												<view class="atMsgItem" v-for="(item,index) in atMsgList" :key="item.nickName+index" @tap="seeMsg(item)">
													<text  style="color: #F0AD4E;">{{item.nickName}}</text>@了您
												</view>
										</view>
										<!-- <view class="chatItem">
											<view class="flex1 itemInfo right">
												<view class="nickName right">名字</view>
												<view class="right-view">
													<view class="sendMsg right"><text>喵喵喵！喵喵喵！喵喵喵！喵喵！喵喵！！喵！喵喵喵！</text></view>
												</view>
											</view>
											<image class="avatar" src="../../static/logo.png"></image>
									</view> -->
										<view class="chatItem"
										v-for="(item,index) in msgList" :key="index" :id="item.msgId">
											<!-- <image class="avatar" src="../../static/user_default.png"></image> -->
											<block v-if="userId == item.userId">
											<image v-if="item.icon" class="avatar" :src="item.icon" @tap="atuser(item)"></image>
											<image v-else class="avatar" src="../../static/assets/user_default.png" @tap="atuser(item)"></image>
											</block>
											<block v-else>
											<image v-if="item.icon" class="avatar" :src="item.icon" @tap="atuser(item)"></image>
											<image v-else class="avatar" src="../../static/assets/user_default.png" @tap="atuser(item)"></image>
											</block>
											<view class="itemInfo left">
												<view class="nickName">
													<text>{{item.nickName}}</text>
													<text style="color: #666666;">{{item.timeTs}}</text>
												</view>
												<view class="sendMsg">
													<text class="bq-msg-img" v-html="item.content"></text>
													<!-- <text class="bq-msg-img" v-html="item.content.replace(/\#[\u4E00-\u9FA5]{1,3}\;/gi, emotion)"></text> -->
													<!-- 指示方向 三角形小箭头 -->
													<div class="arrow">
														<em></em><span></span>
													</div>
												</view>
											</view>
										</view>
									</view>
								</scroll-view>
							</view>

							<view class="cu-bar foot input" :class="[isChatRoom?'':'op5']">
								<!-- <view class="action">
									<text class="cuIcon-sound text-grey"></text>
								</view> -->
								<view class="input-view">
									<view class="action">
										<!-- <text class="cuIcon-emojifill text-grey"></text> -->
										<image @tap="openBQView" class="action-img" src="../../static/aimg/bq.png" mode=""></image>
									</view>
									<!-- isChatRoom -->
									<input class="solid-bottom" 
									:adjust-position="false" 
									:placeholder="isChatRoom?'发表评论...':'聊天室已关闭'" 
									v-model="inputVal" 
									:focus="false"
									:disabled="!isChatRoom"
									 maxlength="300" 
									 :cursor-spacing="cursorSpacing" 
									 @focus="InputFocus" 
									 @blur="InputBlur"></input>
								</view>
								
								<!-- 表情区域 -->
								<div class="browBox" v-if="faceShow">
									<ul>
										<li v-for="(item,index) in faceList" :key="index" @click="getBrow(index)">{{item}}</li>
									</ul>
								</div>
								<div v-if="faceShow" class="close" @click="openBQView"></div>
								
								<button :disabled="!isChatRoom" class="input-but" :style="{'opacity': inputVal ? '1' : '0.6',}" @tap="setmsg">发送</button>
								<!-- <button class="input-but" @tap="toVido">video</button> -->
									<!-- <button class="input-but" @tap="zanting">暂停</button> -->
							</view>
						</view>
						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more> -->
					</scroll-view>
				</swiper-item>
				
				<!-- 录像-->
				<swiper-item v-if="isLive">
					<!-- lx-scroll-view -->
					<!-- <scroll-view class="panel-scroll-box " :scroll-y="enableScroll" @scrolltolower="loadMore"> -->
						<playerVideoPage
						:bigEventTypePath = "matchData.bigEventTypePath"
						:bigEventLogoPath = "matchData.bigEventLogoPath"
						:guestTeamLogoPath="lxDetail.guestTeamLogoPath"
						:guestTeamName="lxDetail.guestTeamName"
						:guestTeamSocre="lxDetail.guestTeamSocre"
						:homeTeamLogoPath="lxDetail.homeTeamLogoPath"
						:homeTeamName="lxDetail.homeTeamName"
						:homeTeamScore="lxDetail.homeTeamScore"
						:isFinsh="lxDetail.isFinsh"
						:isHot="lxDetail.isHot"
						:isRecommend="lxDetail.isRecommend"
						:isTop="lxDetail.isTop"
						:matchBeginTime="lxDetail.matchBeginTime"
						:matchEndTime="lxDetail.matchEndTime"
						:matchLiveSourceDOS="lxDetail.matchLiveSourceDOS"
						:matchStartState="lxDetail.matchStartState"
						:matchTitle="lxDetail.matchTitle"
						></playerVideoPage>
						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more> -->
					<!-- </scroll-view> -->
				</swiper-item>
				<!-- 集锦 -->
				<swiper-item v-if="isHighlights">
					<!-- <scroll-view class="panel-scroll-box" :scroll-y="enableScroll" @scrolltolower="loadMore"> -->
							<!-- :matchId="matchId" -->
						<highlights ref="higref"
						:tabIndexId="tabIndexId"
						:bigEventTypePath = "matchData.bigEventTypePath"
						:bigEventLogoPath = "matchData.bigEventLogoPath"
						:guestTeamLogoPath="jjDetail.guestTeamLogoPath"
						:guestTeamName="jjDetail.guestTeamName"
						:guestTeamSocre="jjDetail.guestTeamSocre"
						:homeTeamLogoPath="jjDetail.homeTeamLogoPath"
						:homeTeamName="jjDetail.homeTeamName"
						:homeTeamScore="jjDetail.homeTeamScore"
						:isFinsh="jjDetail.isFinsh"
						:isHot="jjDetail.isHot"
						:isRecommend="jjDetail.isRecommend"
						:isTop="jjDetail.isTop"
						:matchBeginTime="jjDetail.matchBeginTime"
						:matchEndTime="jjDetail.matchEndTime"
						:matchLiveSourceDOS="jjDetail.matchLiveSourceDOS"
						:matchStartState="jjDetail.matchStartState"
						:matchTitle="jjDetail.matchTitle"
						></highlights>
				
				
						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more> -->
					<!-- </scroll-view> -->
				</swiper-item>
				<!-- 战报 -->
				<swiper-item v-if="isGrand || (matchData.guestTeamSocre != '' && matchData.guestTeamSocre != null)">
					<scroll-view class="panel-scroll-box" :scroll-y="enableScroll" @scrolltolower="loadMore">
						<match-score
						:guestTeamLogoPath="matchData.guestTeamLogoPath"
						:guestTeamName="matchData.guestTeamName"
						:guestTeamSocre="matchData.guestTeamSocre"
						:homeTeamLogoPath="matchData.homeTeamLogoPath"
						:homeTeamName="matchData.homeTeamName"
						:homeTeamScore="matchData.homeTeamScore"
						:isFinsh="matchData.isFinsh"
						:matchStartState="matchData.matchStartState"
						:matchTitle="matchData.matchTitle"
						></match-score>
						<view class="pad20">
							<view v-if="matchReuslt" class="">
								<rich-text :nodes="grandDetail"></rich-text>
							</view>
							<view v-else class="nodata">
								<!-- 暂无数据 -->
							</view>
						</view>
						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more> -->
					</scroll-view>
				</swiper-item>
				<!-- 文字-->
				<swiper-item v-if="isTextLivePath">
					<!-- <scroll-view class="panel-scroll-box" :scroll-y="enableScroll" @scrolltolower="loadMore"> -->
						<!-- <textList></textList> -->

						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more> -->
					<!-- </scroll-view> -->
					<div class="nodata"></div>
				</swiper-item>
				
				<!-- 前瞻 -->
				<swiper-item v-if="isForesight">
					<scroll-view class="panel-scroll-box" :scroll-y="enableScroll" @scrolltolower="loadMore">
						<match-score
						:guestTeamLogoPath="matchData.guestTeamLogoPath"
						:guestTeamName="matchData.guestTeamName"
						:guestTeamSocre="matchData.guestTeamSocre"
						:homeTeamLogoPath="matchData.homeTeamLogoPath"
						:homeTeamName="matchData.homeTeamName"
						:homeTeamScore="matchData.homeTeamScore"
						:isFinsh="matchData.isFinsh"
						:matchStartState="matchData.matchStartState"
						:matchTitle="matchData.matchTitle"
						></match-score>
						<view class="pad20">
							<view v-if="matchProspect" class="">
								<rich-text :nodes="foresightDetail"></rich-text>
							</view>
							<view v-else class="nodata">
								<!-- 暂无数据 -->
							</view>
						</view>

						<!-- 上滑加载更多组件 -->
						<!-- <mix-load-more :status="tabItem.loadMoreStatus"></mix-load-more> -->
					</scroll-view>
				</swiper-item>
				
				
				<!-- 评论 -->
				<swiper-item v-if="isCommentsView">
					
					<scroll-view class="panel-scroll-box" :scroll-y="enableScroll"  @scrolltolower="loadMoreCom">
						<view class="live-main">
							<view class="comments-view">
								<comments :cid="matchId" 
								:comments="comments" 
								:noToken="noToken" 
								:type="comctype" 
								:total="comtotal"></comments>
								<mix-load-more :status="loadMoreStatus"></mix-load-more>
							</view>
							
							<view class="cu-bar foot input">
								<view class="input-view">
									<!-- <view class="action">
										<image @tap="openBQView" class="action-img" src="../../static/aimg/bq.png" mode=""></image>
									</view> -->
									<input class="solid-bottom" 
									:adjust-position="false" 
									placeholder="发表评论..." 
									v-model="commentsInput" 
									:focus="false"
									 maxlength="300" 
									 :cursor-spacing="cursorSpacing" 
									
									 ></input>
									 <!--  @focus="InputFocus" 
									 @blur="InputBlur" -->
								</view>
								<button class="input-but" @tap="submitCom">提交</button>
							</view>
						</view>
						
					</scroll-view>
				</swiper-item>
			</swiper>
		</mix-pulldown-refresh>

	</view>
</template>

<script>
	
	import app from "../../App.vue"
	import json from '@/json'
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	import textList from '../component/text-list.vue';
	import playerVideoPage from '../component/player-video-page.vue';
	import matchScore from '../component/match-score.vue';
	
	import strophe from '@/node_modules/strophe.js/src/strophe.js'

	import highlights from '../component/highlights.vue'
	
	import videoPlayer from '../component/videoPlayer.vue'
	import iframeView from '../component/iframe.vue'
	import webView from '../component/webView.vue'
	
	import bwVideoPlayer from '../component/bw-videoPlayer.vue'
	
	import cuCustom from '../../colorui/components/cu-custom.vue'
	import BWS from '../../bw/js/bw-WebSocket.js'
	import Emotion from '@/components/Emotion/index';
	
	import comments from "../component/comments.vue"
	let windowWidth = 0,
		scrollTimer = false,
		tabBar, that,
		setOverTime;//设置 剩余结束时间
	
	// 导入JSON格式的表情库 (emoticon)
	const Emoji = require("@/bw/emojis.json");
	
	export default {
		components: {
			Emotion,
			cuCustom,
			bwVideoPlayer,
			mixPulldownRefresh,
			mixLoadMore,
			textList,
			playerVideoPage,
			matchScore,
			highlights,
			videoPlayer,
			iframeView,
			webView,
			comments
		},
		data() {
			return {
				comid:0,
				comctype:3,
				comments: [],
				newsContentNumber: 0,	//总评论数
				commentsInput:'',
				submitBtn: false,		// 提交按钮/点赞按钮状态
				loadMoreStatus:0,
				comoffset:1,//评论页
				comtotal:0,//总条数
				noToken: false,
				comInputBottom: 0,
				
				
				
				isBeginAnalys:true,//失效后是否重新解析
				specialName:'',//专题名称
				eventTypeName:'',//项目类型
				eventName:'',//项目名称
				matchLiveListIndex:0,//播放数组下标
				matchLiveList:[],//播放源数组
				atMsgList:[],//@消息数组
				matchIntroduction: '', // 提醒
				isMatchIntroduction:false,
				dataTime:0,//未到解析时间 
				videoPlayerType:1,//1是 video  2是iframe  3：跳转到webLink
				isWebView:true, //是否是webview
				iframeSrc:'',//iframe路径
				isPlaySource:false,//是否有播放源
				isVideoLive:false,//是否是直播
				isAutoplay:true,//是否自动播放
				videoMsg:'',	//video消息
				sourceUrl:'',//播放路径
				cursorSpacing:10,//input光标
				matchReuslt:'',//战报id
				grandDetail:'',//战报详情
				matchProspect:'',//前瞻id
				foresightDetail:'',//前瞻详情
				isGetForesight:false,	//是否获取过 前瞻
				isGetGrand:false,	//是否获取过战报
				isGrand:true,	//是否有战报
				isForesight:true,//是否有前瞻
				tabCurrentIndex: 0, //当前选项卡索引
				tabIndexId:'1',//下标id
				isGetVideo: false, //是否获取过录像
				isGetJJ: false, //是否获取过集锦
				scrollLeft: 0, //顶部选项卡左滑距离
				isGetHomeFunction:false,//是否获取过首页数据
				matchTextLivePath:'',//文字路径
				isTextLivePath:false,//是否有文字
				matchStartState:1,//赛事进行状态 0进行中 1未开始 2已结束
				isOverHours:false,//是否结束一小时
				overTime:0,//剩余结束时间
				pageId:0,
				mixTop:90,
				isShowBar:true,
				matchData: {
					eventId: 0,
					eventTypeId: 0,
					guestTeamId: 0,
					guestTeamLogoPath: "",
					guestTeamName: "",
					guestTeamSocre: '',
					homeTeamId: '',
					homeTeamLogoPath: "",
					homeTeamName: "",
					homeTeamScore: '',
					isFinsh: '',
					isHot: '',
					isRecommend: '',
					isTop: '',
					liveSourceName: '',
					matchBeginTime: "",
					matchEndTime: "",
					matchStartState: '',
					matchTitle: "",
					sort: null,
					specialId: 0,
					matchId: 0,
					matchLiveSourceDOS:[],
					matchSourcePathShortName:''
				},
				mGuestTeamName:'',
				mHomeTeamName:'',
				timeStr:'',
				enableScroll: true,
				isCommentsView:false,//是否有评论
				isChatView:true,//是否有聊天室
				isLive:true,	//是否有录像
				isHighlights:true,//是否有集锦
				
				tabBars: [
					{name: '直播',id: '1',isShow:true},
					{name: '录像',id: '3',isShow:true}, 
					{name: '集锦',id: '4',isShow:true}, 
					{name: '战报',id: '6',isShow:true},
					{name: '文字',id: '2',isShow:true},
					{name: '前瞻',id: '5',isShow:true}, 
					{name: '评论',id: '7',isShow:true}
				],
				
				scrollAnimation: false,
				scrollToView: '', //滚动到消息的id
				isHigVideo: false,
				swiperHeight: '', //滑块高度
				
				InputBottom: 0,
				inputVal: '',
				matchId: 0, //直播id
				sourceId: 0, //直播源id
				playerTitle: '', //直播标题
				playerTime: '', //直播时间
				resultMsg: '', //解析提醒
				playerType:true,
				analysisSourceNumber:0,//解析次数
				timeOutAnalys:null,//延迟解析对象
				
				lxDetail: {
					eventId: 0,
					eventTypeId: 0,
					guestTeamId: 0,
					guestTeamLogoPath: "",
					guestTeamName: "",
					guestTeamSocre: '',
					homeTeamId: '',
					homeTeamLogoPath: "",
					homeTeamName: "",
					homeTeamScore: '',
					isFinsh: '',
					isHot: '',
					isRecommend: '',
					isTop: '',
					liveSourceName: '',
					matchBeginTime: "",
					matchEndTime: "",
					matchStartState: '',
					matchTitle: "",
					sort: null,
					specialId: 0,
					matchId: 0,
					matchLiveSourceDOS:[],
					matchSourcePathShortName:''
				},
				jjDetail:{
					eventId: 0,
					eventTypeId: 0,
					guestTeamId: 0,
					guestTeamLogoPath: "",
					guestTeamName: "",
					guestTeamSocre: '',
					homeTeamId: '',
					homeTeamLogoPath: "",
					homeTeamName: "",
					homeTeamScore: '',
					isFinsh: '',
					isHot: '',
					isRecommend: '',
					isTop: '',
					liveSourceName: '',
					matchBeginTime: "",
					matchEndTime: "",
					matchStartState: '',
					matchTitle: "",
					sort: null,
					specialId: 0,
					matchId: 0,
					matchLiveSourceDOS:[],
					matchSourcePathShortName:''
				},
			
				/*聊天*/
				bindStyle: false,
				textMsg:'',	//输入框
				connection :null ,	//xmpp链接
				connected : false,	//链接状态
				typeMessage1:1,
				bosh:'',
				roomService:'',
				email:'',				
				password:'',		//密码
				historyUrl:'',
				nickname:'',		//昵称
				atName:'',
				isVisitor:true,
				mtBackArray:[],
				imageUrl:'',		//用户头像
				msgList:[],			//消息数组
				delMarks:[],
				preLastMsgTime:0,
				userId:'',				//用户uid
				listTopHeight:0,
				scrollBottom:true,
				heartSec:0,
				sendSec:0,
				heartInterval:null,
				inPage:false,
				isFirst:true,
				unReadCounts:0,
				solHeight:0,
				stanzaId:0,		//历史记录id（最后一条）
				inputbottom:0,
				isChatRoom:true, // 默认开启聊天室
				// isChatRoom: false, // 默认关闭聊天室
				
				livePlatform: 3, // 所属平台
				
				faceList: [],	// 表情列表
				faceShow: false, // 是否显示表情列表
				
				
				AdList: [], // 广告列表
				
				itemSwitch: {}, // 功能项开关控制
			}
		},
		computed: {
			
		},
		onLoad(e) {
			that = this;
			// 获取屏幕宽度
			windowWidth = uni.getSystemInfoSync().windowWidth;
			that.matchId = e.matchId;
			that.livePlatform = e.livePlatform;
			// that.sourceId = e.sourceId;
			that.pageId = e.tabIndex||1;
			that.tabIndexId = e.tabIndex||'1';
			if(e.tabIndex > 1){
					that.tabBars.splice(that.tabBars.findIndex(item=>item.id == 1),1)
					that.isChatView = false;
					that.isCommentsView = true;
			}else{
					that.tabBars.splice(that.tabBars.findIndex(item=>item.id == 7),1)
					that.isCommentsView = false;
					that.isChatView = true;
			}
			
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'zbbfq'})
			.then( res => {
				that.AdList = res
				console.log('直播播放器广告：',that.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
			
			
			that.$nextTick(()=>{
				that.getQueryMatchById();
			})
			
			try {
			    let value = uni.getStorageSync('user');
			    if (value) {
			        console.log("本地缓存数据",value);
							that.userId = value.userId;
							that.imageUrl = value.imageUrl;
			    }
			} catch (e) {
			    // error
			}
			
			uni.$on('setComments',function(arr){
			  that.comments = arr;
			})
			uni.$on('modifyLoginStatus',() => {
				console.log('监听到事件来自 modifyLoginStatus ，修改登录状态');
				// token验证
				this.verifyToken().then(() => {
					console.log('**************************noToken状态：', that.noToken);
					// 查询新闻内容
					that.loadEvaList();
				});
			})
		},
		onReady() {

		},
		/*隐藏页面*/
		onHide(){
			
		},
		/*卸载页面*/
		onUnload() {
			clearTimeout(setOverTime);
			setOverTime = null; 
			if(that.timeOutAnalys){
				clearTimeout(that.timeOutAnalys);
				that.timeOutAnalys = null;
			}
			uni.removeStorage({
			    key: 'liveTabIndexId',
			});
			uni.$off('setComments');
			uni.$off('modifyLoginStatus');
			/*销毁*/
			that.playerDispose();
			
			that.setPreLastMsgTime(new Date().getTime())
			if(that.connection) {
				try{
					that.connection.disconnect("退出聊天室");
				}catch(e){
					//TODO handle the exception
				}
				that.connection = null;
			}
			
		},
		onBackPress(options) {
		},
		methods: {
			submitCom(){
				console.log("评论")
				if(that.commentsInput == ''){
					uni.showToast({
						title:"请输入评论内容",
						icon:"none"
					})
					return;
				}
				let datas = {
						"commentContent": that.commentsInput,
						"id": that.matchId,
						"matchType": that.comctype
				}
				that.$req.req.createMainComment(datas)
				.then( res => {
					console.log(res)
					uni.showToast({
						title:"评论发送成功！",
						icon:"none"
					})
					that.commentsInput = '';
					that.submitBtn = false;
					that.loadEvaList();
				})
			},
			
			//上滑加载
			loadMoreCom(){
				this.loadEvaList('add');
			},
			//获取评论列表
			async loadEvaList(type) {
				if(type === 'add'){
					if(that.loadMoreStatus === 2){
						return;
					}
					if(that.comments.length > 0){
						that.comoffset++;
					}
					that.loadMoreStatus = 1;
				}
				let datas = {
					    "id": that.matchId,
					    "limit": 20,
					    "offset": that.comoffset,
					    "sortTypeId": 1,
					    "typeId": that.comctype
				}
				that.$req.req.queryMainComment(datas, {noToken: that.noToken})
				.then( res => {
					console.log("评论列表",res);
					that.comtotal = res.data.data.total;
					that.comments = res.data.data.list;
					//上滑加载 处理状态
					if(res.data.data.isLastPage){
						that.loadMoreStatus = 2;
					}else{
						that.loadMoreStatus = that.comments.length >= that.comtotal ? 2: 0;
					}
				})
				
				
			},
			
			// 验证token
			verifyToken() {
				return new Promise((resolve, reject) => {
				    // ... some code
					that.noToken = false;
					this.$req.reqc.verificationToken()
					.then( res => {
						if (res.statusCode === 200 && res.data.resultCode === 1) {
							console.log('token状态：',res.data.resultMsg);
						} else {
							console.log('token失效');
							that.noToken = true;
						}
						
						resolve();
					})
					.catch( err => {
						console.log('错误的err：',err);
						that.noToken = true;
						
						resolve();
					})
				})
			},
			
			// 显示/隐藏表情列表
			openBQView(){
				// console.log(Emoji);
				this.faceShow = !this.faceShow;
				if (this.faceShow == true) {
					for (let i in Emoji) {
						this.faceList.push(Emoji[i].char);
					}
				} else {
					this.faceList = [];
				}
				// console.log('表情列表：',this.faceList);
			},
			// 获取用户点击之后的标签，存放到输入框内
			getBrow(index) {
				for (let i in this.faceList) {
					if (index == i) {
						this.inputVal += this.faceList[index];
						// 关闭表情列表
						that.openBQView();
					}
				}
			},
			
			/*选择表情触发*/
			handleEmotion (i) {
			  this.inputVal += i;
				that.visible = !that.visible;
				that.$refs.input.focus();
				// that.inputFocus = true;
			},
			// 将匹配结果替换表情图片
			emotion (res) {
			  let word = res.replace(/\#|\;/gi,'')
			  const list = ['微笑', '撇嘴', '色', '发呆', '得意', '流泪', '害羞', '闭嘴', '睡', '大哭', '尴尬', '发怒', '调皮', '呲牙', '惊讶', '难过', '酷', '冷汗', '抓狂', '吐', '偷笑', '可爱', '白眼', '傲慢', '饥饿', '困', '惊恐', '流汗', '憨笑', '大兵', '奋斗', '咒骂', '疑问', '嘘', '晕', '折磨', '衰', '骷髅', '敲打', '再见', '擦汗', '抠鼻', '鼓掌', '糗大了', '坏笑', '左哼哼', '右哼哼', '哈欠', '鄙视', '委屈', '快哭了', '阴险', '亲亲', '吓', '可怜', '菜刀', '西瓜', '啤酒', '篮球', '乒乓', '咖啡', '饭', '猪头', '玫瑰', '凋谢', '示爱', '爱心', '心碎', '蛋糕', '闪电', '炸弹', '刀', '足球', '瓢虫', '便便', '月亮', '太阳', '礼物', '拥抱', '强', '弱', '握手', '胜利', '抱拳', '勾引', '拳头', '差劲', '爱你', 'NO', 'OK', '爱情', '飞吻', '跳跳', '发抖', '怄火', '转圈', '磕头', '回头', '跳绳', '挥手', '激动', '街舞', '献吻', '左太极', '右太极']
			  let index = list.indexOf(word)
			  return `<img src="https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/${index}.gif" align="middle">`   
			},
			
			toVido(){
				uni.navigateTo({
					url: 'videoPlay',
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
				
			},
			seeMsg(item){
				that.scrollToUserItem(item.msgId).then( res => {
					this.scrollToView = ''
					setTimeout(function() {
						that.atMsgList.splice(that.atMsgList.findIndex(items => {items.msgId == item.msgId}),1)
					}, 300);
				})
			},
			addAtMsg(msg){
				that.atMsgList.push({
					msgId: msg.msgId,
					nickName:msg.nickName
				})
			},
			atuser(item){
				that.inputVal = that.inputVal+' @'+item.nickName+' ';
			},
			zanting(){
				that.$refs.videoplay.playPause();
			},
			/*获取聊天房间*/
			getaddChatRoom(){
				return new Promise((resolve, reject) => {
					that.$req.req.addChatRoom({
						roomId:parseInt(that.matchData.matchId),
						userId:that.userId||'',
						count:50,
						stanzaId:0,
					})
					// that.$req.req.chratChatRoom({roomId:that.liveData.liveId})
					.then(res => {
						console.log("获取结果",res);
						let resp = res.data.data;
						if(resp) {
							that.isChatRoom = true;
							that.bosh = resp.bosh
							that.roomService = resp.roomService
							that.email = resp.email
							that.password = resp.password
							that.historyUrl = resp.historyUrl
							that.nickname = resp.nickname
							that.isVisitor = resp.isVisitor
							that.atName = '@'+resp.nickname
							that.mtBackArray = resp.mt.toString().split(",")
							that.toConnectLiveRoom();
							
							resolve();
						}
						else {
							that.getRoomDetailError(res.data.resultMsg)
						}
					})
				})
			},
			
			/*直播*/
			setlive(){
				// console.log("查看直播")
				/*滑动回来后，继续播放*/
				if(that.matchStartState==0){
					that.$refs.videoplay.play();
				}
			},
			/*直播源反馈*/
			matchReport(sid){
				return new Promise((resp,rej)=>{
					let datas = {
						"livePlatform": that.livePlatform,
						"matchId": that.matchId,
						"sourceId": sid
					}
					console.log("开始反馈")
					that.$req.req.matchReport(datas).then(res=>{
						console.log("反馈",res);
						resp();
					})
				})
			},
			/*重新解析*/
			beginAnalysisSource(isReport = false){
				that.playerDispose().then( res => {
					let mlist = that.matchLiveList,
							index = that.matchLiveListIndex;
					if (isReport) {
						that.matchReport(mlist[index].sourceId).then(ress=>{
							console.log("当前解析,",mlist);
							if(mlist.length > 0){
								that.analysisSource(mlist[index].sourceId);
								// that.setPlaySource(mlist[index]);
							}else{
								that.setNoPlay('暂未获取信号')
							}
						})
					}
					else {
						that.analysisSource(mlist[index].sourceId);
					}
				})
			},
			/*查询录像详情*/
			getQueryMatchListByVideo(vd) {
				return new Promise((resolve,reject) => {
					let datas = {
						matchId: that.matchId,
						viedoType: vd || 0,
					}
					that.$req.req.queryMatchByVideoDetial(datas)
						.then(res => {
							console.log("查询有录像集锦比赛的详情", res)
							uni.hideLoading();
							if (res.data.resultCode === 1 && res.statusCode == 200) {
								let data = res.data.data;
								if(vd == 1){
									that.isGetjj = true;
									that.jjDetail = {
										...data
									}
								}else{
									that.isGetVideo = true;
									that.lxDetail = {
										...data
									}
								}
								resolve();
							} else if (res.data.resultCode !== 1 && res.statusCode == 200) {
					
							}
						}).catch(err => {
							uni.hideLoading();
							uni.showToast({
								icon: 'none',
								title: '请稍后再试'
							})
							console.log(err);
						})
					
				})
				

			},
			/*切换播放源*/
			setSignal(item,index) {
				console.log("选中",item)
				if(that.matchLiveListIndex == index){
					return;
				}
				let mlist = that.matchLiveList
				that.matchLiveListIndex = index;
				this.$forceUpdate();
				uni.hideLoading();
				if(that.timeOutAnalys){
					clearTimeout(that.timeOutAnalys);
					that.timeOutAnalys = null;
				}
				that.playerDispose().then( res => {
					console.log("销毁后开始重置")
					console.log(item.valid)
					// that.setPlaySource(item);
					that.analysisSource(item.sourceId);
				})
			},
			/*销毁播放器*/
			playerDispose() {
				return new Promise( (res,rel) => {
					try{
						that.$refs.videoplay.videoDispose();
						// that.$refs.videoplay.clearStartTime();
					}catch(e){
						//TODO handle the exception
					}
					res();
				})
			},
			
			// 游客是否允许发消息 开关 (1:开；0:关)
			verifyTouristSwitch() {
				that.$req.reqc.verificationMineStatus()
				.then( res => {
					this.itemSwitch = res.data.data;
					if (this.itemSwitch.chatroomTouristSwitch) {
						// 开启聊天
						that.isChatRoom = true;
					} else {
						// 关闭聊天
						that.isChatRoom = false;
					}
				})
			},
			
			/*查询单个赛事*/
			getQueryMatchById() {
				let datas = {
					matchId: that.matchId,
					// sourceId: that.sourceId,
					livePlatform: that.livePlatform,
				}
				uni.showLoading();
				that.$req.req.queryMatchById(datas)
				.then(res => {
					console.log("查询单个赛事", res)
					uni.hideLoading();
					if (res.data.resultCode === 1 && res.statusCode == 200) {
						let data = res.data.data;
						// 修改当前的解析解析状态值'valid'为 → 0:已解析
						if(data.matchLiveSourceDOS.length){
							data.matchLiveSourceDOS.forEach((item,index) => {
								if(item.liveSourceName.length > 10){
									item.liveSourceName = item.liveSourceName.substring(0,10)
								}
							})
						}
						
						that.isChatRoom = data.chatRoom; // 聊天室状态
						// that.isChatRoom =false;
						
						/*设置专题名称*/
						// if(data.specialName != null && data.specialName != ''){
						// 	that.specialName = '['+ data.specialName +']';
						// }
						// if(data.eventName != null && data.eventName != ''){
						// 	that.eventName = '['+ data.eventName +']';
						// }
						/*设置项目名称*/	
						
						
						if(data.eventTypeName != null && data.eventTypeName != '' && data.eventTypeName != '其他'){
							that.eventTypeName = '['+ data.eventTypeName +']';
						}else{
							if(data.eventName !=  null && data.eventName != ''){
								that.eventTypeName = '['+ data.eventName +']';
							}
						}
						that.matchData = data;
						if(data.matchIntroduction){
							that.matchIntroduction = data.matchIntroduction; // 提醒
							that.isMatchIntroduction = true;
						}else{
							that.isMatchIntroduction = false;
						}
						
						that.matchStartState = data.matchStartState;
						
						
						
						if(data.isLive == 1){
							that.tabBars.splice(that.tabBars.findIndex(item=>item.id == 3),1)
							that.isLive = false;
						}else{
							that.isLive = true;
						}
						if(data.isHighlights == 1){
							that.tabBars.splice(that.tabBars.findIndex(item=>item.id == 4),1)
							that.isHighlights = false;
						}else{
							that.isHighlights = true;
						}
						if(data.matchProspect){
							that.isForesight = true;
							that.matchProspect = data.matchProspect;
						}else{
							that.tabBars.splice(that.tabBars.findIndex(item=>item.id == 5),1)
							that.isForesight = false;
						}
						if(data.matchReuslt || (data.guestTeamSocre != '' && data.guestTeamSocre != null)){
							that.matchReuslt = data.matchReuslt;
							that.isGrand = true;
						}else{
							that.tabBars.splice(that.tabBars.findIndex(item=>item.id == 6),1)
							that.isGrand = false;
						}
						if(data.matchTextLivePath){
							that.matchTextLivePath = data.matchTextLivePath
							that.isTextLivePath = true;
						}else{
							that.tabBars.splice(that.tabBars.findIndex(item=>item.id == 2),1)
							that.isTextLivePath = false;
						}
						let tindex = that.tabIndexId;
						console.log("查看传参：",tindex);
						if(data.matchStartState == 2){
							let tlist = that.tabBars;
							if(tlist.length > 1 && that.pageId != 3){
									tindex = tlist[1].id
							}
							if(data.isOverHours == 1){
								that.isOverHours = false;
								setOverTime = setTimeout(function() {
									that.isOverHours = true;
								}, data.overTime);
							}else{
								that.isOverHours = true;
								if (that.pageId != 3) {
									that.tabBars[0].name = '聊天';
									this.$forceUpdate();
								}
							}
						}
						that.mGuestTeamName = data.guestTeamName;
						that.mHomeTeamName = data.homeTeamName;
						that.timeStr = that.timesToTime(data.matchBeginTimeTamp);
						that.playerTitle = data.matchTitle;
						that.playerTime = data.matchBeginTime;
						that.$nextTick(()=>{
							// console.log("查看数组",that.tabBars);
							let indexs = parseInt(that.tabBars.findIndex(item => item.id == tindex));
							// console.log("下标：",indexs)
							if (indexs < 0) {
								indexs = 0
							}
							let liveTabIndexId;
							uni.getStorage({
								key:'liveTabIndexId',
								success(e){
									liveTabIndexId = e.data
								}
							})
							if(liveTabIndexId > 1){
								 that.tabCurrentIndex = that.tabBars.findIndex(item => item.id == liveTabIndexId);
								 that.changeTabFun(liveTabIndexId);
								 return;
							}
							switch (parseInt(tindex)){
								case 1:
									console.log('首页')
									that.homeFunction();
									if(that.isChatRoom){
										that.getaddChatRoom().then(() => {
											// console.log('聊天室状态：',data.chatRoom);
											if (data.chatRoom) {
												// console.log('用户是否已登录:',this.$store.state.hasLogin);
												if (!this.$store.state.hasLogin) { // 用户未登录(游客)
													// 判断是否允许游客发消息
													that.verifyTouristSwitch();
												}
												if (this.$store.state.hasLogin) { // 用户已登录
													// 开启聊天
													that.isChatRoom = true;
												}
											} else {
												// 关闭聊天
												that.isChatRoom = false;
											}
										});
									}
									
									break;
								case 2:
									console.log('文字')
									break;
								case 3:
									console.log('录像')
									break;
								case 4:
									console.log('集锦')
									break;		
								case 5:
									console.log('前瞻')
									
									break;	
								case 6:
									console.log('战报')
									break;				
								default:
									break;
							}
							
							if(tindex > 1 || indexs > 0){
								// setTimeout(function(){
								that.$nextTick(() => {
										that.changeTab(indexs)
								})	
								// },0)
							}
						})
					} 
					else if (res.data.resultCode !== 1 && res.statusCode == 200) {

					}
				}).catch(err => {
					uni.hideLoading();
					uni.showToast({
						icon: 'none',
						title: '请稍后再试'
					})
					console.log(err);
				})
			},
			
			/**
			 * 设置播放源（已获取解析后数据）
			 * isAnalysis：请求解析后返回的播放地址，当 isAnalysis==0|2 且 analysisPlayPathWeb 的值为空时，进行 linkPlayType 判断并获取 webLink
			 * linkPlayType：link解析方式 2iframe 3url跳转
			 * webLink：无地址时直接跳转地址（在 linkPlayType 判断生效时使用）
			 */
			setPlaySource(item){
				// console.log("设置播放源",item)
				if (item.valid == 1) {
					that.analysisSource(item.sourceId);
				} else {
					switch (item.isAnalysis){
						case '0':
						case '2':
							that.videoPlayerType = 1;
							setTimeout(function() {
								if(item.analysisPlayPathWeb != null){
									that.beginVideo({
										analysisPlayPathWeb:item.analysisPlayPathWeb,
										liveSourceName:item.liveSourceName,
										isLive:true,
										isAutoplay:true,
										isFlash:item.isFlash
									})
								}else{
									// 无信号提示
									// that.setNoPlay()
									
									// 判断信号源播放类型
									that.judgeIsAnalysis(item);
								}
							}, 0);
							break;
						case '1':
							that.videoPlayerType = 2;
							this.$forceUpdate();
							setTimeout(function() {
								that.beginIframe({
									liveSourceName:item.liveSourceName,
									iframeSrc:item.notAnalysisPlayPath,
								})
							}, 0);
							break;
						case '3':
							// 加载跳转按钮
							that.beginToWebView(2);
							break;			
						default:
							break;
					}
				}
			},
			
			// 判断信号源播放类型
			judgeIsAnalysis(item) {
				// link解析方式 2iframe 3url跳转
				switch (~~item.linkPlayType){
					case 2:
						that.videoPlayerType = 2;
						this.$nextTick(() => {
							that.beginIframe({
								liveSourceName:item.liveSourceName,
								// iframeSrc:item.notAnalysisPlayPath,
								iframeSrc:item.webLink,
							})
						})
						break;
					case 3:
						// 加载跳转按钮 (3：使用 webLink)
						that.beginToWebView(3);
						break;
					default:
						break;
				}
			},
			
			/*首页函数*/
			homeFunction(){
				that.isGetHomeFunction = true;
				let data = that.matchData;
				console.log("查看首页数据",data);
				if(data.matchLiveSourceDOS.length > 0  && (data.matchStartState != 2 || !that.isOverHours)){
					let mlist = data.matchLiveSourceDOS;
					that.matchLiveList = mlist;
					// that.setPlaySource(mlist[0]);
					that.analysisSource(mlist[0].sourceId);
				}else{
					that.setNoPlay('暂未获取信号')
				}
			},
			
			// 点击跳转到指定url
			navToIframe: function () {
				let data = that.matchLiveList[that.matchLiveListIndex];
				
				let temp = {
					"sourceId": data.sourceId,
					"sourceName": data.liveSourceName,
					"sourcePath": that.videoPlayerType == 3 ? data.webLink : data.notAnalysisPlayPath,
					"matchId": data.matchId,
					"valid": data.valid,
				}
				// console.log('页面跳转参数：',temp);return;
				uni.navigateTo({
					url: '/pages/webview/webview?data=' + encodeURIComponent(JSON.stringify(temp))
				})
			},
			
			
			//加载loading
			initLoading() {
				uni.showLoading({
					title: '加载中...',
					mask: true
				})
				setTimeout(function() {
					uni.hideLoading();
				}, 1000);
			},
			/*加载跳转按钮*/
			beginToWebView(type){
				// that.videoPlayerType = 2;
				that.videoPlayerType = type;
				that.isPlaySource = false;
				that.playerType = false;
				that.isWebView = false;
				console.log("设置跳转按钮")
			},
			/*加载ifrmae*/
			beginIframe(res){
				// that.initLoading();
				that.isWebView = true;
				that.isPlaySource = false;
				that.playerType = false;
				console.log(res);
				that.resultMsg = res.liveSourceName;
				that.iframeSrc = res.iframeSrc;
				console.log("设置ifrmae")
			},
			/*初始化播放器*/
			beginVideo(res){
				that.isPlaySource = true;
				that.sourceUrl = res.analysisPlayPathWeb
				that.isVideoLive = true;
				that.videoMsg = res.liveSourceName;
				that.resultMsg =  res.liveSourceName;
				this.$forceUpdate();
				setTimeout(function() {
					that.$refs.videoplay.initVideo({
						url:res.analysisPlayPathWeb,
						isLive:res.isLive,
						isAutoplay:res.isAutoplay,
						isFlash:res.isFlash==0?true:false,
					});
				}, 10);
			},
			setNoPlay(title){
				uni.hideLoading();
				that.videoPlayerType = 1;
				that.isPlaySource = false;
				that.playerType = false;
				that.videoMsg = title||'暂未获取信号,请选择其他播放源观看';
				// that.resultMsg = title||'暂未获取信号,请选择其他播放源观看';
			},
			/*解析*/
			analysisSource(sid) {
				let datas = {
					"sourcePathId": sid
				}
				that.analysisSourceNumber = 0;
				uni.showLoading();
				that.analysisMatchLiveSource(datas)
			},
			analysisMatchLiveSource(datas){
				// return new Promise((resp,rej) => {
					// 解析直播源
					that.analysisSourceNumber++;
					that.$req.reqc.analysisMatchLiveSource(datas)
						.then(res => {
							console.log("解析直播信息", res)
							let data = res.data.data;
							if (res.data.resultCode == 1 && res.statusCode == 200) {
									// resp(res.data)
									uni.hideLoading();
									data.valid = '0';
									// console.log(data);
									// 解析后更新对应信号源数据
									that.matchLiveList[that.matchLiveListIndex] = data;
									that.setPlaySource(data);
							} else if (res.data.resultCode != 1 && res.statusCode == 200) {
								if(res.data.resultCode == -199){
									if(that.analysisSourceNumber < 10){
										that.timeOutAnalys = setTimeout(function() {
											if(that.analysisSourceNumber == 2){
												uni.showLoading();
											}
											that.analysisMatchLiveSource(datas);
										}, 1000);
									}else{
										that.setNoPlay();
									}
								}else{
									// resp(res.data)
									uni.hideLoading();
									that.setTimeAndVideoMsg(res.data);
								}
							}
						}).catch(err => {
							uni.hideLoading();
							// rej();
							uni.showToast({
								icon: 'none',
								title: '请稍后再试'
							})
							// console.log(err);
						})
				// })
			},
			
			
			setTimeAndVideoMsg(res){
				that.videoPlayerType = 1;
				setTimeout(function() {
					that.playerType = false;
					that.isPlaySource = false;
					that.videoMsg = res.resultMsg;
					that.resultMsg = res.resultMsg;
					console.log("解析提示",that.videoMsg);
					if(res.data > 0){
						that.dataTime = res.data;
						that.$refs.videoplay.setDataTime(res.data);
					}else{
						that.$refs.videoplay.getVideoData();
					}
				}, 0);
			},
			
			InputFocus(e) {
				this.InputBottom = e.detail.height
			},
			InputBlur(e) {
				this.InputBottom = 0
			},
			
			setmsg(val){
				that.textMsg = that.inputVal;
				that.sendText();
			},
			
			/**
			 * 数据处理方法在vue和nvue中通用，可以直接用mixin混合
			 * 这里直接写的
			 * mixin使用方法看index.nuve
			 */
			loadNewsList(type) {
				let tabItem = this.tabBars[this.tabCurrentIndex];
				// console.log(tabItem)
				//type add 加载更多 refresh下拉刷新
				if (type === 'add') {
					if (tabItem.loadMoreStatus === 2) {
						return;
					}
					tabItem.loadMoreStatus = 1;
				}
				// #ifdef APP-PLUS
				else if (type === 'refresh') {
					tabItem.refreshing = true;
				}
				// #endif

				//setTimeout模拟异步请求数据
				setTimeout(() => {
					// let list = json.newsList;
					// list.sort((a,b)=>{
					// 	return Math.random() > .5 ? -1 : 1; //静态数据打乱顺序
					// })
					if (type === 'refresh') {
						tabItem.newsList = []; //刷新前清空数组
						that.dropDownFun(tabItem.id);
					}
					// list.forEach(item=>{
					// 	item.id = parseInt(Math.random() * 10000);
					// 	tabItem.newsList.push(item);
					// })
					//下拉刷新 关闭刷新动画
					if (type === 'refresh') {
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;
					}
					//上滑加载 处理状态
					// if(type === 'add'){
					// 	tabItem.loadMoreStatus = tabItem.newsList.length > 40 ? 2: 0;
					// }
				}, 600)
			},
			//新闻详情
			navToDetails(item) {
				let data = {
					id: item.id,
					title: item.title,
					author: item.author,
					time: item.time
				}
				let url = item.videoSrc ? 'videoDetails' : 'details';

				uni.navigateTo({
					url: `/pages/details/${url}?data=${JSON.stringify(data)}`
				})
			},

			//下拉刷新
			onPulldownReresh() {
				this.loadNewsList('refresh');
			},
			//上滑加载
			loadMore() {
				this.loadNewsList('add');
			},
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable) {
				if (this.enableScroll !== enable) {
					this.enableScroll = enable;
				}
			},
			
			setPlayerVideo(index) {
				if (index != 1) {
					try {
						that.$refs.videoplay.pause(); //暂停播放
					} catch (e) {
						//TODO handle the exception
					}

				}
				if (index != 4 && that.isHigVideo) {
					try {
						that.$refs.higref.higPause();
					} catch (e) {
						//TODO handle the exception
					}

				}
				// if (index == 3 && !that.isHigVideo) {
					// that.$refs.higref.newHigVideo();
					// that.isHigVideo = !that.isHigVideo;
				// }

			},
			/*获取前瞻*/
			getForesight(){
				if(that.matchProspect){
					
					let datas = {
						newsId:parseInt(that.matchProspect)
					}
					that.$req.req.queryNewsContent(datas)
					.then( res => {
						// console.log("前瞻内容",res);
						that.isGetForesight = true;
						let resData = res.data;
						if(resData.resultCode == 1){
							that.foresightDetail = resData.data.newsContent
						}else{
							that.matchProspect = null;
						}
					
					})
				}
			},
			
			/*获取战报*/
			getGrand(){
				if(that.matchReuslt){
					
					let datas = {
						newsId:parseInt(that.matchReuslt)
					}
					that.$req.req.queryNewsContent(datas)
					.then( res => {
						that.isGetGrand = true;
						let resData = res.data;
						// console.log("战报内容",res);
						if(resData.resultCode == 1){
							that.grandDetail = resData.data.newsContent
						}else{
							that.matchReuslt = null;
						}
					})
				}else{
					
				}
			},
			/*下拉刷新*/
			dropDownFun(i){
				switch (parseInt(i)) {
					case 1:
							/*直播刷新数据*/
							clearTimeout(setOverTime);
							setOverTime = null; 
							/*销毁*/
							that.playerDispose();
							that.setPreLastMsgTime(new Date().getTime())
							if(that.connection) {
								try{
									that.connection.disconnect("退出聊天室");
								}catch(e){
									//TODO handle the exception
								}
								that.connection = null;
							}
							that.homeFunction();
							setTimeout(function() {
								if(that.isChatRoom){
									that.getaddChatRoom();
								}
							}, 1300);
						break;
					case 2:
						/*文字*/
						// that.getEqDis();
						break;
					case 3:
						/*获取录像*/
							that.getQueryMatchListByVideo(0);
						break;
					case 4:
						/*获取集锦*/
							that.getQueryMatchListByVideo(1)
							.then( res=> {
								// that.$refs.higref.newHigVideo();
							})
							;
						break;
					case 5:
					/*前瞻*/
							that.getForesight();
						break;
					case 6:
					/*战报*/
							that.getGrand();
						break;	
					default:
						break;
				}
			},
			/*切换触发*/
			changeTabFun(i) {
				that.tabIndexId = i;
				uni.setStorage({
					key:'liveTabIndexId',
					data:i
				})
				switch (parseInt(i)) {
					case 1:
						if(!that.isGetHomeFunction){
							that.homeFunction();
							if(that.isChatRoom){
								that.getaddChatRoom();
							}
						}
						if(that.videoPlayerType == 1){
							that.setlive();
						}
						break;
					case 2:
						// that.getEqDis();
						break;
					case 3:
						/*获取录像*/
						if (!that.isGetVideo) {
							that.getQueryMatchListByVideo(0);
						}
						break;
					case 4:
						/*获取集锦*/
						if (!that.isGetJJ) {
							that.getQueryMatchListByVideo(1)
							.then( res=> {
								// that.$refs.higref.newHigVideo();
							})
							;
						}
						// that.rebirthDetail();
						break;
					case 5:
					/*前瞻*/
						if(!that.isGetForesight){
							that.getForesight();
						}
						break;
					case 6:
					/*战报*/
						if(!that.isGetGrand){
							that.getGrand();
						}
						break;
					case 7:
					/*评论*/
						// token验证
						this.verifyToken().then( () => {
							console.log('noToken状态：',that.noToken);
							that.loadEvaList();
						});
						break;
							
					default:
						break;
				}

			},
			//tab切换
			async changeTab(e) {
				// console.log("滑动切换",e);
				if (scrollTimer) {
					//多次切换只执行最后一次
					clearTimeout(scrollTimer);
					scrollTimer = false;
				}
				let index = e;
				//e=number为点击切换，e=object为swiper滑动切换
				if (typeof e === 'object') {
					index = e.detail.current
				}
				if (typeof tabBar !== 'object') {
					tabBar = await this.getElSize("nav-bar")
				}
				//计算宽度相关
				let tabBarScrollLeft = tabBar.scrollLeft;
				let width = 0;
				let nowWidth = 0;
				//获取可滑动总宽度
				for (let i = 0; i <= index; i++) {
					let result = await this.getElSize('tab' + i);
					width += result.width;
					if (i === index) {
						nowWidth = result.width;
					}
				}
				if (typeof e === 'number') {
					//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
					this.tabCurrentIndex = index;
				}
				
				uni.hideLoading();
				//延迟300ms,等待swiper动画结束再修改tabbar
					that.changeTabFun(that.tabBars[index].id);
				/*改变停止播放*/
				that.setPlayerVideo(that.tabBars[index].id);

				scrollTimer = setTimeout(() => {
					if (width - nowWidth / 2 > windowWidth / 2) {
						//如果当前项越过中心点，将其放在屏幕中心
						this.scrollLeft = width - nowWidth / 2 - windowWidth / 2;
					} else {
						this.scrollLeft = 0;
					}
					if (typeof e === 'object') {
						this.tabCurrentIndex = index;
					}
					this.tabCurrentIndex = index;


					//第一次切换tab，动画结束后需要加载数据
					let tabItem = this.tabBars[this.tabCurrentIndex];
					if (this.tabCurrentIndex !== 0 && tabItem.loaded !== true) {
						this.loadNewsList('add');
						tabItem.loaded = true;
					}
				}, 300)

			},
			//获得元素的size
			getElSize(id) {
				return new Promise((res, rej) => {
					let el = uni.createSelectorQuery().select('#' + id);
					el.fields({
						size: true,
						scrollOffset: true,
						rect: true
					}, (data) => {
						res(data);
					}).exec();
				});
			},
			parseMsg(msg) {
				try{
					if(msg.children.length==1 && msg.getElementsByTagName("body").length>0) {
						// console.log("有body");
						var tipContent = strophe.Strophe.getText(msg.getElementsByTagName("body")[0]).replace(/'/g, "\"");
						if(tipContent && tipContent!=this.$COMMON.CHAT_ROOM_HEART_PONG) {
							var msgContent = {
								msgId:that.uuid(5,16),
								fmt:that.typeMessage3,
								center:that.messageCenterYes,
								content:tipContent
							}
							return msgContent;
						}
					}else {
						var typeMsg = msg.getAttribute("type");
						// console.log(typeMsg)
						if(typeMsg=="groupchat") {
							var bodyEles = msg.getElementsByTagName("body");
							// console.log("bodyEles",bodyEles);
							if(bodyEles.length>0) {
								// var content = crypto.resultChatDecrypt(strophe.Strophe.getText(bodyEles[0])).replace(/'/g, "\"");
								var content = strophe.Strophe.getText(bodyEles[0]).replace(/'/g, "\"");
								var msgName = "";
								var roles = "";
								var ut = "";
								var iconUrl = "";
								var userId = "";
								var admin = "";
								var reject = "";
								var hidden = "";
								var center = "";
								var delMsg = "";
								var fmt = "";
								var bmt = "";
								var ir = "";
								var userProfessorTitle = null;
								var timeTs = 0
								var msgId = msg.getAttribute("id")
								// console.log("第一次解析",content);
								var hcEles = msg.getElementsByTagName("hc");
								if(hcEles.length>0) {
									var hcEle = hcEles[0];
									msgName = hcEle.getAttribute("nn");
									userId = hcEle.getAttribute("uid");
									roles = hcEle.getAttribute("roles");
									ut = hcEle.getAttribute("ut");
									iconUrl = hcEle.getAttribute("icon");
									admin = hcEle.getAttribute("admin");
									reject = hcEle.getAttribute("reject");
									hidden = hcEle.getAttribute("hidden");
									center = hcEle.getAttribute("center");
									delMsg = hcEle.getAttribute("delMsg");
									fmt = hcEle.getAttribute("fmt");
									bmt = hcEle.getAttribute("mt");
									ir = hcEle.getAttribute("ir");
									timeTs = hcEle.getAttribute("ts");
									const upt = hcEle.getAttribute("upt")
									if(upt) {
										userProfessorTitle = JSON.parse(upt)
									}
									if(timeTs) {
										// timeTs = parseInt(timeTs)
										timeTs = BWS.returnMsgTime(parseInt(timeTs));
										// timeTs = new Date(delayValue).getTime();
									}else {
										var delayEles = msg.getElementsByTagName("delay");
										if(delayEles.length>0) {
											var delayValue = delayEles[0].getAttribute("stamp");
											timeTs = new Date(delayValue).getTime();
										}
									}
								}
								
								
								var stanzaId = ""
								var stanzaIdEles = msg.getElementsByTagName("stanza-id");
								if(stanzaIdEles && stanzaIdEles.length>0) {
									stanzaId = stanzaIdEles[0].getAttribute("id");
								}
								
								if(content) {
									let redpacketId
									if(content.indexOf("[==红包==:")!=-1) {
										redpacketId = content.split(":")[1].split("]")[0]
									}else if(
									(that.roomId!=that.room_id_lh && 
									that.chatroomInfos[that.room_id_lh] && 
									content.indexOf(that.room_flag_lh)!=-1) || 
									(that.roomId!=that.room_id_ssc && 
									that.chatroomInfos[that.room_id_ssc] && 
									content.indexOf(that.room_flag_ssc)!=-1)) {
										content = "<text style=\"color: #3498db;\">"+content+"</text>";
									}
									content = content.replace(/0.12rem/g,'26rpx')
									return {
										nickName: msgName,
										content: that.escape2Html(content),
										timeTs: timeTs,
										roles: roles,
										icon: iconUrl,
										userId: userId,
										msgId: msgId,
										ut:ut,
										admin:admin,
										reject:reject,
										hidden:hidden,
										center:center,
										delMsg:delMsg,
										fmt:fmt,
										bmt:bmt,
										ir:ir,
										stanzaId:stanzaId,
										redpacketId:redpacketId,
										upt:userProfessorTitle
									}
								}
							}
						}else{
							
							
						}
					}
				}catch(e) {}
			},
			escape2Html(str) {
				var arrEntities={'lt':'<','gt':'>','nbsp':' ','amp':'&','quot':'"'};
				return str.replace(/&(lt|gt|nbsp|amp|quot);/ig,function(all,t){return arrEntities[t];});
			},
			uuid(len, radix) {
			    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
			    var uuid = [], i;
			    radix = radix || chars.length;
			 
			    if (len) {
					for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
			    } else {
					var r;
					uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
					uuid[14] = '4';
					for (i = 0; i < 36; i++) {
						if (!uuid[i]) {
						  r = 0 | Math.random()*16;
						  uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
						}
					}
				}
			    return 'msg'+uuid.join('');
			},
			/*获取历史消息*/
			getHistory(hideLoading) {
				let msgId
				let stanzaId = 0
				if(this.msgList.length>0) {
					msgId = this.msgList[0].msgId
					stanzaId = this.msgList[0].stanzaId
				}
				uni.request({
					url: that.historyUrl,
					method: 'GET',
					data: {
						count:20,
						stanzaId:that.stanzaId,
					},
					header: {
					'custom-header': 'hello' //自定义请求头信息
					},
					success: res => {
						console.log("历史记录：",res)
						if(res.data && res.data.length>0) {
							let dataArray = that.bindMsgList(res.data)
							console.log("返回数组",dataArray);
							that.msgList.splice(0,0,...dataArray)
							that.$nextTick(function() {
								if(msgId) {
									that.scrollToView = msgId
								}else {
									that.scrollToBottom()
								}
								that.$nextTick(function() {
									that.scrollAnimation = true
								})
							})
							
							// console.log("返回后的数组",that.msgList)
						}else {
							if(!hideLoading) {
								uni.showToast({
									title:'加載完成',
									icon:'none'
								})
							}
						}
					},
					fail: () => {},
					complete: () => {}
				});
				
				
			},
			sendmsg(){
				// 创建一个<message>元素并发送
				var msg = $msg({
				    to: toJid, 
				    from: fromJid, 
				    type: 'chat'
				}).c("body", null, that.textMsg);
				// console.log(msg);
				that.connection.send(msg.tree());
			},
			scrollToBottom() {
				if(this.msgList.length>0) {
					const msgId = this.msgList[this.msgList.length-1].msgId
					this.scrollToView = msgId
					setTimeout(function() {this.scrollToView = ''}, 300);
					// console.log(this.scrollToView);
				}
			},
			scrollToUserItem(msgId) {
				// let msgId = this.msgList[this.msgList.findIndex((item => {item.userId == uid}))].msgId
				return new Promise( (res,rel) => {
					this.scrollToView = msgId
					// console.log(this.scrollToView);
					res();
				})
			},
			toScroll(e) {
				let eDetail = e.detail
				const h = eDetail.scrollHeight-eDetail.scrollTop-that.scrollViewHeight
				if(h>that.distanceBottomMaxHeight) {
					that.scrollBottom = false
				}else {
					that.scrollBottom = true
				}
				if(h<10) {
					that.unReadCounts = 0
				}
			},
			bindMsgList(historyMsg) {
				let dataArray = []
				historyMsg.forEach(function(item,index) {
					try{
						let msg = that.parseMsg(that.string2XML(item).children[0])
						// console.log("查看消息：",msg);
						if(msg) {
							let msgContent = msg.content
							if(msgContent.indexOf(that.atName)!=-1) {
								// 拿最上层的msgId   (that.msgList.length==0 && index==0):排除如果是在底部的
								if(msg.timeTs>that.preLastMsgTime && !(that.msgList.length==0 && index==0)) {
									that.atMsgId = msg.msgId
								}
							}
							dataArray.unshift(msg)
						}
					}catch(e){
						//TODO handle the exception
					}
					
				})
				return dataArray
			},
			string2XML(xmlString) {
				var parser = new DOMParser();
				var xmlObject = parser.parseFromString(xmlString, "text/xml");
				return xmlObject;
			},
			setPreLastMsgTime(ts) {
				if(that.userId) {
					uni.setStorage({
						key:that.getLastMsgTimeKey(),
						data:ts
					})
				}
			},
			/*发送消息*/
			sendText(){
				if(that.connected) {
						let mtext = this.textMsg.trim().replace(new RegExp('\n', 'gm'), '<br/>');
						
						if(mtext) {
							let hcObject = {
								// roles:that.roles,
								uid:that.userId,
								nn:that.nickname,
								fmt:that.typeMessage1,
								xmlns:"hc:client"
							}
							if(that.imageUrl) {
								hcObject['icon'] = that.imageUrl
							}
							// if(that.userProfessorTitle) {
							// 	hcObject['upt'] = JSON.stringify(that.userProfessorTitle)
							// }
							
							// crypto.requestChatEncrypt(mtext)
							var msg = strophe.$msg({
								to: that.roomService, 
								from: that.email, 
								type: "groupchat",
								id:that.uuid(5,16)
							}).c("body", null, mtext).c("hc", hcObject);
							that.connection.send(msg.tree())
							that.textMsg = '';
							that.inputVal = '';
							that.sendSec = 0
						}else {
							uni.showToast({
								title:'發送內容不能為空',
								icon:'none'
							})
						}
				}else {
					that.getRoomDetailError()
				}
			},
			toConnectLiveRoom() {
				if(!that.connected) {
					
					// uni.showToast({
					// 	title:'正在連接...',
					// 	icon:'none'
					// })
					
					that.getPreLastMsgTime()
					that.msgList.splice(0, that.msgList.length)
					if(!that.connection) {
						that.connection = new strophe.Strophe.Connection(that.bosh);
					}
					that.connection.connect(that.email, that.password, that.onConnect)
				}
			},
			getRoomDetailError(msg) {
				that.isChatRoom = false;
				uni.showToast({
					title:msg||'加入失败',
					icon:'none'
				})
				return;
				uni.showModal({
					title:'提示',
					cancelText:'取消',
					confirmText:'刷新',
					content:msg||'加入失败',
					success:function(res){
						if(res.confirm) {
							if(that.isChatRoom){
								that.getaddChatRoom();
							}
						}else {
							// uni.navigateBack({
							// 	delta:1
							// })
						}
					}
				})
			},
			getPreLastMsgTime() {
				if(that.userId) {
					try{
						let preLastMsgTime = uni.getStorageSync(that.getLastMsgTimeKey())
						if(preLastMsgTime) {
							that.preLastMsgTime = preLastMsgTime
						}
					}catch(e){}
				}
			},
			getLastMsgTimeKey() {
				return that.roomId+'_'+that.userId
			},
			/*链接状态*/
			onConnect(status) {
				switch(status) {
					case Strophe.Status.ERROR:
						// console.log('ERROR')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'链接错误',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
						
					case Strophe.Status.CONNECTING:
						console.log('链接中。。。')
						break;
					
					case Strophe.Status.CONNFAIL:
						console.log('链接失败。。')
						that.connected = false
						break;
						
					case Strophe.Status.AUTHENTICATING:
						console.log("正在授權");
						break;
						
					case Strophe.Status.AUTHFAIL:
						console.log('身份验证失败')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'授权失败或账号在其他地方登录',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									// uni.navigateBack({
									// 	delta:1
									// })
								}
							}
						})
						break;
						
					case Strophe.Status.CONNECTED:
						console.log("連接成功");
						that.connectSuccess();
						break;
						
					case Strophe.Status.DISCONNECTED:
						console.log('链接断开')
						that.connected = false
						break;
						
					case Strophe.Status.DISCONNECTING:
						console.log("斷開連接中");
						break;
						
					case Strophe.Status.ATTACHED:
						console.log("連接已附加");
						break;
						
					case Strophe.Status.REDIRECT:
						console.log('REDIRECT')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'链接被拒绝',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									uni.navigateBack({
										delta:1
									})
								}
							}
						})
						break;
						
					case Strophe.Status.CONNTIMEOUT:
						console.log('链接超时。。。')
						that.connected = false
						uni.showModal({
							title:'提示',
							content:'聊天室链接超时',
							showCancel:false,
							confirmText:"好的",
							success:function(res){
								if(res.confirm) {
									// uni.navigateBack({
									// 	delta:1
									// })
								}
							}
						})
						break;
				}
			},
			onMessage(msg) {
				var resultMsg = this.parseMsg(msg)
				// console.log(resultMsg);
				if(resultMsg) {
					// console.log("添加消息")
					that.bindMsg(resultMsg)
					if(resultMsg.userId == 0 && resultMsg.content == '关闭聊天室'){
						that.isChatRoom = false;
						that.setPreLastMsgTime(new Date().getTime())
						if(that.connection) {
							that.connection.disconnect("退出聊天室");
						}
						that.getRoomDetailError('聊天室已关闭');
						// uni.showToast({
						// 	title:'',
						// 	icon:'none'
						// })
						// return false;
					}
				}
				return true
			},
			bindMsg(msg) {
				// if(msg.delMsg==that.isDelete) {
				// 	const delContent = msg.content
				// 	if(that.delMarks.indexOf(delContent)==-1) {
				// 		that.delMarks.push(delContent)
				// 	}
				// }else if(that.mtBackArray.indexOf(msg.bmt)!=-1 || that.mtFrontArray.indexOf(msg.fmt)!=-1) {
					// console.log("消息带入数组");
					// console.log("查看是否被@",msg);
					let msgContent = msg.content
					if(msgContent.indexOf(that.atName)!=-1) {
						msg.content = msgContent.replace(new RegExp(that.atName, 'gm'), "<text style=\"color:#F0AD4E;margin-right: 8px;\">"+that.atName+"</text>")
						that.addAtMsg(msg);
						// 拿at的上一個id
						if(!that.atMsgId && this.msgList.length>0 && msg.timeTs>that.preLastMsgTime) {
							that.atMsgId = that.msgList[that.msgList.length-1].msgId
						}
					}
					if(msg.hidden == 1){
					// 	that.msgList.push(msg)
					return;
					}
					// console.log("msg",msg);
					that.msgList.push(msg)
					if(that.scrollBottom || msg.userId==that.userId) {
						// console.log("滚动");
						that.$nextTick(function() {
							that.scrollToBottom();
							that.$nextTick(function() {
								that.scrollAnimation = true
							})
						})
						
					}else {
						that.unReadCounts++
					}
					
				// }
			},
			connectSuccess() {
				if(that.connection) {
					if(that.msgList.length > 0){
						that.msgList.splice(0,that.msgList.length)
					}
					if(that.delMarks.length > 0){
						that.delMarks.splice(0,that.delMarks.length)
					}
					
					that.connected = true;
					try{
						that.getHistory(true)
					}catch(e){
						//TODO handle the exception
					}
					
					
					
					that.connection.addHandler(that.onMessage, null, 'message');
					that.connection.send(strophe.$pres().tree());
					
					var pres = strophe.$pres({
						from: that.email,
						to: that.roomService + "/" + that.email.substring(0,that.email.indexOf("@"))
					}).c('x',{xmlns: 'http://jabber.org/protocol/muc'}).c("history", {
						maxchars:0
					}).tree()
					that.connection.send(pres)
					
					// setTimeout(function() {
					// 	uni.showToast({
					// 		title:'加入聊天室成功',
					// 		icon:'none'
					// 	})
					// }, 500)
				}
			},
					
		}
	}
</script>

<style lang='scss' scoped>
	page,
	.content {
		/* background-color: #f8f8f8; */
		height: 100%;
		overflow: hidden;
	}
	.comments-view{
		padding-bottom: 90rpx;
		
	}
	
	/deep/.bq-msg-img img{
		position: relative;
		top: -12rpx;
	}
	.scroll-view-iframe{
		height: 100%;
		.scroll-view-iframe-view{
			height: 80vh;
			/* height: auto; */
		}
	}
	.t:first-child {}

	.header-content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		/* line-height: 1; */
		height: 100%;
		text {
			font-family: PingFang SC;
			color: rgba(255, 255, 255, 1);
			line-height: 36rpx;
			overflow: hidden; /*自动隐藏文字*/
			text-overflow: ellipsis;/*文字隐藏后添加省略号*/
			white-space: nowrap;/*强制不换行*/
			width: 100%;
		}

		text:first-child {
			font-size: 30rpx;
			font-weight: 500;
		}

		text:last-child {
			font-size: 22rpx;
			font-weight: 400;
		}
	}

	/*直播*/
	.live-main {
		.cu-bar {
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 15rpx 20rpx;
			
			/* 表情区域 */
			.browBox {
				width: 100%;
				height: 200px;
				background: #EEEEEE;
				position: absolute;
				bottom: 100rpx;
				left: 50%;
				transform: translateX(-50%);
				overflow: scroll;
				border-top: 2px solid rgba(200, 200, 200, 1);
				ul {
					display: flex;
					flex-wrap: wrap;
					padding: 10px;
					li {
						width: 14%;
						font-size: 26px;
						list-style: none;
						text-align: center;
					}
				}
			}
			.close {
				position: absolute;
				right: 0;
				bottom: 100rpx;
				width: 150rpx;
				height: 100rpx;
				background-color: rgba(238,238,238, .9);
				background-image: url(../../static/iconSet/close_4.png);
				background-repeat: no-repeat;
				background-size: 50rpx;
				background-position: center;
			}

			.input-view {
				background: rgba(248, 248, 248, 1);
				border: 1rpx solid rgba(234, 234, 234, 1);
				border-radius: 12rpx;
				flex: 1;
				display: flex;
				align-items: center;
				justify-content: space-between;
				.action-img{
					width: 44rpx;
					height: 44rpx;
				}
				.solid-bottom::after {
					border: 0;
				}
			}

			.input-but {
				display: flex;
				align-items: center;
				justify-content: center;
				white-space: nowrap;
				width: 96rpx;
				height: 50rpx;
				background: rgba(255, 83, 55, 1);
				border-radius: 25rpx;
				font-size: 22rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: rgba(255, 255, 255, 1);
				line-height: 46rpx;
				margin-left: 12rpx;
			}
		}

		.room-view {

			/* background-color: #FFFFFF; */
			/* padding-top: 15rpx; */
			.gg-view-mian{
				position: absolute;
				z-index: 1000;
			}
			.chatBox {
				padding-bottom: 20rpx;
				position: relative;
				
				.atMsgList{
					position: fixed;
					right: 10rpx;
					bottom: 150rpx;
					/* width: 200rpx; */
					/* height: 100rpx; */
					z-index: 999;
					display: flex;
					flex-direction: column-reverse;
					.atMsgItem{
						background-color: white;
						width: auto;
						white-space: nowrap;
						/* color: blue; */
						
						line-height: 1;
						border-radius: 777rpx;
						margin-bottom: 10rpx;
						border: 1rpx solid #666666;
						box-shadow: 1rpx 1rpx 5rpx #666666;
						padding: 11rpx;
						text-align: right;
					}
				}
			}
			.msg-list{
				top: 577rpx;
				bottom: 98rpx;
			}
			.msg-list2{
				top: 0rpx;
				bottom: 98rpx;
			}
			.isIntroduction-msg{
				top: 533rpx !important;
			}
			
			.msg-list,.msg-list2,.msg-list3{
				position: absolute;
				background-color: #FFFFFF;
				.chatItem {
					display: flex;
					/* margin-bottom: 20rpx; */
					padding: 7rpx;

					.right {
						text-align: right;
					}

					.right-view {
						display: flex;
						justify-content: flex-end;
					}

					.avatar {
						width: 80rpx;
						height: 80rpx;
						min-width: 80rpx;
						min-height: 80rpx;
						border-radius: 50%;
					}

					.itemInfo {
						flex: 1;

						&.left {
							margin-left: 14rpx;
						}

						&.right {
							margin-right: 14rpx;
						}
						.nickName {
							font-size: 11px;
							color: #1E95DC;
							margin-bottom: 6rpx;
							display: flex;
							justify-content: space-between;
							align-items: center;
							text{
								flex: 1;
								overflow: hidden;
								text-overflow: ellipsis;
								white-space: nowrap;
								&:last-child{
									text-align: right;
								}
							}
						}

						.sendMsg {
							width: fit-content;
							border-radius: 8rpx;
							box-sizing: border-box;
							padding: 21rpx;
							/* font-size: 14px; */
							background: rgba(255, 255, 255, 1);
							border: 1rpx solid rgba(195, 195, 195, 1);
							position: relative;
							z-index: 99;
							text {
								word-wrap: break-word;
								/* 超出3行时，隐藏并显示省略符 */
								overflow: hidden;
								text-overflow: ellipsis;
								display: -webkit-box;
								-webkit-line-clamp: 3;
								/* 行数控制 */
								-webkit-box-orient: vertical;
								font-size: 28rpx;
								font-family: PingFang SC;
								font-weight: 400;
								color: rgba(0, 0, 0, 1);
								line-height: 32rpx;
								padding-top: 12rpx;
							}
							
							/* 指示方向 三角形小箭头 */
							.arrow{ 
								position:absolute; 
								top: 6px;
								left: 0;
								/* width:10px;
								height:5px; */
								transform:rotate(90deg);
							}
							.arrow *{display:block; border-width:5px; position:absolute; border-style:solid dashed dashed dashed; font-size:0; line-height:0;}
							.arrow em{border-color:#c3c3c3 transparent transparent;}
							.arrow span{border-color: #FFFFFF transparent transparent; top:-2px;}

							/* &::before,
							&::after {
								content: "";
								top: 13rpx;
								-webkit-transform: rotate(45deg);
								transform: rotate(45deg);
								position: absolute;
								display: inline-block;
								overflow: hidden;
								width: 24rpx;
								height: 24rpx;
								right: initial;
								background-color: rgba(255, 255, 255, 1);
							}

							&::before {
								left: -12rpx;
								z-index: 99;
							}
							&::after {
								left: -14rpx;
								background-color: rgba(195, 195, 195, 1);
							} */
						}
					}
				}
			}

		}

		.video-title {
			background: rgba(53, 50, 53, 1);
			font-size: 22rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: rgba(255, 255, 255, 1);
			height: 44rpx;
			line-height: 44rpx;
			padding-left: 20rpx;
		}

		.video-view {
			width: 750rpx;
			height: 450rpx;
			background-color: #000000;
			position: relative;
			.video-player,.iframe-view{
				width: 100%;
				height:100%
				
			}
			.iframe-view{
				overflow: auto;
				/* -webkit-overflow-scrolling: touch; */
				/* -webkit-overflow-scrolling: touch; */
				/* -webkit-overflow:auto; */
				iframe{
					width: 100%;
					height: 100%;
					overflow: auto;
					/* -webkit-overflow-scrolling: touch; */
					/* -webkit-overflow-scrolling: touch; */
					/* -webkit-overflow:auto; */
				}
			}
			.playerSetView{
				position: absolute;
				width: 72rpx;
				height: 72rpx;
				bottom: 0;
				background-color: initial;
				z-index: 99;
				.playerBut{
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					left: 20rpx;
					bottom:16rpx ;
					background-color: red;
				}
				.playerFullScreen{
					width: 48rpx;
					height: 48rpx;
					position: absolute;
					right: 20rpx;
					bottom:16rpx ;
					background-color: red;
				}
			}
			
			.noPlayer{
				height: 450rpx;
				width: 100%;
				text-align: center;
				color: white;
				font-size: 40rpx;
				padding: 30rpx;
				display: flex;
				align-items: center;
				justify-content: center;
			}
			.prism-player {}
		}

		.video-signal {
			z-index: 101;
			height: 88rpx;
			background: rgba(255, 255, 255, 1);
			position: relative;
			box-shadow: 0px 5rpx 15rpx 0px rgba(102, 102, 102, .34);
			-webkit-box-shadow: 0px 5rpx 15rpx 0px rgba(102, 102, 102, .34);
			-moz-box-shadow: 0px 5rpx 15rpx 0px rgba(102, 102, 102, .34);

			.signal-nav-bar {
				height: 80rpx;
				white-space: nowrap;
				padding: 0 7rpx;
				/* box-shadow:0px 5rpx 15rpx 0px rgba(102,102,102,0.34); */
				position: relative;

				/* box-shadow:0px 5rpx 15rpx 0px rgba(102,102,102,.34);
				-webkit-box-shadow:0px 5rpx 15rpx 0px rgba(102,102,102,.34);
				-moz-box-shadow:0px 5rpx 15rpx 0px rgba(102,102,102,.34); */
				.video-signal-item {
					position: relative;
					/* display: inline-block; */
					/* width: 152rpx; */
					height: 80rpx;
					/* margin: 0; */
					display: inline-block;
					&:last-child{
						margin-right: 16rpx;
					}
					.signal-item-name {
						display: flex;
						align-items: center;
						justify-content: center;
						/* width: 100%; */
						height: 100%;
							margin-left:6rpx;
							padding: 0 6rpx;
						.signal-item-but {
							min-width: 100rpx;
							height: 40rpx;
							border: 1rpx solid rgba(26, 27, 48, 1);
							border-radius: 20rpx;
							display: flex;
							align-items: center;
							justify-content: center;
							text-align: center;
							text-align: center;
							font-family: PingFang SC;
							font-size: 20rpx;
							font-weight: 400;
							color: rgba(26, 27, 48, 1);
							overflow: hidden;
							/* text-overflow: ellipsis; */
							white-space: nowrap;
							/* line-height: 1.8; */
							padding: 0 12rpx;
							/* padding-right: 16rpx; */
						}
						
						.current-signal-item {
							background: rgba(27, 27, 48, 1) !important;
							color: rgba(255, 255, 255, 1) !important;
							
						}
					}

				}
				
			}
		}
	}

	/* 顶部tabbar */
	.nav-bar {
		position: relative;
		z-index: 10;
		height: 90rpx;
		white-space: nowrap;
		/* box-shadow: 0 2upx 8upx rgba(0,0,0,.06); */
		background-color: #F8F6F9;

		.nav-item {
			display: inline-block;
			width: 125rpx;
			height: 90rpx;
			text-align: center;
			line-height: 90rpx;
			font-size: 30rpx;
			color: #999999;
			position: relative;
		}

		.current {
			color: #1B1B30;
			font-weight: 600;
		}
	}

	.swiper-box {
		height: 100%;
	}
	
	swiper-item {
		height: 100%;
	}
	
	.panel-scroll-box {
		height: 100%;
	}
	.lx-scroll-view{
		height: 750rpx;
	}

	/* 新闻列表  emmm 仅供参考 */
	.news-item {
		width: 750upx;
		padding: 24upx 30upx;
		border-bottom-width: 1px;
		border-color: #eee;
		background-color: #fff;
	}

	.title {
		font-size: 32upx;
		color: #303133;
		line-height: 46upx;
	}

	.bot {
		flex-direction: row;
	}

	.author {
		font-size: 26upx;
		color: #aaa;
	}

	.time {
		font-size: 26upx;
		color: #aaa;
		margin-left: 20upx;
	}

	.img-list {
		flex-shrink: 0;
		flex-direction: row;
		background-color: #fff;
		width: 220upx;
		height: 140upx;
	}

	.img-wrapper {
		flex: 1;
		flex-direction: row;
		height: 140upx;
		position: relative;
		overflow: hidden;
	}

	.img {
		flex: 1;
	}

	.img-empty {
		height: 20upx;
	}

	/* 图在左 */
	.img-list1 {
		position: absolute;
		left: 30upx;
		top: 24upx;
	}

	.title1 {
		padding-left: 240upx;
	}

	.bot1 {
		padding-left: 240upx;
		margin-top: 20upx;
	}

	/* 图在右 */
	.img-list2 {
		position: absolute;
		right: 30upx;
		top: 24upx;
	}

	.title2 {
		padding-right: 210upx;
	}

	.bot2 {
		margin-top: 20upx;
	}

	/* 底部3图 */
	.img-list3 {
		width: 700upx;
		margin: 16upx 0upx;
	}

	.img-wrapper3 {
		margin-right: 4upx;
	}

	/* 底部大图 */
	.img-list-single {
		width: 690upx;
		height: 240upx;
		margin: 16upx 0upx;
	}

	.img-wrapper-single {
		height: 240upx;
		margin-right: 0upx;
	}

	.video-tip {
		position: absolute;
		left: 0;
		top: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, .3);
	}

	.video-tip-icon {
		width: 60upx;
		height: 60upx;
	}
	
	
	.navToText {
		position: absolute;
		top: 180rpx;
		left: 175rpx;
		width: 400rpx;
		height: 90rpx;
		background-color: rgba(255,255,255,0);
		border-width: 1px;
		border-color: #FFFFFF;
		border-style: solid;
	}
	.navToPrompt {
		font-size: 16px;
		line-height: 90rpx;
		/* color: #333333; */
		color: #FFFFFF;
	}
	.sourceTitle {
		color: red;
	}
	
</style>
