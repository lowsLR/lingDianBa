<template>
	<view>
		<view class="video-main">
			<bwVideoPlayer class="video-player vjs-custom-skin"
				:isLiveType="1"
				:isPlaySource="isPlaySource"
				:isLive="isVideoLive"
				:sourceUrl="sourceUrl"
				:isAutoplay="isAutoplay"
				:videoMsg="videoMsg"
				:dataTime="dataTime"
				ref="videoplay"
			></bwVideoPlayer>
		</view>
		
		<!-- 广告位 -->
		<block v-if="AdList.length >= 1 && $store.state.ADstatus.bfqAD">
			<view class="boxMargin"></view>
			<bwAdvertising :AdName="'bfqAD'" :AdList="AdList[0]"></bwAdvertising>
		</block>
		
	</view>
</template>

<script>
	import bwVideoPlayer from '../component/bw-videoPlayer.vue'
	let that;
	export default {
		components:{
			bwVideoPlayer
		},
		data() {
			return {
				isPlaySource:true,//是否有播放源
				isVideoLive:false,//是否是直播
				isAutoplay:true,//是否自动播放
				videoMsg:'',	//video消息
				sourceUrl:'',//播放路径
				dataTime:0,//未到解析时间 
				
				AdList: [], // 广告列表
			};
		},
		onLoad(op) {
			that = this;
			let temp = JSON.parse(decodeURIComponent(op.data));
			console.log(temp);
			that.sourceUrl = temp.sourcePath;
			uni.setNavigationBarTitle({
				title: temp.title
			})
			
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'lxbfq'})
			.then( res => {
				that.AdList = res
				console.log('录像播放器广告：',that.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
			
		},
		onReady() {
			
		},
		methods:{
			
			
		}
	}
</script>

<style lang="scss">
	.video-main{
		width: 750rpx;
		/* height: 500rpx; */
		height: 450rpx;
		display: flex;
	}
	
	.video-player{
		flex: 1;
		width: 100%;
		height: 100%;
	}
	
</style>
