<template>
	<view class="container">
		<view class="subhead">
			<!-- 已选择<text>可长按并拖拽调整顺序</text> -->
			已选择<text></text>
		</view>
		<view class="selected">
		<!-- <movable-area class="selected drag-sort" :style="{height: selTagArrLength + 'px'}" id="drag"> -->
			<block v-for="(item,index) in eventList" :key="index">
				<view v-if="item.isFocus == true" class="item">
					<view class="leftBox">
						<view @tap="setEvent(item,index,false)" :class="[index > 2 ? 'round lIcon' : '']"></view>
						<view class="title">{{item.name}}</view>
					</view>
					<view class="sortBtn"></view>
				</view>
			</block>
		<!-- </movable-area> -->
		</view>
		<view class="subhead">未选择</view>
		<view class="unselected">
			<block v-for="(item,index) in eventList" :key="index">
				<view v-if="!item.isFocus" class="item">
					<view class="leftBox">
						<view class="title">{{item.name}}</view>
					</view>
					<view @tap="setEvent(item,index,true)" class="round rIcon"></view>
				</view>
			</block>
		</view>
	</view> 
</template>

<script>
	
	export default {
		data() {
			return {
				eventList:[], // 本地存储全部标签
				selTagArr: [], // 已选中标签
				unSelTagArr: [], // 未选中标签
				height: 44, // 高度
			}
		},
		onLoad: function () {
			let that = this;
			uni.getStorage({
				key: 'eventList',
				success: function (res) {
					console.log("全部标签数据：",res.data);
					that.eventList = res.data;
					that.eventList.forEach((item, index) => {
						if (item.sortNum != null) {
							// console.log(item);
							that.selTagArr.push(item)
						}
					})
					console.log(that.selTagArr.length, that.selTagArr);
				}
			});
		},
		computed: {
			selTagArrLength (){
				return this.selTagArr.length * this.height
			}
		},
		methods: {
			// 根据"sortNum"进行数组排序
			// that.selTagArr.sort(that.compare('sortNum'));
			// 数组对象比较函数
			compare: function (type) {
				return function(m,n){
					let a = m[type];
					let b = n[type];
					return a - b; // 升序，(b-a：降序)
				}
			},
			setEvent(item,index,type){
				console.log(item,index)
				let that = this;
				if(item.id!==''){
					if (that.eventList[index].isFocus == undefined){
						that.eventList[index].isFocus = type;
					}else{
						that.eventList[index].isFocus = !that.eventList[index].isFocus;
					}
				}
				uni.setStorage({
				    key: 'eventList',
				    data: that.eventList
				});
				// 首页/视频/新闻 页面
				let temp = {
					id: item.id,
					ntype: item.type,
					type: type
				}
				// 触发标签更新事件
				uni.$emit('setEventList',temp);
			}
			
		}
		
	}
</script>

<style lang="scss" scoped>
	.container {
		flex: 1;
		flex-direction: column;
		// align-items: center;
		// justify-content: center;
		overflow: hidden;
		background-color: #F7F7F7;
	}
	
	.container {
		color: #000000;
	}
	/* 副标题 */
	.subhead {
		height: 58rpx;
		line-height: 58rpx;
		padding-left: 38rpx;
		font-size: 13px;
		text {
			font-size: 11px;
			color: #999999;
			margin-left: 14rpx;
		}
	}
	/* 列表 */
	.selected, .unselected {
		box-sizing: border-box;
		padding-left: 20rpx;
		background-color: #FFFFFF;
			
		.item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			height: 88rpx;
			box-sizing: border-box;
			border-bottom: 1px solid #E8E8E8;
			/* 左侧框 */
			.leftBox {
				display: flex;
				align-items: center;
				.title {
					font-size: 15px;
				}
			}
			/* 排序按钮 */
			.sortBtn {
				width: 38rpx;
				height: 22rpx;
				margin-right: 20rpx;
				background-size: cover;
				background-image: url(../../static/images/custom_sort.png);
			}
			/* 圆形图标 */
			.round {
				width: 38rpx;
				height: 38rpx;
				background-size: cover;
			}
			.lIcon {
				margin-right: 17rpx;
				background-image: url(../../static/images/custom_remove.png);
			}
			.rIcon {
				margin-right: 20rpx;
				background-image: url(../../static/images/custom_add.png);
			}
		}
	}
</style>
