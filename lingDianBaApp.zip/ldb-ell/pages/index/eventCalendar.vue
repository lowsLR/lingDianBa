<template>
	<view class="container">
		<!-- 插入模式 -->
		<uni-calendar :showMonth="false" :start-date="startDate" :end-date="endDate" 
		@clickSelDate="clickSelDate" 
		@change="change" />
		<button @tap="confirm">确认</button>
	</view>
</template>

<script>
	import uniCalendar from '@/components/uni-calendar/uni-calendar.vue'
	import {dateData,timeStamp,getSevenDate} from '@/components/xiujun-time-selector/date.js'
	export default {
		components: {
			uniCalendar
		},
		data() {
			return {
				selDate: null,
				startDate: '',	// 开始时间 'YYYY-MM-DD'
				endDate: '',	// 结束时间 'YYYY-MM-DD'
				sourceType: '',	// 类型 0直播 1录像
				dateList: [],
				dateArr: [],
			}
		},
		onBackPress(options) {
			let page = getCurrentPages();
			// #ifdef H5
			if (options.from === 'navigateBack') {
				if (page.length < 2) {
					window.history.back();
					// history.go(-1)
					// history.back(-1)
					// history.back()
					return true;
				}
				return false;
			}
			// #endif
			return false;
		},
		onLoad: function(option) {
			// 获取当前时间
			this.selDate = this.getTime()
			// console.log(this.selDate);

			// 接收参数
			if (Object.keys(option).length == 0) {
				// 空对象
				console.log(option);
			} else {
				const item = JSON.parse(decodeURIComponent(option.item));
				this.startDate = item.startDate;
				this.endDate = item.endDate;
				this.sourceType = item.sourceType;
			}
			console.log('-----------------页面类型----------------->：',this.sourceType===0?'直播':'录像');
			
			// 获取两个日期之间所有日期的方法
			this.getDateList();
			
		},
		methods: {
			clickSelDate(e) {
				console.log('clickSelDate 返回:', e)
				uni.$emit('getSelectedDate', e)
			},
			change(e) {
				console.log('change 返回:', e)
				this.selDate = e.fulldate
			},
			// 回到上一页
			confirm: function() {
				// 直播
				if (this.sourceType === 0) {
					// console.log('选中日期：',this.selDate);
					this.beforePage(this.selDate);
					uni.navigateBack();
				}
				// 录像
				else{
					let index = this.dateList.indexOf(this.selDate);
					// console.log('选中日期下标：',index);
					let temp = [6,5,4,3,2,1,0]; // 日期排序顺序
					let indexNum = 4, startIndex = 0;
					let val = this.dateList.length-1 - index;
					if (val <= 3) {
						indexNum = val;
					}
					else if ((val + 3) <= (this.dateList.length-1)) {
						indexNum = 3;
					}
					if (indexNum > 3) {
						startIndex = index;
					} else {
						startIndex = temp[indexNum];
					}
					console.log('当前日期应处位置：',startIndex,' 日期：',this.dateList[index]);
					
					// 获取日期列表
					let arr = getSevenDate(this.dateList[index], startIndex)
					
					this.beforePage(arr, startIndex);
					uni.navigateBack();
				}
			},

			beforePage(date, index) {
				let pages = getCurrentPages(); //当前页
				let beforePage = pages[pages.length - 2]; //上个页面 (-2：上一页面)
				// console.log(beforePage);
				// #ifdef H5
				if (this.sourceType === 0) {
					beforePage.RefreshMatchData(date)
				} else {
					beforePage.RefreshMatchData(date, index)
				}
				// #endif
				// #ifndef H5
				if (this.sourceType === 0) {
					beforePage.$vm.RefreshMatchData(date)
				} else {
					beforePage.$vm.RefreshMatchData(date, index)
				}
				// beforePage.$vm.RefreshMatchData(date, index)
				// #endif
			},

			// 获取当前时间
			getTime: function() {
				var date = new Date();

				var year = date.getFullYear();
				var month = date.getMonth() + 1 < 10 ? ('0' + (date.getMonth() + 1)) : (date.getMonth() + 1);
				var day = date.getDate() < 10 ? ('0' + date.getDate()) : date.getDate();

				var time = year + '-' + month + '-' + day

				return time;
			},
			
			// 获取两个日期之间所有日期的方法
			getDateList: function () {
				function getDate(datestr) {
					var temp = datestr.split("-");
					var date = new Date(temp[0], temp[1], temp[2]);
					return date;
				}
				
				var start = this.startDate; // '2012-3-25' / '2020-02-23'
				var end = this.endDate; // '2012-4-3' / '2020-03-28'
				var startTime = getDate(start);
				var endTime = getDate(end);
				// console.log(startTime,endTime);
				while ((endTime.getTime() - startTime.getTime()) >= 0) {
					var year = startTime.getFullYear();
					var month = startTime.getMonth().toString().length == 1 ? "0" + startTime.getMonth().toString() : startTime.getMonth();
					var day = startTime.getDate().toString().length == 1 ? "0" + startTime.getDate() : startTime.getDate();
					// alert(year+"-"+month+"-"+day);
					this.dateList.push(year + '-' + month + '-' + day)
				
					// 修改开始日期，setDate() 方法用于设置一个月的某一天
					startTime.setDate(startTime.getDate() + 1);
				}
				// console.log(this.dateList);
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		height: 100%;
	}

	.container {
		display: flex;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
		// width: 100%;
		overflow: hidden;
		// background-color: #FFFFFF;

		button {
			width: 80%;
			margin-top: 88rpx;
			color: #FFFFFF;
			background-color: #1B1B30;
		}
	}
</style>
