<template>
	<view class="content" >
		<bar :nav="setNav" v-on:tapNavBarButton="clickNavBarButton"></bar>
		<!-- 顶部选项卡 -->
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<!-- nav-item -->
			<view 
			 v-for="(item,index) in tabList" :key="item.name+index"
				class="uni-tab-item"
				:class="{current: index === tabCurrentIndex}"
				:id="'tab'+index"
				@click="changeTab(index)"
			>
			<!-- {{item.name}} -->
			<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{item.name}}</text>
			<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
		</scroll-view>
		<view class="addTag" @tap="openCustom"></view>
		<!-- <scroll-view id="nav-bar" class="scroll-h" :show-scrollbar="false" scroll-with-animation scroll-x :scroll-left="scrollLeft">
			<view v-for="(item,index) in tabList" :key="index" class="uni-tab-item" :class="[index === tabList.length-1 ? 'lastOne' : '']" :data-current="index" @tap="tabSelect(index,$event)">
				<text class="uni-tab-item-title" :class="[tabCurrentIndex === index ? 'uni-tab-item-title-active' : '']">{{item.name}}</text>
				<text class="uni-tab-item-border" :class="[tabCurrentIndex === index ? 'uni-tab-item-border-active' : '']"></text>
			</view>
			<view class="addTag" @tap="openCustom"></view>
		</scroll-view> -->
		
		<!-- 下拉刷新组件 -->
		<mix-pulldown-refresh ref="mixPulldownRefresh" class="panel-content" :top="74" @refresh="onPulldownReresh" @setEnableScroll="setEnableScroll">
			<!-- 内容部分 -->
			<swiper 
				id="swiper"
				class="swiper-box" 
				:duration="300" 
				:current="tabCurrentIndex" 
				@change="changeTab"
			>
				<!-- <swiper-item v-for="tabItem in tabList" :key="tabItem.index"> -->
				<swiper-item v-for="(tabItem, cindex) in tabList" :key="cindex">
					<scroll-view 
						:scroll-top="tabItem.scrollTop"
						:scroll-with-animation='true'
						class="panel-scroll-box" 
						:scroll-y="enableScroll" 
						@scrolltolower="loadMore"
						>
						<!-- 
							* 新闻列表 
							* 和nvue的区别只是需要把uni标签转为weex标签而已
							* class 和 style的绑定限制了一些语法，其他并没有不同
						-->
						<!-- {{tabItem.data}} -->
						<!-- <image :src="tabItem.data[0].images" mode=""></image> -->
						<block v-for="(item, index) in tabItem.data" :key="'X'+index">
							<view class="matchDate" :id="'active'+cindex+index">
							<!-- <view class="matchDate" :id="'active'+index"> -->
								{{item.dateString}}
							</view>
							
							<block v-for="(xitem, xindex) in item.sportMatchVOS" :key="'X'+index+xindex">
								
								<!-- 广告位（初始设置） -->
								<!-- <block v-if="AdList.length >= 1 && index == 0 && xindex == (AdList[0].advertisementSort > item.sportMatchVOS.length ? item.sportMatchVOS.length-1 : AdList[0].advertisementSort) && $store.state.ADstatus.syAD1">
									<bwAdvertising :AdName="'syAD1'" :AdList="AdList[0]"></bwAdvertising>
								</block>
								<block v-if="AdList.length >= 2 && index == 0 && xindex == (AdList[1].advertisementSort > item.sportMatchVOS.length ? item.sportMatchVOS.length-1 : AdList[1].advertisementSort) && $store.state.ADstatus.syAD2">
									<bwAdvertising :AdName="'syAD2'" :AdList="AdList[1]"></bwAdvertising>
								</block> -->
								<!-- <bwAdvertising :AdStatus.sync='isShowAD1'></bwAdvertising> -->
								<!-- <bwAdvertising @closeAD="closeADFun1"></bwAdvertising> -->
								
								<view class="list-item" @tap="openLive(xitem, cindex)">
									<view class="gameTitle">
										<!-- matchState(比赛状态) ==2：时间待定，!=2：显示时间 -->
										<view class="time" v-if="xitem.matchState != 2">{{xitem.matchBeginTime | CaptureTime}}</view>
										<view class="time" v-else>{{xitem.matchIntroduction}}</view>
										<!-- 赛事标题显示：正常情况下 赛事类型名称(eventTypeName) 或者 专题名称(specialName) + 赛事标题(matchTitle)；如果赛事类型(eventTypeName)为'其他'则显示 项目名称(eventName) + (加空格)赛事标题 -->
										<view class="matchTitle">
											{{xitem.eventTypeName == '' || xitem.eventTypeName == null ? xitem.specialName + (xitem.matchTitle == '' || xitem.matchTitle == null ? '' : ' ') + xitem.matchTitle : (xitem.eventTypeName == '其他' ? (xitem.eventName + (xitem.matchTitle == '' || xitem.matchTitle == null ? '' : ' ') + xitem.matchTitle) : (xitem.eventTypeName + xitem.matchTitle))}}
										</view>
									</view>
									<view class="gameInfo">
										<view class="leftTeam">
											<image @error="imageError(cindex,index, xindex, 1)" v-if="xitem.homeTeamId != null" :src="xitem.homeTeamLogoPath != null && xitem.homeTeamLogoPath != '' ? xitem.homeTeamLogoPath : '../../static/assets/homeTeam.png'" mode=""></image>
											<text class="teamName" v-if="xitem.homeTeamName != '' && xitem.homeTeamName != null">{{xitem.homeTeamName}}</text>
										</view>
										
										<!-- @tap.stop="playNow(xitem, cindex, index, xindex)" -->
										<view class="liveBtn" :class="xitem.matchState != 0 ? 'disable' : ''" v-if="xitem.matchLiveSourceDOS.length > 0 && cindex !== 2">视频直播</view>
										<view class="liveBtn disable" v-else-if="xitem.matchLiveSourceDOS.length <= 0 && cindex !== 2">暂无信号</view>
										<!-- 完赛赛事按钮类型 (取消判断是否存在播放源) -->
										<view class="liveBtn" :class="xitem.matchState != 0 ? 'disable' : ''" v-if="cindex === 2">{{xitem | ModifyBtnType}}</view>
										
										<view class="rightTeam">
											<image @error="imageError(cindex,index, xindex, 0)" v-if="xitem.guestTeamId != null" :src="xitem.guestTeamLogoPath != null && xitem.guestTeamLogoPath != '' ? xitem.guestTeamLogoPath : '../../static/assets/guestTeam.png'" mode=""></image>
											<text class="teamName" v-if="xitem.guestTeamName != '' && xitem.guestTeamName != null">{{xitem.guestTeamName}}</text>
										</view>
									</view>
									<!-- matchState(比赛状态)：0正常 1延期 2时间待定 -->
									<view class="prompt" v-if="xitem.matchIntroduction != null && xitem.matchIntroduction != '' && xitem.matchState != 2">{{xitem.matchIntroduction}}</view>
								</view>
								
								
								<!-- 广告位测试 Begin -->
								<block v-if="AdList.length >= 1 && index == 0 && xindex == (AdList[0].advertisementSort >= firstLimit ? firstLimit-1 : (AdList[0].advertisementSort > 0 ? AdList[0].advertisementSort-1 : 0)) && $store.state.ADstatus.syAD2">
									<bwAdvertising :AdName="'syAD1'" :AdList="AdList[0]"></bwAdvertising>
								</block>
								<block v-if="AdList.length >= 2 && index == 0 && xindex == (AdList[1].advertisementSort >= firstLimit ? firstLimit-1 : AdList[1].advertisementSort) && $store.state.ADstatus.syAD1">
									<bwAdvertising :AdName="'syAD2'" :AdList="AdList[1]"></bwAdvertising>
								</block>
								<!-- 广告位测试 END -->
								
							</block>
						</block>
						
						<!-- 赛事日历 -->
						<!-- v-if="tabItem.data.length > 0" -->
						<view class="calendar">
							<!-- <view class="icon reset" @tap="reset"></view> -->
							<view class="reset" @tap="reset">重置</view>
							<view class="icon calend" @tap="openCalendar"></view>
						</view>
						
						<!-- 上滑加载更多组件 -->
						<mix-load-more v-if="networkStatus" :status="tabItem.loadMoreStatus"></mix-load-more>
						
						<!-- <view class="networkClass" v-if="!networkStatus">
							<view class="networkText">
								<text>网络链接中断,请检查网络链接...</text>
								<text></text>
							</view>
							<button type="default" @tap="loadNewsList('refresh');">刷新试试</button>
						</view> -->
						<netWorkErr 
						:height="(windowHeight - StatusBar - 44 - 37 - 50 - 44)"
						:newWorlErrMsg="newWorlErrMsg"
						:networkStatus="networkStatus"
						@netWorkButTap="netButClick"
						></netWorkErr>
						<!-- 底部占位 -->
						<!-- <view class="" v-if="appPlatform == 1" style="width: 100%; height: 108rpx;"></view> -->
						<!-- <view class="" v-else style="width: 100%; height: 158rpx;"></view> -->
					</scroll-view>
				</swiper-item>
			</swiper>
		</mix-pulldown-refresh>
		
		<!-- #ifdef H5 -->
		<downloadBuoy></downloadBuoy>
		<!-- #endif -->
	</view>
</template>
 
<script>
	//#ifdef H5
	import downloadBuoy from '../component/downloadBuoy/downloadBuoy.vue';
	//#endif
	import bar from '../../components/bar/bar.vue';
	import mixAdvert from '@/components/mix-advert/vue/mix-advert';
	import json from '@/json'
	import mixPulldownRefresh from '@/components/mix-pulldown-refresh/mix-pulldown-refresh';
	import mixLoadMore from '@/components/mix-load-more/mix-load-more';
	import netWorkErr from '../component/netWorkErr'
	let windowWidth = 0, scrollTimer = false, tabBar,that;
	export default {
		components: {
			bar,
			mixPulldownRefresh,
			mixLoadMore,
			mixAdvert,
			netWorkErr,
			//#ifdef H5
			downloadBuoy
			//#endif
		},
		data() {
			return {
				// 自定义导航栏对象
				newWorlErrMsg:'网络链接中断,请检查网络链接...',
				networkStatus: true,
				setNav:{
					'bg':'#1B1B30',		// 背景色
					'navTitle':'首页',	// 导航标题
					// 'borderStyle': '1px solid red', // 底部边框
					'leftIcon': '../../static/images/tabBar_search.png',	// 左图标
					'rightIcon': '../../static/images/tabBar_user_s.png',	// 右图标
					'rightText': '右侧',										// 右文本
					// #ifndef MP-WEIXIN
					'isdisPlayLeftBtn': true,	// 是否显示左侧按钮
					// #endif
					// #ifdef MP-WEIXIN
					'isdisPlayLeftBtn': false,	// 是否显示左侧按钮
					// #endif
					'isRightType': 1,			// 右侧标签显示类型 0不显示 1图标 2文本
					// 由于导航栏是共用的，把所有的东西封装好，然后有些页面不需要的东西通过条件控制进行显示与隐藏
				},
				
				tabCurrentIndex: 0, // 当前选项卡索引 (sweiper所在页)
				scrollLeft: 0, //顶部选项卡左滑距离
				enableScroll: true,
				// tabBars: [],
				limit: 10, // 赛事列表 请求条数
				total:100,
				firstLimit: 0, // 赛事列表 当前日期首次请求的数据条数
				tabList: [
					{id:'', name:'全部', type:'5', sort: 0},
					{id:'', name:'热门', type:'3', sort: 0},
					{id:'', name:'完赛', type:'4', sort: 0},
				],
				
				tabListNo:[],
				tabListAll:[],
				
				dateRefresh: false, // 判断刷新类型，是否为指定日期刷新
				
				livePlatform: 3, // 所属平台 0:pc、1:安卓、2:苹果、3:h5;
				
				currentYear: null,
				currentMonth: null,
				currentDay: null,
				currentDate: null,
				
				homeTeamLogo: '../../static/assets/homeTeam.png',
				guestTeamLogo: '../../static/assets/guestTeam.png',
				
				AdList: [], // 广告列表
			}
		},
		
		// onNavigationBarButtonTap:function(e){
		// 	// console.log("监听到原生标题栏按钮点击事件");
		// 	// console.log(e.index);
		// 	if (e.index) {
		// 		uni.navigateTo({
		// 			url: '/pages/mine/mine'
		// 		})
		// 	} else {
		// 		uni.navigateTo({
		// 			url: '/pages/search/search'
		// 		})
		// 	}
		// },
		
		onLoad() {
			that = this;
			// console.log('-----------------首页onload-------------------');
			// 获取屏幕宽度
			windowWidth = uni.getSystemInfoSync().windowWidth;
			// 获取当前年月日
			let date = new Date();
			this.currentYear = date.getFullYear();
			this.currentMonth = date.getMonth()+1 < 10 ? ('0'+(date.getMonth()+1)) : (date.getMonth()+1);
			this.currentDay = date.getDate() < 10 ? ('0'+date.getDate()) : date.getDate();
			this.currentDate = this.currentYear+'-'+this.currentMonth+'-'+this.currentDay
			// console.log('当前日期：',this.currentDate);
			
			
			// 获取页面广告列表
			that.utils.getAdvertiseList({locationKey: 'sy'})
			.then( res => {
				that.AdList = res
				console.log('广告列表：',that.AdList);
			})
			.catch( err => {
				console.log('err：',err);
			})
			
			
			/* uni.removeStorage({
				key: 'indexTabList',
				success: function (res) {
					console.log('success');
				}
			}); */
			uni.getStorage({
				key: 'indexTabList',
				success: function (res) {
					that.livePlatform = that.appPlatform;
					that.loadtabList();
				},
				fail:function(res){
					that.getNavigationList()
					.then( res => {
						that.livePlatform = that.appPlatform;
						that.loadtabList();
					})
				}
			})
			
			// 监听tab标签改变，并更新显示赛事列表数据
			uni.$on('setIndexEventList',(res)=>{
				that.tabList = res.selTagArr;
				that.tabListNo = res.unSelTagArr;
				// console.log(res,that.tabList,that.tabListNo);
				
				// 避免删除到只有一个标签时 显示空页面
				if(that.tabCurrentIndex > that.tabList.length-1){
					that.tabCurrentIndex = that.tabList.length-1;
				}
				uni.setStorage({
				    key: 'indexTabList',
				    data: {
							rd:that.tabListAll,
							rdarr:that.tabList,
							nordarr:that.tabListNo,
						},
				    success: function () {
				        console.log('缓存数据success');
				    }
				});
			})
		},
		onReady(){
			// this.loadtabList();
		},
		methods: {
			// 网络检查
			netButClick(){
				if(that.tabListAll.length < 4){
					that.getNavigationList()
					.then( res => {
						that.loadtabList();
					})
				}else{
					that.loadNewsList('refresh');
				}
			},
			
			/*监听图片出错*/
			imageError(cindex, index, xindex, type){
				// console.log(cindex, index, xindex, type)
				// console.log('list：',that.tabList[cindex].data[index].sportMatchVOS[xindex].homeTeamLogoPath);
				if (type) {
					that.tabList[cindex].data[index].sportMatchVOS[xindex].homeTeamLogoPath = that.homeTeamLogo
				} else {
					that.tabList[cindex].data[index].sportMatchVOS[xindex].guestTeamLogoPath = that.guestTeamLogo
				}
				that.$forceUpdate();
			},
			
			// 获取导航
			getNavigationList(){
				let that = this;
				return new Promise( (res,rel) => {
					this.$req.req.queryNavigationList({
						navigationKey:'app_navigation_index'
					})
					.then( resp => {
						// console.log("首页导航",resp.data.data)
						// let rd = resp.data.data;
						// that.tabListAll = rd;
						// let rdarr = rd.filter(item => item.sort < 20),
						// 	nordarr = rd.filter(item => item.sort >= 20);
						// // that.tabList = rdarr;
						// that.tabList = [...that.tabList, ...rdarr];
						// that.tabListNo = nordarr;
						// res();
						let rd = [ 
						 {id:'', name:'全部', type:'5', sort: 0},
						 {id:'', name:'热门', type:'3', sort: 0},
						 {id:'', name:'完赛', type:'4', sort: 0},
						 ...resp.data.data];
						let rdarr = rd.filter(item => item.sort < 20),
							nordarr = rd.filter(item => item.sort >= 20);
						uni.setStorage({
						    key: 'indexTabList',
						    data: {
									rd:rd,
									rdarr:rdarr,
									nordarr:nordarr,
								},
						    success: function () {
						        console.log('缓存数据success');
										res();
						    }
						});
						
						
						
						
					})
					.catch(err => {
						// console.log("请求返回错误",err)
					})
				})
			},
			
			// 初始化分类
			loadtabList(){
				uni.getStorage({
				    key: 'indexTabList',
				    success: function (res) {
						that.tabListAll =res.data.rd;
						that.tabList = res.data.rdarr;
						that.tabListNo = res.data.nordarr;
						let tabarr = that.tabList;
						tabarr.forEach(item=>{
							item.data = [];
							item.loadMoreStatus = 0; //加载更多 0加载前，1加载中，2没有更多了
							item.refreshing = 0;
							item.offset = 1;
							item.isLastPage = false;
							// item.selDate = "";
							item.selDate = that.currentDate; // 默认当前日期
							item.scrollTop= 0; // 滑动高度
						})
						that.tabList = tabarr;
						that.loadNewsList('add');
				    }
				});
			},
			
			
			// 查询赛事列表数据
			loadNewsList(type){
				let tabItem = this.tabList[this.tabCurrentIndex];
				that.networkStatus = true;
				// console.log("选中",tabItem)
				//type add 加载更多 refresh下拉刷新
				if(type === 'add'){
					if(tabItem.loadMoreStatus === 2 || tabItem.isLastPage){
						console.log("分页状态",tabItem.isLastPage)
						return;
					}
					if(tabItem.data&&tabItem.data.length > 0){
						tabItem.offset++;
					}
					tabItem.loadMoreStatus = 1;
				}
				// #ifdef APP-PLUS
				else if(type === 'refresh'){
					tabItem.refreshing = true;
				}
				// #endif
				if(type === 'refresh'){
					tabItem.data = []; //刷新前清空数组
					tabItem.offset = 1;
					
					console.log('---------------------刷新---------------------');
					uni.showLoading({
						title: '加载中...',
						mask: true
					})
				}
				
				// '全部'标签只显示今日往后的数据
				if (tabItem.selDate == '' && tabItem.type == 5) {
					tabItem.selDate = this.currentDate
					console.log("'全部'标签 初始 查询时间：",tabItem.selDate);
				}
				
				let datas = {
					"date": tabItem.selDate,
					"id": String(tabItem.id) || '',
					"limit": that.limit,
					"offset": tabItem.offset,
					"type": Number(tabItem.type),
					"livePlatform": String(this.livePlatform)
				}
				// console.log('请求参数-->：',datas);
				// return;
				that.$req.reqc.queryAllEvents(datas)
				.then( res => {
					if(type === 'refresh'){
						uni.hideLoading();
					}
					// console.log("返回结果-->：",res)
					let list = res.data.data.list[0];
					
					if (list.length <= 0 && tabItem.selDate != '') {
						uni.showToast({
							icon: 'none',
							title: '暂无该日期数据',
							duration: 1500
						})
					}
					
					// 更新分页状态
					tabItem.isLastPage = res.data.data.isLastPage;
					// console.log("赛事列表",res.data.data.list)
					this.total = res.data.data.total;
					
					// 数据合并前裁剪主客队名称长度，最大字数：8
					list.forEach((item,index) => {
						let MatchArr = item.sportMatchVOS;
						for (let i = 0; i < MatchArr.length; i++) {
							// 主队名称
							if(MatchArr[i].homeTeamName && MatchArr[i].homeTeamName.length > 8){
								MatchArr[i].homeTeamName = MatchArr[i].homeTeamName.substring(0,8)
							}
							// 客队名称
							if(MatchArr[i].guestTeamName && MatchArr[i].guestTeamName.length > 8){
								MatchArr[i].guestTeamName = MatchArr[i].guestTeamName.substring(0,8)
							}
						}
					})
					
					// 赛事日期相同的数据合并
					if (tabItem.data.length > 0) {
						let TempArr = tabItem.data[tabItem.data.length-1]
						// console.log(TempArr, tabItem.data.length);
						let date = TempArr.dateString
						list.forEach ((item, index) => {
							if (item.dateString == date) {
								tabItem.data[tabItem.data.length-1].sportMatchVOS = TempArr.sportMatchVOS.concat(list[index].sportMatchVOS)
								list.splice(index, 1);
								// console.log('相同', tabItem.data[tabItem.data.length-1].sportMatchVOS);
							}
						})
					}
					
					let dateIndex = 0;
					list.forEach((item,index) => {
						// 获取与选中日期相同的数据下标
						if (this.dateRefresh === true) {
							let tempDate = item.dateString.split(/\s+/)[0]
							if (tempDate == tabItem.selDate) {
								dateIndex = index;
							}
						}
						
						item.sportMatchVOS.forEach((citem, cindex) => {
							citem.homeTeamLogoPath = 'https://images.weserv.nl/?url='+citem.homeTeamLogoPath
							citem.guestTeamLogoPath = 'https://images.weserv.nl/?url='+citem.guestTeamLogoPath
						})
						
						tabItem.data.push(item);
					})
					
					console.log('赛事列表数据：',tabItem.data);
					
					// 获取当前日期首次请求的数据条数（在数组最终生成后判断）
					if (tabItem.offset == 1) {
						that.firstLimit = tabItem.data[0]&&tabItem.data[0].sportMatchVOS.length || 0
						// console.log('firstLimit:',that.firstLimit);
						that.$forceUpdate();
					}
					
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;						
					}
					// 上滑加载、下拉刷新 处理状态 (返回数据长度小于零/数据长度与总数据量相等 → '没有更多数据了')
					if(type === 'add' || type === 'refresh'){
						// tabItem.loadMoreStatus = tabItem.data.length >= this.total ? 2 : 0;
						// console.log('是否为末页：',tabItem.isLastPage);
						tabItem.loadMoreStatus = tabItem.isLastPage ? 2 : 0;
					}
					// this.tabList[this.tabCurrentIndex] = tabItem;
					// console.log("全部数据",this.tabList)
					// console.log("全部数据",tabItem);
					// console.log("全部数据",this.tabList[this.tabCurrentIndex].data);
					// 二维数组，开启强制渲染
					this.$forceUpdate();
					
					// 滑动到指定日期的赛事列表
					/**
					 * 点击同一天时，无法定位所在日期
					 */
					if(type === 'refresh'){
						console.log('指向日期id属性-------->','active'+this.tabCurrentIndex+dateIndex);
						// $nextTick：在下次 DOM 更新循环结束之后，执行延迟回调
						this.$nextTick(() => {
							console.log('页面滚动前高度：',tabItem.scrollTop);
							if (this.dateRefresh) {
								this.getScrollTop('active'+this.tabCurrentIndex+dateIndex).then((res) => {
									this.dateRefresh = false;
									console.log('节点距离页面顶部距离：',res.top);
									tabItem.scrollTop = res.top-81;
									this.$forceUpdate();
									console.log('页面滚动后高度：',tabItem.scrollTop);
								});
							} else {
								tabItem.scrollTop = 0;
								this.$forceUpdate();
								console.log('重置页面滚动后高度：',tabItem.scrollTop);
							}
						})
					}
					
				}).catch(err => {
					console.log(err);
					// tabItem.loadMoreStatus = 2;
					
					if(type === 'refresh'){
						this.$refs.mixPulldownRefresh && this.$refs.mixPulldownRefresh.endPulldownRefresh();
						// #ifdef APP-PLUS
						tabItem.refreshing = false;
						// #endif
						tabItem.loadMoreStatus = 0;						
					}
					// 上滑加载、下拉刷新 处理状态 (返回数据长度小于零/数据长度与总数据量相等 → '没有更多数据了')
					if(type === 'add' || type === 'refresh'){
						tabItem.loadMoreStatus = tabItem.isLastPage ? 2 : 0;
					}
					uni.hideLoading();
					console.log("网络中断")
					that.networkStatus = false;
					this.$forceUpdate();
				})
			
			},
			
			//下拉刷新
			onPulldownReresh(){
				this.loadNewsList('refresh');
			},
			//上滑加载
			loadMore(){
				this.loadNewsList('add');
			},
			
			// 获取指定id属性 的高度
			getScrollTop(id) {
				return new Promise((resolve, reject) => {
					let el = uni.createSelectorQuery().in(this).select('#'+id);
					el.fields({
						rect: true,
					}, data => {
						resolve(data);
					}).exec();
				})
			},
			
			// 自定义标签页
			openCustom: function () {
				uni.navigateTo({
					// url: '/pages/index/customTag'
					// url: '/pages/index/newCustomTag?pageType=1&data='+JSON.stringify(this.tabList)+'&nodata='+JSON.stringify(this.tabListNo)
					url: '/pages/index/newCustomTag?pageType=1&data='+
						encodeURIComponent(JSON.stringify(this.tabList)) + 
						'&nodata=' + encodeURIComponent(JSON.stringify(this.tabListNo))
				})
			},
			
			// 自定义导航栏按钮点击事件
			clickNavBarButton: function (e) {
				// console.log(e) //子组件传递的参数
				if (e) {
					uni.navigateTo({
						url: '/pages/search/search'
					})
				} else {
					uni.navigateTo({
						url: '/pages/mine/mine'
					})
				}
			},
			
			
			//tab切换
			async changeTab(e){
				
				if(scrollTimer){
					//多次切换只执行最后一次
					clearTimeout(scrollTimer);
					scrollTimer = false;
				}
				let index = e;
				//e=number为点击切换，e=object为swiper滑动切换
				if(typeof e === 'object'){
					index = e.detail.current
				}
				if(typeof tabBar !== 'object'){
					tabBar = await this.getElSize("nav-bar")
				}
				//计算宽度相关
				let tabListcrollLeft = tabBar.scrollLeft;
				let width = 0; 
				let nowWidth = 0;
				//获取可滑动总宽度
				for (let i = 0; i <= index; i++) {
					let result = await this.getElSize('tab' + i);
					width += result.width;
					if(i === index){
						nowWidth = result.width;
					}
				}
				if(typeof e === 'number'){
					//点击切换时先切换再滚动tabbar，避免同时切换视觉错位
					this.tabCurrentIndex = index; 
				}
				//延迟300ms,等待swiper动画结束再修改tabbar
				scrollTimer = setTimeout(()=>{
					if (width - nowWidth/2 > windowWidth / 2) {
						//如果当前项越过中心点，将其放在屏幕中心
						this.scrollLeft = width - nowWidth/2 - windowWidth / 2;
					}else{
						this.scrollLeft = 0;
					}
					if(typeof e === 'object'){
						this.tabCurrentIndex = index; 
					}
					this.tabCurrentIndex = index; 
					
					
					//第一次切换tab，动画结束后需要加载数据
					let tabItem = this.tabList[this.tabCurrentIndex];
					if(this.tabCurrentIndex !== 0 && tabItem.loaded !== true){
						this.loadNewsList('add');
						tabItem.loaded = true;
					}
				}, 300)
				
			},
			//获得元素的size
			getElSize(id) {
				return new Promise((res, rej) => {
					let el = uni.createSelectorQuery().select('#' + id);
					el.fields({
						size: true,
						scrollOffset: true,
						rect: true
					}, (data) => {
						res(data);
					}).exec();
				});
			},
			//设置scroll-view是否允许滚动，在小程序里下拉刷新时避免列表可以滑动
			setEnableScroll(enable){
				if(this.enableScroll !== enable){
					this.enableScroll = enable;
				}
			},
			
			// 直播详情
			openLive: function (e, cindex) {
				// console.log('传递参数：', e);return;
				// matchState：比赛状态 0正常 1延期 2时间待定	↓
				if ((e.matchLiveSourceDOS.length <= 0 || e.matchState != 0) && cindex != 2) {
					let msg = '';
					switch (e.matchState){
						case 1:
						case 2:
							msg = e.matchIntroduction
							break;
						default:
							msg = '当前项没有直播源'
							break;
					}
					uni.showToast({
						icon: 'none',
						title: msg
					})
				} else {
					// #ifdef APP-PLUS
					this.uniSkip.navigateTo({
						url: '/pages/index/player',
						data: {
							matchId:e.matchId,
							livePlatform:this.livePlatform
						}
					});
					// #endif					
					// #ifndef APP-PLUS
					uni.navigateTo({
						url: '/pages/index/player?matchId=' + e.matchId + '&livePlatform=' + this.livePlatform
						// url: '/pages/index/player?matchId=' + e.matchId
					})
				// #endif
				}
			},
			// 进入直播播放页(webview)
			playNow: function (item, cindex, index, xindex) {
				let that = this,
					source = that.tabList[cindex].data[index].sportMatchVOS[xindex].matchLiveSourceDOS,
					// source = item.matchLiveSourceDOS,
					status = false, // 判断是否解析第一条直播源
					newPath;
					uni.navigateTo({
						url: '/pages/index/player?mid=1'
					})
					return;
				// console.log(cindex, index, xindex);
				
				for (let i = 0; i < source.length; i++) {
					if (source[i].valid == 0) {
						merge(source[i], 1)
					} else {
						if ((i+1) == source.length) {
							status = true;
						}
						continue;
					}
				}
				// 无可用直播源时，则解析第一条直播源
				if (status && source[0].valid == 1) {
					uni.showLoading({
						title: '请稍后...'
					})
					let datas = {
						"sourcePathId": source[0].sourceId
					}
					// console.log('解析直播源参数(id)：',datas);
					// 解析直播源
					that.$req.reqc.analysisMatchLiveSource(datas)
					.then(res => {
						// console.log("解析直播信息",res)
						uni.hideLoading();
						if (res.data.resultCode === 1 && res.statusCode == 200) {
							let data = res.data.data;
							// 修改当前的解析解析状态值'valid'为 → 0:已解析
							source[0].valid = '0';
							// console.log("*****链接已更新*****")
							// console.log("当前项解析状态："+(source[0].valid == 0 ? '已解析' : '未解析'))
							
							merge(data, 1)
						}
						else if (res.data.resultCode !== 1 && res.statusCode == 200) {
							// uni.showToast({
							// 	icon: 'none',
							// 	title: res.data.resultMsg,
							// })
							merge(source[0], 0)
						}
					}).catch(err => {
						uni.hideLoading();
						uni.showToast({
							icon: 'none',
							title: '请稍后再试'
						})
						// console.log(err);
					})
				}
				
				function merge (data, type) {
					// console.log("********链接 "+ (type == 0 ? '不可' : '可') +" 用********")
					// console.log('(传递)解析后数据：', data)
					// 1、匹配播放地址(0：解析，1：不解析)
					if (data.isAnalysis == 0) {
						newPath = data.analysisPlayPathWeb
					}
					if (data.isAnalysis == 1) {
						newPath = data.notAnalysisPlayPath
					}
					// if (newPath == '' || newPath == null) {
					// 	uni.showToast({
					// 		icon: 'none',
					// 		title: '当前播放源不可用'
					// 	})
					// 	return;
					// }
					let temp = {
						matchId: data.matchId,
						sourceId: data.sourceId,
						sourcePath: newPath,
						usable: type
					}
					// console.log(temp);
					uni.navigateTo({
						url: '/pages/webview/webview?data=' + encodeURIComponent(JSON.stringify(temp))
					})
				}
			},
			
			// (日历页)日期选择
			openCalendar: function () {
				// 获取日历的初始与结束日期
				let datas = {
					"date": this.currentDate, // 选中的月份,其他月份默认日期为01
					"matchId": 0,
					"sourceType": 0, // 类型 0直播 1录像
					"viedoType": 0,
				}
				// console.log('查询日期传参：',datas);
				uni.showLoading({
					title: '请稍后...'
				})
				this.$req.reqc.queryMatchByVideoDetail(datas)
				.then( res => {
					uni.hideLoading();
					let startDate, endDate;
					let list = res.data.data
					if (list && list.length > 0) {
						console.log('初始日期：',list[0],' 结束日期：',list[list.length-1]);
						// 直播只能看当天和以后的数据
						// startDate = list[0].date;
						startDate = this.currentDate;
						endDate = list[list.length-1].date;
					}
					let sourceType = 0; // 类型 0直播 1录像
					let dateObj = {startDate, endDate, sourceType}
					uni.navigateTo({
						url: '/pages/index/eventCalendar?item='+ encodeURIComponent(JSON.stringify(dateObj))
					})
				})
				.catch( err => {
					uni.hideLoading();
					// console.log(err);
				})
			},
			// 获取选中日期的赛事数据
			RefreshMatchData(date) {
				this.tabList[this.tabCurrentIndex].selDate = date;
				// console.log('查询日期：',this.tabList[this.tabCurrentIndex].selDate);
				this.dateRefresh = true; // 指定日期刷新
				this.loadNewsList('refresh');
			},
			// 重置数据
			reset: function () {
				// 改变当前标签页的滑动高度，使(scrollTop=0)页面置顶生效
				this.tabList[this.tabCurrentIndex].scrollTop = -1;
				
				// '全部'标签只显示今日往后的数据，其他清空日期
				// if (this.tabList[this.tabCurrentIndex].type == 5) {
					this.tabList[this.tabCurrentIndex].selDate = this.currentDate
					// console.log('查询时间已重置：',this.tabList[this.tabCurrentIndex].selDate);
				// } else {
				// 	this.tabList[this.tabCurrentIndex].selDate = '';
				// 	console.log('查询日期已清空');
				// }
				this.loadNewsList('refresh');
			},
		},
		filters: {
			CaptureTime: function (str) {
				// return str.trim().split(/\s+/)[1];
				let time = str.trim().split(/\s+/)[1];
				let hour = time.split(/:/)[0] + ':' + time.split(/:/)[1]
				return hour;
			},
			ModifyBtnType: function(obj) {
				// console.log(obj);
				if (obj.isLive == 0) {
					return '观看录像';
				}
				else if (obj.isHighlights == 0) {
					return '观看集锦';
				}
				else if (obj.matchReuslt) {
					return '查看战报';
				}
				else if (obj.matchProspect) {
					return '查看前瞻';
				}
				else if (obj.matchTextLivePath) {
					return '比赛详情';
				}
				else {
					// 结束时间超过1小时
					if (obj.isOverHours == 0) {
						return '聊天室';
					} else {
						// 结束时间1小时内
						return '直播室';
					}
				}
				
			}
		}
	}
</script>

<style lang='scss' scoped>
	
	page, .content{
		background-color: #f8f8f8;
		/* height: calc(100vh - var(--status-bar-height)); */
		/* #ifdef H5 */
		height: 100%;
		/* #endif */
		/* #ifndef H5 */
		height: 100vh;
		/* #endif */
		/* height: 100%; */
		overflow: hidden; 
		width: 100vw;
	}
	.networkClass{
		width: 750rpx;
		height: calc(100% - 74rpx);
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		
	}

	/* 顶部tabbar */
	
	.addTag {
		position: absolute;
		/* #ifdef H5 */
		top: 44px;
		/* #endif */
		/* #ifdef APP-PLUS */
		/* 使用固定像素单位，避免不同手机出现位置错乱的问题 */
		top: calc(44px + var(--status-bar-height));
		/* #endif */
		right: 0;
		width: 80rpx;
		height: 72rpx;
		background: linear-gradient(to right, rgba(255,255,255,0), rgba(255,255,255,1));
		background-size: cover;
		background-image: url(../../static/images/home_add.png);
		z-index: 10;
	}
	.nav-bar{
		/* 标签栏顶部固定 → 防止 iPhone端 出现下拉移位的问题 */
		position: fixed;
		top: 0;
		
		position: relative;
		z-index: 10;
		width: 100%;
		height: 74rpx;
		box-sizing: border-box;
		flex-direction: row;
		white-space: nowrap;
		background-color: #FFFFFF;
		border-bottom: 1px solid #F2F2F2;
	}
	.nav-bar .uni-tab-item:last-child{
		margin-right: 80upx;
	}
	
	
	/* 赛事日期 */
	.matchDate {
		height: 58rpx;
		line-height: 58rpx;
		text-align: center;
		font-size: 13px;
		font-weight: bold;
		background-color: #F7F7F7;
		position: relative;
	}
	
	/* 赛事日历 */
	.calendar {
		/* position: fixed; */
		/* #ifdef H5 */
		/* top: calc(88rpx + 74rpx); */
		/* #endif */
		/* #ifdef APP-PLUS */
		/* top: calc(88rpx + 74rpx + var(--status-bar-height)); */
		/* #endif */
		position: absolute;
		top: 0;
		right: 0;
		
		z-index: 100;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 180rpx;
		height: 58rpx;
		background-color: #F7F7F7;
		border-top-left-radius: 40rpx;
		border-bottom-left-radius: 40rpx;
		overflow: hidden;
		
		.icon {
			width: 40rpx;
			height: 40rpx;
			background-size: cover;
		}
		/* .reset {
			background-image: url(../../static/images/index_reset.png);
		} */
		.reset {
			height: 58rpx;
			line-height: 58rpx;
			padding: 0 20rpx;
			color: #999999;
		}
		.calend {
			width: 43rpx;
			margin: 0 24rpx 0 0;
			background-image: url(../../static/images/index_calendar.png);
		}
	}
	
	/* 列表项 */
	.list-item {
		display: flex;
		flex-direction: column;
		/* height: 226rpx; */
		max-height: 246rpx;
		box-sizing: border-box;
		/* padding: 0 106rpx; */
		padding-bottom: 20rpx;
		/* border-bottom: 1px solid #F2F2F2; */
		border-bottom: 1px solid #EDEDED;
		overflow: hidden;
		position: relative;
		
		/* 标题 */
		.gameTitle {
			margin: 0 106rpx;
			text-align: center;
			height: 55rpx;
			
			.time, .matchTitle {
				font-size: 11px;
			}
			.time {
				position: absolute;
				top: 5px;
				left: 10px;
			}
			.matchTitle {
				margin-top: 14rpx;
				line-height: 30rpx;
				
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				/* 文本内容超出1行 显示省略符 */
				-webkit-line-clamp: 1;
				-webkit-box-orient: vertical;
			}
		}
		/* 比赛信息 */
		.gameInfo {
			display: flex;
			align-items: center;
			justify-content: space-between;
			min-height: 88rpx;
			padding: 0 80rpx;
			
			image {
				width: 88rpx;
				height: 88rpx;
				border-radius: 50%;
			}
			.leftTeam, .rightTeam {
				display: flex;
				flex-direction: column;
				align-items: center;
				/* 赋值宽度，使中间按钮在flex布局下始终保持在中间 */
				width: 200rpx;
			}
			.teamName {
				width: 200rpx;
				height: 40rpx;
				line-height: 40rpx;
				text-align: center;
				font-size: 12px;
				overflow: hidden;
			}
			.liveBtn {
				min-width: 150rpx;
				max-width: 150rpx;
				height: 44rpx;
				line-height: 44rpx;
				margin-bottom: 20rpx;
				text-align: center;
				font-size: 11px;
				color: #FFFFFF;
				border-radius: 25rpx;
				background-color: #1B1B30;
			}
			.disable {
				background-color: #CCCCCC;
			}
		}
		.prompt {
			margin: 0 106rpx;
			text-align: center;
			font-size: 10px;
			line-height: 14px;
			color: #666666;
			/* 超出宽度后就隐藏 */
			overflow: hidden;
			/* 规定段落中的文本不换行 */
			white-space:nowrap;
			/* 当文本内容溢出时显示省略标记 */
			text-overflow: ellipsis;
		}
	}
	
	

	/* 可滚动窗体高度（swiper外层刷新组件高度），100vh(相对于视窗的高度)  */
	/* calc(100vh - 38px - 50px)：100vh(整个浏览器窗口高度) - 38px(顶部标签滑动栏高度) - 50px(底部tabBar栏高度(固定)) 的大小 */
	.panel-content {
		/* height: calc(100vh - 74rpx - var(--status-bar-height));
		max-height: calc(100vh - 74rpx - var(--status-bar-height)); */
	}
	
	.swiper-box{
		height: 100%;
		/* 可滚动区域高度 calc(100vh - 38px - 50px - 44px)：100vh(整个浏览器窗口高度) - 38px(顶部标签栏高度) - 50px(底部tabBar栏高度(固定)) - 44px(顶部(自定义)状态栏高度) 的大小 */
		/* var(--status-bar-height) */
		/* height: calc(100vh - 74rpx - 100rpx - 88rpx - var(--status-bar-height)); */
		/* height: calc(100vh - 74rpx - var(--status-bar-height)); */
		/* margin-bottom: 88rpx; */
		/* padding-bottom: 60rpx; */
		/* background-color: red; */
	}

	.panel-scroll-box{
		/* #ifdef H5 */
		height: calc(100% - 74rpx - var(--status-bar-height));
		/* #endif */
		/* #ifndef H5 */
		height: calc(100vh - 74rpx - 88rpx - var(--status-bar-height));
		/* #endif */
		
		/* height: 100%; */
		background-color: #FFFFFF;
	}
	
	.uni-tab-item {
		display: inline-block;
		flex-wrap: nowrap;
		padding-left: 14.5px;
		padding-right: 14.5px;
		/* border: 1px solid red; */
		position: relative;
	}
	
	/* 滚动tab 标签 */
	.uni-tab-item-title {
		color: #999999;
		font-size: 12px;
		height: 38px;
		line-height: 38px;
		flex-wrap: nowrap;
		white-space: nowrap;
	}
	.uni-tab-item-title-active {
		color: #000000;
	}
	/* 滚动tab 底部选中条 */
	.uni-tab-item-border {
		position: absolute;
		top: 85%;
		left: 50%;
		transform: translate(-50%,-50%);
	}
	.uni-tab-item-border-active {
		width: 14px;
		height: 2px;
		background-color: #000000;
	}
	
	.swiper {
		/* display: block; */
		height: 100%;
	}
	
	.swiper-item {
		display: flex;
		flex: 1;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
		box-sizing: border-box;
		
		.list {
			width: 100%;
			/* height: 100%; */
			/* 状态栏的高度为 var(--status-bar-height) 此变量为uni-app框架提供仅在在css生效 */
			/* 38px → 标签栏38px */
			height: calc(100% - 74rpx);
		}
	}
</style>
