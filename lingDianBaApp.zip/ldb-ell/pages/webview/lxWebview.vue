<template>
	<view>
		<view class="">
			<web-view ref="webview" :src="sourcePath"></web-view>
		</view>
	</view>
</template>

<script>
	let that;
	export default {
		data() {
			return {
				matchId: null,	// 赛事id
				sourceId: null,	// 播放源id
				sourcePath: '',	// 播放链接
				usable: null,	// 可用状态
				title:'',
			};
		},
		onLoad: function (option) {
			that = this;
			// 接收参数
			let temp = JSON.parse(decodeURIComponent(option.data));
			console.log(temp);
			that.matchId = temp.matchId;
			that.sourceId = temp.sourceId;
			that.sourcePath = temp.sourcePath;
			// that.sourcePath = 'http://ivi.bupt.edu.cn/hls/cctv1hd.m3u8';
			that.usable = temp.usable;
			if(temp.title){
				that.title = temp.title
			}else{
				that.title = '录像/集锦'
			}
			that.webViewRend();
			if (that.usable === 0) {
				uni.showToast({
					icon: 'none',
					title: '当前播放源不可用'
				})
			}
			
			uni.showLoading({
				title: '请稍后...',
				mask: true
			})
			let timer = setTimeout(function() {
				clearTimeout(timer)
				uni.hideLoading();
			}, 1500);
		},
		methods: {
			webViewRend(){
				// let pages = getCurrentPages(); //当前页
				// let v = pages[pages.length - 1]; 
				// currentWebview = v.$getAppWebview();
				var currentWebview = this.$scope.$getAppWebview();
				// var currentWebview = plus.webview.currentWebview();
				currentWebview.checkRenderedContent({type:'auto',interval:100},function(e){
					if(e.rendered){
						console.log("渲染完成")
					// var t = document.getElementById('video').innerHTML;
					// alert(t)
						setTimeout(function() {
							uni.setNavigationBarTitle({
								title:that.title
							})
						}, 2000);
					}else{
						console.log("渲染未完成")
						setTimeout(function() {
							uni.setNavigationBarTitle({
								title:that.title
							})
						}, 2000);
					}
				},function(err){
					console.log("渲染失败")
					console.log(err);
					setTimeout(function() {
						uni.setNavigationBarTitle({
							title:that.title
						})
					}, 2000);
					
				})
			},
		},
	}
</script>

<style lang="scss">

</style>
