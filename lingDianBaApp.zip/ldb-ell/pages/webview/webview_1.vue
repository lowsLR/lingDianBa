<template>
	<view>
		<view class="" id="iframeView">
			<!-- #ifdef H5 -->
			<web-view ref="webview" :src="sourcePath"></web-view>
			<!-- #endif -->
		</view>
	</view>
</template>

<script>
	let that,
		currentWebview = null,
		ws = null;
	export default {
		data() {
			return {
				sourceName: '',		// 信号源名称
				sourcePath: '',		// 信号链接
				sourceId: '',		// 信号源id
				mainId: '',			// 赛事/电视id
				tvName: '',			// 电视名称
				invalidMessage: '',	// 提示信息
				valid: '0',			// 可用状态
			};
		},
		onUnload() {
			// #ifdef APP-PLUS
			// plus.screen.lockOrientation('portrait-primary'); //锁定
			// #endif
		},
		onLoad: function(option) {
			that = this;
			// #ifdef APP-PLUS
			// plus.screen.unlockOrientation();
			// #endif
			
			// 接收参数
			let temp = JSON.parse(decodeURIComponent(option.data));
			console.log(temp);
			that.sourceId = temp.sourceId;
			that.sourcePath = temp.sourcePath;
			// that.sourcePath = 'http://ivi.bupt.edu.cn/hls/cctv1hd.m3u8';
			
			// 判断对象是否存在某个字段：obj.hasOwnProperty("key")
			if (temp.hasOwnProperty("tvName")) {
				console.log(temp.tvName);
				that.tvName = temp.tvName;
			}

			if (temp.sourceName) {
				that.sourceName = that.tvName == '' ?  temp.sourceName : (that.tvName + '\xa0\xa0' + temp.sourceName)
			} else {
				that.sourceName = '录像/集锦'
			}
			uni.setNavigationBarTitle({
				title: that.sourceName
			})

			// #ifndef H5
			ws = plus.webview.create(that.sourcePath, 'iframeView', {
				top: uni.getSystemInfoSync().statusBarHeight + 44
			}, {
				preload: 'preload webview'
			});
			currentWebview = this.$mp.page.$getAppWebview();
			currentWebview.append(ws);
			// #endif


			uni.showLoading({
				title: '请稍后...',
				mask: true
			})
			let timer = setTimeout(function() {
				clearTimeout(timer)
				uni.hideLoading();
			}, 1500);
		},
		// 页面销毁
		destroyed() {
			// #ifndef H5
			currentWebview = ws = null;
			plus.webview.close(ws);
			plus.webview.close(currentWebview);
			this.$mp.page.$getAppWebview().close();
			// #endif
		},
		methods: {
			
		},
	}
</script>

<style lang="scss">

</style>
