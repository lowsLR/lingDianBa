<template>
	<view>
		<web-view :src="link"></web-view>
	</view>
</template>

<script>
	let that;
	export default {
		data() {
			return {
				link: '',
			}
		},
		onLoad: function (option) {
			that = this;
			let temp = JSON.parse(decodeURIComponent(option.data));
			// console.log(temp);
			that.link = temp.link;
			uni.setNavigationBarTitle({
				title: that.link
			})
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
