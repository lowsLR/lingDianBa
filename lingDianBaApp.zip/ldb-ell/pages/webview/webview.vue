<template>
	<view class="">
		<web-view ref="webview" :src="sourcePath"></web-view>
	</view>
</template>

<script>
	let that;
	export default {
		data() {
			return {
				sourceName: '',		// 信号源名称
				sourcePath: '',		// 信号链接
				sourceId: '',		// 信号源id
				mainId: '',			// 赛事/电视id
				tvName: '',			// 电视名称
				invalidMessage: '',	// 提示信息
				valid: '0',			// 可用状态
			};
		},
		
		onLoad: function(option) {
			that = this;
			
			// 接收参数
			let temp = JSON.parse(decodeURIComponent(option.data));
			console.log(temp);
			that.sourceId = temp.sourceId;
			that.sourcePath = temp.sourcePath;
			// that.sourcePath = 'http://ivi.bupt.edu.cn/hls/cctv1hd.m3u8';
			
			// 判断对象是否存在某个字段：obj.hasOwnProperty("key")
			if (temp.hasOwnProperty("tvName")) {
				console.log(temp.tvName);
				that.tvName = temp.tvName;
			}

			if (temp.sourceName) {
				that.sourceName = that.tvName == '' ?  temp.sourceName : (that.tvName + '\xa0\xa0' + temp.sourceName)
			} else {
				that.sourceName = '录像/集锦'
			}
			uni.setNavigationBarTitle({
				title: that.sourceName
			})
		},
		onUnload() {
			
		},
		// 页面销毁
		destroyed() {
			
		},
		methods: {
			
		},
	}
</script>

<style>

</style>