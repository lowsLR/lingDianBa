import Vue from 'vue'
import App from './App'
import { http } from '@/utils/luch-request/index.js' // 全局挂载引入，配置相关在该index.js文件里修改

/*color头部模板*/

import cuCustom from './colorui/components/cu-custom.vue'
Vue.component('cu-custom',cuCustom)

import bwAdvertising from '@/pages/component/bw-advertising.vue'
Vue.component('bwAdvertising',bwAdvertising)

import '@/common/ican-clipBoard.js' // 引入H5剪切板

// import { pathToBase64, base64ToPath } from '@/common/image-tools/index.js' // 图像转换工具
 
// 引入封装好的可用于uni-app的axios插件
import axios from '@/common/plugins/axios/index'

import req from '@/api/index'//挂载请求



// 引入underScore工具函数库
import underscore from 'underscore'

//引入vuex
import store from './store'


import apiconfig from 'api/apiconfig.js'
import mysocket from 'api/mysocket.js'

import uniSkip from 'api/uni-skip.js'

// #ifdef H5
import VideoPlayer from 'vue-video-player';

// require('video.js/dist/video-js.css');
require('static/videojs.min.css');
require('vue-video-player/src/custom-theme.css');
const hls = require('videojs-contrib-hls');
Vue.use(hls)
Vue.use(VideoPlayer)
// #endif

import directives from '@/bw/js/directives.js';
Vue.use(directives);

import utils from '@/api/util.js';
Vue.prototype.utils = utils;


Vue.prototype.uniSkip=uniSkip



// var express = require('express');
// var proxy = require('express-http-proxy');
// var router = express.Router();
// var urlParse = require('url').parse;
// var controller = require('common/controller.js');
// // 代理直播源
// router.get('/videos', controller.videoProxy);
// router.use(
//   '/tsProxy',
//   proxy(
//     function(req) {
//       var target = urlParse(decodeURIComponent(req.query.url))
//       return target.host
//     },
//     {
//       parseReqBody: false, // 去除默认的 body，解决某些播放源 411 问题
//       proxyReqPathResolver: function(req) {
//         var target = urlParse(decodeURIComponent(req.query.url))
//         return target.path
//       },
//     }
//   )
// )



Vue.prototype.$apiconfig = apiconfig;

Vue.prototype.$mysocket =mysocket;

Vue.prototype.$store = store
Vue.prototype.$req = req 
Vue.prototype.$_ = underscore
Vue.prototype.$axios = axios()
Vue.prototype.$http = http

Vue.prototype.timesToTime = function(timestamp){
		    let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
		    let Y = date.getFullYear() + '年';
		    let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '月';
		    let D = date.getDate() + '日 ';
		    let h = date.getHours() + ':';
		    let m = date.getMinutes()<10?'0'+date.getMinutes()+ ':':date.getMinutes()+ ':';
		    let s = date.getSeconds()<10?'0'+date.getSeconds():date.getSeconds();
		    return Y + M + D + h + m + s;
}

Vue.prototype.navTo = function(url,data){
	 uni.navigateTo({
		url: url,
		success: res => {},
		fail: () => {},
		complete: () => {}
	 });
}

Vue.prototype.navBack = function(n = 1){
	uni.navigateBack({
		delta: n
	});
}


Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App,
	store
})
app.$mount()
