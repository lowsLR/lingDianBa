function log(t) {
	console.log(t);
}

module.exports = {
	log
}