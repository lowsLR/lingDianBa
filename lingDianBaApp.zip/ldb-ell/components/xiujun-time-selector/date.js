//字符串拼接
function strFormat(str) {
	return str < 10 ? `0${str}` : str
}


//时间戳转日期
export function timeStamp(time) {
	const dates = new Date(time)
	const year = dates.getFullYear()
	const month = dates.getMonth() + 1
	const date = dates.getDate()
	const day = dates.getDay()
	const hour = dates.getHours()
	const min = dates.getMinutes()
	const days = ['日', '一', '二', '三', '四', '五', '六']
	return {
		allDate: `${year}/${strFormat(month)}/${strFormat(date)}`,
		date: `${strFormat(month)}-${strFormat(date)}`, //返回的日期 07-01
		day: `周${days[day]}`, //返回的礼拜天数  星期一
		hour: strFormat(hour) + ':' + strFormat(min) //返回的时钟 08:00
	}
}

// 根据 日期 与 (指定)下标 获取指定的七天，参考 dateData()方法
export function getSevenDate(optDate, index) {
	// console.log(optDate, index);
	const time = []
	let now = null;
	if (optDate == '' || optDate == null) {
		now = new Date().getTime() // 获取当前日期的时间戳 (13位数,毫秒)
	} else {
		now = new Date(optDate).getTime() // 获取指定日期的时间戳
	}
	let timeStr = 3600 * 24 * 1000 //一天的时间戳
	for (let i = 0; i < 7; i++) {
		const timeObj = {}
		// \是转义的意思，\/代表的是/字符
		timeObj.reqDate = timeStamp(now - timeStr * (index - i)).allDate.replace(/\//g,"-") // 完整日期(转换格式)
		timeObj.allDate = timeStamp(now - timeStr * (index - i)).allDate // 完整日期
		timeObj.date = timeStamp(now - timeStr * (index - i)).date //保存日期 (计算前七天的日期)
		timeObj.timeStamp = now - timeStr * (index - i) //保存时间戳
		if (i == index) {
			let curDate = new Date(),
				today = `${curDate.getFullYear()}/${strFormat(curDate.getMonth()+1)}/${strFormat(curDate.getDate())}`
			if (timeObj.allDate == today) {
				timeObj.week = '今天'
			} else {
				timeObj.week = timeStamp(now - timeStr * (index - i)).day
			}
		}
		else {
			timeObj.week = timeStamp(now - timeStr * (index - i)).day
		}
		time.push(timeObj)
		// time.unshift(timeObj)
	}
	return time
}


//获取最近7天的日期和礼拜天数
export function dateData(optDate) {
	const time = []
	let now = null;
	if (optDate == '' || optDate == null) {
		now = new Date().getTime() // 获取当前日期的时间戳 (13位数,毫秒)
	} else {
		now = new Date(optDate).getTime() // 获取指定日期的时间戳
	}
	let timeStr = 3600 * 24 * 1000 //一天的时间戳
	for (let i = 0; i < 7; i++) {
		const timeObj = {}
		// \是转义的意思，\/代表的是/字符
		timeObj.reqDate = timeStamp(now - timeStr * i).allDate.replace(/\//g,"-") // 完整日期(转换格式)
		timeObj.allDate = timeStamp(now - timeStr * i).allDate // 完整日期
		// timeObj.date = timeStamp(now + timeStr * i).date //保存日期
		timeObj.date = timeStamp(now - timeStr * i).date //保存日期 (计算前七天的日期)
		// timeObj.timeStamp = now + timeStr * i //保存时间戳
		timeObj.timeStamp = now - timeStr * i //保存时间戳
		if (i == 0) {
			let curDate = new Date(),
				today = `${curDate.getFullYear()}/${strFormat(curDate.getMonth()+1)}/${strFormat(curDate.getDate())}`
			if (timeObj.allDate == today) {
				timeObj.week = '今天'
			} else {
				timeObj.week = timeStamp(now - timeStr * i).day
			}
		} 
		// else if (i == 1) {
		// 	timeObj.week = '明天'
		// 	// timeObj.week = timeStamp(now + timeStr * i).day
		// } else if (i == 2) {
		// 	timeObj.week = '后天'
		// }
		else {
			timeObj.week = timeStamp(now - timeStr * i).day
		}
		// time.push(timeObj)
		time.unshift(timeObj)
	}
	return time
}