<template>
	<view class="container">
		<!-- tab栏 -->
		<scroll-view class="scroll-view_H" scroll-x>
			<block v-for="(item,index) in dateArr" :key="index">
				<div class="flex-box" @click="selectDateEvent(index)" :style="{'border-bottom':index==dateActive ? '2px solid ' + selectedTabColor : ''}">
					<view class="date-box">
						<text class="days" :style="{color:index==dateActive?selectedTabColor:'#999999'}">{{item.week}}</text>
						<text class="date" :style="{color:index==dateActive?selectedTabColor:'#999999'}">{{item.date}}</text>
					</view>
				</div>
			</block>
		</scroll-view>
	</view>
</template>

<script>
import {dateData,timeStamp} from './date.js'
export default {
	props:{
		//选中的tab颜色
		selectedTabColor:{
			type:String,
			// default:'red'
			// default:'#0092D5'
			default:'#333333'
		},
	},
	data(){
		return{
			dateArr:[],//日期数据
			// dateActive: 6,//选中的日期索引
			dateActive: -1,//选中的日期索引（默认未选中）
			optDate:'',//选择的日期数据
		}
	},
	created() {
		let myDate = new Date();
		this.optDate = myDate.getFullYear() + '/' + (myDate.getMonth()+1 >= 10 ? myDate.getMonth()+1 : '0'+(myDate.getMonth()+1)) + '/' + (myDate.getDate() >= 10 ? myDate.getDate() : '0'+(myDate.getDate()))
		// console.log(this.optDate);
		//获取日期tab数据
		this.dateArr = dateData(this.optDate)
		// this.selectDateEvent(6);	//默认选中的日期
	},
	methods:{
		selectDateEvent(index){
			// 点击相同日期：取消选中，否则赋值选中日期的下标
			this.dateActive = this.dateActive == index ? -1 : index;
			// this.dateActive = index
			
			// this.selectDate = `${this.dateArr[index]['date']}(${this.dateArr[index]['week']})`
			// this.$emit('selectTime',`${this.selectDate}`)
			this.$emit('selectTime', this.dateArr[index])
		},
		childMethod(date) {
			console.log('childMethod do...')
			let val = date.replace(/-/g,"/")
			if (this.optDate == val) {
				let timer = setTimeout(function() {
					uni.showToast({
						icon: 'none',
						title: '当前为目标日期'
					})
					clearTimeout(timer)
				}, 10);
				return;
			} else {
				this.optDate = val
			}
			// let ymd = optDate.split("/")
			// console.log(new Date(optDate).getTime());
			// new Date("2018/09/09 12:30:22").getTime();
			
			// 重置默认选中日期
			this.dateActive = 6
			
			// 重新获取日期tab数据
			this.dateArr = dateData(this.optDate)
		},
		// 取消选中的日期
		UncheckDate: function () {
			this.dateActive = -1
		},
	}
};
</script>

<style lang="scss" scoped>
.container{
	view,text,image{
		box-sizing: border-box;
	}
	scroll-view{
		width: 100%;
		white-space: nowrap;
		height: 100%;
		padding: 0 80rpx 0 8rpx;
		position: relative;
		&::after{
			background: #CCCCCC;
			content: '';
			display:block;
			width: 100%;
			height: 1px;
			position: absolute;
			bottom: 0;
			left: 0;
			transform:scaleY(0.5) 
		}
		.flex-box{
			display: inline-block;
			height: 100%;
			// padding: 0 20rpx;
			margin: 0 16rpx;
			box-sizing: border-box;
			.date-box{	
				display: flex;
				height: 100%;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				font-size: 24rpx;
				line-height: 15px;
			}
		}
		
	}
}
</style>
