import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
    state: {
        forcedLogin: false, // 是否需要强制登录
        hasLogin: false,	// 是否已登录
        userName: "",
		token:'',
		eventList:[],
		
		// 广告状态
		ADstatus: {
			syAD1: true, // 首页广告1
			syAD2: true, // 首页广告2
			
			lxAD1: true, // 录像广告1
			lxAD2: true, // 录像广告2
			
			spAD1: true, // 视频广告1
			spAD2: true, // 视频广告2
			
			xwAD1: true, // 新闻广告1
			xwAD2: true, // 新闻广告2
			
			zbszbAD: true, // 直播室直播广告
			zbsjjAD: true, // 直播室集锦广告
			
			spxqAD: true, // 视频详情广告
			dsxqAD: true, // 电视详情广告
			
			bfqAD: true, // 播放器广告(录像)
		}
    },
    mutations: {
		// 修改广告状态
		modifyAdStatus(state, obj) {
			state.ADstatus[obj.name] = false;
		},
		
        login(state, userName) {
            state.userName = userName || '新用户';
            state.hasLogin = true;
        },
        logout(state) {
            state.userName = "";
            state.hasLogin = false;
			state.token = '';
        },
		setUserName(state,userName) {
			state.userName = userName;
		},
		setToken(state,token) {
			state.token = token;
		},
		setEventList(state,eventList) {
			state.eventList = eventList;
		},
    }
})

export default store
