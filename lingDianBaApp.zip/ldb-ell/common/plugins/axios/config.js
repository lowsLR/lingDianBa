/*
 * @Description: DIY http request config
 * @Author: Edmund
 * @Email: q1592193221@gmail.com
 * @Date: 2019-11-07 14:44:56
 * @LastEditTime: 2019-11-21 17:53:48
 * @LastEditors: Edmund
 */
import Vue from 'vue'

import Interceptor from "./core/interceptor"
import envConfig from '@/config.js'
import store from '@/store/index';
// import axios from "./index"
// // 拿取token
// const token = uni.getStorageSync('user').token
// // 拿取系统信息
// const systemInfo = uni.getSystemInfoSync()
export const globalInterceptor = {
	request: new Interceptor(),
	response: new Interceptor()
}

/**
 * @Description: 全局配置 (只能配置 静态数据)
 * @param {String} `baseURL` 请求的基准url
 * @param {String} `content-type` 默认为 application/json
 * @param {String}  `content-type`设置特殊参数 或 配置其他会导致触发 跨域 问题,出现跨域会直接进入响应拦截器的catch函数中
 */
// console.log("store数据",store.state.token);
// let token = '';

// 获取token
const getTokenStorage = () => {
	let token;
  try {
    token = uni.getStorageSync('token') || ''
	// token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJtb2JpbGVQaG9uZSI6IjEzNjM4NjQyNDAwIiwiZW5hYmxlUGFzc3dvcmQiOiIxMjM0NTYiLCJpc3MiOiJjaHVuYm9fdXNlciIsImV4cCI6MTU3OTgzMzE2NCwibm9uY2VTdHIiOiJjRUFBTCJ9.JrVZe0INFQqTWaE2hOn6WkJxz9qimEXpLnqEsjjJN6w'
	// console.log(store.state.token);
  } catch (e) {
  }
  return token
}

export const config = {
	baseURL: envConfig.dev.BASE_URL,
	// baseURL: envConfig.test.testURL,
	// baseURL: envConfig.test.BASE_URL,
	header: { // 设置请求头
		// 'X-Auth-Token': 'xxxx',
		// contentType: "application/x-www-form-urlencoded",
		'Content-Type': 'application/json',
		timeStamp: new Date() * 1,
		token: getTokenStorage(),
	},
}

/**
 * @Description: 全局 请求拦截器
 * @param {Object} config 发送请求的配置数据
 * @return: config 继续发送请求
 * @return: false 停止发送请求，不进行错误数据拦截，不进入请求对象的catch函数
 * @return: Promise.reject('xxxxx') 停止发送请求, 进行错误数据拦截，进入catch函数中
 */
globalInterceptor.request.use(
	config => {
		// console.log('is global request interceptorA')
		// console.log("拦截前",config);
		if(config.noToken){
			config.header.token = ''; 
		}else{
			config.header.token = getTokenStorage() // 重新赋值token
		}
		
		
		return config
		// return false
		// return Promise.reject('is error')
	},
	err => {
		console.error("成功的err: ", err)
		return false
	}
)

// 支持添加多个请求、响应拦截器
// globalInterceptor.request.use(config => {
//   console.log('is global request interceptor 2')
//   return config
// }, err => {
//   console.error('global request: ', err)
//   return false
// })

/**
 * @Description: 全局响应拦截器支持添加多个
 * @Description: 例如: 根据状态码选择性拦截、过滤转换数据
 * @param {Object} config 发送请求的配置数据
 * @param {Object} res 请求返回的数据
 * @param {Object} err 错误对象
 * @param {Boolean} false 停止返回数据，不拦截错误数据，不进入catch函数中
 * @return {Object|Boolean|Promise<reject>} 返回错误信息, 拦截错误数据，执行catch
 */
globalInterceptor.response.use(
	(res, config) => {
		// console.log("response的res", res);

		// 回传数据中没有携带 code
		if (!(res.data && res.data.code)) {
			// console.log("错误情况:",res);
			
			if([-140].indexOf(res.data.resultCode) != -1){
				uni.showToast({
				    icon: 'none',
				    title: "请重新登录!"
				});
				setTimeout(function() {
					uni.navigateTo({
						url: '/pages/login/login'
					})
				}, 1000);
				return false;
			}
			
			
			return res
		}

		// 用code模拟http状态码
		const code = parseInt(res.data.code)

		// 20x ~ 30x
		if (200 <= code && code < 400) {

			uni.showToast({
				icon: "none",
				title: "test"
			})
			return res
		} else {
			return Promise.reject(res, config)
		}
		// return false
		// return Promise.reject('is error')
	},
	(err, config) => {
		console.log("response的err: ", err);
		// console.log(config);
		if(err.data){
				// getTokenType, 状态码 与 token状态验证
				if (['1003', '1004'].indexOf(err.data.code) != -1 && config.getTokenType) {
					console.log('token - code',err.data.code);
					return err;
				}
				
				
				
				// if (err.data&&err.data.msg == "token null ,请重新登录") {
				if (['1003'].indexOf(err.data.code) != -1 || (err.data&&err.data.msg == "token null ,请重新登录")) {
					uni.showToast({
							icon: 'none',
							title: "请先登录!"
					});
					setTimeout(function() {
						uni.navigateTo({
							url: '/pages/login/login'
						})
					}, 1000);
				}
				else if (['1004'].indexOf(err.data.code) != -1 || (err.data&&err.data.msg == "token验证redis失败,请重新登录")) {
					// console.log(err.data.msg);
					uni.showToast({
							icon: 'none',
							title: "请重新登录!"
					});
					setTimeout(function() {
						uni.navigateTo({
							url: '/pages/login/login'
						})
					}, 1000);
				}
			// console.error("config: ", config)
		}
		if (err && err.response && err.response.status) {
			// 请求已发出，但是不在2xx的范围 

			// errorHandle(err.response.status, response.data);
			return Promise.reject(response);
		} else {
			console.log(err.response)
			// 处理断网的情况
			// uni.showToast({
			// 		icon: 'none',
			// 		title: "服务器出错，请稍后再试!"
			// });
			
		}
		
		if (err.errMsg == "request:fail timeout") {
			uni.showToast({
				title: '请求超时',
				icon: 'none'
			})
		}

		return Promise.reject(err)
	}
)


const errorHandle = (status, other) => {
	// 状态码判断
	console.log(other);
	switch (status) {
		case 400:
			break;

			// 401: 未登录状态，跳转登录页
		case 401:
			break;

			// 清除token并跳转登录页
		case 403:
			console.log("403错误")
			// localStorage.removeItem('token');
			break;
			// 404请求不存在
		case 404:

			break;
		case 500:

			break;
	}
}
