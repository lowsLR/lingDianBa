
//bwWebSocket.js  未完善ez2

import {
		DOMParser
	} from 'xmldom'
const BWS = {
	VERSION: "0.23",
	xmlDecl: '<?xml version="1.0" encoding="UTF-8" ?>\n',
	attr_prefix: '-',
	surl:'ws://110.172.101.244:7070/ws/',	//webscoket路径
	to:'110.172.101.244',					//送给
	protocols:'xmpp',	//子协议
	connected: false,	//是否已经链接
	connecting: false,	//链接中
	socketTask: false,	//链接成功
	msg: false,					//消息
	islogin:false,			//是否登录
	onlive:false,				//是否在线
	id:'',							// id标识符
	authentication:'PLAIN',//登录类型
	fromUser:'sport-32-1589182481036',//from 路径
	number:'12346789',						//发送人
	xmlns:"urn:ietf:params:xml:ns:xmpp-framing", 
	version:"1.0",			//版本
	xmllang:"zh",				//语言
	resource:"sport",			
	chatroomId: "room1",//房间id
	roomService:'room1@sport.110.172.101.244',//房间服务
	username :'sport-25-1589179441931@sport.com',//用户名
	//密码
	password:'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJoYyIsImlzQWRtaW4iOiIwIiwiZXhwIjoxNTg5Nzg0MjQxLCJzZXJ2aWNlTmFtZSI6InNwb3J0IiwiaWF0IjoxNTg5MTc5NDQxLCJ1c2VySWQiOiIyNSIsIm5vbmNlU3RyIjoiZTdiODcwNDEtNTIxNC00OTY5LWIyODEtMmFkZjk0NTY3YWZlIn0.zU-5g_o7FZlADEeAxrFL10kcK-saSvvLvAl80kurVGo',
	nickname: "1234567",//昵称
	//获取历史消息
	historyUrl:'',
	/*字符串拼接*/
	joinStr(arr){
		return arr.join('\0');
	},
	returnMsgTime(timespan){
			let dateTime = new Date(timespan);
		  let year = dateTime.getFullYear();
		  let month = dateTime.getMonth() + 1;
		  let day = dateTime.getDate();
		  let hour = dateTime.getHours();
		  let minute = dateTime.getMinutes();
		  let second = dateTime.getSeconds();
		  // let now_new = Date.parse(now.toDateString());  //获取当天时间戳
			let now_new = Date.parse(new Date());  //获取现在时间戳
		  let milliseconds = 0;
		  let timeSpanStr;
		  milliseconds = now_new - timespan;
		  if (milliseconds <= 1000 * 60 * 1) {
		    timeSpanStr = '刚刚';
		  }
		  else if (1000 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60) {
		    timeSpanStr = Math.round((milliseconds / (1000 * 60))) + '分钟前';
		  }
		  else if (1000 * 60 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24) {
		    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60)) + '小时前';
		  }
		  else if (1000 * 60 * 60 * 24 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 15) {
		    timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24)) + '天前';
		  }
		  else if (milliseconds > 1000 * 60 * 60 * 24 * 15 && year == now.getFullYear()) {
		    timeSpanStr = month + '-' + day + ' ' + hour + ':' + minute;
		  } else {
		    timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute;
		  }
		  return timeSpanStr;
	},
	timesToTime(timestamp){
		let date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
		let Y = date.getFullYear() + '年';
		let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '月';
		let D = date.getDate() + '日 ';
		let h = date.getHours() + ':';
		let m = date.getMinutes()<10?'0'+date.getMinutes()+ ':':date.getMinutes()+ ':';
		let s = date.getSeconds()<10?'0'+date.getSeconds():date.getSeconds();
		return Y + M + D + h + m + s;
	},
	/*初始化*/
	connect(){
		if (this.connected || this.connecting) {
			uni.showModal({
				content: '正在连接或者已经连接，请勿重复连接',
				showCancel: false
			})
			return false
		}
		this.connecting = true
		uni.showLoading({
			title: '连接中...'
		})
		this.socketTask = uni.connectSocket({
			// url: 'wss://echo.websocket.org',
			url: this.surl,
			protocols:this.protocols,
			data() {
				return {
					msg: 'Hello'
				}
			},
			// #ifdef MP
			header: {
				'content-type': 'application/json'
			},
			// #endif
			// #ifdef MP-WEIXIN
			method: 'GET',
			// #endif
			success(res) {
				// 这里是接口调用成功的回调，不是连接成功的回调，请注意
			},
			fail(err) {
				// 这里是接口调用失败的回调，不是连接失败的回调，请注意
			}
		})
		console.log(this.socketTask);
		this.socketTask.onOpen((res) => {
			this.connecting = false
			this.connected = true
			uni.hideLoading()
			uni.showToast({
				icon: 'none',
				title: '连接成功'
			})
			console.log('onOpen', res);
		that.connwsopen();
			
		this.socketTask.onError((err) => {
			this.connecting = false
			this.connected = false
			uni.hideLoading()
			uni.showModal({
				content: '连接失败，可能是websocket服务不可用，请稍后再试',
				showCancel: false
			})
			console.log('onError', err);
		})
		this.socketTask.onMessage((res) => {
			this.msg = res.data;
			// console.log('onMessage', res);
			// console.log('转换后的数据', msgdata);
			this.parsingMsg(res.data);
			
		})
		this.socketTask.onClose((res) => {
			this.connected = false
			this.startRecive = false
			this.socketTask = false
			this.msg = false
			console.log('onClose', res)
		})
		console.log('task', this.socketTask)
		
		})
	},
	
	parsingMsg(res){
		console.warn("接收到的", res);
		var jsondata = this.xml2json(res);
		console.warn("转换后的", jsondata);
		if ( undefined != jsondata.message){
			
		  if( undefined != jsondata.message.body){
		    console.log("收到的消息：",jsondata.message.body);
				
		  } else if(undefined != jsondata.message.composing){
				
				console.log("对方正在输入")
		  } else if(undefined != jsondata.message.gone){
				console.log("对方已关闭和您的聊天")
				
		  } else if(undefined != jsondata.message.file){
		    console.log("收到的文件：",jsondata.message);
				
		  } else {
		
		  }
			
		} else if (undefined != jsondata.open) {
		  //记录id	
		  this.id = jsondata.open["-id"];
		  console.log("记录id",this.id);
		} else if (undefined != jsondata["stream:features"]) {
		  if (undefined != jsondata["stream:features"].mechanisms) {
		    //获取登录验证方式
		    this.auth();
				
		    //auth(jsondata["stream:features"].mechanisms.mechanism[0]);
		  } else if(undefined != jsondata["stream:features"].bind){
		    this.bind();
		  } else {
		    //Do-nothing
		  }
		} else if (undefined != jsondata.failure) {
		  that.islogin = false;
		  console.log("登录失败，用户名或者密码错误");
		} else if (undefined != jsondata.success) {
		  that.islogin = true;
		  console.log("登录成功！");
		  //发起新的流
		  this.newopen();
		} else if (undefined != jsondata.iq) {
		  if(undefined != jsondata.iq.bind){
		    //获取session会话
		    this.getsession();
		  } else {
		    this.presence();
		  }
		} else {
			if(jsondata.presence.complete){
				if(!that.onlive){
					console.log("所有操作执行完毕，开始加入房间")
					that.onlive = true;
					that.joinroom();
				}
			}
		}//if(undefined != jsondata["stream:features"])
	},
	//登录验证
	auth() {
	  //字符串格式是：jid+password，以\0作为分隔符
	  //var temp = username + "@" + to + "\0" + password;  
	  //这里我修改了一下
	  let temp = this.username + "@" + this.to + "\0" + this.username+ "\0" + this.password;
		// var temp = that.username + "@" + that.to + "\0" + that.password;
	  //Base64编码
	  // var token = window.btoa(temp);
		let token = new Buffer(temp).toString('base64');
		console.log(token);
	  // var message = "<auth xmlns='urn:ietf:params:xml:ns:xmpp-sasl' mechanism='PLAIN'>" + token + "</auth>";
	  var message = {
	    "auth": {
	      "-xmlns": "urn:ietf:params:xml:ns:xmpp-sasl",
	      "-mechanism": this.authentication,
	      "#text": token
	    }
	  };
		this.sendMsg(this.json2xml(message))
	},
	getBase64(arr){
		return new Promise( (res,rej) => {
			uni.request({
				url: 'http://47.112.131.52:8087/app/analyMsg/analyMsg',
				method: 'POST',
				data: {
					msg:arr
				},
				success: resp => {
					res(resp.data);
				},
				fail: (err) => {
					rej(err)
				},
				complete: () => {}
			});
		})
	},
	//bind操作
	bind() {
	  var temp = {
	    "iq": {
	      "-id": this.id,
	      "-type": "set",
	      "bind": {
	        "-xmlns": "urn:ietf:params:xml:ns:xmpp-bind",
	        "resource":this.resource
	      }
	    }
	  };
	  //转化为xml
		this.sendMsg(this.json2xml(temp))
	},
	joinroom() {
	  var temp = {
	    "presence": {
	      "-from": this.fromUser+'@'+this.to,
	      "-id": this.id,
	      "-to": "room1@sport.110.172.101.244/sport-32-1589182481036",
	      "x": { "-xmlns": "http://jabber.org/protocol/muc" }
	    }
	  }
		this.sendMsg(this.json2xml(temp))
	},
	//发起新的流
	newopen() {
	  // <open xmlns='jabber:client' to='127.0.0.1' version='1.0' from='wuxinzhe@127.0.0.1' id='70tvu3ooiu' xml:lang='zh'/>
	  var temp = {
	    "open": {
	      "-xmlns": "jabber:client",
	      "-to": this.to,
	      "-version": this.version,
	      "-from": this.fromUser+'@'+this.to,
	      "-id": this.id,
	      "-xml:lang": this.xmllang
	    }
	  };
	  //转化为xml
	 this.sendMsg(this.json2xml(temp))
	},
	//获取session
	getsession() {
	  //<iq xmlns="jabber:client" id="ak014gz6x7" type="set"><session xmlns="urn:ietf:params:xml:ns:xmpp-session"/></iq>
	  var temp = {
	    "iq": {
	      "-xmlns": "jabber:client",
	      "-id": this.id,
	      "-type": "set",
	      "session": {"-xmlns": "urn:ietf:params:xml:ns:xmpp-session"}
	    }
	  };
	  //转化为xml
	  this.sendMsg(this.json2xml(temp))
	},
	//上线
	presence() {
	  //<presence id="ak014gz6x7"><status>Online</status><priority>1</priority></presence>
	  var temp = {
	    "presence": {
	      "-id": this.id,
	      "status": "online",
	      "priority": "1"
	    }
	  };
	  //转化为xml
	  this.sendMsg(this.json2xml(temp))
	},
	sendMsg(str){
		return new Promise((res,rej) => {
			that.socketTask.send({
				data:str,
				// data: 'from ' + platform + ' : ' + parseInt(Math.random() * 10000).toString(),
				success(r) {
					console.log("发送成功",r);
					res(r)
				},
				fail(err) {
					console.log("发送失败",err);
					rej(err)
				}
			})
		})
	},
	json2xml(jsonstring) {
	  //将xml字符串格式化
	  return this.writeXML(jsonstring);;
	},
	//xml转json
	xml2json(xmlstring) {
	  //将xml字符串转为json
	  let json = this.parseXML(xmlstring);
	  //将json对象转为格式化的字符串
	  return JSON.parse(this.dump(json));
	},
	
	//  Dump the data into JSON format
	dump ( data, offset ) {
	    if ( typeof(offset) == "undefined" ) offset = "";
	    var nextoff = offset + "  ";
	    switch ( typeof(data) ) {
	    case "string":
	        return '"'+this.escapeString(data)+'"';
	        break;
	    case "number":
	        return data;
	        break;
	    case "boolean":
	        return data ? "true" : "false";
	        break;
	    case "undefined":
	        return "null";
	        break;
	    case "object":
	        if ( data == null ) {
	            return "null";
	        } else if ( data.constructor == Array ) {
	            var array = [];
	            for ( var i=0; i<data.length; i++ ) {
	                array[i] = this.dump( data[i], nextoff );
	            }
	            return "[\n"+nextoff+array.join( ",\n"+nextoff )+"\n"+offset+"]";
	        } else {
	            var array = [];
	            for ( var key in data ) {
	                var val = this.dump( data[key], nextoff );
	//              if ( key.match( /[^A-Za-z0-9_]/ )) {
	                    key = '"'+this.escapeString( key )+'"';
	//              }
	                array[array.length] = key+": "+val;
	            }
	            if ( array.length == 1 && ! array[0].match( /[\n\{\[]/ ) ) {
	                return "{ "+array[0]+" }";
	            }
	            return "{\n"+nextoff+array.join( ",\n"+nextoff )+"\n"+offset+"}";
	        }
	        break;
	    default:
	        return data;
	        // unsupported data type
	        break;
	    }
	},
	
	//  escape '\' and '"'
	
	escapeString ( str ) {
	    return str.replace( /\\/g, "\\\\" ).replace( /\"/g, "\\\"" );
	},
	parseXML(xml) {
		// var root;
		// if (window.DOMParser) {
		// 	var xmldom = new DOMParser();
		// 	//      xmldom.async = false;           // DOMParser is always sync-mode
		// 	var dom = xmldom.parseFromString(xml, "application/xml");
		// 	if (!dom) return;
		// 	root = dom.documentElement;
		// } else if (window.ActiveXObject) {
		// 	xmldom = new ActiveXObject('Microsoft.XMLDOM');
		// 	xmldom.async = false;
		// 	xmldom.loadXML(xml);
		// 	root = xmldom.documentElement;
		// }
		// if (!root) return;
		
		let doc = new DOMParser().parseFromString(xml, 'text/xml');
		// console.log(doc)
		// console.log(doc.documentElement.getElementsByTagName('mechanisms'))
		// var darr = this.doc2Json(doc)
		// console.log("返回的json",darr);
		let test = this.parseDOM(doc);
		// test['#document'];
		// return this.parseDOM(root);
		return test['#document'];
		// var root;
		// if (window.DOMParser) {
		// 	var xmldom = new DOMParser();
		// 	//      xmldom.async = false;           // DOMParser is always sync-mode
		// 	var dom = xmldom.parseFromString(xml, "application/xml");
		// 	if (!dom) return;
		// 	root = dom.documentElement;
		// } else if (window.ActiveXObject) {
		// 	xmldom = new ActiveXObject('Microsoft.XMLDOM');
		// 	xmldom.async = false;
		// 	xmldom.loadXML(xml);
		// 	root = xmldom.documentElement;
		// }
		// if (!root) return;
		// return this.parseDOM(root);
		
		
		// // var nsAttr = doc.documentElement.getAttributeNS('./lite','x')  
		// // console.log(nsAttr);
		// console.log("查看xml",xml)
		// let doc = new DOMParser().parseFromString(xml, 'text/xml');
		// console.log(doc)
		// console.log(doc.documentElement.getElementsByTagName('mechanisms'))
		// // console.log("doc",doc);
		// // console.log("doc",doc.toString());
		// // var nsAttr = doc.documentElement.getAttributeNS('./lite','x')
		// let jsondata = this.convertToJSON(doc);
		
		// console.log(jsondata);
		// return doc;
	},
	doc2Json(doc){
		var djson = {};
		let darr = doc.childNodes[0];
		darr.childNodes.forEach((item,index) => {
			darr[item.nodeName] = {};
			item.childNodes.forEach((items,indexs) => {
				// if(typeof  items.attributes == '')
				// if(items.childNodes){
					
				// }
				// darr[item.nodeName][items.nodeName] = items.childNodes[0].nodeValue;
				
			})
			
		})
		return djson;
		
	},
	/**
	 * 将XML的Document对象转换为JSON字符串
	 * @param xmlDoc xml的Document对象
	 * @return string
	 */
	convertToJSON(xmlDoc) {
	    //准备JSON字符串和缓存（提升性能）
	    var jsonStr = "";
	    var buffer = new Array();
	
	    buffer.push("{");
	    //获取xml文档的所有子节点
	    var nodeList = xmlDoc.childNodes;
			// console.log("所有子节点",nodeList.toString() )
	    generate(nodeList);
	
	    /**
	     * 中间函数，用于递归解析xml文档对象，并附加到json字符串中
	     * @param node_list xml文档的的nodeList
	     */
	    function generate(node_list) {
	
	        for (var i = 0; i < node_list.length; i++) {
	            var curr_node = node_list[i];
	            //忽略子节点中的换行和空格
	            if (curr_node.nodeType == 3) {
	                continue;
	            }
	            //如果子节点还包括子节点，则继续进行遍历
	            if (curr_node.childNodes.length > 1) {
	                buffer.push("\"" + curr_node.nodeName + "\": {");
	                generate(curr_node.childNodes);
	            } else {
	                var firstChild = curr_node.childNodes[0];
	
	                if (firstChild != null) {
	                    //nodeValue不为null
	                    buffer.push("\"" + curr_node.nodeName + "\":\"" + firstChild.nodeValue + "\"");
	                } else {
	                    //nodeValue为null
	                    buffer.push("\"" + curr_node.nodeName + "\":\"\"");
	                }
	
	            }
	            if (i < (node_list.length - 2)) {
	                buffer.push(",");
	            } else {
	                break;
	            }
	        }
	        //添加末尾的"}"
	        buffer.push("}");
	    }
	
	    jsonStr = buffer.join("");
	    return jsonStr;
	},
	
	
	//xml数据转成json对象的数据
	 xmlTojson(xmlObj, nodename, isarray){
	        var obj = xmlObj;
	        var itemobj = {};
	        var nodenames = "";
	        var getAllAttrs = function(node){//递归解析xml 转换成json对象
	            var _itemobj = {};
	            var notNull = false;
	            var nodechilds = node.childNodes;
	            var childlenght = nodechilds.length;
	            var _attrs = node.attributes;
	            var firstnodeName = "#text";
	            try{
	                firstnodeName = nodechilds[0].nodeName;
	            }catch(e){
	
	            }
	            if((childlenght > 0 && firstnodeName != "#text") || _attrs.length > 0){
	                var _childs = nodechilds;
	                var _childslength = nodechilds.length;
	                var _fileName_ = "";
	                if(undefined != _attrs){
	                    var _attrslength = _attrs.length;
	                    for(var i = 0; i < _attrslength; i++){//解析xml节点属性
	                        var attrname = _attrs[i].nodeName;
	                        var attrvalue = _attrs[i].nodeValue;
	                        _itemobj[attrname] = attrvalue;
	                    }
	                }
	                for (var j = 0; j < _childslength; j++) {//解析xml子节点
	                    var _node = _childs[j];
	                    var _fildName = _node.nodeName;
	                    if("#text" == _fildName){break;};
	                    if(_itemobj[_fildName] != undefined){//如果有重复的节点需要转为数组格式
	                        if(!(_itemobj[_fildName] instanceof Array)){
	                            var a = _itemobj[_fildName];
	                            _itemobj[_fildName] = [a];//如果该节点出现大于一个的情况 把第一个的值存放到数组中
	                        }
	                    }
	                    var _fildValue = getAllAttrs(_node);
	                    try{
	                        _itemobj[_fildName].push(_fildValue);
	                    }catch(e){
	                        _itemobj[_fildName] = _fildValue;
	                        _itemobj["length"] = 1;
	                    }
	                }
	           }else{
	                _itemobj = (node.textContent == undefined) ? node.text : node.textContent;
	           }
	           return _itemobj;
	        };
	
	        if(nodename){
	            nodenames = nodename.split("/")
	        }
	        for(var i = 0;i < nodenames.length; i++){
	            obj = obj.find(nodenames[i]);
	        }
	        obj.forEach(function(key, item){
	            if(itemobj[item.nodeName] != undefined){
	                if(!(itemobj[item.nodeName] instanceof Array)){
	                    var a = itemobj[item.nodeName];
	                    itemobj[item.nodeName] = [a];
	                }
	                itemobj[item.nodeName].push(getAllAttrs(item));
	            }else{
	                if(nodenames.length > 0){
	                    itemobj[item.nodeName] = getAllAttrs(item);
	                }else{
	                    itemobj[item.firstChild.nodeName] = getAllAttrs(item.firstChild);
	                }
	            }
	        });
	
	        if(nodenames.length > 1){
	            itemobj = itemobj[nodenames[nodenames.length-1]];
	        }
	        if(isarray && !(itemobj instanceof Array) && itemobj != undefined){
	            itemobj = [itemobj];
	        }
	        return itemobj;
	    },

	//  method: parseHTTP( url, options, callback )

	parseHTTP(url, options, callback) {
		var myopt = {};
		for (var key in options) {
			myopt[key] = options[key]; // copy object
		}
		if (!myopt.method) {
			if (typeof(myopt.postBody) == "undefined" &&
				typeof(myopt.postbody) == "undefined" &&
				typeof(myopt.parameters) == "undefined") {
				myopt.method = "get";
			} else {
				myopt.method = "post";
			}
		}
		if (callback) {
			myopt.asynchronous = true; // async-mode
			var __this = this;
			var __func = callback;
			var __save = myopt.onComplete;
			myopt.onComplete = function(trans) {
				var tree;
				if (trans && trans.responseXML && trans.responseXML.documentElement) {
					tree = __this.parseDOM(trans.responseXML.documentElement);
				}
				__func(tree, trans);
				if (__save) __save(trans);
			};
		} else {
			myopt.asynchronous = false; // sync-mode
		}
		var trans;
		if (typeof(HTTP) != "undefined" && HTTP.Request) {
			myopt.uri = url;
			var req = new HTTP.Request(myopt); // JSAN
			if (req) trans = req.transport;
		} else if (typeof(Ajax) != "undefined" && Ajax.Request) {
			var req = new Ajax.Request(url, myopt); // ptorotype.js
			if (req) trans = req.transport;
		}
		if (callback) return trans;
		if (trans && trans.responseXML && trans.responseXML.documentElement) {
			return this.parseDOM(trans.responseXML.documentElement);
		}
	},

	//  method: parseDOM( documentroot )

	parseDOM(root) {
		if (!root) return;

		this.__force_array = {};
		if (this.force_array) {
			for (var i = 0; i < this.force_array.length; i++) {
				this.__force_array[this.force_array[i]] = 1;
			}
		}

		var json = this.parseElement(root); // parse root node
		if (this.__force_array[root.nodeName]) {
			json = [json];
		}
		if (root.nodeType != 11) { // DOCUMENT_FRAGMENT_NODE
			var tmp = {};
			tmp[root.nodeName] = json; // root nodeName
			json = tmp;
		}
		return json;
	},

	//  method: parseElement( element )

	parseElement(elem) {
		//  COMMENT_NODE
		if (elem.nodeType == 7) {
			return;
		}

		//  TEXT_NODE CDATA_SECTION_NODE
		if (elem.nodeType == 3 || elem.nodeType == 4) {
			var bool = elem.nodeValue.match(/[^\x00-\x20]/);
			if (bool == null) return; // ignore white spaces
			return elem.nodeValue;
		}

		var retval;
		var cnt = {};

		//  parse attributes
		if (elem.attributes && elem.attributes.length) {
			retval = {};
			for (var i = 0; i < elem.attributes.length; i++) {
				var key = elem.attributes[i].nodeName;
				if (typeof(key) != "string") continue;
				var val = elem.attributes[i].nodeValue;
				if (!val) continue;
				key = this.attr_prefix + key;
				if (typeof(cnt[key]) == "undefined") cnt[key] = 0;
				cnt[key]++;
				this.addNode(retval, key, cnt[key], val);
			}
		}

		//  parse child nodes (recursive)
		if (elem.childNodes && elem.childNodes.length) {
			var textonly = true;
			if (retval) textonly = false; // some attributes exists
			for (var i = 0; i < elem.childNodes.length && textonly; i++) {
				var ntype = elem.childNodes[i].nodeType;
				if (ntype == 3 || ntype == 4) continue;
				textonly = false;
			}
			if (textonly) {
				if (!retval) retval = "";
				for (var i = 0; i < elem.childNodes.length; i++) {
					retval += elem.childNodes[i].nodeValue;
				}
			} else {
				if (!retval) retval = {};
				for (var i = 0; i < elem.childNodes.length; i++) {
					var key = elem.childNodes[i].nodeName;
					if (typeof(key) != "string") continue;
					var val = this.parseElement(elem.childNodes[i]);
					if (!val) continue;
					if (typeof(cnt[key]) == "undefined") cnt[key] = 0;
					cnt[key]++;
					this.addNode(retval, key, cnt[key], val);
				}
			}
		}
		return retval;
	},

	//  method: addNode( hash, key, count, value )

	addNode(hash, key, cnts, val) {
		if (this.__force_array[key]) {
			if (cnts == 1) hash[key] = [];
			hash[key][hash[key].length] = val; // push
		} else if (cnts == 1) { // 1st sibling
			hash[key] = val;
		} else if (cnts == 2) { // 2nd sibling
			hash[key] = [hash[key], val];
		} else { // 3rd sibling and more
			hash[key][hash[key].length] = val;
		}
	},

	//  method: writeXML( tree )

	writeXML(tree) {
		var xml = this.hash_to_xml(null, tree);
		return this.xmlDecl + xml;
	},

	//  method: hash_to_xml( tagName, tree )

	hash_to_xml(name, tree) {
		var elem = [];
		var attr = [];
		for (var key in tree) {
			if (!tree.hasOwnProperty(key)) continue;
			var val = tree[key];
			if (key.charAt(0) != this.attr_prefix) {
				if (typeof(val) == "undefined" || val == null) {
					elem[elem.length] = "<" + key + " />";
				} else if (typeof(val) == "object" && val.constructor == Array) {
					elem[elem.length] = this.array_to_xml(key, val);
				} else if (typeof(val) == "object") {
					elem[elem.length] = this.hash_to_xml(key, val);
				} else {
					elem[elem.length] = this.scalar_to_xml(key, val);
				}
			} else {
				attr[attr.length] = " " + (key.substring(1)) + '="' + (this.xml_escape(val)) + '"';
			}
		}
		var jattr = attr.join("");
		var jelem = elem.join("");
		if (typeof(name) == "undefined" || name == null) {
			// no tag
		} else if (elem.length > 0) {
			if (jelem.match(/\n/)) {
				jelem = "<" + name + jattr + ">\n" + jelem + "</" + name + ">\n";
			} else {
				jelem = "<" + name + jattr + ">" + jelem + "</" + name + ">\n";
			}
		} else {
			jelem = "<" + name + jattr + " />\n";
		}
		return jelem;
	},

	//  method: array_to_xml( tagName, array )

	array_to_xml(name, array) {
		var out = [];
		for (var i = 0; i < array.length; i++) {
			var val = array[i];
			if (typeof(val) == "undefined" || val == null) {
				out[out.length] = "<" + name + " />";
			} else if (typeof(val) == "object" && val.constructor == Array) {
				out[out.length] = this.array_to_xml(name, val);
			} else if (typeof(val) == "object") {
				out[out.length] = this.hash_to_xml(name, val);
			} else {
				out[out.length] = this.scalar_to_xml(name, val);
			}
		}
		return out.join("");
	},

	//  method: scalar_to_xml( tagName, text )

	scalar_to_xml(name, text) {
		if (name == "#text") {
			return this.xml_escape(text);
		} else {
			return "<" + name + ">" + this.xml_escape(text) + "</" + name + ">\n";
		}
	},

	//  method: xml_escape( text )

	xml_escape(text) {
		return text&&text.toString().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
		// if(typeof text == 'string'){
		// 	text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
		// }else{
		// 	return text
		// }
	},
}


export default BWS;
