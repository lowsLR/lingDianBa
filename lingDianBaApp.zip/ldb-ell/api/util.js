'use strict'
/**
 * public function
 */

import reqc from '@/api/reqc.js' //挂载请求

export default {
	// 获取当前日期
	getCurrentDate: function() {
		let date = new Date();
	
		let year = date.getFullYear();
		let month = date.getMonth() + 1 < 10 ? ('0' + (date.getMonth() + 1)) : (date.getMonth() + 1);
		let day = date.getDate() < 10 ? ('0' + date.getDate()) : date.getDate();
		// 'YYYY-MM-DD'
		let time = year + '-' + month + '-' + day;
	
		return time;
	},
	
	/**
	 * 获取广告列表  参数说明：
	 * 1、advertisementSort(广告排序：所处列表位置) 仅在 locationType(广告位置类型)为('1':列表状态)时有效
	 * 2、 locationPosition(广告位置)：广告显示的位置
	 */
	getAdvertiseList: function (datas) {
		return new Promise((resolve, reject) => {
			reqc.queryAdvertisement(datas)
			.then( res => {
				// console.log("广告接口返回数据:",res);
				if (res.statusCode === 200 && res.data.resultCode === 1) {
					let list = res.data.data;
					// 根据宽高比转换为指定像素的宽高
					list.forEach((item, index) => {
						// item.AdWidth = 750 * item.advertisementWeight + 'rpx'
						item.AdWidth = 750 * (item.advertisementWeight > 1 ? 1 : item.advertisementWeight) + 'rpx'
						item.AdHeight = 120 * item.advertisementHeight + 'rpx'
						// console.log(item.AdWidth, item.AdHeight);
					})
					resolve(list);
				} else {
					reject(res);
				}
			})
			.catch( err => {
				reject(err);
			})
		})
	}
	
}