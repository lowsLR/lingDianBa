import axios from '@/common/plugins/axios/index'

const req = {
	// 校验app版本
	verificationAppVersion(data) {
		return axios().request({
			url: '/app/token/verificationAppVersion',
			method: 'get',
			data: data,
		})
	},
	
	
	// app开关配置信息
	verificationMineStatus(data) {
		return axios().request({
			url: '/app/switch/info',
			method: 'post'
		})
	},
	
	
	
	// 查询广告
	queryAdvertisement(data) {
		return axios().request({
			url: '/app/advertisement/queryAdvertisement',
			method: 'post',
			data: data,
		})
	},
	
	
	// token验证
	verificationToken(){
		return axios().request({
			url: '/app/token/verificationToken',
			method: 'get',
			getTokenType: true,
		})
	},
	
	// 查询所有赛事类型专题项目(标签)
	queryAllTags(data){
		return axios().request({
			url: '/app/matchs/queryAllEventList',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	// 查询首页赛事内容
	queryAllEvents(data){
		return axios().request({
			url: '/app/matchs/queryAllMatchList',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	// 查询单个赛事
	queryMatchById(data){
		return axios().request({
			url: '/app/matchs/queryMatchById',
			method: 'post',
			data: data
		})
	},
	// 查询有直播/录像比赛的日期
	queryMatchByVideoDetail(data){
		return axios().request({
			url: '/app/matchs/queryMatchByVideoDetail',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	// 解析 电视 直播源
	analysisTv(data){
		return axios().request({
			url: '/app/tv/analysisTv',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	// 解析直播源
	analysisMatchLiveSource(data){
		return axios().request({
			url: '/app/matchs/analysisMatchLiveSource',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	// 初始化直播源
	initMatchLiveSource(data){
		return axios().request({
			url: '/app/matchs/initMatchLiveSource',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	
	// 查询视频列表
	queryVideo(data){
		return axios().request({
			url: '/app/match/Live/queryLiveTitle',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	// 查询视频内容 (动态赋值 noToken)
	queryLiveContent(data, res) {
		return axios().request({
			url: '/app/match/Live/queryLiveContent',
			// method: 'get',
			method: 'post',
			data: data,
			// noToken:true,
			noToken: res.noToken,
		})
	},
	// 视频点赞
	updateLivelike(data){
		return axios().request({
			url: '/app/like/updateLivelike',
			method: 'post',
			data: data
		})
	},
	
	// 查询个人信息
	queryUserInfo(){
		return axios().request({
			url: '/app/user/info/queryUserInfo',
			method: 'post'
		})
	},
	
	// 分发任务
	distributionTask(){
		return axios().request({
			url: '/app/task/distributionTask',
			method: 'post'
		})
	},
	// 查询签到次数
	countBySign(data){
		return axios().request({
			url: '/app/task/countBySign',
			method: 'post',
			data: data
		})
	},
	// 查询任务
	queryTaskToday(data){
		return axios().request({
			url: '/app/task/queryTaskToday',
			method: 'post',
			data: data
		})
	},
	// 执行(完成)任务
	finshTask(data){
		return axios().request({
			url: '/app/task/finshTask',
			method: 'post',
			data: data
		})
	},
	// 查询积分详情记录
	IntegralLog(data){
		return axios().request({
			url: '/app/task/queryUserIntegralLog',
			method: 'post',
			data: data
		})
	},
	
	
	/**
	 * 商城模块
	 */
	// 查询商城列表
	queryShoppingAll(data){
		return axios().request({
			url: '/app/shopping/queryShoppingAll',
			method: 'post',
			data: data
		})
	},
	// 获取商城订单号
	queryOrderNumber(data){
		return axios().request({
			url: '/app/shopping/queryShoppingOrderNumber',
			method: 'post',
			data: data
		})
	},
	// 商城兑换
	shoppingExchange(data){
		return axios().request({
			url: '/app/shopping/shoppingExchange',
			method: 'post',
			data: data
		})
	},
	// 查询个人商品兑换信息
	shoppingExchangeInfo(data){
		return axios().request({
			url: '/app/shopping/shoppingExchangeInfo',
			method: 'post',
			data: data
		})
	},
	
	// 查询全部地址
	queryAddressAll(data){
		return axios().request({
			url: '/app/shopping/queryAddressAll',
			method: 'post',
			data: data
		})
	},
	// 添加个人地址
	addAddress(data){
		return axios().request({
			url: '/app/shopping/addAddress',
			method: 'post',
			data: data
		})
	},
	// 修改地址
	updateAddress(data){
		return axios().request({
			url: '/app/shopping/updateAddress',
			method: 'post',
			data: data
		})
	},
	
	
	
	// 意见反馈
	createFeedback(data){
		return axios().request({
			url: '/app/feedback/createFeedback',
			method: 'post',
			data: data
		})
	},
	
	
	// (直播)查询赛事点赞接口
	queryMatchLike(data){
		return axios().request({
			url: '/app/matchLike/queryMatchLike',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	// (直播)创建赛事点赞接口
	createMatchLike(data){
		return axios().request({
			url: '/app/matchLike/createMatchLike',
			method: 'post',
			data: data
		})
	},
	
	
	/**
	 * 邀请好友
	 */
	// 获取用户所有记录类型的次数
	allShareTypeCount() {
		return axios().request({
			url: '/app/user/share/allShareTypeCount',
			method: 'get'
		})
	},
	// 记录用户扫描二维码
	scanCode(data) {
		return axios().request({
			url: '/app/user/share/scanCode',
			method: 'get',
			data: data
		})
	},
	// 记录用户分享下载链接日志
	recordDownload(data) {
		return axios().request({
			url: '/app/user/share/recordDownload',
			method: 'get',
			data: data
		})
	},
	
	
	
	
	/**
	 * 电视
	 */
	// 查询电视分类
	queryTvType(){
		return axios().request({
			url: '/app/tv/queryTvType',
			method: 'get'
		})
	},
	// 查询省区
	queryTvProvince(){
		return axios().request({
			url: '/app/tv/queryTvProvince',
			method: 'get'
		})
	},
	// 查询电视台信息
	queryTvInfo(data){
		return axios().request({
			url: '/app/tv/queryTvInfo',
			method: 'post',
			data: data
		})
	},
	// 查询电视台内容信息
	queryTvConten(data){
		return axios().request({
			url: '/app/tv/queryTvConten',
			method: 'post',
			data: data
		})
	},
	
	
	/**
	 * 录像
	 */
	// 查询有录像的赛事
	queryMatchListByVideo(data){
		return axios().request({
			url: '/app/matchs/queryMatchListByVideo',
			method: 'post',
			data: data
		})
	},
	// 查询有录像比赛的详情
	queryMatchByVideoDetial(data){
		return axios().request({
			url: '/app/matchs/queryMatchByVideoDetial',
			method: 'post',
			data: data
		})
	},
	
	
	/**
	 * 搜索
	 */
	// 综合搜索
	searchAll(data){
		return axios().request({
			url: '/app/search/searchAll',
			method: 'post',
			data: data
		})
	},
	// 搜索赛事
	searchMatch(data){
		return axios().request({
			url: '/app/search/searchMatch',
			method: 'post',
			data: data
		})
	},
	// 搜索有录像的赛事
	searchMatchListByVideo(data){
		return axios().request({
			url: '/app/search/searchMatchListByVideo',
			method: 'post',
			data: data
		})
	},
	// 搜索视频
	searchLiveTitle(data){
		return axios().request({
			url: '/app/search/searchLiveTitle',
			method: 'post',
			data: data
		})
	},
	// 搜索新闻列表
	searchNewsTitle(data){
		return axios().request({
			url: '/app/search/searchNewsTitle',
			method: 'post',
			data: data
		})
	},
	// 模糊查询电视台
	queryLikeTvName(data){
		return axios().request({
			url: '/web/tv/queryLikeTvName',
			method: 'post',
			data: data
		})
	},
	
	
}
export default req;
