import axios from '@/common/plugins/axios/index'

let loadUrl = 'http://47.112.131.52:8096/v.json';
let currVersion = ''
// #ifdef APP-PLUS
plus.runtime.getProperty(plus.runtime.appid, function(inf) {
	currVersion = inf.version.split('.').join('')
})
// #endif
// 判断更新
//toUpdate,	
const toUpdate = () => {
	if(!currVersion) {
		plus.runtime.getProperty(plus.runtime.appid, function(inf) {
			currVersion = inf.version.split('.').join('')
			if(!currVersion) {
				currVersion = '100'  //预防一直拿不到的死循环
			}
			toUpdate()
		})
		return
	}
	try {
		uni.request({
			url: loadUrl,
			header: {
				"Cache-Control":"no-cache"
			},
			success: (res) => {
				if(res.statusCode==200) {
					const resArray = res.data
					if(resArray && currVersion) {
						let keyArray = []
						for(let key in resArray) {
							keyArray.push(parseInt(key))
						}
						
						if(keyArray.length>0) {
							keyArray.sort(function(a,b){
								return b - a;
							})
							
							const targetVersion = keyArray[0]
							if(targetVersion>parseInt(currVersion)) {
								//存在最新的
								let wgtArray = resArray[targetVersion]
								if(wgtArray && wgtArray.length>0) {
									const wgtUrl = wgtArray[wgtArray.length-1]
									uni.reLaunch({
										url:'/pages/uLoad/uLoad?url='+wgtUrl
									})
								}
							}
						}
					}
				}
			}
		})
	}catch(e) {}
}

const req = {
	// 查询所有赛事类型专题项目(标签)
	queryAllEventList(data) {
		return axios().request({
			url: '/app/matchs/queryAllEventList',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	
	//查询新闻类容
	queryNewsContent(data, res) {
		return axios().request({
			url: '/app/match/news/queryNewsContent',
			method: 'get',
			data: data,
			// noToken:true,
			noToken: res && res.noToken ? true : false,
		})
	},

	//查询新闻标题列表
	queryNewsTitle(data) {
		return axios().request({
			url: '/app/match/news/queryNewsTitle',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	
	//跟新新闻点赞
	updateNewslike(data) {
		return axios().request({
			url: '/app/like/updateNewslike',
			method: 'post',
			data: data
		})
	},
	
	//新增删除用户关注栏目
	updateUserAttend(data) {
		return axios().request({
			url: '/app/match/updateUserAttend',
			method: 'post',
			data: data
		})
	},

	//查询评论一级列表
	queryMainComment(data, res) {
		return axios().request({
			url: '/app/match/comment/queryMainComment',
			method: 'post',
			data: data,
			noToken: res.noToken,
		})
	},

	//创建评论一级列表
	createMainComment(data) {
		return axios().request({
			url: '/app/publish/comment/createMainComment',
			method: 'post',
			data: data
		})
	},

	//查询评论二级列表
	queryCommentChild(data) {
		return axios().request({
			url: '/app/match/comment/queryCommentChild',
			method: 'post',
			data: data,
			// noToken:true,
		})
	},
	
	//创建评论二级列表
	createCommentChi(data) {
		return axios().request({
			url: '/app/publish/comment/createCommentChi',
			method: 'post',
			data: data
		})
	},

	//跟新评论一级列表点赞
	updateMainCommentlike(data) {
		return axios().request({
			url: '/app/like/updateMainCommentlike',
			method: 'post',
			data: data
		})
	},

	//跟新评论二级列表点赞
	updateCommentlikeChi(data) {
		return axios().request({
			url: '/app/like/updateCommentlikeChi',
			method: 'post',
			data: data
		})
	},
	
	//修改userInfo图片
	updateUserInfoImg(data) {
		return axios().request({
			url: '/app/user/info/updateUserInfoImg',
			method: 'post',
			data: data
		})
	},
	
	//修改userInfo名称
	updateUserInfoName(data) {
		return axios().request({
			url: '/app/user/info/updateUserInfoName',
			method: 'post',
			data: data
		})
	},
	
	//UserInfo
	// userInfo(data) {
	// 	return axios().request({
	// 		url: '/sport/userInfo',
	// 		method: 'GET',
	// 		data: data
	// 	})
	// },
	
	//查询新闻轮播图列表
	queryRotationChart(data) {
		return axios().request({
			url: '/app/match/news/queryRotationChart',
			method: 'GET',
			data: data,
			noToken:true,
		})
	},
	
	
	//用户登陆
	login(data) {
		return axios().request({
			url: '/app/login/userAccount/login',
			method: 'post',
			data: data,
			noToken:true,
		})
	},
	

	//查询赛事信息
	queryMatch(data) {
		
		return axios().request({
			url: '/app/matchs/queryMatch',
			method: 'post',
			data: data
		})
	},
	//获创建聊天室信息
	chratChatRoom(data) {
		return axios().request({
			url: '/app/chatRoom/chratChatRoom',
			method: 'post',
			data: data
		})
	},
	
	//获取进入聊天室信息
	addChatRoom(data) {
		// console.log("带入参数",data);
		return axios().request({
			url: '/app/chatRoom/addChatRoom?roomId='+data.roomId,
			method: 'post',
			data: data
		})
	},
	
	// 查询单个赛事
	queryMatchById(data){
		return axios().request({
			url: '/app/matchs/queryMatchById',
			method: 'post',
			data: data
		})
	},
	
	
	// 查询有录像的赛事
	queryMatchListByVideo(data){
		return axios().request({
			url: '/app/matchs/queryMatchListByVideo',
			method: 'post',
			data: data
		})
	},
	
	// 查询有录像比赛的详情
	queryMatchByVideoDetial(data){
		return axios().request({
			url: '/app/matchs/queryMatchByVideoDetial',
			method: 'post',
			data: data
		})
	},
	
	// 查询导航配置列表
	queryNavigationList(data){
		return axios().request({
			url: '/app/matchs/queryNavigationList',
			method: 'post',
			data: data
		})
	},
	
	// 直播源反馈
	matchReport(data){
		return axios().request({
			url: '/app/matchs/matchReport',
			method: 'post',
			data: data
		})
	},

}
export default req;
