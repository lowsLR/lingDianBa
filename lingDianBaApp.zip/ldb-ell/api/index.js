// .author chenjw

import req from '@/api/req.js';
import reqc from '@/api/reqc.js';

// 导出接口
export default {    
	req,
	reqc
}