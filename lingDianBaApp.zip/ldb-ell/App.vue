<script>
	import Vue from 'vue'
	import store from '@/store/index'; //引入vuex
	export default {
		globalData:{
			liveTabIndexId:1,
			vuexStore: store,
		},
		onLaunch: function() {
			let that = this;
			
			// #ifdef APP-PLUS
			// 获取本地应用资源版本号
			plus.runtime.getProperty(plus.runtime.appid, function(widgetInfo) {
				console.log('当前应用版本：' + widgetInfo.version, '应用名称：' + widgetInfo.name);
				// return;
				let datas = {
					version: widgetInfo.version
				};
				that.$req.reqc.verificationAppVersion(datas)
				.then(res => {
					console.log('版本号校验信息：',res);
					if (res.statusCode === 200 && res.data.resultCode === 1) {
						let data = res.data.data;
						console.log('>>>>>版本更新信息<<<<<', data);
						// 下载wgt文件
						if (data.appDownloadPath !== null && data.appVersion !==  datas.version) {
							console.log('下载地址：', data.appDownloadPath);
							uni.showModal({
								title: '版本更新',
								content: '当前有可用版本更新',
								cancelText: '以后再说',
								confirmText: '立即更新',
								success: function (res) {
									if (res.confirm) {
										//创建一个showWaiting对象
										let showLoading = plus.nativeUI.showWaiting("正在初始化");
										
										const downloadTask = uni.downloadFile({
											url: data.appDownloadPath,
											success: downloadResult => {
												console.log('升级包地址：', downloadResult);
												if (downloadResult.statusCode === 200) {
													showLoading.setTitle("正在安装");
													plus.runtime.install(
														downloadResult.tempFilePath,
														{
															force: true
														},
														function() {
															showLoading.setTitle("准备重启应用");
															plus.nativeUI.closeWaiting();
															console.log('install success...');
															// 重启应用
															plus.runtime.restart();
														},
														function(e) {
															console.log(e);
															uni.showToast({
																icon: 'none',
																title: e.message
															});
															plus.nativeUI.closeWaiting();
															console.error('install fail...');
														}
													);
												}
											}
										});
										
										// 监听下载进度
										downloadTask.onProgressUpdate((res) => {
											// if (res.progress > 0) {}
												// let titleText = '下载中:'+res.progress+'%';
												let titleText = `下载中: ${res.progress}%`;
												showLoading.setTitle(titleText);
												// console.log('下载进度' + res.progress, typeof res.progress);
										});
									}
									else if (res.cancel) {
										console.log('用户点击取消');
									}
								}
							});
						}
					} else {
						console.log(res.data.resultMsg);
					}
				})
				.catch(err => {
					console.log(err);
				});
			});
			// #endif
			
			
			// #ifdef APP-PLUS
			// 锁定屏幕方向
			plus.screen.lockOrientation('portrait-primary'); //锁定
			// that.$req.toUpdate();
			// #endif
			
			// 获取系统信息
			uni.getSystemInfo({
				success: function(e) {
					/**
					 *	判断当前所属平台
					 */
					Vue.prototype.appPlatform = 0; // pc端
					
					// #ifdef H5
					Vue.prototype.appPlatform = 3; // H5端
					// #endif
					
					// #ifdef APP-PLUS
					// 获取系统信息同步接口
					// if(uni.getSystemInfoSync().platform === 'android')
					if(e.platform === 'android')
					{
						Vue.prototype.appPlatform = 1; // Android端
					}else{
						Vue.prototype.appPlatform = 2; // iOS端
					}
					// #endif
					
					
					// 获取系统信息
					Vue.prototype.platform = e.platform;
					
					Vue.prototype.windowWidth = e.windowWidth; 
					Vue.prototype.windowHeight = e.windowHeight; 
					// #ifndef MP
					Vue.prototype.StatusBar = e.statusBarHeight; 
					// console.log('状态栏高度：',e.statusBarHeight)
					 
					Vue.prototype.CustomBar = e.statusBarHeight 
					if (e.platform == 'android') {
						Vue.prototype.CustomBar = e.statusBarHeight + 50;
					} else {
						Vue.prototype.CustomBar = e.statusBarHeight + 45;
					};
					// #endif
			
					// #ifdef MP-WEIXIN
					Vue.prototype.StatusBar = e.statusBarHeight;
					let custom = wx.getMenuButtonBoundingClientRect();
					Vue.prototype.Custom = custom;
					Vue.prototype.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
					// #endif		
			
					// #ifdef MP-ALIPAY
					Vue.prototype.StatusBar = e.statusBarHeight;
					Vue.prototype.CustomBar = e.statusBarHeight + e.titleBarHeight;
					// #endif
				}
			})
			
			uni.getStorage({
				key: 'user',
				success: res => {
					console.log("用户本地缓存信息：", res);
					// console.log("如果成功，代表有值");
					that.$store.commit('setToken',res.data.token);
					that.$store.commit('login',res.data.nickName);
				},
				fail: () => {},
				complete: () => {}
			});
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang='scss'>
	/*每个页面公共css */
	
	@import "bw/css/bw.css"; 
	
	/* #ifndef APP-PLUS-NVUE */
	
	/* 阿里字体图标库引入（已使用项目管理） */
	@import url('common/css/font-family/iconfont.css');

	@import './common/uni.css';
	@import "colorui/main.css";
	@import "colorui/icon.css";
	@import './common/general.css';
	@import './common/ccss.css';
	
	/* 富文本组件样式引入 */
	@import url('components/gaoyia-parse/parse.css');

	page {
		color: $default-text-color;
	}
	.bg-black {
		background-color: #1B1B30;
		color: #ffffff;
	}
	
	/* 系统 导航栏 (按钮)样式修改 */
	uni-page-head .uni-page-head {
		padding: 7px 10px;
	}
	.uni-page-head-btn {
		margin-top: 3px;
	}
	
	

	/*边框*/
	.b-b:after,
	.b-t:after {
		position: absolute;
		z-index: 3;
		left: 0;
		right: 0;
		height: 0;
		content: '';
		transform: scaleY(.5);
		border-bottom: 1px solid $border-color-base;
	}

	.b-b:after {
		bottom: 0;
	}

	.b-t:after {
		top: 0;
	}

	/* button样式改写 */
	uni-button,
	button {
		height: 80upx;
		line-height: 80upx;
		font-size: $font-lg + 2upx;
		font-weight: normal;

		&.no-border:before,
		&.no-border:after {
			border: 0;
		}
	}

	uni-button[type=default],
	button[type=default] {
		color: $font-color-dark;
	}

	/* input 样式 */
	.input-placeholder {
		color: #999999;
	}

	.placeholder {
		color: #999999;
	}
	
	/* #endif */
</style>
