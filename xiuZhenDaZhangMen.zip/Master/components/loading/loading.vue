<template>
	<view>
		<uni-popup ref="refLoading" type="center" maskOpacity="0.8" :custom="true" :mask-click="false">
			<view class="loader bb">
				<image class="logo" src="/static/recharge-dialog-loading.png"></image>
				<view class="lt-l lt bb"></view>
			</view>
			<view class="tText bb">{{loadingText}}. . .</view>
		</uni-popup>
	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	
	export default {
		components: {
			uniPopup
		},
		data() {
			return {
				
			}
		},
		props: {
			loadingText:{
				type: String,
				default: 'loading'
			}
		},
		name: 'loading',
		methods: {
			close() {
				this.$refs.refLoading.close()
			},
			open() {
				this.$refs.refLoading.open()
			}
		}
	}
</script>

<style>
	
	.bb {
		box-sizing: border-box;
	}
	
	.loader {
		text-align: center;
		position: relative;
	}
	
	.tText {
		font-size: 40rpx;
		text-align: center;
		color: #FADC81;
		margin-top: 26rpx;
	}
	
	.logo {
		width: 200rpx;
		height: 200rpx;
		animation: rotate 1s linear infinite;
		
		position: fixed;
		vertical-align: top;
		z-index: 1;
	}
	
	.lt-l {
		display: inline-block;
		width: 200rpx;
	    height: 200rpx;
		
	    border: 12rpx solid transparent;
	    border-radius: 50%;
	    box-shadow: inset -999px 0 0 #000;
	    animation: rotate 1s linear infinite;
	}
	.lt {
		background: linear-gradient(90deg, #FADC81, #000000 100%);
		-moz-background-origin: border;
		background-origin: border-box;
	}
	@keyframes rotate{
		from{transform: rotate(0deg)}
		to{transform: rotate(359deg)}
	}
	
</style>
