<template>
	<view>
		<uni-popup ref="refDisciple" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDisciple.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dDisciple" style="display: flex;flex-direction: column;align-items: center;">
				<scroll-view scroll-y="true" style="line-height: 54rpx;font-size: 28rpx;color: #FEFEFE;height: 890rpx;width: 480rpx;padding-top: 50rpx;">
					<view style="display: flex;flex-direction: row;">
						<view style="display: flex;flex: 1;flex-direction: column;line-height: 64rpx;font-size: 30rpx;">
							<view>姓名：{{dialog.name}}</view>
							<view>性别：{{dialog.sex}}</view>
							<view>身份：{{dialog.identity}}</view>
							<view>时代：{{dialog.era}}</view>
						</view>
						<image style="width: 182rpx;height: 247rpx;margin-left: 26rpx;vertical-align: top;" :src="dialog.avatarUrl?dialog.avatarUrl:''"></image>
						
					</view>
					
					<view class="mar-t-30">天赋：{{dialog.specialGift}}</view>
					<view style="display: flex;flex-direction: row;">
						<view style="display: flex;flex: 1;">资质：{{dialog.qualification}}</view>
						<view style="display: flex;flex: 1;">体质：{{dialog.specialPhysique}}</view>
					</view>
					
					<view class="mar-t-30" style="display: flex;flex-direction: row;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>初始气血：{{dialog.p1}}</view>
							<view>初始神念：{{dialog.p3}}</view>
							<view>初始破甲：{{dialog.p5}}</view>
							<view>初始命中：{{dialog.p7}}</view>
							<view>初始暴击：{{dialog.p9}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>初始灵力：{{dialog.p2}}</view>
							<view>初始肉身：{{dialog.p4}}</view>
							<view>初始格挡：{{dialog.p6}}</view>
							<view>初始躲闪：{{dialog.p8}}</view>
							<view>初始抗暴：{{dialog.p10}}</view>
						</view>
					</view>
					
					<view class="mar-t-30" v-html="dialog.description?util.exchangeLineBreak(dialog.description):''"></view>
					
				</scroll-view>
			</view>
		</uni-popup>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				dialog:{}
			}
		},
		props: {
			cHtml:{
				type:String,
				default:''
			}
		},
		name: 'popupWords',
		methods: {
			open(dInfo) {
				this.util.getAvatarUrl(dInfo.sex,dInfo.icon,url => {
					dInfo.avatarUrl = url
					this.dialog = dInfo
					this.$refs.refDisciple.open()
				})
			}
		}
	}
</script>

<style>
	
	.dDisciple {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
