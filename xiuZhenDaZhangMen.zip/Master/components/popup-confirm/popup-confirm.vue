<template>
	<view>
		<uni-popup :ref="refPopup" type="center" :custom="true" :mask-click="maskClick" :maskOpacity="maskOpacity">
			<view class="leaveLayout" style="display: flex;flex-direction: column;align-items: center;color: #FFFFFF;">
				<view style="line-height: 60rpx;padding: 16rpx 30rpx 0 30rpx;display: flex;justify-content: center;align-items: center;height: 184rpx;text-align: center;"><text v-html="content"></text></view>
				<view style="display: flex;flex-direction: row;width: 460rpx;justify-content: center;">
					<block v-if="showCancel">
						<view @tap="close" class="confirmBtn confirmBtn1">取消</view>
						<view @tap="confirm" class="confirmBtn confirmBtn2" style="margin-left: 60rpx;">{{confirmText}}</view>
					</block>
					<block v-else>
						<view @tap="confirm" class="confirmBtn confirmBtn2">{{confirmText}}</view>
					</block>
				</view>
			</view>
		</uni-popup>
		
		
	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	
	export default {
		components: {
			uniPopup
		},
		data() {
			return {
				refPopup:'refPopup'
			}
		},
		props: {
			maskClick: {
				type:Boolean,
				default:false
			},
			showCancel: {
				type:Boolean,
				default:true
			},
			maskOpacity: {
				type:String,
				default: '0.4'
			},
			content: {
				type:String,
				default:''
			},
			confirmText:{
				type:String,
				default:'确定'
			},
			closeAction:{
				type:Boolean,
				default:false
			}
		},
		name: 'popupConfirm',
		methods: {
			open(e) {
				this.$refs[this.refPopup].open()
			},
			confirm() {
				this.$refs[this.refPopup].close()
				this.$emit('confirm')
			},
			close() {
				this.$refs[this.refPopup].close()
				if(this.closeAction) {
					this.$emit('close')
				}
			}
		}
	}
</script>

<style>
	.leaveLayout {
		width: 568rpx;
		height: 342rpx;
		background:url(../../static/map-dialog-leave-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.confirmBtn {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
	.confirmBtn1 {
		color: #676767;
		background:url(../../static/building-disciple-recruit-bt-abandon.png) center center no-repeat;background-size:100% 100%;
	}
	
	.confirmBtn2 {
		background:url(../../static/building-disciple-recruit-bt-get.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
