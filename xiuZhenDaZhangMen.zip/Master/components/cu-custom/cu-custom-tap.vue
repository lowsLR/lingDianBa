<template>
	<view>
		<view class="cu-custom">
			<view class="cu-bar fixed">
				<view class="action" @tap="BackPage" v-if="isBack">
					<!-- <text class="cuIcon-back"></text>
					<slot name="backText"></slot> -->
					<image class="iconBack" src="/static/icon-back.png"></image>
				</view>
				<view class="content">
					<slot name="content"></slot>
				</view>
				<slot name="left"></slot>
				<slot name="right"></slot>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		name: 'cu-custom',
		props: {
			isBack: {
				type: [Boolean, String],
				default: false
			},
			handleBack: {
				type: [Boolean],
				default: false
			}
		},
		methods: {
			BackPage() {
				if(this.handleBack) {
					this.$emit('handleBack')
				}else {
					if(getCurrentPages().length < 2) {
						return uni.reLaunch({
							url:'/pages/login/login'
						})
					}
					uni.navigateBack({
						delta: 1
					})
				}
			}
		}
	}
</script>

<style>
	.cu-bar {
		color: #FFFFFF;
		/* height: calc(100upx + var(--status-bar-height)); */
		height: 100rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-bottom: 1px solid #666666;
		padding-top: var(--status-bar-height);
	}
	
	.cu-custom {
		display: block;
		position: relative;
		height: calc(100upx + var(--status-bar-height));
	}
	
	.cu-bar.fixed {
		position: fixed;
		width: 100%;
		top: 0;
		z-index: 98;
		box-shadow: 0 1upx 6upx rgba(0, 0, 0, 0.1);
	}
	
	.cu-bar .content {
		position: absolute;
		text-align: center;
		width: calc(100% - 340upx);
		left: 0;
		right: 0;
		bottom: 0;
		top: var(--status-bar-height);
		margin: auto;
		height: 60upx;
		font-size: 38upx;
		line-height: 60upx;
		/* cursor: none;
		pointer-events: none; */
		text-overflow: ellipsis;
		white-space: nowrap;
		overflow: hidden;
	}
	
	.cu-bar.tabbar .action {
		font-size: 22upx;
		position: relative;
		flex: 1;
		text-align: center;
		padding: 0;
		display: block;
		height: auto;
		line-height: 1;
		margin: 0;
		background-color: inherit;
		overflow: initial;
	}
	
	.iconBack {
		width: 64rpx;
		height: 64rpx;
		margin-left: 24rpx;
		vertical-align: top;
	}
	
</style>
