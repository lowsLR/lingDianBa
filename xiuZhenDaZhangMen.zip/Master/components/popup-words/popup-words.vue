<template>
	<view>
		<uni-popup ref="words" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.words.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dLayout" style="display: flex;flex-direction: column;align-items: center;">
				<scroll-view scroll-y="true" style="margin-top: 30rpx;width: 480rpx;height: 530rpx;margin-bottom: 30rpx;font-size: 30rpx;color: #FFFFFF;line-height: 50rpx;margin-top: 100rpx;">
					<view class="isVerticleCenter" v-html="cHtml.replace(/\n/g,'<br>')" style="height: 100%;"></view>
				</scroll-view>
				<view @tap="$refs.words.close()" class="dBt">确定</view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		props: {
			cHtml:{
				type:String,
				default:''
			}
		},
		name: 'popupWords',
		methods: {
			open() {
				this.$refs.words.open()
			}
		}
	}
</script>

<style>
	
	.dLayout {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dBt {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
