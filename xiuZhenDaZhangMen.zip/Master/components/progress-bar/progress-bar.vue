<template>
	<view>
		<view class="progressBar" :style="[{'box-shadow':'0px 0px 20rpx '+pbColor,'width':pbWidth+'rpx'}]">
			<view :style="[{'width':(progress/maxProgress)*pbWidth+'rpx','background-color':pbColor}]"></view>
		</view>
	</view>
</template>

<script>
	
	export default {
		data() {
			return {
				
			}
		},
		props: {
			pbWidth:{
				type:Number,
				default:750
			},
			pbColor:{
				type: String,
				default: '#FFFFFF'
			},
			progress:{
				type:Number,
				default:0
			},
			maxProgress:{
				type:Number,
				default:100
			},
		},
		name: 'progress-bar',
		methods: {
			close() {
				this.$refs.refLoading.close()
			},
			open() {
				this.$refs.refLoading.open()
			}
		}
	}
</script>

<style>
	
	.progressBar {
		/* width: 400rpx; */
		height: 32rpx;
		border-radius: 16rpx;
		/* margin: 10rpx 0 10rpx 6rpx; */
		display: flex;
		flex-direction: row;
		align-items: center;
		/* box-shadow:0px 0px 20rpx #F9DB87; */
	}
	
	.progressBar view {
		height: 100%;
		/* background-color: #F9DB87; */
		border-radius: 20rpx;
	}
	
</style>
