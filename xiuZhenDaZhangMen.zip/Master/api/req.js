import {httpRequest} from '@/js_sdk/luch-request/index.js'
import util from '@/common/util.js'
import requestCrypto from '@/api/request-crypto.js'
import md5 from '@/js_sdk/ccdzhang-dokey/md5.js'
let CryptoJS = require('@/js_sdk/crypto-js');

const developType = 2   // 1:开发  2:正式
let isDes = false       // 是否加密
let ipIndex = 0
let httpUrls = [
	'http://47.112.131.52:21051'
]
let loadUrl = 'http://47.112.131.52:8097/v.json'
if(developType==2) {
	isDes = true
	httpUrls = [
		'http://110.172.104.145',
		'http://110.172.104.146'
	]
	loadUrl = 'https://cnjfjfa-xzmffu1lop0.com:8800/jm/v.json'
}

const REQUEST_OPTION = {
	URL:'URL',
	PARAMETER:'PARAMETER',
	SUCCESS:'SUCCESS',
	ERROR:'ERROR',
	LOADING_HIDE:'LOADING_HIDE',
	LOADING_1:'LOADING_1',  // 只开不关，优先级大于 LOADING_HIDE
	LOADING_2:'LOADING_2',  // 只关不开，优先级大于 LOADING_HIDE
	DATA:'DATA',
	HANDLE_MAP:'HANDLE_MAP',
	HANDLE_AUCTION:'HANDLE_AUCTION',
	HANDLE_ERROR_CODE:'HANDLE_ERROR_CODE'
}

const REQUEST_URL = {
	jmAccountRegist:'/jm-account/account/regist',
	jmAccountLogin:'/jm-account/account/login',
	jmServerServerList:'/jm-account/server/serverList',
	jmServerServerTime:'/jm-account/server/serverTime',
	jmServerConnect:'/jm/server/connect',
	jmServerSettle:'/jm/server/settle',
	jmRequestCmd:'/jm/request/cmd'
}

let gameUrlPre = ''
let gameUrls = [REQUEST_URL.jmServerConnect,REQUEST_URL.jmServerSettle,REQUEST_URL.jmRequestCmd]
const getRequestUrl = (url) => {
	let requestUrl = ''
	if(gameUrls.indexOf(url)!=-1) {
		if(!gameUrlPre) {
			gameUrlPre = getApp().globalData.gameUrlPre
		}
		requestUrl = gameUrlPre+url
	}else {
		requestUrl = httpUrls[ipIndex]+url
	}
	return requestUrl
}

const setIpIndex = (url) => {
	if(gameUrls.indexOf(url)==-1) {
		ipIndex++
		if(ipIndex>httpUrls.length-1) {
			ipIndex = 0
		}
	}
}
	
let currVersion = ''
// #ifdef APP-PLUS
plus.runtime.getProperty(plus.runtime.appid, function(inf) {
	currVersion = inf.version.split('.').join('')
})
// #endif

const getServerTime = (times,callback) => {
	var option = {}
	option[REQUEST_OPTION.LOADING_HIDE] = true
	option[REQUEST_OPTION.URL] = REQUEST_URL.jmServerServerTime
	option[REQUEST_OPTION.SUCCESS] = function(resData) {
		if(callback) {
			callback(resData)
		}
	}
	option[REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {
		times++
		if(times<4) {
			getServerTime(times,callback)
		}else {
			if(callback) {
				callback()
			}
		}
	}
	handleRequest(option)
}

// 判断更新
const toUpdate = () => {
	if(!currVersion) {
		plus.runtime.getProperty(plus.runtime.appid, function(inf) {
			currVersion = inf.version.split('.').join('')
			if(!currVersion) {
				currVersion = '100'  //预防一直拿不到的死循环
			}
			toUpdate()
		})
		return
	}
	try {
		uni.request({
			url: loadUrl,
			header: {
				"Cache-Control":"no-cache"
			},
			success: (res) => {
				if(res.statusCode==200) {
					const resArray = res.data
					if(resArray && currVersion) {
						let keyArray = []
						for(let key in resArray) {
							keyArray.push(parseInt(key))
						}
						
						if(keyArray.length>0) {
							keyArray.sort(function(a,b){
								return b - a;
							})
							
							const targetVersion = keyArray[0]
							if(targetVersion>parseInt(currVersion)) {
								//存在最新的
								let wgtArray = resArray[targetVersion]
								if(wgtArray && wgtArray.length>0) {
									const wgtUrl = wgtArray[wgtArray.length-1]
									uni.reLaunch({
										url:'/pages/uLoad/uLoad?url='+wgtUrl
									})
								}
							}
						}
					}
				}
			}
		})
	}catch(e) {}
}

const  handleLoadingShow = (option) => {
	if(option[REQUEST_OPTION.LOADING_1]) {
		uni.showLoading({
		    title:'loading',
			mask:true
		})
	}else if(option[REQUEST_OPTION.LOADING_2]) {
		// 只关不开，不做任何处理
	}else {
		if(!option[REQUEST_OPTION.LOADING_HIDE]) {
			uni.showLoading({
			    title:'loading',
				mask:true
			})
		}
	}
}

const  handleLoadingHide = (option) => {
	if(option[REQUEST_OPTION.LOADING_1]) {
		// 只开不关，不做任何处理
	}else if(option[REQUEST_OPTION.LOADING_2]) {
		uni.hideLoading()
	}else {
		if(!option[REQUEST_OPTION.LOADING_HIDE]) {
			uni.hideLoading()
		}
	}
}

const  handleRequest = (option) => {
	var optionParams = option[REQUEST_OPTION.PARAMETER]
	if(!optionParams) {
		optionParams = {}
	}
	
	switch(option[REQUEST_OPTION.URL]) {
		case REQUEST_URL.jmRequestCmd:
			optionParams.requestId = util.generateUUID()
			optionParams.timestamp = getApp().globalData.serverTime
			optionParams.secret = util.gameSign(optionParams)
			break;
	}
	handleLoadingShow(option)
	
	// const requestUrl = httpUrls[ipIndex]+option[REQUEST_OPTION.URL]
	const requestUrl = getRequestUrl(option[REQUEST_OPTION.URL])
	let requestParams = optionParams
	if(isDes) {
		requestParams = requestCrypto.requestChatEncrypt(optionParams)
	}
	httpRequest.post(requestUrl, requestParams).then(res => {
		handleLoadingHide(option)
		if(res.statusCode==200) {
			let resData = res.data
			if(resData) {
				if(isDes) {
					resData = requestCrypto.resultRequestDecrypt(resData)
				}
				if(option[REQUEST_OPTION.URL]==REQUEST_URL.jmRequestCmd) {
					const ts = resData.ts
					if(ts) {
						getApp().globalData.serverTime = ts
					}
					
					const resCode = resData.code
					if(resCode==1) {
						let responseData = resData.responseData;
						if(responseData.errCode){
							if([904,906,915,922,902].indexOf(responseData.errCode)!=-1 && option[REQUEST_OPTION.HANDLE_MAP]) {
								option[REQUEST_OPTION.HANDLE_MAP](responseData)
							}else {
								if(option[REQUEST_OPTION.HANDLE_ERROR_CODE]) {
									option[REQUEST_OPTION.HANDLE_ERROR_CODE](responseData.errMsg)
								}else {
									//cmd请求错误 输出错误消息
									uni.showToast({
										title:responseData.errMsg,
										icon:'none'
									})
								}
							}
						}else{
							// #ifdef APP-PLUS
							let version = responseData.version
							if(version && currVersion) {
								let targetVersion = parseInt(version.split('.').join(''))
								if(targetVersion>parseInt(currVersion)) {
									toUpdate()
								}
							}
							// #endif
							
							/**
							 * 更新全局物品表
							 */
							util.updateMaterialObj(responseData.consume,true)
							util.updateMaterialObj(responseData.gain,false)
							util.updateEquips(responseData.equips)
							util.updateDisciples(responseData.disciples)
							
							if(option[REQUEST_OPTION.SUCCESS]) {
								option[REQUEST_OPTION.SUCCESS](responseData)
							}
						}
					}else if([2,3,4,5,6].indexOf(resCode)!=-1) {
						let toastTitle = ''
						switch(resCode) {
							case 2:
								toastTitle = '命令错误'
								break;
								
							case 3:
								toastTitle = '处理错误'
								break;
								
							case 4:
								toastTitle = '未授权'
								break;
								
							case 5:
								toastTitle = '账号已在其他设备登录'
								break;
								
							case 6:
								toastTitle = '账号已被锁定'
								break;
						}
						uni.showToast({
							title:toastTitle,
							icon:'none'
						})
						if([4,5].indexOf(resCode)!=-1) {
							util.clearLoginData()
							setTimeout(function() {
								uni.reLaunch({
									url:'/pages/login/login'
								})
							},200)
						}else {
							if(option[REQUEST_OPTION.HANDLE_ERROR_CODE]) {
								option[REQUEST_OPTION.HANDLE_ERROR_CODE]()
							}
						}
					}else {
						const resultMsg = resData.resultMsg
						if(option[REQUEST_OPTION.HANDLE_ERROR_CODE]) {
							option[REQUEST_OPTION.HANDLE_ERROR_CODE](resultMsg)
						}else {
							if(resultMsg) {
								uni.showToast({
									title:resultMsg,
									icon:'none'
								})
							}
						}
					}
				}else {
					// 游戏命令和其他接口返回结果分开
					const resCode = resData.resultCode
					if(resCode==1) {
						if(option[REQUEST_OPTION.SUCCESS]) {
							option[REQUEST_OPTION.SUCCESS](resData.data)
						}
					}else {
						if(option[REQUEST_OPTION.HANDLE_ERROR_CODE]) {
							option[REQUEST_OPTION.HANDLE_ERROR_CODE]()
						}else {
							uni.showToast({
								title:resData.resultMsg,
								icon:'none'
							})
						}
					}
				}
			}
		}
	}).catch(err => {
		setIpIndex(option[REQUEST_OPTION.URL])
		if(!option[REQUEST_OPTION.LOADING_HIDE]) {
			uni.hideLoading()
		}
		if(option[REQUEST_OPTION.ERROR]) {
			option[REQUEST_OPTION.ERROR](err)
		}else {
			uni.showToast({
				title:'网络错误',
				icon:'none'
			})
		}
		console.log(err.toString())
	})
}

export default {
	toUpdate,
	REQUEST_OPTION,
	REQUEST_URL,
	handleRequest,
	getServerTime
}
