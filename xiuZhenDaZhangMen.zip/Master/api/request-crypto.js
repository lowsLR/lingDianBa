let CryptoJS = require('@/js_sdk/crypto-js');
var toRequestDes = true;
var requestDesKey;
const getChatDesKey = () => {
	if(!requestDesKey) {
		requestDesKey = CryptoJS.enc.Utf8.parse("dzm0#999gm");
	}
	return requestDesKey;
}
const requestDecrypt = (content) => {
	var bytes = CryptoJS.DES.decrypt({
		ciphertext: CryptoJS.enc.Hex.parse(content)
	}, getChatDesKey(), {
		mode: CryptoJS.mode.ECB,
		padding: CryptoJS.pad.Pkcs7
	});
	var decryptResult = bytes.toString(CryptoJS.enc.Utf8);
	return decryptResult.toString();
}
const requestEncrypt = (content) => {
	var encryptResult = CryptoJS.DES.encrypt(content, getChatDesKey(), {
		mode: CryptoJS.mode.ECB,
		padding: CryptoJS.pad.Pkcs7
	});
	return encryptResult.ciphertext.toString().toUpperCase();
}
export default {
	requestChatEncrypt(requestData) {
		if(toRequestDes) {
			requestData = requestEncrypt(JSON.stringify(requestData));
		}
		return requestData;
	},
	resultRequestDecrypt(resultData) {
		if(toRequestDes) {
			resultData = JSON.parse(requestDecrypt(resultData));
		}
		return resultData;
	}
}