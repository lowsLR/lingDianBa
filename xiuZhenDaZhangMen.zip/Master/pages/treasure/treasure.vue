<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">宗门宝库</block>
		</cu-custom>
		
		<view style="display: flex;justify-content: center;align-items: center;height: 140rpx;">
			<uni-segmented-control style="width: 650rpx;" :current="current" :values="items" @clickItem="onClickItem" style-type="button" active-color="#CBBDAF"></uni-segmented-control>
		</view>
		
		<scroll-view scroll-y="true" class="sv">
			<block v-if="datas[materialLocation] && datas[materialLocation].length>0">
				<view v-for="(array,i1) in datas[materialLocation]" :key="i1" style="display: flex;flex-direction: row;margin-bottom: 10rpx;">
					<view @tap="tapItem(info)" v-for="(info,i2) in array" :key="i2" class="itemLayout" :class="'m-'+info.quality">
						{{info.name}}
						<!-- <text style="position: absolute;bottom: 8rpx;right: 18rpx;font-size: 24rpx;" v-if="info.count">{{info.count}}</text> -->
					</view>
				</view>
			</block>
			<view v-else style="text-align: center;color: #666666;font-size: 30rpx;line-height: 200rpx;">暂无数据</view>
		</scroll-view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDialog.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;" :class="'m-'+dialogInfo.quality">{{dialogInfo.name}}</view>
				<scroll-view scroll-y="true" style="line-height: 44rpx;font-size: 26rpx;color: #818181;height: 390rpx;width: 460rpx;border-bottom: solid 1px #333333;" :class="dialogInfo.exchange?'':'notSell'">
					<block v-if="materialLocation==2">
						<view style="display: flex;flex-direction: row;">
							<view style="display: flex;flex-direction: column;flex: 1;">
								<view>品级：{{dialogInfo.qualityName}}</view>
								<view>类型：{{dialogInfo.typeText}}</view>
								<view>等级：{{dialogInfo.sl}}/{{dialogInfo.maxLevel}}</view>
								<view>限制：{{dialogInfo.limitText}}</view>
								<view>评分：{{dialogInfo.equipScore}}</view>
							</view>
							<view style="display: flex;flex-direction: column;flex: 1;padding-left: 40rpx;">
								<view style="display: flex;flex-direction: row;">
									基础：
									<view style="display: flex;flex: 1;flex-direction: column;">
										<view v-for="(text,index) in dialogInfo.basicPropertyArray" :key="index">{{text}}</view>
									</view>
								</view>
								<view style="display: flex;flex-direction: row;">
									附加：
									<view v-if="dialogInfo.extraPropertyArray && dialogInfo.extraPropertyArray.length>0" style="display: flex;flex: 1;flex-direction: column;">
										<view v-for="(text,index) in dialogInfo.extraPropertyArray" :key="index">{{text}}</view>
									</view>
									<text v-else>无</text>
								</view>
							</view>
						</view>
						<view v-if="dialogInfo.equipSe" style="text-align: center;margin-top: 20rpx;">{{dialogInfo.equipSe}}</view>
					</block>
					<block v-else>
						<view>物品品质：{{dialogInfo.qualityName}}</view>
						<view>物品类别：{{jsonParse.getMaterialNameByType(dialogInfo.type)}}</view>
						<view>拥有数量：{{dialogInfo.count}}</view>
						<view v-if="dialogInfo.exchange">出售价格：{{dialogInfo.exchange?dialogInfo.exchange.priceText:''}}</view>
						<view style="padding-top: 10rpx;"><text style="color: transparent;">空格</text>{{dialogInfo.materialDescription}}</view>
					</block>
				</scroll-view>
				
				<block v-if="dialogInfo.exchange">
					<view style="display: flex;flex-direction: row;color: #666666;font-size: 32rpx;justify-content: flex-end;width: 460rpx;margin: 26rpx 0;">
						<image @tap="tapAddMinus(1)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-minus.png"></image>
						<view style="padding: 0 20rpx;">{{dialogInfo.sellCount}}/{{dialogInfo.count}}</view>
						<image @tap="tapAddMinus(2)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-add.png"></image>
					</view>
					<view @tap="tapSell" class="dialogBt">出售</view>
				</block>
				
			</view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
		<popup-confirm ref="refBuy" @confirm="ajaxSell" :content="tdialogSellText" maskOpacity="0.8"></popup-confirm>
		<popup-confirm ref="refText" :showCancel="false" :content="dialogText"></popup-confirm>
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import popupWords from '@/components/popup-words/popup-words.vue'
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	import uniSegmentedControl from "@/components/uni-segmented-control/uni-segmented-control.vue"
	var _self
	
	export default {
		components:{
			uniPopup,
			popupWords,
			popupConfirm,
			uniSegmentedControl
		},
		data() {
			return {
				name:'',
				items: ['材料','装备','丹药','特殊'],
				locations:[1,2,3,4],  // 1 - 材料 - 铸造材料、炼丹材料
				current: 0,
				listArray:[[1,1,1],[1,1,1],[1,1,1],[1,1,1],[1,1,1],[1,1,1]],  // [[1,1,1],[1,1]]
				loaded:false,
				marketType:1,
				materialLocation:1,
				datas:{},
				dialogInfo:{},
				tdialogSellText:'',
				dialogText:'',
				tapInfo:null,
				wordsNew:'',
				keyWordsNew:'',
				maxSellCount:500
			}
		},
		onLoad(option) {
			_self = this
			_self.$nextTick(function(){
				_self.toGetWordsNew()
				_self.loadList()
			})
		},
		methods: {
			toWordsNew(count) {
				let wordObj = _self.jsonParse.getNewWords('treasure')
				if(wordObj) {
					if(wordObj.count>count) {
						_self.wordsNew = wordObj.content
						_self.$refs.refWords.open()
						
						uni.setStorage({
						    key: _self.keyWordsNew,
						    data: count+1
						})
					}
				}
			},
			toGetWordsNew() {
				let keyWordsNew = 'wnt-'+getApp().globalData.sectView.sectId
				_self.keyWordsNew = keyWordsNew
				
				uni.getStorage({
				    key: keyWordsNew,
					success:function(res){
						_self.toWordsNew(res.data)
					},
				    fail:function(res){
						_self.toWordsNew(0)
					}
				})
			},
			loadList() {
				let materialArray = []
				let materialLocation = _self.materialLocation
				let materialObj = getApp().globalData.materialObj
				if(materialLocation==2) {
					let equips = getApp().globalData.equips
					equips.forEach((item)=>{
						let equipInfo = _self.jsonParse.getEquipInfo(item.etid,item.sl)
						if(equipInfo) {
							item.quality = equipInfo.quality
							item.qualityName = _self.jsonParse.getEquipQualityName(equipInfo.quality)
							item.maxLevel = _self.jsonParse.getEquipMaxLevel(item.etid)
							item.name = equipInfo.name
							item.limitText = equipInfo.require.replace('=','>=')
							item.basicPropertyArray = _self.util.parseEquipProperty(item.bp,'+')
							item.extraPropertyArray = _self.util.parseEquipProperty(item.ep,'+')
							
							let dressOccupation = equipInfo.dressOccupation
							let typeText = _self.jsonParse.getEquipTypeName(equipInfo.type)
							if(dressOccupation!='无') {
								typeText = dressOccupation+typeText
							}
							item.typeText = typeText
							item.equipSe = _self.util.exchangeFR(item.se)
							
							materialArray.push(item)
						}
					})
				}else {
					Object.keys(materialObj).map(key => {
						let obj = materialObj[key]
						if(obj.count>0) {
							let objType = obj.type
							if((materialLocation==1 && (objType==2 || objType==3)) || (materialLocation==3 && objType==5) || (materialLocation==4 && objType==4)) {
								let materialInfo = _self.jsonParse.getMaterialInfo(objType,obj.id)
								if(materialInfo) {
									let exchangeInfo = _self.jsonParse.getExchangeMaterialInfo(materialInfo.name)
									if(exchangeInfo) {
										materialInfo.exchange = exchangeInfo
									}
									materialInfo.count = obj.count
									materialArray.push(materialInfo)
								}
							}
						}
					})
				}
				let listArray = []
				materialArray.forEach((info,index)=>{
					if(index%3==0) {
						let itemArray = []
						itemArray.push(info)
						if(index+2<materialArray.length) {
							let info1 = materialArray[index+1]
							let info2 = materialArray[index+2]
							itemArray.push(info1)
							itemArray.push(info2)
						}else if(index+1<materialArray.length) {
							let info1 = materialArray[index+1]
							itemArray.push(info1)
						}
						listArray.push(itemArray)
					}
				})
				_self.datas[_self.materialLocation] = listArray
				_self.$forceUpdate()
			},
			doTextDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			doSellDialog(text) {
				_self.tdialogSellText = text
				_self.$refs.refBuy.open()
			},
			tapSell() {
				let buyText = '物品：'+_self.dialogInfo.name+'<br>数量：'+_self.dialogInfo.sellCount
				_self.doSellDialog(buyText)
			},
			tapAddMinus(type) {
				// 限制：一次最多500个
				let sellCount = _self.dialogInfo.sellCount
				switch(type) {
					case 1:
						if(sellCount>1) {
							sellCount--
						}
						break;
						
					case 2:
						if(sellCount==_self.dialogInfo.count || sellCount==_self.maxSellCount) {
							_self.showToast('已是最大出售数')
						}else {
							sellCount++
						}
						break;
				}
				if(sellCount!=_self.dialogInfo.sellCount) {
					_self.dialogInfo.sellCount = sellCount
				}
			},
			toCloseDialog() {
				_self.$refs.refDialog.close()
			},
			toOpenDialog() {
				_self.$refs.refDialog.open()
			},
			tapItem(info) {
				if(_self.materialLocation==2) {
					info.equipScore = _self.util.getEquipScore(info.bp,info.ep)
				}else {
					info.qualityName = _self.jsonParse.getMaterialQualityName(info.quality)
				}
				
				let sellCount = info.count
				if(sellCount>_self.maxSellCount) {
					sellCount = _self.maxSellCount
				}
				info.sellCount = sellCount
				_self.dialogInfo = info
				_self.toOpenDialog()
			},
			onClickItem(e) {
				let eCurrent = e.currentIndex
				if (_self.current != eCurrent) {
					_self.current = eCurrent
					_self.materialLocation = _self.locations[eCurrent]
					
					if(!_self.datas[_self.materialLocation]) {
						_self.loadList()
					}
				}
			},
			ajaxSell() {
				let sellAll = false
				if(_self.dialogInfo.sellCount==_self.dialogInfo.count) {
					sellAll = true
				}
				
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'8_4',
					params:{
						materialType:_self.dialogInfo.type,
						typeId:_self.dialogInfo.id,
						count:_self.dialogInfo.sellCount
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.showToast('出售成功')
						_self.loadList()
						if(sellAll) {
							_self.toCloseDialog()
						}else {
							_self.dialogInfo.sellCount = 1
						}
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogLayout {
		width: 568rpx;
		height: 762rpx;
		background:url(../../static/market-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogBt {
		width: 442rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #A31B27;
		background:url(../../static/market-detail-dialog-bt-buy.png) center center no-repeat;background-size:100% 100%;
	}
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 100rpx - 140rpx);
	}
	
	.itemLayout {
		width: 226rpx;
		height: 120rpx;
		margin-left: 19rpx;
		line-height: 40rpx;
		padding-top: 4rpx;
		font-size: 28rpx;
		color: #FFFFFF;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		
		background:url(../../static/disciple-equip-list-bg-item.png) center center no-repeat;background-size:100% 100%;
	}
	
	.notSell {
		height: 580rpx!important;
		border-bottom: none!important;
	}
	
	
</style>
