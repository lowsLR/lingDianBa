<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">原材料</block>
		</cu-custom>
		
		<scroll-view scroll-y="true" class="sv">
			<block v-if="materialList.length>0">
				<view v-for="(array,i1) in materialList" :key="i1" class="rowLayout">
					<view @tap="tapItem(info)" v-for="(info,i2) in array" :key="i2" class="itemLayout" style="position: relative;">
						{{info.name}}
						<text style="position: absolute;bottom: 8rpx;right: 18rpx;font-size: 24rpx;" v-if="info.count">{{info.count}}</text>
					</view>
				</view>
			</block>
			<view v-else style="text-align: center;color: #666666;font-size: 30rpx;line-height: 200rpx;">暂无数据</view>
		</scroll-view>
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				materialList:[]
			}
		},
		onLoad(option) {
			_self = this
			_self.loadList()
		},
		methods: {
			tapItem(info) {
				uni.$emit('mix', info)
				uni.navigateBack({
					delta:1
				})
			},
			loadList() {
				// 获取存在的融合材料   背包有的才显示
				let mixNameArray = _self.jsonParse.getMaterialMixNameArray()
				let materialArray = []
				let materialObj = getApp().globalData.materialObj
				Object.keys(materialObj).map(key => {
					let obj = materialObj[key]
					if(obj.count>0) {
						let materialInfo = _self.jsonParse.getMaterialInfo(obj.type,obj.id)
						if(materialInfo) {
							if(mixNameArray.indexOf(materialInfo.name)!=-1) {
								materialInfo.count = obj.count
								materialArray.push(materialInfo)
							}
						}
					}
				})
				
				let listArray = []
				materialArray.forEach((info,index)=>{
					if(index%3==0) {
						let itemArray = []
						itemArray.push(info)
						if(index+2<materialArray.length) {
							let info1 = materialArray[index+1]
							let info2 = materialArray[index+2]
							itemArray.push(info1)
							itemArray.push(info2)
						}else if(index+1<materialArray.length) {
							let info1 = materialArray[index+1]
							itemArray.push(info1)
						}
						listArray.push(itemArray)
					}
				})
				_self.materialList = listArray
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
	.itemLayout {
		width: 226rpx;
		height: 120rpx;
		margin-left: 19rpx;
		line-height: 40rpx;
		padding-top: 4rpx;
		font-size: 28rpx;
		color: #FFFFFF;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		
		background:url(../../static/disciple-equip-list-bg-item.png) center center no-repeat;background-size:100% 100%;
	}
	
	.rowLayout {
		display: flex;
		flex-direction: row;
		margin-bottom: 10rpx;
	}
	
	.rowLayout:first-child {
		margin-top: 10rpx;
	}
	
	
</style>
