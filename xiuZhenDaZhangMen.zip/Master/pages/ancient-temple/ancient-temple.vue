<template>
	<view style="container">
		<cu-custom :isBack="true"><block slot="content">古圣阁</block></cu-custom>
		<!-- tar切换 -->
		<view style="display: flex;justify-content: center;align-items: center;height: 140rpx;">
			<uni-segmented-control
				style="width: 650rpx;"
				:current="current"
				:values="items"
				@clickItem="onClickItem"
				style-type="button"
				active-color="#CBBDAF"
			></uni-segmented-control>
		</view>

		<template v-if="current == 0">
			<view class="eyes"><image src="../../static/ancient-temple/eyes.png" mode=""></image></view>

			<!--进度条-->
			<view class="progress">
				<view class="progress-box"><progress percent="60" activeColor="red" stroke-width="14" border-radius="8" backgroundColor="rgba(0,0,0,1)" /></view>
				<view class="num">50000/100000</view>
			</view>

			<!-- 伤害计算 -->
			<view class="calculate-damage">
				<view class="calculate">总伤害:500000</view>
				<view class="damage">
					<view class="surplus">
						剩余次数:
						<text>5</text>
						/5
					</view>
					<view class="addpic"></view>
				</view>
			</view>

			<!-- 战 -->
			<view class="btn-layout"><view class="btn">战</view></view>

			<!-- 阵型 -->
			<view class="lineup-reward">
				<view>阵型</view>
				<view>奖励排名</view>
			</view>
		</template>
	</view>
</template>

<script>
import uniSegmentedControl from '@/components/uni-segmented-control/uni-segmented-control.vue';

export default {
	components: {
		uniSegmentedControl
	},
	data() {
		return {
			items: ['道奴之影', '古圣阁'],
			current: 0
		};
	},
	methods: {
		onClickItem(e) {
			let eCurrent = e.currentIndex;
			this.current = eCurrent;
			console.log(eCurrent, '目前是eCurrent');
			if(eCurrent == 1){
				uni.navigateTo({
					url:'/pages/ancient-science/ancient-science'
				})
			}
		}
	}
};
</script>

<style scoped>
.container {
	width: 750rpx;
	height: 100vh;
	background: url(../../static/market-detail/other-black-bg.png) center center no-repeat;
	background-size: 750rpx 1550rpx;
}

.eyes {
	width: 100%;
	height: 500rpx;
	display: flex;
	align-items: center;
	justify-content: center;
}

.eyes > image {
	width: 424rpx;
	height: 424rpx;
	display: block;
}
.progress {
	padding: 0 91rpx;
}
.progress-box {
	/* 暂时这里放背景图的 */
	border: 1px solid #ff0000;
	border-radius: 16rpx;
	overflow: hidden;
}
.progress .num {
	width: 100%;
	color: #fefefe;
	font-size: 30rpx;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 36rpx;
}

.calculate-damage {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin: 66rpx 0 58rpx 0;
}

.calculate-damage .calculate,
.calculate-damage .damage {
	flex: 1;
	color: #fefefe;
	font-size: 30rpx;
	display: flex;
	align-items: center;
	justify-content: center;
}
.calculate-damage .damage {
	display: flex;
	align-items: center;
}

.calculate-damage .damage .surplus {
	display: flex;
	align-items: center;
}
.calculate-damage .damage .addpic {
	width: 40rpx;
	height: 40rpx;
	margin-left: 10rpx;
	background: url(../../static/ancient-temple/yellow-add.png) center center no-repeat;
	background-size: 100% 100%;
}

.btn-layout {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
}

.btn-layout .btn {
	width: 500rpx;
	height: 88rpx;
	background: url(../../static/ancient-temple/z-btn.png) center center no-repeat;
	background-size: 100% 100%;
	font-size: 32rpx;
	color: #ffffff;
	text-align: center;
	line-height: 88rpx;
	font-weight: 500;
}

.lineup-reward {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 13rpx;
}

.lineup-reward > view {
	width: 220rpx;
	height: 88rpx;
	font-size: 32rpx;
	font-weight: 500;
	color: #ffffff;
	line-height: 88rpx;
	text-align: center;
	background: url(../../static/ancient-temple/bottom-btn.png) center center no-repeat;
	background-size: 100% 100%;
	margin: 30rpx;
}
</style>
