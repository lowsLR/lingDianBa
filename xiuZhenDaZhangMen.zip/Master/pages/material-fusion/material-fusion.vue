<template>
	<view class="container">
		<cu-custom :isBack="true"><block slot="content">材料融合</block></cu-custom>

		<!-- tar切换 -->
		<view style="display: flex;justify-content: center;align-items: center;height: 140rpx;">
			<uni-segmented-control
				style="width: 650rpx;"
				:current="current"
				:values="items"
				@clickItem="onClickItem"
				style-type="button"
				active-color="#CBBDAF"
			></uni-segmented-control>
		</view>

		<!-- 材料 -->
		<template v-if="current == 0">
			<!-- 原材料 -->
			<view class="rawMaterial">
				<view class="content">
					<view class="raw">原材料:</view>
					<view class="add"></view>
					<view class="calculation">
						<view class="subtraction"></view>
						<view class="num">
							<text>5</text>
							/5
						</view>
						<view class="addition"></view>
					</view>
				</view>
			</view>

			<!-- 获得 -->
			<view class="rawMaterial qxpadding">
				<view class="content">
					<view class="raw">融合获得:</view>
					<view class="colorOrange">获得材料名称</view>
					<view class="calculation">成功概率:90%</view>
				</view>
			</view>

			<!-- 描述 -->
			<view class="describe">
				<view class="content">
					<scroll-view scroll-y="true" class="scrollView">
						<view>1、可融合的材料为锻造材料，炼丹材料，符阵 石。</view>
						<view>2、放入的原材料数量越多，成功率越高，上限5 个原材料，成功率100%。</view>
						<view>1、可融合的材料为锻造材料，炼丹材料，符阵 石。</view>
						<view>2、放入的原材料数量越多，成功率越高，上限5 个原材料，成功率100%。</view>
					</scroll-view>
				</view>
			</view>

			<view class="fusion"><view class="content">融合</view></view>
		</template>

		<!-- 神兵 -->
		<template v-if="current == 1">
			<view class="selecter">
				<!-- 添加材料合成 -->
				<view class="synthesis">
					<view></view>
					<view></view>
					<view></view>
					<view></view>
				</view>
			</view>
			<view class="nopic">我没有这张图片</view>
			<view class="marketBigPic"><view class="marketpic"></view></view>
			<view class="nopic">我没有这张图片</view>
			<view class="marketBigWhat"><view class="marketwhat"></view></view>
			<!-- 描述 -->
			<view class="describe-current1">
				<view class="content">
					<scroll-view scroll-y="true" class="scrollView">
						<view>1、可融合的材料为锻造材料，炼丹材料，符阵 石。</view>
						<view>2、放入的原材料数量越多，成功率越高，上限5 个原材料，成功率100%。</view>
						<view>1、可融合的材料为锻造材料，炼丹材料，符阵 石。</view>
						<view>2、放入的原材料数量越多，成功率越高，上限5 个原材料，成功率100%。</view>
					</scroll-view>
				</view>
			</view>

			<view class="consume"><view class="content">锻造(消耗5000矿石)</view></view>
		</template>
	</view>
</template>

<script>
import uniSegmentedControl from '@/components/uni-segmented-control/uni-segmented-control.vue';
export default {
	components: {
		uniSegmentedControl
	},
	data() {
		return {
			// tar选项卡
			items: ['材料融合', '神兵锻造'],
			current: 0
		};
	},
	methods: {
		onClickItem(e) {
			let eCurrent = e.currentIndex;
			this.current = eCurrent;
			console.log(eCurrent, '目前是eCurrent');
		}
	}
};
</script>

<style scoped>
.container {
	width: 750rpx;
	height: 100vh;
	background: url(../../static/home-bg.png) center center no-repeat;
	background-size: 750rpx 1550rpx;
	overflow: hidden;
}
.rawMaterial {
	padding: 60rpx;
	font-size: 30rpx;
	color: #ffffff;
}
.qxpadding {
	padding-top: 0;
	margin-top: 12rpx;
}
.rawMaterial .content {
	display: flex;
	align-items: center;
	flex-wrap: nowrap;
}
.rawMaterial .content > view {
	/* flex: 1; */
	/* border: 1px solid #f59; */
	box-sizing: border-box;
}
.rawMaterial .raw {
	/* margin-right: 20rpx; */
}

.rawMaterial .add {
	/* margin-right: 20rpx; */
	width: 238rpx;
	height: 74rpx;
	background: url(../../static/market-detail/market-detail-yellow-add.png) center center no-repeat;
	background-size: 100% 100%;
	margin: 0 20px;
}

.rawMaterial .colorOrange {
	margin-right: 20rpx;
	width: 238rpx;
	height: 74rpx;
	background: url(../../static/market-detail/market-detail-yellow-msk.png) center center no-repeat;
	background-size: 100% 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	color: #ffb662;
	font-size: 30rpx;
}

.rawMaterial .calculation {
	display: flex;
	align-items: center;
}

.rawMaterial .subtraction,
.rawMaterial .addition {
	width: 40rpx;
	height: 40rpx;
}

.rawMaterial .subtraction {
	margin-right: 20rpx;
	background: url(../../static/market-detail-dialog-bt-minus.png) center center no-repeat;
	background-size: 100% 100%;
}
.rawMaterial .addition {
	background: url(../../static/market-detail-dialog-bt-add.png) center center no-repeat;
	background-size: 100% 100%;
}

.rawMaterial .num {
	margin-right: 20rpx;
}

.rawMaterial .num > text {
}

.describe {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
}

.describe .content {
	width: 684rpx;
	height: 204rpx;
	font-size: 26rpx;
	color: #b3b3b3;
	background: url(../../static/market-detail/market-text-gral-msk.png) center center no-repeat;
	background-size: 100% 100%;

	font-family: PingFang SC;
	font-weight: 400;
	line-height: 42rpx;
}
.describe .scrollView {
	width: 644rpx;
	height: 152rpx;
	padding: 26rpx 0;
	margin-left: 20rpx;
}

.fusion {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 183rpx;
}

.fusion .content {
	width: 246rpx;
	height: 88rpx;
	font-size: 30rpx;
	color: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
	background: url(../../static/disciple-property-bg-bt.png) center center no-repeat;
	background-size: 100% 100%;
}

.selecter {
	margin-top: 40rpx;
	padding: 0 62rpx;
}
.selecter .synthesis {
	display: flex;
	align-items: center;
	justify-content: space-between;
}

.selecter .synthesis > view {
	width: 140rpx;
	height: 74rpx;
	background: url(../../static/market-detail/market-shenbing-yellow-min-add.png) center center no-repeat;
	background-size: 100% 100%;
}

.nopic {
	color: #fff200;
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
}
.marketBigPic,
.marketBigWhat {
	display: flex;
	align-items: center;
	justify-content: center;
	width: 100%;
}

.marketBigPic .marketpic {
	width: 238rpx;
	height: 74rpx;
	background: url(../../static/market-detail/market-shenbing-yellow-add.png) center center no-repeat;
	background-size: 100% 100%;
}

.marketBigWhat .marketwhat {
	width: 238rpx;
	height: 74rpx;
	background: url(../../static/market-detail/market-shenbing-yellow-what.png) center center no-repeat;
	background-size: 100% 100%;
}

.describe-current1 {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 97rpx;
}

.describe-current1 .content {
	width: 684rpx;
	height: 292rpx;
	font-size: 26rpx;
	color: #b3b3b3;
	background: url(../../static/market-detail/market-text-gral-msk.png) center center no-repeat;
	background-size: 100% 100%;

	font-family: PingFang SC;
	font-weight: 400;
	line-height: 42rpx;
}

.describe-current1 .content .scrollView {
	padding: 26rpx 39rpx;
	height: 240rpx;
}

.consume {
	margin-top: 60rpx;
	display: flex;
	align-items: center;
	justify-content: center;
}
.consume .content {
	width: 460rpx;
	height: 88rpx;
	font-size: 30rpx;
	color: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
	background: url(../../static/market-detail/market-shenbing-black-msk.png) center center no-repeat;
	background-size: 100% 100%;
}
</style>
