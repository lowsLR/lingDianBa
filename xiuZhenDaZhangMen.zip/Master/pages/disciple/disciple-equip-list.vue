<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">装备列表</block>
		</cu-custom>
		
		<view class="listHeight" style="overflow: scroll;">
			<block v-if="listArray.length>0">
				<view v-for="(array,i1) in listArray" :key="i1" style="display: flex;flex-direction: row;margin-top: 19rpx;">
					<view @tap="tapItem(info)" v-for="(info,i2) in array" :key="i2" class="itemLayout" :class="info.w?'wearSelect':'wearNormal'">
						<view :class="'m-'+info.equip.quality">{{info.equip.name}}</view>
						<view>{{info.sl}}级</view>
					</view>
				</view>
			</block>
			<view v-else-if="loaded" style="text-align: center;color: #666666;font-size: 30rpx;line-height: 200rpx;">暂无数据</view>
		</view>
		
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				listArray:[],  // [[1,1,1],[1,1]]
				loaded:false,
				discipleId:0,
				hideLoading:false,
				equipType:0,
				wearEquipId:0,
				dressOccupation:''
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.discipleId = detail.discipleId
			_self.equipType = detail.equipType
		},
		onShow() {
			let disciples = getApp().globalData.disciples
			let discipleInfo = disciples[disciples.findIndex(item => item.id==_self.discipleId)]
			if(discipleInfo) {
				let eId = _self.util.handleWearText(discipleInfo.we)[_self.equipType]
				if(eId) {
					_self.wearEquipId = eId
				}else {
					_self.wearEquipId = 0
				}
				_self.dressOccupation = _self.jsonParse.getNameByJob(discipleInfo.job)
			}
			_self.updateData()
		},
		methods: {
			updateData() {
				let listArray = []
				let equips = getApp().globalData.equips
				
				let equipArray = []
				equips.forEach((item)=>{
					let equipInfo = _self.jsonParse.getEquipInfo(item.etid,item.sl)
					if(equipInfo && equipInfo.type==_self.equipType && (equipInfo.dressOccupation=='无' || equipInfo.dressOccupation==_self.dressOccupation)) {
						if((item.w && item.eid==_self.wearEquipId) || !item.w) {
							item.equip = equipInfo
							equipArray.push(item)
						}
					}
				})
				equipArray.sort(function(a,b){
					return b.w-a.w
				})
				
				equipArray.forEach((info,index)=>{
					if(index%3==0) {
						let itemArray = []
						itemArray.push(info)
						if(index+2<equipArray.length) {
							let info1 = equipArray[index+1]
							let info2 = equipArray[index+2]
							itemArray.push(info1)
							itemArray.push(info2)
						}else if(index+1<equipArray.length) {
							let info1 = equipArray[index+1]
							itemArray.push(info1)
						}
						listArray.push(itemArray)
					}
				})
				_self.listArray = listArray
				_self.loaded = true
			},
			tapItem(info) {
				info.discipleId = _self.discipleId
				info.wearEquipId = _self.wearEquipId
				_self.navigateTo(_self.util.toEncodeUri('/pages/disciple/disciple-equip-detail',info))
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.itemLayout {
		width: 226rpx;
		height: 120rpx;
		margin-left: 19rpx;
		line-height: 40rpx;
		padding-top: 4rpx;
		font-size: 28rpx;
		color: #000000;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		
		background:url(../../static/disciple-equip-list-bg-item.png) center center no-repeat;background-size:100% 100%;
	}
	
	.wearSelect {
		color: #666666;
		/* background:url(../../static/disciple-equip-list-bg-item-select.png) center center no-repeat;background-size:100% 100%; */
	}
	
	.wearNormal {
		color: #FFFFFF;
		/* background:url(../../static/disciple-equip-list-bg-item-normal.png) center center no-repeat;background-size:100% 100%; */
	}
	
	.listHeight {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
</style>
