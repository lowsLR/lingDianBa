<template>
	<view class="container">
		<!-- <cu-custom :isBack="true">
			<block slot="content">{{titleName}} 提品考核</block>
		</cu-custom> -->
		<image @tap="tapBack" class="iconBack" src="/static/icon-back.png"></image>
		<view @tap="tapWh" class="iconQuestion">?</view>
		<view :class="'m-'+level" style="text-align: center;font-size: 40rpx;">{{titleName}} 提品考核</view>
		
		<template v-if="formulaType==1">
			<view v-if="accessInfo" style="display: flex;justify-content: center;align-items: center;height: 80vh;">
				<view style="width: 650rpx;color: #FFFFFF;">
					<view v-for="(array,i1) in listArray" :key="i1" style="display: flex;flex-direction: row;margin-top: 30rpx;">
						<view @tap="tapItem(info)" v-for="(info,i2) in array" :key="i2" style="display: flex;flex: 1;flex-direction: column;align-items: center;">
							<view class="itemLayout">
								<image :src="info.exist?'/static/building-forge-formula-bright.png':'/static/building-forge-formula-gray.png'" style="width: 122rpx;height: 81rpx;"></image>
							</view>
							<view class="isEllipsis" :class="'m-'+info.quality" style="line-height: 60rpx;font-size: 30rpx;text-align: center;">{{info.name}}</view>
						</view>
					</view>
					<view style="font-size: 34rpx;margin-top: 100rpx;line-height: 66rpx;text-align: center;">
						<view>通过评分：{{accessRequire}}</view>
						<view>每次考核额外消耗 {{accessInfo?accessInfo.consume:''}}</view>
					</view>
				</view>
			</view>
			<view v-else style="text-align: center;color: #666666;font-size: 34rpx;padding-top: 100rpx;">{{notOpenText}}</view>
		</template>
		<template v-if="formulaType==2">
			<view v-if="accessInfo" style="display: flex;justify-content: center;align-items: center;height: 80vh;">
				<view style="width: 650rpx;color: #FFFFFF;">
					<view style="font-size: 34rpx;text-align: center;">提品条件：炼制「{{accessInfo?accessInfo.formula:'丹药'}}」数量达到{{accessRequire}}</view>
					
					<view style="font-size: 30rpx;padding: 60rpx 0 30rpx 0;text-align: center;">炼制进度 ({{accessInfo?accessInfo.formula:'丹药'}})</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<progress-bar :pbWidth="570" pbColor="#FB0D1B" :progress="alchemyCount" :maxProgress="accessRequire?accessRequire:0"></progress-bar>
						<view style="width: 80rpx;text-align: center;">{{accessRequire?accessRequire:0}}</view>
					</view>
					
					<view style="display: flex;justify-content: center;margin-top: 160rpx;">
						<view @tap="tapAlchemy" class="bt1" style="">提品 <text v-if="accessInfo" style="margin-left: 10rpx;">(消耗{{accessInfo?accessInfo.consume:''}})</text></view>
					</view>
				</view>
			</view>
			<view v-else style="text-align: center;color: #666666;font-size: 34rpx;padding-top: 100rpx;">{{notOpenText}}</view>
		</template>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDialog.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDisciple" style="display: flex;flex-direction: column;align-items: center;">
				<view style="width: 54rpx;height: 54rpx;color: #FFFF00;border-radius: 50%;display: flex;justify-content: center;align-items: center;box-shadow: 0 0 20rpx #FFFF00;position: absolute;left: 50rpx;top: 50rpx;font-weight: 500;font-size: 28rpx;">{{remainCount}}</view>
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{infoObj.name?infoObj.name:''}}</view>
				<block v-if="formulaType==1">
					<scroll-view scroll-y="true" style="line-height: 54rpx;font-size: 28rpx;color: #818181;height: 680rpx;width: 468rpx;margin-bottom: 34rpx;">
						<view class="c-FFFFCC">装备品质：<text :class="'e-'+infoObj.quality">{{qualityName}}</text></view>
						<view class="c-CCFFFF">装备类型：<text :class="equipTypeColorObj[equipTypeName]">{{equipTypeName}}</text><text class="mar-l-12" :class="equipColorClass[equipObj.propertyType]">{{equipObj.propertyType?equipObj.propertyType:''}}</text></view>
						<view class="c-FFFF00">成功概率：{{infoObj.rate?parseInt(infoObj.rate*100):''}}%</view>
						<view class="c-99CCFF">锻造经验：<text :class="infoObj.gainExp?'e-'+infoObj.gainExp.toString().length:''">{{infoObj.gainExp?infoObj.gainExp:0}}</text></view>
						<view class="c-CCCC00">所需水平：<text :class="'e-'+infoObj.require">{{requireLevel}}</text></view>
						<view class="c-FFFF00">锻造门人：{{disciple?disciple.nm:''}}<text class="mar-l-12" :class="'e-'+disciple.zl">{{forgeLevel}}</text></view>
						<view class="c-00FFCC">基础属性：<text :class="equipObj.initialMax?'e-'+equipObj.initialMax.length:''">{{equipObj.initialRange?equipObj.initialRange:''}}</text></view>
						<view class="c-00FFCC">附加属性：<text :class="equipObj.extraMax?'e-'+equipObj.extraMax.length:''">{{equipObj.extraRange?equipObj.extraRange:''}}</text></view>
						<view class="c-00FFCC">附加条数：<text :class="'e-'+extraNumQuality">{{extraNum}}</text></view>
						<view class="c-FF0000" style="text-align: center;">锻造材料</view>
						<view style="display: flex;flex-direction: row;color: #FFFFFF;justify-content: center;">
							<view v-for="(obj,index) in infoObj.materialArray" :key="index" style="display: flex;flex-direction: column;">
								<view class="mLayout">
									{{obj.name}}
								</view>
								<view style="text-align: center;font-size: 26rpx;width: 156rpx;" class="isEllipsis"><text class="c-FFFF00">{{obj.totalCountText}}</text>/<text class="c-FF0000">{{obj.count}}</text></view>
							</view>
						</view>
					</scroll-view>
					<view @tap="tapForge" class="bt1">考核 <text v-if="accessInfo" style="margin-left: 10rpx;">(消耗{{accessInfo?accessInfo.consume:''}})</text></view>
				</block>
				<block v-if="formulaType==2">
					<scroll-view scroll-y="true" style="line-height: 54rpx;font-size: 28rpx;color: #818181;height: 680rpx;width: 468rpx;margin-bottom: 34rpx;">
						<view class="c-FFFFCC">丹药品质：<text :class="'m-'+infoObj.quality">{{qualityName}}</text></view>
						<view class="c-CCFFFF">丹药类型：{{direction}}</view>
						<view class="c-FFFF00">成功概率：{{infoObj.rate?parseInt(infoObj.rate*100):''}}%</view>
						<view class="c-99CCFF">炼丹经验：<text :class="infoObj.gainExp?'m-'+infoObj.gainExp.toString().length:''">{{infoObj.gainExp?infoObj.gainExp:0}}</text></view>
						<view class="c-CCCC00">所需水平：<text :class="'m-'+infoObj.require">{{requireLevel}}</text></view>
						<view class="c-FFFF00">炼制门人：{{disciple?disciple.nm:''}}<text class="mar-l-12" :class="'m-'+disciple.zl">{{forgeLevel}}</text></view>
						<view class="c-00FFCC">成品数量：<text :class="'m-'+extraNumQuality">{{extraNum}}</text></view>
						<view class="c-FF0000" style="text-align: center;">炼丹材料</view>
						<view style="display: flex;flex-direction: row;color: #FFFFFF;justify-content: center;">
							<view v-for="(obj,index) in infoObj.materialArray" :key="index" style="display: flex;flex-direction: column;">
								<view class="mLayout">
									{{obj.name}}
								</view>
								<view style="text-align: center;font-size: 26rpx;width: 156rpx;" class="isEllipsis"><text class="c-FFFF00">{{obj.totalCountText}}</text>/<text class="c-FF0000">{{obj.count}}</text></view>
							</view>
						</view>
					</scroll-view>
					<view @tap="tapForge" class="bt1">炼制</view>
				</block>
			</view>
		</uni-popup>
		
		<uni-popup ref="refResult" type="center" :custom="true" :mask-click="true" maskOpacity="0.7">
			<block v-if="resultRs">
				<image @tap="$refs.refResult.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
				<view class="dialogResult" style="display: flex;align-items: center;flex-direction: column;">
					<image style="width: 466rpx;height: 171rpx;" src="/static/building-forge-formula-list-dialog-success.png"></image>
					<block v-if="formulaType==1">
						<view style="line-height: 100rpx;text-align: center;font-size: 32rpx;">{{infoObj.result?infoObj.result:''}}</view>
						<view style="display: flex;flex-direction: row;line-height: 54rpx;width: 460rpx;font-size: 30rpx;">
							<view style="display: flex;flex-direction: column;flex: 1.5;">
								<view>装备评分：{{forgeResult}}</view>
								<view style="display: flex;flex-direction: row;">
									基础属性：
									<view v-if="basicPropertyArray.length>0" style="display: flex;flex: 1;flex-direction: column;">
										<view v-for="(text,index) in basicPropertyArray" :key="index">{{text}}</view>
									</view>
									<text v-else>无</text>
								</view>
								<view style="display: flex;flex-direction: row;">
									附加属性：
									<view v-if="extraPropertyArray.length>0" style="display: flex;flex: 1;flex-direction: column;">
										<view v-for="(text,index) in extraPropertyArray" :key="index">{{text}}</view>
									</view>
									<text v-else>无</text>
								</view>
							</view>
							<view style="display: flex;flex-direction: column;flex: 1;font-size: 34rpx;">
								<view style="text-align: center;">考核评分</view>
								<view style="line-height: 100rpx;text-align: center;">{{accessRequire}}</view>
							</view>
						</view>
						<view style="padding-top: 50rpx;text-align: center;font-size: 32rpx;">
							<text v-if="pass" class="c-FFFF00">通过考核</text>
							<text v-else class="c-FF0000">未通过考核</text>
						</view>
					</block>
					<block v-if="formulaType==2">
						<view style="line-height: 100rpx;text-align: center;font-size: 32rpx;">丹药炼制结果</view>
						<view style="display: flex;flex-direction: column;line-height: 54rpx;width: 460rpx;font-size: 30rpx;">
							<view>炼制成品数量：{{forgeResult}}</view>
							<view>炼制极限数量：{{infoObj.limit?infoObj.limit:0}}</view>
						</view>
					</block>
				</view>
			</block>
			<image v-else style="width: 466rpx;height: 171rpx;" src="/static/building-forge-formula-list-dialog-fail.png"></image>
		</uni-popup>
		
		<uni-popup ref="refLoading" type="center" maskOpacity="0.8" :custom="true" :mask-click="false">
			<image v-if="formulaType==1" class="iconDz" src="/static/sect-achievement-dz.png"></image>
			<image v-if="formulaType==2" class="iconLd" src="/static/sect-achievement-ld.png"></image>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	import progressBar from '@/components/progress-bar/progress-bar.vue'
	var _self
	
	export default {
		components:{
			progressBar,
			popupWords
		},
		data() {
			return {
				listArray:[],  // [[1,1,1],[1,1]]
				loaded:false,
				direction:'',
				disciple:null,
				infoObj:{
					materialArray:[]
				},
				equipObj:{},
				qualityName:'',
				extraNum:'',
				requireLevel:'',
				forgeLevel:'',
				equipTypeName:'',
				buildType:-1,
				equipTypeColorObj:{
					'剑修武器':'c-FFFFCC',
					'体修武器':'c-FF6633',
					'医修武器':'c-00FF00',
					'魂修武器':'c-003399',
					'衣服':'c-FF9900',
					'配饰':'c-660099',
					'鞋子':'c-0033FF',
				},
				equipColorClass:{
					'气血':'p-1',
					'灵力':'p-2',
					'神念':'p-3',
					'肉身':'p-4',
					'破甲':'p-5',
					'格挡':'p-6'
				},
				extraNumQuality:-1,
				basicPropertyArray:[],
				extraPropertyArray:[],
				forgeResult:0,
				resultRs:0,
				remainCount:0,
				formulaType:-1,   // 1:铸造、2：炼丹
				titleName:'',
				accessInfo:null,
				notOpenText:'暂未开放',
				pass:0,
				discipleId:-1,
				accessRequire:0,
				level:1,
				alchemyCount:0,
				wordsNew:''
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.formulaType = detail.formulaType
			_self.discipleId = detail.discipleId
			
			_self.initData()
			if(_self.formulaType==1) {
				_self.$nextTick(function(){
					_self.ajaxCount()
				})
			}
		},
		methods: {
			tapWh() {
				let wordKey = ''
				switch(_self.formulaType) {
					case 1:
						wordKey = 'access-forge'
						break;
						
					case 2:
						wordKey = 'access-alchemy'
						break;
				}
				let wordObj = _self.jsonParse.getIntroWords(wordKey)
				if(wordObj) {
					_self.wordsNew = wordObj.content
					_self.$refs.refWords.open()
				}
			},
			tapAlchemy() {
				if(_self.alchemyCount>=_self.accessRequire) {
					_self.ajaxAlchemy()
				}else {
					_self.showToast('不满足条件')
				}
			},
			tapBack() {
				uni.navigateBack({
					delta:1
				})
			},
			initData() {
				let disciples = getApp().globalData.disciples
				let disciple = disciples[disciples.findIndex(disciple => disciple.id==_self.discipleId)]
				_self.disciple = disciple
				
				let titleName = ''
				let accessInfo
				let level = 1
				switch(_self.formulaType) {
					case 1:
						level = disciple.zl
						titleName =  _self.jsonParse.getAlchemyForgeName(level,2)
						accessInfo = _self.jsonParse.getAlchemyForgeAccessInfo(_self.formulaType,level)
						
						break;
						
					case 2:
						level = disciple.ll
						titleName = _self.jsonParse.getAlchemyForgeName(level,1)
						accessInfo = _self.jsonParse.getAlchemyForgeAccessInfo(_self.formulaType,level)
						// 通過物品名查詢對應的物品詳情
						if(accessInfo) {
							let mInfo = _self.jsonParse.getMaterialInfoByName(accessInfo.formula)
							if(mInfo) {
								_self.ajaxAlchemyCount(mInfo.id)
							}
						}
						break;
				}
				
				if(accessInfo) {
					_self.fillList(accessInfo)
					_self.accessRequire = accessInfo.require
				}
				_self.level = level
				_self.titleName = titleName
				_self.accessInfo = accessInfo
				
			},
			tapForge() {
				if(_self.remainCount>0) {
					let isEnough = true
					let materialArray = _self.infoObj.materialArray
					materialArray.forEach((item)=>{
						if(item.count>item.totalCount) {
							isEnough = false
						}
					})
					if(isEnough) {
						_self.ajaxAccess()
					}else {
						_self.showToast('材料不足')
					}
				}else {
					_self.showToast('该弟子合成次数超过每日限制')
				}
			},
			ajaxAlchemyCount(danMaterialType) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_31',
					params:{
						discipleId:_self.disciple.id,
						danMaterialType:danMaterialType
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.alchemyCount = resData.count
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxAlchemy() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_30',
					params:{
						discipleId:_self.disciple.id
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.showToast('提品成功')
						let discipleView = resData.discipleView
						_self.util.updateDiscipleData(discipleView)
						_self.initData()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxCount() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'4_11',
					params:{
						discipleId:_self.disciple.id,
						formulaType:_self.formulaType
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.remainCount = resData.opCountLimit-resData.opCount
					}
				}
				_self.$req.handleRequest(option)
			},
			toOpenLoading() {
				_self.$refs.refLoading.open()
			},
			toCloseLoading() {
				_self.$refs.refLoading.close()
			},
			toOpenResult() {
				_self.$refs.refResult.open()
			},
			toCloseResult() {
				_self.$refs.refResult.close()
			},
			forgeSuccess(resData) {
				switch(_self.formulaType) {
					case 1:
						let equips = resData.equips
						if(equips && equips.length>0) {
							let equip = equips[0]
							let bp = equip.bp
							let ep = equip.ep
							_self.basicPropertyArray = _self.util.parseEquipProperty(bp,'+')
							_self.extraPropertyArray = _self.util.parseEquipProperty(ep,'+')
							_self.forgeResult = resData.score
						}
						break;
						
					case 2:
						let gain = resData.gain
						if(gain) {
							let gainArray = gain.split(':')
							if(gainArray.length==3) {
								_self.forgeResult = gainArray[2]
							}
						}
						break;
				}
				
				// 如果是通过考核的，更新页面和弟子数据  多个 discipleView 字段
				let pass = resData.pass
				if(pass==1) {
					_self.$refs.refDialog.close()
					let discipleView = resData.discipleView
					_self.util.updateDiscipleData(discipleView)
					_self.initData()
				}
				_self.pass = pass
				
				_self.toOpenResult()
			},
			handleTime(startTime,callback) {
				let endTime = new Date().getTime()
				if(endTime-startTime>1000) {
					_self.toCloseLoading()
					callback()
				}else {
					setTimeout(function() {
						_self.toCloseLoading()
						callback()
					},1000)
				}
			},
			ajaxAccess() {
				let startTime = new Date().getTime()
				_self.toOpenLoading()
				
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_32',
					params:{
						discipleId:_self.disciple.id,
						formulaId:_self.infoObj.id
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.remainCount--
					_self.handleTime(startTime,function() {
						if(resData) {
							_self.fillDialogData()
							_self.$forceUpdate()
							
							let resultRs = resData.dzRs
							_self.resultRs = resultRs
							switch(resultRs) {
								case 0:
									_self.toOpenResult()
									break;
									
								case 1:
									_self.forgeSuccess(resData)
									break;
							}
						}
					})
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function(errorMsg) {
					_self.handleTime(startTime,function() {
						if(errorMsg) {
							_self.showToast(errorMsg)
						}
					})
				}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {
					_self.handleTime(startTime,function() {
						_self.showToast('处理错误')
					})
				}
				_self.$req.handleRequest(option)
			},
			fillDialogData() {
				if(_self.formulaType==1) {
					let equipInfo = _self.jsonParse.getEquipInitialInfoByName(_self.infoObj.result)
					if(equipInfo) {
						let initialRange = equipInfo.initialRange
						let extraRange = equipInfo.extraRange
						let initialMax = initialRange
						let extraMax = extraRange
						if(initialRange.indexOf('-')!=-1) {
							initialMax = initialRange.split('-')[1]
						}
						if(extraRange.indexOf('-')!=-1) {
							extraMax = extraRange.split('-')[1]
						}
						equipInfo.initialMax = initialMax
						equipInfo.extraMax = extraMax
						
						_self.equipObj = equipInfo
					}
					
					let t1 = _self.infoObj.material   // 矿石*300#铁矿*10
					let t2 = _self.jsonParse.exchangeMapMaterialFormat(t1)  // 1:10004:300#2:20001:10
					let tArray1 = t1.split('#')
					let tArray2 = t2.split('#')
					let materialObj = getApp().globalData.materialObj
					let materialArray = []
					tArray2.forEach((item,index)=>{
						let itemArray = item.split(':')
						let p0 = parseInt(itemArray[0])
						let p1 = parseInt(itemArray[1])
						let p2 = parseInt(itemArray[2])
						let itemObj = {
							type:p0,
							id:p1,
							count:p2,
							name:tArray1[index].split('*')[0]
						}
						
						let itemMaterial = materialObj[_self.util.getMaterialKey(p0,p1)]
						if(itemMaterial) {
							let totalCount = materialObj[_self.util.getMaterialKey(itemMaterial.type,itemMaterial.id)].count
							itemObj.totalCountText = _self.util.exchangeNum(totalCount)
							itemObj.totalCount = totalCount
						}else {
							itemObj.totalCountText = 0
							itemObj.totalCount = 0
						}
						materialArray.push(itemObj)
					})
					_self.infoObj.materialArray = materialArray
					
					let extraNum = _self.jsonParse.getEquipExtraNumberByQuality(_self.infoObj.quality)
					_self.extraNum = extraNum
					_self.extraNumQuality = extraNum.split('-')[1]
					
					_self.qualityName = _self.jsonParse.getEquipQualityName(_self.infoObj.quality)
					_self.equipTypeName = _self.jsonParse.getEquipTypeNameByEquipName(_self.infoObj.result)
					
					_self.requireLevel = _self.jsonParse.getAlchemyForgeName(_self.infoObj.require,2)  // 1:炼丹、2：铸造
					_self.forgeLevel = _self.jsonParse.getAlchemyForgeName(_self.disciple.zl,2)
				}else if(_self.formulaType==2) {
					let equipInfo = _self.jsonParse.getEquipInitialInfoByName(_self.infoObj.result)
					if(equipInfo) {
						let initialRange = equipInfo.initialRange
						let extraRange = equipInfo.extraRange
						let initialMax = initialRange
						let extraMax = extraRange
						if(initialRange.indexOf('-')!=-1) {
							initialMax = initialRange.split('-')[1]
						}
						if(extraRange.indexOf('-')!=-1) {
							extraMax = extraRange.split('-')[1]
						}
						equipInfo.initialMax = initialMax
						equipInfo.extraMax = extraMax
						
						_self.equipObj = equipInfo
					}
					
					let t1 = _self.infoObj.material   // 矿石*300#铁矿*10
					let t2 = _self.jsonParse.exchangeMapMaterialFormat(t1)  // 1:10004:300#2:20001:10
					let tArray1 = t1.split('#')
					let tArray2 = t2.split('#')
					let materialObj = getApp().globalData.materialObj
					let materialArray = []
					tArray2.forEach((item,index)=>{
						let itemArray = item.split(':')
						let p0 = parseInt(itemArray[0])
						let p1 = parseInt(itemArray[1])
						let p2 = parseInt(itemArray[2])
						let itemObj = {
							type:p0,
							id:p1,
							count:p2,
							name:tArray1[index].split('*')[0]
						}
						
						let itemMaterial = materialObj[_self.util.getMaterialKey(p0,p1)]
						if(itemMaterial) {
							let totalCount = materialObj[_self.util.getMaterialKey(itemMaterial.type,itemMaterial.id)].count
							itemObj.totalCountText = _self.util.exchangeNum(totalCount)
							itemObj.totalCount = totalCount
						}else {
							itemObj.totalCountText = 0
							itemObj.totalCount = 0
						}
						
						materialArray.push(itemObj)
					})
					_self.infoObj.materialArray = materialArray
					
					let extraNum = _self.infoObj.number
					let extraNumQuality = extraNum
					if(extraNum.indexOf('-')!=-1) {
						extraNumQuality = extraNum.split('-')[1]
					}
					_self.extraNum = extraNum
					_self.extraNumQuality = extraNumQuality
					
					_self.qualityName = _self.jsonParse.getMaterialQualityName(_self.infoObj.quality)
					_self.requireLevel = _self.jsonParse.getAlchemyForgeName(_self.infoObj.require,1)  // 1:炼丹、2：铸造
					_self.forgeLevel = _self.jsonParse.getAlchemyForgeName(_self.disciple.ll,1)
				}
			},
			fillList(accessInfo) {
				let materialObj = getApp().globalData.materialObj
				let listArray = []
				let formulaArray = _self.jsonParse.getFormulaArrayFromAccess(accessInfo.formula)
				formulaArray.forEach((info)=>{
					/**
					 * 过滤，判断用户是否获得
					 */
					let formulaInfo = materialObj[_self.util.getMaterialKey(7,info.id)]
					if(formulaInfo && formulaInfo.count>0) {
						info.exist = true
					}
				})
				formulaArray.forEach((info,index)=>{
					if(index%2==0) {
						let itemArray = []
						itemArray.push(info)
						if(index+1<formulaArray.length) {
							let info1 = formulaArray[index+1]
							itemArray.push(info1)
						}
						listArray.push(itemArray)
					}
				})
				_self.listArray = listArray
			},
			tapItem(info) {
				if(info.exist) {
					_self.infoObj = info
					_self.fillDialogData()
					_self.$refs.refDialog.open()
				}else {
					_self.showToast('配方未获得')
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.itemLayout {
		/* width: 210rpx;
		height: 158rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background:url(../../static/building-forge-formula-list-item.png) center center no-repeat;background-size:100% 100%; */
		
		width: 226rpx;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		background:url(../../static/disciple-equip-list-bg-item.png) center center no-repeat;background-size:100% 100%;
	}
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
	.dialogDisciple {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.mLayout {
		width: 156rpx;
		height: 82rpx;
		line-height: 82rpx;
		font-size: 24rpx;
		text-align: center;
		background:url(../../static/disciple-equip-list-bg-item.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogResult {
		width: 568rpx;
		height: 688rpx;
		line-height: 44rpx;
		font-size: 28rpx;
		color: #FFFFFF;
		background:url(../../static/building-forge-formula-list-dialog.png) center center no-repeat;background-size:100% 100%;
	}
	
	@keyframes zy1 {
		0% {
			transform: rotate(-30deg);
		}
		30% {
			transform: rotate(0deg);
		}
		50% {
			transform: rotate(30deg);
		}
		70% {
			transform: rotate(0deg);
		}
		100% {
			transform: rotate(-30deg);
		}
	}
	
	@keyframes zy2 {
		0% {
			transform: rotate(15deg);
		}
		30% {
			transform: rotate(30deg);
		}
		50% {
			transform: rotate(45deg);
		}
		70% {
			transform: rotate(30deg);
		}
		100% {
			transform: rotate(15deg);
		}
	}
	
	
	.iconLd {
		width: 300rpx;
		height: 300rpx;
		animation: zy1 1s linear infinite;
	}
	
	.iconDz {
		width: 300rpx;
		height: 300rpx;
		animation: zy2 1s linear infinite;
	}
	
	.iconBack {
		width: 64rpx;
		height: 64rpx;
		margin-top: calc(18rpx + var(--status-bar-height));
		margin-left: 24rpx;
	}
	
	.iconQuestion {
		position: absolute;
		top: calc(18rpx + var(--status-bar-height));
		right: 24rpx;
		width: 64rpx;
		height: 64rpx;
		border-radius: 50%;
		font-size: 40rpx;
		line-height: 64rpx;
		text-align: center;
		color: #FCFCFC;
		box-shadow: 0 0 6rpx #FCFCFC;
	}
	
</style>
