<template>
	<view class="container">
		<image @tap="tapBack" class="iconBack" src="/static/icon-back.png"></image>
		
		<view class="cententLayout" style="display: flex;flex-direction: column;align-items: center;">
			<image v-if="discipleIndex!=0" @tap="tapSwitch(directionLeft)" style="width: 40rpx;height: 50rpx;vertical-align: top;position: absolute;left: 30rpx;margin-top: 315rpx;" src="/static/disciple-arrow-left.png"></image>
			<image v-if="discipleIndex!=(disciples.length-1)" @tap="tapSwitch(directionRight)" style="width: 40rpx;height: 50rpx;vertical-align: top;position: absolute;right: 30rpx;margin-top: 315rpx;" src="/static/disciple-arrow-right.png"></image>
			<view style="display: flex;flex-direction: row;justify-content: center;align-items: center;">
				<image style="width: 20rpx;height: 20rpx;" src="/static/disciple-dot.png"></image>
				<view style="font-size: 34rpx;line-height: 100rpx;color: #FFFFFF;margin: 0 20rpx;">{{discipleName}}</view>
				<image style="width: 20rpx;height: 20rpx;" src="/static/disciple-dot.png"></image>
			</view>
			<view style="display: flex;flex-direction: row;width: 604rpx;margin-top: 20rpx;">
				<view style="display: flex;flex-direction: column;">
					<image @tap="tapEquip(1)" style="width: 120rpx;height: 120rpx;vertical-align: top;" :src="wearObj['1']?'/static/disciple-weapon-select.png':'/static/disciple-weapon-normal.png'"></image>
					<image @tap="tapEquip(2)" style="width: 120rpx;height: 120rpx;vertical-align: top;" :src="wearObj['2']?'/static/disciple-clothes-select.png':'/static/disciple-clothes-normal.png'"></image>
					<image @tap="tapEquip(3)" style="width: 120rpx;height: 120rpx;vertical-align: top;" :src="wearObj['3']?'/static/disciple-accessory-select.png':'/static/disciple-accessory-normal.png'"></image>
					<image @tap="tapEquip(4)" style="width: 120rpx;height: 120rpx;vertical-align: top;" :src="wearObj['4']?'/static/disciple-shoes-select.png':'/static/disciple-shoes-normal.png'"></image>
				</view>
				<view class="avatarLayout" :class="iconId>100?'':'avatarBg'">
					<image :class="iconId>100?'avaterSpecialSize':'avatarSize'" :src="avatarUrl?avatarUrl:''"></image>
				</view>
				<view style="display: flex;flex-direction: column;">
					<!-- <image v-if="!isMaster" @tap="tapIntro" style="width: 120rpx;height: 120rpx;vertical-align: top;" src="/static/disciple-icon-intro.png"></image> -->
					<image @tap="tapDiscipleProperty" style="width: 120rpx;height: 120rpx;vertical-align: top;" src="/static/disciple-icon-attr.png"></image>
					<image @tap="tapDiscipleLifeSoul" style="width: 120rpx;height: 120rpx;vertical-align: top;" src="/static/disciple-icon-life-soul.png"></image>
					<image @tap="tapAccess" style="width: 120rpx;height: 120rpx;vertical-align: top;" src="/static/disciple-icon-access.png"></image>
				</view>
			</view>
			<view class="scoreText" v-if="powerText" style="color: #790E15;margin-top: -26rpx;font-size: 30rpx;">
				<!-- {{powerText}} -->
				<view style="margin-left: 94rpx;width: 100rpx;text-align: center;">{{powerText}}</view>
			</view>
		</view>
		
		<view style="display: flex;flex-direction: row;line-height: 60rpx;font-size: 32rpx;color: #FFFFFF;margin-top: 50rpx;">
			<view style="display: flex;flex-direction: column;flex: 1;padding-left: 50rpx;">
				<view class="c-FFFFFF">人物性别：<text :class="'sex-'+optionDetail.sex">{{sex}}</text></view>
				<view class="c-FFFFCC">修真寿元：<text class="c-FFFFCC">{{time}}</text></view>
				<view class="c-CCFFCC">炼丹实力：<text :class="'m-'+optionDetail.ll">{{almycheName}}</text></view>
				<view class="c-999966">修真方向：<text :class="'job-'+optionDetail.job">{{jobName}}</text></view>
			</view>
			<view style="display: flex;flex-direction: column;flex: 1;padding-left: 30rpx;">
				<view class="c-CCFFFF">门派职位：<text :class="'pstn-'+optionDetail.pstn">{{pstnName}}</text></view>
				<view class="c-FFCCFF">修真道侣：<text class="c-FFCCFF">无</text></text></view>
				<view class="c-0066FF">铸造实力：<text :class="'m-'+optionDetail.zl">{{forgeName}}</text></view>
			</view>
		</view>
		
		<view style="width: 100%;display: flex;flex-direction: row;margin-top: 50rpx;justify-content: center;">
			<view class="btLayout" @tap="tapSkill">功法树</view>
			<!-- <block v-if="!isMaster">
				<view style="margin: 0 45rpx;" class="btLayout" @tap="tapBreakThrough">破极限</view>
				<view class="btLayout" @tap="toOpenDialogExpel">逐离</view>
			</block> -->
			<view v-if="!isMaster && (disciples[discipleIndex]&&(disciples[discipleIndex].rm!=1 || disciples[discipleIndex].rml!=1))" class="btLayout mar-l-45" @tap="toOpenDialogRebuild">重修</view>
		</view>
		
		<view v-if="!isMaster" @tap="toOpenDialogExpel" class="mbcF13426" style="width: 80rpx;height: 80rpx;border-radius: 50%;font-size: 38rpx;line-height: 80rpx;text-align: center;position: absolute;bottom: 30rpx;right: 30rpx;">逐</view>
		
		
		<uni-popup ref="refIntro" type="top" :custom="true" :mask-click="true" maskOpacity="0">
			<view class="introView" v-html="intro"></view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
		<popup-confirm @confirm="ajaxExpel" ref="refExpel" :content="text1"></popup-confirm>
		<popup-confirm @confirm="ajaxRebuild" ref="refRebuild" :content="text3"></popup-confirm>
		<popup-confirm ref="refText" :showCancel="false" :content="dialogText"></popup-confirm>
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import popupWords from '@/components/popup-words/popup-words.vue'
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	
	export default {
		components:{
			uniPopup,
			popupWords,
			popupConfirm
		},
		data() {
			return {
				discipleName:'',
				jobName:'',
				sex:'',
				pstnName:'',
				almycheName:'',
				forgeName:'',
				avatarUrl:'',
				iconId:0,
				time:'',
				optionDetail:null,
				intro:'弟子描述',
				discipleIndex:0,
				disciples:[],
				directionLeft:'left',
				directionRight:'right',
				wearObj:{},
				isMaster:false,
				dialogText:'',
				text1:'弟子消失，概率获得物品<br>此操作不可逆，请慎重',
				text2:'弟子已被逐离',
				text3:'消耗一万灵石重修<br>境界回归天门境一重',
				text4:'重修成功',
				wordsNew:'',
				keyWordsNew:'',
				powerText:'',
				discipleId:-1
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.discipleId = detail.discipleId
			_self.$nextTick(function(){
				_self.toGetWordsNew()
			})
		},
		onShow() {
			_self.updateData()
		},
		methods: {
			toWordsNew(count) {
				let wordObj = _self.jsonParse.getNewWords('disciple')
				if(wordObj) {
					if(wordObj.count>count) {
						_self.wordsNew = wordObj.content
						_self.$refs.refWords.open()
						
						uni.setStorage({
						    key: _self.keyWordsNew,
						    data: count+1
						})
					}
				}
			},
			toGetWordsNew() {
				let keyWordsNew = 'wnd-'+getApp().globalData.sectView.sectId
				_self.keyWordsNew = keyWordsNew
				
				uni.getStorage({
				    key: keyWordsNew,
					success:function(res){
						_self.toWordsNew(res.data)
					},
				    fail:function(res){
						_self.toWordsNew(0)
					}
				})
			},
			updateData() {
				// _self.disciples = _self.util.updateDiscipleArray(disciples,_self)
				let disciples = _self.util.getSortDisciples(_self)
				_self.disciples = disciples
				
				let discipleIndex = disciples.findIndex(disciple => disciple.id==_self.discipleId)
				if(discipleIndex!=-1) {
					_self.discipleIndex = discipleIndex
				}
				_self.fillData()
			},
			ajaxRebuild() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_6',
					params:{
						discipleId:_self.optionDetail.id
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.doDialog(_self.text4)
						
						let discipleView = resData.discipleView
						_self.util.updateDiscipleData(discipleView)
						
						// 更新当前 discipleIndex - 重修之后大小境界初始化为1，排序变了
						_self.discipleId = discipleView.id
						_self.updateData()
						
						let equips = resData.equips.equips
						_self.util.updateEquips(equips)
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxExpel() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_5',
					params:{
						discipleId:_self.optionDetail.id
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let resultText = _self.text2
						let gain = resData.gain
						if(gain) {
							resultText = '逐离获得：'+_self.jsonParse.getMaterialArray(gain).toString()
						}
						_self.doDialog(resultText)
						
						let expelDiscipleId = resData.expelDiscipleId
						_self.util.deleteDisciple(expelDiscipleId)
						
						let equips = resData.equips.equips
						_self.util.updateEquips(equips)
						
						_self.discipleId = _self.disciples[0].id
						_self.updateData()
					}
				}
				_self.$req.handleRequest(option)
			},
			toOpenDialogExpel() {
				_self.$refs.refExpel.open()
			},
			toCloseDialogExpel() {
				_self.$refs.refExpel.close()
			},
			toOpenDialogRebuild() {
				_self.$refs.refRebuild.open()
			},
			toCloseDialogRebuild() {
				_self.$refs.refRebuild.close()
			},
			doDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			tapSwitch(direction) {
				switch(direction) {
					case _self.directionLeft:
						_self.discipleIndex--
						break;
						
					case _self.directionRight:
						_self.discipleIndex++
						break;
				}
				_self.fillData()
			},
			fillData() {
				let detail = _self.disciples[_self.discipleIndex]
				if(!detail) {
					//可能不存在 - 弟子死亡，则拿第一个掌门
					_self.discipleIndex = 0
					detail = _self.disciples[_self.discipleIndex]
				}
				_self.discipleId = detail.id
				_self.isMaster = _self.util.isMaster(detail.pstn)
				
				let discipleQualityInfo = _self.jsonParse.getDiscipleQuality(detail.itgc)
				if(discipleQualityInfo) {
					detail.qualification = discipleQualityInfo.name
				}
				_self.optionDetail = detail
				
				_self.discipleName = detail.nm
				_self.jobName = detail.jobName
				_self.pstnName = detail.pstnName
				_self.almycheName = _self.jsonParse.getAlchemyForgeName(detail.ll,1)
				_self.forgeName = _self.jsonParse.getAlchemyForgeName(detail.zl,2)
				_self.sex = _self.util.getNameBySex(detail.sex)
				_self.wearObj = _self.util.handleWearText(detail.we)
				_self.time = _self.util.formatTimeBySeconds(detail.cs)
				_self.iconId = detail.icon
				_self.util.getAvatarUrl(detail.sex,detail.icon,url => {
					_self.avatarUrl = url
				})
				
				let time = 1
				let cs = detail.cs
				if(cs) {
					time = Math.ceil(cs/3600)
				}
				_self.time = time+'年'
				
				let powerText = ''
				try {
					let tpObj = _self.util.parseProperty(detail.tp)
					let tzQuality = 0
					let tzInfo = _self.jsonParse.getPhysiqueGift(detail.ps)
					if(tzInfo) {
						tzQuality = tzInfo.quality
					}
					
					let tfQuality = 0
					let tfInfo = _self.jsonParse.getPhysiqueGift(detail.gs)
					if(tfInfo) {
						tfQuality = tfInfo.quality
					}
					
					let powerValue = parseInt(tpObj['1']+tpObj['2']*0.9+(tpObj['3']+tpObj['4'])*1.1+(tpObj['5']+tpObj['6'])*1.15+tzQuality*tzQuality*250+tfQuality*tfQuality*150)
					powerText = powerValue
				}catch(e) {
					powerText = ''
				}
				_self.powerText = powerText
			},
			tapIntro() {
				this.$refs.refIntro.open()
			},
			tapAccess() {
				_self.navigateTo(_self.util.toEncodeUri('/pages/disciple/disciple-alchemy-forge-access',{
					discipleId:_self.discipleId
				}))
			},
			tapDiscipleLifeSoul() {
				_self.navigateTo(_self.util.toEncodeUri('/pages/disciple/disciple-life-soul',{
					discipleId:_self.discipleId
				}))
			},
			tapDiscipleProperty() {
				_self.navigateTo(_self.util.toEncodeUri('/pages/disciple/disciple-property',_self.optionDetail))
			},
			tapBreakThrough() {
				_self.navigateTo(_self.util.toEncodeUri('/pages/disciple/disciple-break-through',{
					discipleId:_self.optionDetail.id
				}))
			},
			tapSkill() {
				_self.navigateTo(_self.util.toEncodeUri('/pages/disciple/disciple-skill',{
					id:_self.optionDetail.ssid,
					skillStr:_self.optionDetail.st,
					discipleId:_self.optionDetail.id
				}))
			},
			tapEquip(equipType) {
				_self.navigateTo(_self.util.toEncodeUri('/pages/disciple/disciple-equip-list',{
					discipleId:_self.optionDetail.id,
					equipType:equipType
				}))
			},
			tapBack() {
				uni.navigateBack({
					delta:1
				})
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 190rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout2 {
		width: 190rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.iconBack {
		width: 64rpx;
		height: 64rpx;
		margin-top: calc(18rpx + var(--status-bar-height));
		margin-left: 24rpx;
	}
	
	.cententLayout {
		width: 100%;
		height: 680rpx;
		background:url(../../static/disciple-bg-character-image.png) center center no-repeat;background-size: 574rpx 100%;
	}
	
	.avatarLayout {
		width: 424rpx;
		height: 436rpx;
		margin-top: 20rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
	.avatarBg {
		background:url(../../static/disciple-bg-character.png) center center no-repeat;background-size: 320rpx 100%;
	}
	
	.avatarSize {
		width: 300rpx;
		height: 300rpx;
	}
	
	.avaterSpecialSize {
		width: 320rpx;
		height: 436rpx;
	}
	
	.introView {
	    padding: 20rpx;
	    border-radius: 10rpx;
	    display: -webkit-inline-box;
	    display: -webkit-inline-flex;
	    display: -ms-inline-flexbox;
	    display: inline-flex;
	    max-width: 280rpx;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    -ms-flex-align: center;
	    align-items: center;
	    font-size: 32rpx;
	    line-height: 40rpx;
	    text-align: left;
		box-shadow: 0 0 20rpx #FFFFFF;
		color: #FFFFFF;
		background-color: #000000;
		opacity: 0.7;
		
		position: absolute;
		right: 200rpx;
		margin-top: calc(240rpx + var(--status-bar-height));
	}
	
	.introView:after {
	    content: "";
	    top: 13px;
	    -webkit-transform: rotate(45deg);
	    -ms-transform: rotate(45deg);
	    transform: rotate(45deg);
	    position: absolute;
	    z-index: 100;
	    display: inline-block;
	    overflow: hidden;
	    width: 12px;
	    height: 12px;
	    left: auto;
	    right: -6px;
	    background-color: inherit;
	}
	
	.scoreText {
		width: 217rpx;
		height: 96rpx;
		display: flex;
		align-items: center;
		background:url(../../static/disciple-icon-score.png) center center no-repeat;background-size: 100% 100%;
	}
	
</style>
