<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">破极限</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;align-items: center;">
			<view @tap="ajaxDetail(info)" v-for="(info,index) in lists" :key="index" class="btLayout">
				{{info.name}}
			</view>
		</view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{dialogInfo.name}}</view>
				<scroll-view scroll-y="true" style="display: flex;flex-direction: column;line-height: 48rpx;font-size: 26rpx;color: #818181;height: 682rpx;width: 470rpx;margin-bottom: 34rpx;">
					<view style="text-align: center;" v-html="dialogInfo.description"></view>
					<view style="text-align: center;color: #E8E8E8;font-size: 32rpx;margin: 28rpx 0;">当前实力：{{dialogInfo.strengthRate}}%</view>
					<view style="text-align: center;color: #E8E8E8;font-size: 32rpx;">挑战消耗：{{dialogInfo.consumeExp}}修为</view>
					<view style="text-align: center;color: #E8E8E8;font-size: 32rpx;margin-top: 6rpx;">已挑战次数：{{dialogInfo.failCount}}次</view>
					<view style="margin-top: 28rpx;" v-html="dialogInfo.rule"></view>
				</scroll-view>
				<view v-if="dialogInfo.passed" class="bt2">已战胜</view>
				<view v-else @tap="ajaxChanllenge" class="bt1">战</view>
			</view>
		</uni-popup>
		
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	var _self
	
	export default {
		components:{
			uniPopup
		},
		data() {
			return {
				lists:[],
				dialogInfo:{},
				discipleId:0
			}
		},
		onLoad(option) {
			_self = this
			_self.lists = _self.jsonParse.getBreakThroughArray()
			_self.discipleId = _self.util.toDecodeUri(option).discipleId
		},
		methods: {
			ajaxChanllenge() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'7_2',
					params:{
						discipleId:_self.discipleId,
						challengeId:_self.dialogInfo.id
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.$refs.refDialog.close()
						let discipleView = resData.discipleView
						if(discipleView) {
							if(resData.discipleDeath) {
								_self.util.deleteDisciple(discipleView.id)
							}else {
								_self.util.updateDiscipleData(discipleView)
							}
						}
						
						let equips = resData.equips.equips
						_self.util.updateEquips(equips)
						
						_self.navigateTo(_self.util.toEncodeUri('/pages/fight/fight',{
							resData:resData,
							typeText:'break-through'
						}))
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxDetail(info) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'7_1',
					params:{
						discipleId:_self.discipleId,
						challengeId:info.id
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						info.description =  _self.util.exchangeLineBreak(info.description)
						info.rule = _self.util.exchangeLineBreak(info.rule)
						
						let burstView = resData.burstView
						_self.dialogInfo = {
							...burstView,
							...info
						}
						_self.$refs.refDialog.open()
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/disciple-break-through-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogLayout {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg2.png) center center no-repeat;background-size:100% 100%;
		
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt2 {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #999999;
		background:url(../../static/skill-bt-normal.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
