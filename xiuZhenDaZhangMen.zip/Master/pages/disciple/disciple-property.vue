<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">弟子属性</block>
			<block slot="right">
				<view @tap="tapWh" class="iconRight">?</view>
			</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;line-height: 60rpx;font-size: 30rpx;color: #FFFFFF;margin-top: 50rpx;padding-left: 50rpx;">
			<!-- <view style="display: flex;flex-direction: column;flex: 1;padding-left: 50rpx;">
				<view>大境界：{{greatRealmName}}</view>
				<view>体质：{{physique}}</view>
			</view>
			<view style="display: flex;flex-direction: column;flex: 1;padding-left: 50rpx;">
				<view>小境界：{{smallRealmName}}</view>
				<view>天赋：{{gift}}</view>
			</view> -->
			<view class="c-FFFFFF">
				修真境界：<text :class="'gr-'+greatRealm">{{greatRealmName}}</text><text style="margin-left: 30rpx;" :class="'sr-'+greatRealm+'-'+smallRealm">{{smallRealmName}}</text>
			</view>
			<view class="c-FFCC00">先天体质：<text :class="'m-'+physiqueQuality">{{physique}}</text></view>
			<view class="c-66FFCC">修真天赋：<text :class="'m-'+giftQuality">{{gift}}</text></view>
		</view>
		
		<view style="display: flex;flex-direction: row;line-height: 60rpx;font-size: 30rpx;color: #FFFFFF;margin-top: 50rpx;">
			<view style="display: flex;flex-direction: column;flex: 1;padding-left: 50rpx;">
				<view class="flex-row p-1">气血：<view class="width-80" :class="totalProperty?'m-'+totalProperty['1'].toString().length:''">{{totalProperty?totalProperty['1']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['1']+' )':''}}</text></view>
				<view class="flex-row p-3">神念：<view class="width-80" :class="totalProperty?'m-'+totalProperty['3'].toString().length:''">{{totalProperty?totalProperty['3']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['3']+' )':''}}</text></view>
				<view class="flex-row p-5">破甲：<view class="width-80" :class="totalProperty?'m-'+totalProperty['5'].toString().length:''">{{totalProperty?totalProperty['5']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['5']+' )':''}}</text></view>
				<view class="flex-row p-7">命中：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['7']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['7']*100)+'% )':''}}</text></view>
				<view class="flex-row p-9">暴击：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['9']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['9']*100)+'% )':''}}</text></view>
			</view>
			<view style="display: flex;flex-direction: column;flex: 1;padding-left: 50rpx;">
				<view class="flex-row p-2">灵力：<view class="width-80" :class="totalProperty?'m-'+totalProperty['2'].toString().length:''">{{totalProperty?totalProperty['2']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['2']+' )':''}}</text></view>
				<view class="flex-row p-4">肉身：<view class="width-80" :class="totalProperty?'m-'+totalProperty['4'].toString().length:''">{{totalProperty?totalProperty['4']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['4']+' )':''}}</text></view>
				<view class="flex-row p-6">格挡：<view class="width-80" :class="totalProperty?'m-'+totalProperty['6'].toString().length:''">{{totalProperty?totalProperty['6']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['6']+' )':''}}</text></view>
				<view class="flex-row p-8">躲闪：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['8']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['8']*100)+'% )':''}}</text></view>
				<view class="flex-row p-10">抗暴：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['10']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['10']*100)+'% )':''}}</text></view>
			</view>
		</view>
		
		<view style="display: flex;flex-direction: column;line-height: 60rpx;font-size: 30rpx;color: #FFFFFF;margin-top: 50rpx;padding-left: 50rpx;">
			<view class="c-FFFFCC">修真资质：<text :class="'m-'+discipleQuality">{{qualification}}</text></view>
			<view class="c-CCFFCC">炼丹经验：<text class="c-FFFF00">{{le}}/{{leMax}}</text></view>
			<view class="c-0066FF">铸造经验：<text class="c-FFFF00">{{ze}}/{{zeMax}}</text></view>
			<view class="c-990033">渡劫概率：<text class="c-FFFF00">{{promoteRate?util.keepTwoDecimal(promoteRate*100)+'%':notOpenText}}</text></view>
			<view class="c-FF6699">情缘好感：0/100</view>
		</view>
		
		<view style="width: 100%;display: flex;flex-direction: row;margin-top: 50rpx;justify-content: center;">
			<view @tap="tapCross" class="btLayout">渡劫突破</view>
			<!-- <view class="btLayout mar-l-86">后续开发</view> -->
		</view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDialog.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDetail" style="display: flex;align-items: center;color: #FFFFFF;flex-direction: column;">
				<view style="width: 488rpx;margin-top: 40rpx;display: flex;flex-direction: column;font-size: 24rpx;padding-left: 16rpx;line-height: 54rpx;overflow: scroll;height: 780rpx;">
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">大境界：{{greatRealmName}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'大境界：'+nextObj.greatRealmName:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">小境界：{{smallRealmName}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'小境界：'+nextObj.smallRealmName:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">气血：{{basicProperty?basicProperty['1']:0}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'气血：'+nextObj.p1:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">灵力：{{basicProperty?basicProperty['2']:0}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'灵力：'+nextObj.p2:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">神念：{{basicProperty?basicProperty['3']:0}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'神念：'+nextObj.p3:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">肉身：{{basicProperty?basicProperty['4']:0}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'肉身：'+nextObj.p4:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">破甲：{{basicProperty?basicProperty['5']:0}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'破甲：'+nextObj.p5:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">格挡：{{basicProperty?basicProperty['6']:0}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'格挡：'+nextObj.p6:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">命中：{{basicProperty?parseInt(basicProperty['7']*100):0}}%</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'命中：'+(basicProperty?parseInt(basicProperty['7']*100)+'%':'0%'):notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">躲闪：{{basicProperty?parseInt(basicProperty['8']*100):0}}%</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'躲闪：'+(basicProperty?parseInt(basicProperty['8']*100)+'%':'0%'):notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">暴击：{{basicProperty?parseInt(basicProperty['9']*100):0}}%</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'暴击：'+(basicProperty?parseInt(basicProperty['9']*100)+'%':'0%'):notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">抗暴：{{basicProperty?parseInt(basicProperty['10']*100):0}}%</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'抗暴：'+(basicProperty?parseInt(basicProperty['10']*100)+'%':'0%'):notOpenText}}</view>
					</view>
					
					<view style="margin-top: 30rpx;">渡劫概率：{{promoteRate?util.keepTwoDecimal(promoteRate*100)+'%':notOpenText}}</view>
					<view>渡劫消耗：{{nextObj?nextObj.consume:notOpenText}}</view>
				</view>
				
				<view v-if="nextObj" @tap="toCross" class="btPromote">渡劫突破</view>
			</view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	var _self
	
	export default {
		components:{
			popupWords
		},
		data() {
			return {
				discipleId:0,
				greatRealm:0,
				smallRealm:0,
				greatRealmName:'',
				smallRealmName:'',
				qualification:'',
				physique:'',
				gift:'',
				physiqueQuality:0,
				giftQuality:0,
				discipleQuality:0,
				le:0,
				ze:0,
				leMax:0,
				zeMax:0,
				rCount:0,
				pstn:-1,
				itgc:0,
				basicProperty:null,
				totalProperty:null,
				promoteRate:0,
				infoObj:{},
				nextObj:null,
				notOpenText:'不可升级',
				wordsNew:''
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.fillData(detail)
		},
		
		methods: {
			tapWh() {
				let wordObj = _self.jsonParse.getIntroWords('disciple')
				if(wordObj) {
					_self.wordsNew = wordObj.content
					_self.$refs.refWords.open()
				}
			},
			handleCross(resData) {
				if(resData) {
					let disciple = resData.disciple
					if(disciple) {
						_self.util.updateDiscipleData(disciple)
					}
					
					switch(resData.rs) {
						case 0:
							_self.showToast('渡劫突破失败')
							break;
							
						case 1:
							_self.showToast('渡劫突破成功')
							let disciple = resData.disciple
							disciple.pstnName = _self.util.getNameByPstn(disciple.pstn)
							disciple.jobName = _self.jsonParse.getNameByJob(disciple.job)
							let realmInfo = _self.jsonParse.getRealm(disciple.rm,disciple.rml)
							if(realmInfo) {
								disciple.realm = realmInfo
							}
							_self.fillData(disciple)
							_self.fillDialog()
							break;
					}
				}
			},
			fillData(detail) {
				_self.greatRealmName = detail.realm.greatRealmName
				_self.smallRealmName = detail.realm.smallRealmName
				_self.le = detail.le
				_self.ze = detail.ze
				_self.itgc = detail.itgc
				_self.rCount = detail.rc
				_self.pstn = detail.pstn
				_self.greatRealm = detail.rm
				_self.smallRealm = detail.rml
				_self.discipleId = detail.id
				_self.promoteRate = _self.jsonParse.getDisciplePromoteRate(detail.rm,detail.rml,detail.rc)
				_self.basicProperty = _self.util.parseProperty(detail.bp)
				_self.totalProperty = _self.util.parseProperty(detail.tp)
				
				_self.leMax = _self.jsonParse.getAlchemyForgeExt(detail.ll,1)
				_self.zeMax = _self.jsonParse.getAlchemyForgeExt(detail.zl,2)
				
				const physiqueInfo = _self.jsonParse.getPhysiqueGift(detail.ps)
				if(physiqueInfo) {
					_self.physique = physiqueInfo.name
					_self.physiqueQuality = physiqueInfo.quality
				}else {
					_self.physique = '无'
					_self.physiqueQuality = 1
				}
				const giftInfo = _self.jsonParse.getPhysiqueGift(detail.gs)
				if(giftInfo) {
					_self.gift = giftInfo.name
					_self.giftQuality = giftInfo.quality
				}else {
					_self.gift = '无'
					_self.giftQuality = 1
				}
				
				const discipleQualityInfo = _self.jsonParse.getDiscipleQuality(detail.itgc)
				if(discipleQualityInfo) {
					_self.qualification = discipleQualityInfo.name
					_self.discipleQuality = discipleQualityInfo.quality
				}
			},
			fillDialog() {
				let nextObj
				let basicProperty = _self.basicProperty
				let cmInfo = _self.jsonParse.getMasterProperty(_self.greatRealm,_self.smallRealm,_self.rCount)
				let cdInfo = _self.jsonParse.getDiscipleProperty(_self.itgc,_self.greatRealm,_self.rCount)
				let isGreat = _self.jsonParse.breakThroughByGreatRealm(_self.greatRealm,_self.smallRealm,_self.rCount)
				if(isGreat) {
					let realmInfo = _self.jsonParse.getRealm(_self.greatRealm+1,1)
					if(cdInfo && realmInfo) {
						if(_self.util.isMaster(_self.pstn)) {
							let masterPromoteGreatRealm = cdInfo.masterPromoteGreatRealm
							if(masterPromoteGreatRealm) {
								nextObj = {
									p1:basicProperty['1']+masterPromoteGreatRealm,
									p2:basicProperty['2']+masterPromoteGreatRealm,
									p3:basicProperty['3']+masterPromoteGreatRealm,
									p4:basicProperty['4']+masterPromoteGreatRealm,
									p5:basicProperty['5']+masterPromoteGreatRealm,
									p6:basicProperty['6']+masterPromoteGreatRealm
								}
							}
						}else {
							let greatRealmRange = cdInfo.greatRealmRange
							if(greatRealmRange && greatRealmRange.indexOf('-')!=-1) {
								let greatRealmRangeArray = greatRealmRange.split('-')
								let gr0 = parseInt(greatRealmRangeArray[0])
								let gr1 = parseInt(greatRealmRangeArray[1])
								nextObj = {
									p1:(basicProperty['1']+gr0)+'-'+(basicProperty['1']+gr1),
									p2:(basicProperty['2']+gr0)+'-'+(basicProperty['2']+gr1),
									p3:(basicProperty['3']+gr0)+'-'+(basicProperty['3']+gr1),
									p4:(basicProperty['4']+gr0)+'-'+(basicProperty['4']+gr1),
									p5:(basicProperty['5']+gr0)+'-'+(basicProperty['5']+gr1),
									p6:(basicProperty['6']+gr0)+'-'+(basicProperty['6']+gr1)
								}
							}
						}
						if(nextObj) {
							nextObj.greatRealmName = realmInfo.greatRealmName
							nextObj.smallRealmName = realmInfo.smallRealmName
						}
					}
				}else {
					let nmInfo = _self.jsonParse.getMasterProperty(_self.greatRealm,_self.smallRealm+1,_self.rCount)
					let realmInfo = _self.jsonParse.getRealm(_self.greatRealm,_self.smallRealm+1)
					if(cdInfo && nmInfo && realmInfo) {
						if(_self.util.isMaster(_self.pstn)) {
							nextObj = {
								p1:nmInfo.p1,
								p2:nmInfo.p2,
								p3:nmInfo.p3,
								p4:nmInfo.p4,
								p5:nmInfo.p5,
								p6:nmInfo.p6
							}
						}else {
							let smallRealmRange = cdInfo.smallRealmRange
							if(smallRealmRange && smallRealmRange.indexOf('-')!=-1) {
								let smallRealmRangeArray = smallRealmRange.split('-')
								let sr0 = parseInt(smallRealmRangeArray[0])
								let sr1 = parseInt(smallRealmRangeArray[1])
								nextObj = {
									p1:(basicProperty['1']+sr0)+'-'+(basicProperty['1']+sr1),
									p2:(basicProperty['2']+sr0)+'-'+(basicProperty['2']+sr1),
									p3:(basicProperty['3']+sr0)+'-'+(basicProperty['3']+sr1),
									p4:(basicProperty['4']+sr0)+'-'+(basicProperty['4']+sr1),
									p5:(basicProperty['5']+sr0)+'-'+(basicProperty['5']+sr1),
									p6:(basicProperty['6']+sr0)+'-'+(basicProperty['6']+sr1)
								}
							}
						}
						if(nextObj) {
							nextObj.greatRealmName = realmInfo.greatRealmName
							nextObj.smallRealmName = realmInfo.smallRealmName
						}
					}
				}
				if(nextObj && cmInfo) {
					let consume = '修为*'+cmInfo.consumeUpgrade
					if(cmInfo.consumeMaterial!='无') {
						consume += ', '+cmInfo.consumeMaterial
					}
					nextObj.consume = consume
				}
				_self.nextObj = nextObj
			},
			toCross() {
				let isGreat = _self.jsonParse.breakThroughByGreatRealm(_self.greatRealm,_self.smallRealm,_self.rCount)
				if(isGreat) {
					_self.ajaxGreatCross()
				}else {
					_self.ajaxSmallCross()
				}
			},
			tapCross() {
				_self.fillDialog()
				_self.$refs.refDialog.open()
			},
			ajaxGreatCross() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_4',
					params:{
						discipleId:_self.discipleId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.handleCross(resData)
				}
				_self.$req.handleRequest(option)
			},
			ajaxSmallCross() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_3',
					params:{
						discipleId:_self.discipleId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.handleCross(resData)
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.cententLayout {
		width: 100%;
		height: 680rpx;
		background:url(../../static/disciple-bg-character-image.png) center center no-repeat;background-size: 574rpx 100%;
	}
	
	.avatarLayout {
		width: 424rpx;
		height: 436rpx;
		margin-top: 20rpx;
		background:url(../../static/disciple-bg-character.png) center center no-repeat;background-size: 320rpx 100%;
	}
	
	.dialogDetail {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btPromote {
		position: absolute;
		bottom: 50rpx;
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
