<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">技能系介绍</block>
		</cu-custom>
		
		<view class="cLayout">
			<view @tap="tapItem(layerArray1[0])" :class="layerArray1[0]&&layerArray1[0].skillId==selectSkillId?'tapActive':''" style="width: 304rpx;height: 90rpx;margin-left: 180rpx;text-align: center;font-size: 36rpx;position: absolute;line-height: 92rpx;">{{layerArray1[0]?layerArray1[0].skillName:''}}</view>
			<view style="margin-top: 146rpx;display: flex;flex-direction: row;position: absolute;width: 659rpx;">
				<view v-if="layerArray2[0]&&(layerArray2[0].skillId==layerInfo['2'] || (maxLayer==1 && currLayerLevel==maxLayerLevel))" @tap="tapItem(layerArray2[0])" :class="layerArray2[0]&&layerArray2[0].skillId==selectSkillId?'tapActive':''" style="height: 90rpx;display: flex;flex: 1;font-size: 36rpx;line-height: 94rpx;justify-content: center;">{{layerArray2[0]?layerArray2[0].skillName:''}}</view>
				<view v-else style="height: 90rpx;display: flex;flex: 1;font-size: 36rpx;line-height: 94rpx;justify-content: center;color: #999999;">{{layerArray2[0]?layerArray2[0].skillName:''}}</view>
				<view v-if="layerArray2[1]&&(layerArray2[1].skillId==layerInfo['2'] || (maxLayer==1 && currLayerLevel==maxLayerLevel))" @tap="tapItem(layerArray2[1])" :class="layerArray2[1]&&layerArray2[1].skillId==selectSkillId?'tapActive':''" style="height: 90rpx;display: flex;flex: 1;font-size: 36rpx;line-height: 94rpx;justify-content: center;margin-left: 54rpx;">{{layerArray2[1]?layerArray2[1].skillName:''}}</view>
				<view v-else style="height: 90rpx;display: flex;flex: 1;font-size: 36rpx;line-height: 94rpx;justify-content: center;margin-left: 54rpx;color: #999999;">{{layerArray2[1]?layerArray2[1].skillName:''}}</view>
			</view>
			
			<view style="margin-top: 340rpx;display: flex;flex-direction: row;position: absolute;width: 659rpx;">
				<view v-if="layerArray3[0]&&(layerArray3[0].skillId==layerInfo['3'] || (maxLayer==2 && currLayerLevel==maxLayerLevel && maxLayerSkillId==layerArray2[0].skillId))" @tap="tapItem(layerArray3[0])" :class="layerArray3[0]&&layerArray3[0].skillId==selectSkillId?'tapActive':''" style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;">{{layerArray3[0]?layerArray3[0].skillName:''}}</view>
				<view v-else style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;color: #999999;">{{layerArray3[0]?layerArray3[0].skillName:''}}</view>
				<view v-if="layerArray3[1]&&(layerArray3[1].skillId==layerInfo['3'] || (maxLayer==2 && currLayerLevel==maxLayerLevel && maxLayerSkillId==layerArray2[0].skillId))" @tap="tapItem(layerArray3[1])" :class="layerArray3[1]&&layerArray3[1].skillId==selectSkillId?'tapActive':''" style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;">{{layerArray3[1]?layerArray3[1].skillName:''}}</view>
				<view v-else style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;color: #999999;">{{layerArray3[1]?layerArray3[1].skillName:''}}</view>
				<view v-if="layerArray3[2]&&(layerArray3[2].skillId==layerInfo['3'] || (maxLayer==2 && currLayerLevel==maxLayerLevel && maxLayerSkillId==layerArray2[1].skillId))" @tap="tapItem(layerArray3[2])" :class="layerArray3[2]&&layerArray3[2].skillId==selectSkillId?'tapActive':''" style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 54rpx;">{{layerArray3[2]?layerArray3[2].skillName:''}}</view>
				<view v-else style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 54rpx;color: #999999;">{{layerArray3[2]?layerArray3[2].skillName:''}}</view>
				<view v-if="layerArray3[3]&&(layerArray3[3].skillId==layerInfo['3'] || (maxLayer==2 && currLayerLevel==maxLayerLevel && maxLayerSkillId==layerArray2[1].skillId))" @tap="tapItem(layerArray3[3])" :class="layerArray3[3]&&layerArray3[3].skillId==selectSkillId?'tapActive':''" style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;">{{layerArray3[3]?layerArray3[3].skillName:''}}</view>
				<view v-else style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;color: #999999;">{{layerArray3[3]?layerArray3[3].skillName:''}}</view>
			</view>
			
			<view style="margin-top: 474rpx;display: flex;flex-direction: row;position: absolute;width: 659rpx;color: #999999;">
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;">后续开放</view>
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;">后续开放</view>
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 54rpx;">后续开放</view>
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;">后续开放</view>
			</view>
			
			<view style="margin-top: 608rpx;display: flex;flex-direction: row;position: absolute;width: 659rpx;color: #999999;">
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;">后续开放</view>
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;">后续开放</view>
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 54rpx;">后续开放</view>
				<view style="height: 90rpx;display: flex;flex: 1;font-size: 26rpx;line-height: 94rpx;justify-content: center;margin-left: 22rpx;">后续开放</view>
			</view>
			
		</view>
		
		<view style="width: 100%;display: flex;flex-direction: row;margin-top: 100rpx;justify-content: center;">
			<!-- <view v-if="doBt1" @tap="tapSet" class="btLayout1">设置主技</view>
			<view v-else class="btLayout2">设置主技</view>
			<view v-if="doBt2" @tap="tapLearn(true)" class="btLayout1 mar-l-86">修炼功法</view>
			<view v-else class="btLayout2 mar-l-86">修炼功法</view> -->
			
			<!-- <view v-if="doBt2" @tap="tapLearn(true)" class="btLayout1">修炼功法</view>
			<view v-else class="btLayout2">修炼功法</view> -->
			
			<view v-if="doBt2" @tap="tapLearn(true)" class="btLayout1">修炼功法</view>
			<view v-else @tap="tapPreLayer" :class="skillInfo?'btLayout1':'btLayout2'">修炼功法</view>
		</view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDialog.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDetail" style="display: flex;align-items: center;color: #FFFFFF;flex-direction: column;">
				<view style="width: 488rpx;margin-top: 40rpx;display: flex;flex-direction: column;font-size: 24rpx;padding-left: 16rpx;line-height: 54rpx;overflow: scroll;height: 780rpx;">
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;justify-content: center;">{{infoObj.t1}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;visibility: hidden;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;justify-content: center;">{{nextObj?nextObj.t1:fullLevelText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">{{infoObj.t2}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?nextObj.t2:fullLevelText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;line-height: 42rpx;margin:10rpx 0;">
						<view style="display: flex;flex: 1;">{{infoObj.t3}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?nextObj.t3:fullLevelText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;">
						<view style="display: flex;flex: 1;">{{infoObj.t4}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?nextObj.t4:fullLevelText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;line-height: 42rpx;margin:10rpx 0;">
						<view style="display: flex;flex: 1;">{{infoObj.t5}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?nextObj.t5:fullLevelText}}</view>
					</view>
					
					<view>技能描述：{{skillInfo?skillInfo.skillDescription:''}}</view>
					<view>{{nextObj?infoObj.t6:''}}</view>
					<view>最高层数：{{skillInfo?skillInfo.maxLevel:'-'}}层</view>
					<view>修习限制：{{skillInfo?skillInfo.attrRequire:'无'}}</view>
					<view>失败惩罚：技能等级下降一</view>
					<view>保底设置：每五级保底</view>
				</view>
				
				<view v-if="nextObj" @tap="toLearn" class="btPromote">修习功法</view>
			</view>
		</uni-popup>
		
		<popup-confirm ref="refText" :showCancel="false" :content="dialogText"></popup-confirm>
	</view>
</template>

<script>
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	
	export default {
		components:{
			popupConfirm
		},
		data() {
			return {
				id:0,
				layerArray1:[],
				layerArray2:[],
				layerArray3:[],
				selectSkillId:0,
				discipleId:0,
				maxLayer:1,
				maxLayerLevel:1,
				currLayerLevel:1,
				layerInfo:{},
				skillInfo:null,
				doBt1:false,
				doBt2:false,
				dialogText:'',
				notOpenText:'',
				promoteRate:0,
				nextObj:null,
				infoObj:{},
				fullLevelText:'满级',
				st:''
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.discipleId = detail.discipleId
			_self.id = detail.id
			_self.parseData(detail.skillStr)
			
			let skillArray = _self.jsonParse.getSkillArrayById(detail.id)
			if(skillArray.length>0) {
				let layerArray1 = []
				let layerArray2 = []
				let layerArray3 = []
				skillArray.forEach((info,index)=>{
					switch(info.layer) {
						case 1:
							layerArray1.push(info)
							break;
							
						case 2:
							layerArray2.push(info)
							break;
							
						case 3:
							layerArray3.push(info)
							break;
					}
				})
				_self.layerArray1 = layerArray1
				_self.layerArray2 = layerArray2
				_self.layerArray3 = layerArray3
			}
		},
		methods: {
			handleFormulaPassive(text,level) {
				try {
					let result  = 0
					if(text!='无') {
						if(text.indexOf('*')!=-1) {
							result = Math.ceil(parseFloat(text.split('*')[0])*(level*level+level))
						}else {
							result = _self.util.keepTwoDecimal(parseFloat(text)*100)+'%'
						}
					}
					return result
				}catch(e) {}
			},
			handleFormulaSkill(text,level) {
				try {
					let array1 = text.split('+')
					let array2 = array1[1].split('/')
					return _self.util.keepTwoDecimal(parseFloat(array1[0])+(level*level/parseFloat(array2[1])))
				}catch(e) {}
			},
			handleFormulaLl(text,level) {
				try {
					return parseInt(level*parseFloat(text.split('*')[1]))
				}catch(e) {}
			},
			handleFormulaLearnSuccess(text,level) {
				try {
					let array = text.split('-')
					return parseInt((parseFloat(array[0])-parseFloat(array[1].split('*')[0])*level)*100)+'%'
				}catch(e) {}
			},
			handleFormulaLearnConsume(text,level) {
				try {
					let array = text.split('+')
					return parseInt(parseFloat(array[0])+parseFloat(array[1].split('*')[0])*level)
				}catch(e) {}
			},
			doDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			parseData(skillStr) {
				_self.st = skillStr
				
				let array1 = skillStr.split('=')
				let maxLayer = 0
				let currLayerLevel = 0
				let maxLayerSkillId = 0
				let layerInfo = {}
				let array2 = array1[1].split('#')
				array2.forEach((text)=>{
					let array3 = text.split(':')
					let skillLayer = array3[0]
					if(skillLayer>maxLayer) {
						maxLayer = skillLayer
						currLayerLevel = array3[2]
						maxLayerSkillId = array3[1]
					}
					layerInfo[array3[0]] = array3[1]
				})
				_self.maxLayer = maxLayer
				_self.layerInfo = layerInfo
				_self.maxLayerSkillId = maxLayerSkillId
				_self.currLayerLevel = currLayerLevel
				_self.maxLayerLevel = _self.jsonParse.getSkillMaxLayerLevel(_self.id,maxLayerSkillId)
			},
			tapSet() {
				if(_self.skillInfo) {
					_self.ajaxSet()
				}
			},
			toLearn() {
				let skillInfo = _self.skillInfo
				if(skillInfo.layer==_self.maxLayer) {
					_self.ajaxPromote()
				}else {
					_self.ajaxLearn()
				}
			},
			tapPreLayer() {
				// 查看满级的数据
				let skillInfo = _self.skillInfo
				if(skillInfo) {
					let consume = skillInfo.consume
					
					let maxLevel = skillInfo.maxLevel
					let t6 = '修习消耗：灵石*'+_self.handleFormulaLearnConsume(skillInfo.formulaLearnConsume,maxLevel)
					if(consume!='无') {
						t6 += ', '+consume
					}
					_self.infoObj.t1 = skillInfo.skillName+'+'+maxLevel
					_self.infoObj.t2 = '技能系数：'+_self.handleFormulaSkill(skillInfo.formulaSkill,maxLevel)
					_self.infoObj.t3 = skillInfo.passiveDescription+_self.handleFormulaPassive(skillInfo.formulaPassive,maxLevel)
					_self.infoObj.t4 = '灵力消耗：'+_self.handleFormulaLl(skillInfo.formulaLl,maxLevel)
					_self.infoObj.t5 = '学习概率：'+_self.handleFormulaLearnSuccess(skillInfo.formulaLearnSuccess,maxLevel)
					_self.infoObj.t6 = t6
					
					_self.nextObj = null
					_self.$forceUpdate()
					_self.$refs.refDialog.open()
				}
			},
			tapLearn(openDialog) {
				let skillInfo = _self.skillInfo
				if(skillInfo) {
					if(skillInfo.layer==_self.maxLayer) {
						let consume = skillInfo.consume
						
						let currLayerLevel = parseInt(_self.currLayerLevel)
						let t6 = '修习消耗：灵石*'+_self.handleFormulaLearnConsume(skillInfo.formulaLearnConsume,currLayerLevel)
						if(consume!='无') {
							t6 += ', '+consume
						}
						_self.infoObj.t1 = skillInfo.skillName+'+'+currLayerLevel
						_self.infoObj.t2 = '技能系数：'+_self.handleFormulaSkill(skillInfo.formulaSkill,currLayerLevel)
						_self.infoObj.t3 = skillInfo.passiveDescription+_self.handleFormulaPassive(skillInfo.formulaPassive,currLayerLevel)
						_self.infoObj.t4 = '灵力消耗：'+_self.handleFormulaLl(skillInfo.formulaLl,currLayerLevel)
						_self.infoObj.t5 = '学习概率：'+_self.handleFormulaLearnSuccess(skillInfo.formulaLearnSuccess,currLayerLevel)
						_self.infoObj.t6 = t6
						
						if(currLayerLevel>=_self.maxLayerLevel) {
							_self.nextObj = null
						}else {
							let nextObj = {}
							let nextLayerLevel = currLayerLevel+1
							nextObj.t1 = skillInfo.skillName+'+'+nextLayerLevel
							nextObj.t2 = '技能系数：'+_self.handleFormulaSkill(skillInfo.formulaSkill,nextLayerLevel)
							nextObj.t3 = skillInfo.passiveDescription+_self.handleFormulaPassive(skillInfo.formulaPassive,nextLayerLevel)
							nextObj.t4 = '灵力消耗：'+_self.handleFormulaLl(skillInfo.formulaLl,nextLayerLevel)
							nextObj.t5 = '学习概率：'+_self.handleFormulaLearnSuccess(skillInfo.formulaLearnSuccess,nextLayerLevel)
							_self.nextObj = nextObj
						}
					}else {
						/**
						 * 拿到上一层选中的技能的最高等级数据
						 */
						let preLayer = skillInfo.layer-1
						let st = _self.st
						if(st) {
							let array1 = st.split('=')[1].split('#')
							array1.forEach((text)=>{
								let array2 = text.split(':')
								if(preLayer==parseInt(array2[0])) {
									let skillInfo = _self.jsonParse.getSkillInfo(parseInt(array2[1]))
									if(skillInfo) {
										let layerLevel = skillInfo.maxLevel
										_self.infoObj.t1 = skillInfo.skillName+'+'+layerLevel
										_self.infoObj.t2 = '技能系数：'+_self.handleFormulaSkill(skillInfo.formulaSkill,layerLevel)
										_self.infoObj.t3 = skillInfo.passiveDescription+_self.handleFormulaPassive(skillInfo.formulaPassive,layerLevel)
										_self.infoObj.t4 = '灵力消耗：'+_self.handleFormulaLl(skillInfo.formulaLl,layerLevel)
										_self.infoObj.t5 = '学习概率：'+_self.handleFormulaLearnSuccess(skillInfo.formulaLearnSuccess,layerLevel)
									}
								}
							})
						}
						
						let consume = skillInfo.consume
						let t6 = '修习消耗：灵石*'+_self.handleFormulaLearnConsume(skillInfo.formulaLearnConsume,skillInfo.minLevel)
						if(consume!='无') {
							t6 += ', '+consume
						}
						_self.infoObj.t6 = t6
						
						let nextObj = {}
						let nextLayerLevel = skillInfo.minLevel
						nextObj.t1 = skillInfo.skillName+'+'+nextLayerLevel
						nextObj.t2 = '技能系数：'+_self.handleFormulaSkill(skillInfo.formulaSkill,nextLayerLevel)
						nextObj.t3 = skillInfo.passiveDescription+_self.handleFormulaPassive(skillInfo.formulaPassive,nextLayerLevel)
						nextObj.t4 = '灵力消耗：'+_self.handleFormulaLl(skillInfo.formulaLl,nextLayerLevel)
						nextObj.t5 = '学习概率：'+_self.handleFormulaLearnSuccess(skillInfo.formulaLearnSuccess,nextLayerLevel)
						_self.nextObj = nextObj
					}
					_self.$forceUpdate()
					if(openDialog) {
						_self.$refs.refDialog.open()
					}
				}
			},
			tapItem(info) {
				if(info) {
					let skillLayer = info.layer
					if(skillLayer<_self.maxLayer) {
						_self.doBt1 = true
						_self.doBt2 = false
					}else if(skillLayer==_self.maxLayer) {
						if(info.maxLevel>_self.currLayerLevel) {
							_self.doBt2 = true
						}
						_self.doBt1 = true
					}else {
						_self.doBt1 = false
						_self.doBt2 = true
					}
					_self.skillInfo = info
					_self.selectSkillId = info.skillId
				}
			},
			ajaxPromote() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_10',
					params:{
						discipleId:_self.discipleId,
						layer:_self.skillInfo.layer
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						switch(resData.rs) {
							case 0:
								_self.showToast('修炼功法失败')
								break;
								
							case 1:
								_self.showToast('修炼功法成功')
								break;
						}
						let disciple = resData.disciple
						if(disciple) {
							_self.parseData(disciple.st)
							_self.tapLearn()
							_self.util.updateDiscipleData(disciple)
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxLearn() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_11',
					params:{
						discipleId:_self.discipleId,
						layer:_self.skillInfo.layer,
						skillId:_self.skillInfo.skillId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						switch(resData.rs) {
							case 0:
								_self.showToast('学习功法失败')
								break;
								
							case 1:
								_self.showToast('学习功法成功')
								break;
						}
						let disciple = resData.disciple
						if(disciple) {
							_self.parseData(disciple.st)
							_self.tapLearn()
							_self.util.updateDiscipleData(disciple)
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxSet() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_12',
					params:{
						discipleId:_self.discipleId,
						skillId:_self.skillInfo.skillId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.doDialog('设置主技能成功')
						let disciple = resData.disciple
						if(disciple) {
							_self.parseData(disciple.st)
							_self.util.updateDiscipleData(disciple)
						}
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.cLayout {
		width: 659rpx;
		height: 697rpx;
		margin-left: 46rpx;
		margin-top: 60rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-skill-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout1 {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout2 {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #999999;
		background:url(../../static/skill-bt-normal.png) center center no-repeat;background-size:100% 100%;
	}
	
	
	
	.tapActive {
		color: #e74c3c!important;
	}
	
	.dialogDetail {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btPromote {
		position: absolute;
		bottom: 50rpx;
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	
</style>
