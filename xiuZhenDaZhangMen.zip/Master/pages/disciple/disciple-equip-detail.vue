<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">{{equipName}}</block>
			<block slot="right">
				<view @tap="tapWh" class="iconRight">?</view>
			</block>
		</cu-custom>
		
		<view class="detailLayout">
			<view style="width: 622rpx;height: 428rpx;">
				<view v-if="equipScore" style="position: absolute;margin-left: 30rpx;margin-top: 30rpx;border: solid 1px #E5E5E5;border-radius: 50%;min-width: 50rpx;height: 50rpx;display: flex;justify-content: center;align-items: center;padding: 10rpx;">{{equipScore}}</view>
				<view style="line-height: 110rpx;text-align: center;font-size: 32rpx;padding-top: 20rpx;"><text :class="'m-'+quality">{{equipName}}</text><text v-if="jxInfo1" :style="[{'color':jxInfo1?jxInfo1.color:'inherit'}]">{{jxInfo1?jxInfo1.text:''}}</text></view>
				<view style="display: flex;flex-direction: row;">
					<view style="display: flex;flex-direction: column;flex: 1;padding-left: 40rpx;">
						<view>品级：{{qualityName}}</view>
						<view>类型：{{typeText}}</view>
						<view>等级：{{level}}/{{maxLevel}}</view>
						<view>限制：{{limitText}}</view>
					</view>
					<view style="display: flex;flex-direction: column;flex: 1.3;padding-left: 20rpx;">
						<view style="display: flex;flex-direction: row;">
							基础：
							<view style="display: flex;flex: 1;flex-direction: column;">
								<view v-for="(text,index) in basicPropertyArray" :key="index">{{text}} ({{initPropertyArray[index]}})</view>
							</view>
						</view>
						<view style="display: flex;flex-direction: row;">
							附加：
							<view v-if="extraPropertyArray.length>0" style="display: flex;flex: 1;flex-direction: column;">
								<view v-for="(text,index) in extraPropertyArray" :key="index">{{text}}</view>
							</view>
							<text v-else>无</text>
						</view>
					</view>
					
				</view>
				<view v-if="equipSe" style="text-align: center;margin-top: 20rpx;">{{equipSe}}</view>
			</view>
		</view>
		
		<!-- <view v-if="wear" @tap="tapTakeOff(true)" class="bt1">卸下</view>
		<view v-else @tap="tapWear(true)" class="bt1">穿戴</view> -->
		<view style="display: flex;flex-direction: row;width: 460rpx;margin-left: 145rpx;margin-top: 40rpx;">
			<view v-if="wear" @tap="tapTakeOff(true)" class="bt2">卸下</view>
			<view v-else @tap="tapWear(true)" class="bt2">穿戴</view>
			<view class="bt2 mar-l-80" @tap="tapStrength">蕴器</view>
		</view>
		<view style="display: flex;flex-direction: row;width: 460rpx;margin-left: 145rpx;margin-top: 40rpx;">
			<view v-if="level==maxLevel" class="bt2" @tap="tapJx">提品</view>
			<view v-else class="bt4" @tap="showToast('装备满级才可以提品')">提品</view>
			<view v-if="wear" class="bt4 mar-l-80" @tap="showToast('穿戴中的装备不能被分解')">分解</view>
			<view v-else class="bt2 mar-l-80" @tap="tapBreak">分解</view>
		</view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="precipitatorDialog" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">蕴器</view>
				<scroll-view scroll-y="true" style="display: flex;flex-direction: column;line-height: 54rpx;font-size: 26rpx;color: #CBC8C9;height: 570rpx;width: 428rpx;margin-bottom: 34rpx;">
					<view>名称：{{equipName}}</view>
					<view>品级：{{qualityName}}</view>
					<view>类型：{{typeText}}</view>
					<view>蕴器等级：{{level}}级</view>
					<view>蕴器上限：{{maxLevel}}级</view>
					<view>当前属性：{{initialAttr}}<text class="mar-l-6" v-if="totalBoost>0">(+{{totalBoost}})</text></view>
					<view>成功提升属性：+{{boostValue}}</view>
					<view>蕴器成功率：{{successRate*100}}%</view>
					<view style="display: flex;flex-direction: row;">
						蕴器消耗：<view style="display: flex;flex: 1;">{{level==maxLevel?strengthConsume:'灵石*'+strengthConsume}}</view>
					</view>
					<view>失败损失：蕴器等级下降一</view>
				</scroll-view>
				<view v-if="level<maxLevel" @tap="ajaxStrength" class="bt3">蕴器</view>
				<view v-else class="bt4">不可强化</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refStrength" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refStrength.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogStrength" style="display: flex;justify-content: center;color: #FFFFFF;">
				<view style="width: 488rpx;margin-top: 40rpx;display: flex;flex-direction: column;font-size: 30rpx;padding-left: 16rpx;line-height: 60rpx;">
					<view style="display: flex;flex-direction: row;align-items: center;line-height: 42rpx;margin:10rpx 0;">
						<view style="display: flex;flex: 1;">{{equipName+'+'+level}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">
							<text v-if="level<maxLevel">{{equipName+'+'+(level+1)}}</text>
							<text v-else>{{notOpenText1}}</text>
						</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">{{iName}}：{{iValue1}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">
							<text v-if="level<maxLevel">{{iName}}：{{iValue2}}</text>
							<text v-else>{{notOpenText1}}</text>
						</view>
					</view>
					
					<view>品质：{{qualityName}}</view>
					<view>类型：{{typeText}}</view>
					<view v-if="level<maxLevel">成功概率：{{util.keepTwoDecimal(successRate*100)}}%</view>
					<view>失败惩罚：蕴器等级下降一</view>
					<view>保底设置：每五级保底</view>
					<view v-if="level<maxLevel" style="display: flex;flex-direction: row;">
						蕴器消耗：<view style="display: flex;flex: 1;">{{'灵石*'+strengthConsume}}</view>
					</view>
					
				</view>
				
				<view v-if="level<maxLevel" @tap="ajaxStrength" class="btStrength">蕴器</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refWearOff" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refWearOff.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogStrength" style="display: flex;justify-content: center;color: #FFFFFF;">
				<view style="width: 440rpx;margin-top: 40rpx;display: flex;flex-direction: column;font-size: 30rpx;padding-left: 16rpx;line-height: 60rpx;overflow: scroll;height: 780rpx;">
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;justify-content: center;">原属性</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;visibility: hidden;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;justify-content: center;">新属性</view>
					</view>
					<view v-for="(name,index) in nameArray" :key="index" style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">{{name}}：{{index>5?parseInt(tpObj[index+1]*100)+'%':tpObj[index+1]}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{name}}：{{index>5?parseInt(leObj[index+1]*100)+'%':leObj[index+1]}}</view>
						<image v-if="leObj[index+1]-tpObj[index+1]>0" style="width: 46rpx;height: 46rpx;position: absolute;right: 20rpx;" src="/static/arrow-up.png"></image>
						<image v-else-if="leObj[index+1]-tpObj[index+1]<0" style="width: 46rpx;height: 46rpx;position: absolute;right: 20rpx;" src="/static/arrow-down.png"></image>
					</view>
					
				</view>
				
				<view v-if="wear" @tap="ajaxTakeOff" class="btStrength">卸下</view>
				<view v-else @tap="ajaxWear" class="btStrength">穿戴</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refJx" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refJx.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogStrength" style="display: flex;justify-content: center;color: #FFFFFF;">
				<view class="isCenter" style="width: 440rpx;margin-top: 40rpx;font-size: 30rpx;padding-left: 16rpx;line-height: 60rpx;height: 780rpx;">
					<view style="width: 100%;">
						<view style="display: flex;flex-direction: row;line-height: 50rpx;align-items: center;">
							<view style="display: flex;flex: 1;justify-content: center;"><text>{{equipName}}<br><text v-if="jxInfo1" :style="[{'color':jxInfo1?jxInfo1.color:'inherit'}]">{{jxInfo1?jxInfo1.text:''}}</text></text></view>
							<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;visibility: hidden;" src="/static/arrow-right.png"></image>
							<view style="display: flex;flex: 1;justify-content: center;">
								<text v-if="jxInfo2">{{equipName}}<br><text v-if="jxInfo2" :style="[{'color':jxInfo2?jxInfo2.color:'inherit'}]">{{jxInfo2?jxInfo2.text:''}}</text></text>
								<text v-else>{{notOpenText2}}</text></view>
						</view>
						
						<view class="mar-t-20" v-if="jxInitPropertyArray.length>0" style="display: flex;flex-direction: row;line-height: 44rpx;align-items: center;font-size: 26rpx;color: #666666;">
							<view style="display: flex;flex: 1;justify-content: center;">基础属性</view>
							<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;visibility: hidden;" src="/static/arrow-right.png"></image>
							<view style="display: flex;flex: 1;justify-content: center;">基础属性</view>
						</view>
						<view v-for="(item,index) in jxInitPropertyArray" :key="'i'+index" style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
							<view style="display: flex;flex: 1;">{{item.name}}：{{item.value}}</view>
							<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
							<view style="display: flex;flex: 1;"><text v-if="jxInfo2">{{item.name}}：{{handleFormulaJxProperty(item.value)}}</text><text v-else>{{notOpenText2}}</text></view>
						</view>
						
						<view v-if="jxExtraPropertyArray.length>0" class="mar-t-20" style="display: flex;flex-direction: row;line-height: 44rpx;align-items: center;font-size: 26rpx;color: #666666;">
							<view style="display: flex;flex: 1;justify-content: center;">附加属性</view>
							<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;visibility: hidden;" src="/static/arrow-right.png"></image>
							<view style="display: flex;flex: 1;justify-content: center;">附加属性</view>
						</view>
						<view v-for="(item,index) in jxExtraPropertyArray" :key="'e'+index" style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
							<view style="display: flex;flex: 1;">{{item.name}}：{{item.value}}</view>
							<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
							<view style="display: flex;flex: 1;"><text v-if="jxInfo2">{{item.name}}：{{handleFormulaJxProperty(item.value)}}</text><text v-else>{{notOpenText2}}</text></view>
						</view>
						
						<block v-if="jxInfo2">
							<view class="mar-t-20" style="text-align: left;color: #666666;">提品成功率：{{handleFormulaSr()}}%</view>
							<view style="text-align: left;color: #666666;">装备爆炸率：{{(100-handleFormulaSr())}}%</view>
						</block>
						
						<view v-if="handleFormulaSr()>0 && handleFormulaSr()<100" class="mar-t-20">
							<view style="display: flex;flex-direction: row;">
								<view @tap="tapCb(floorType2)" style="display: flex;flex: 1;flex-direction: row;height: 60rpx;align-items: center;">
									<image style="width: 44rpx;height: 32rpx;" :src="floorType==floorType2?'/static/checkbox_select.png':'/static/checkbox_normal.png'"></image>
									<view style="margin-left: 10rpx;">灵石保底</view>
								</view>
								<view @tap="tapCb(floorType1)" style="display: flex;flex: 1;flex-direction: row;height: 60rpx;align-items: center;">
									<image style="width: 44rpx;height: 32rpx;" :src="floorType==floorType1?'/static/checkbox_select.png':'/static/checkbox_normal.png'"></image>
									<view style="margin-left: 10rpx;">仙石保底</view>
								</view>
							</view>
							<view style="display: flex;flex-direction: row;color: #666666;">
								<view style="display: flex;flex: 1;">{{floorInfo.consumeLs}}</view>
								<view style="display: flex;flex: 1;">{{floorInfo.consumeXs}}</view>
							</view>
						</view>
					</view>
					
				</view>
				<view v-if="jxInfo2" @tap="tapStar" class="btStrength">提品</view>
				<view v-else class="btStrength">{{notOpenText2}}</view>
			</view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
		<popup-confirm @confirm="ajaxBreak" ref="refBreak" :maskClick="true" :content="'分解装备：'+equipName"></popup-confirm>
		<popup-confirm @confirm="tapBack" ref="refBreakText" :showCancel="false" :content="breakText"></popup-confirm>
		<popup-confirm @confirm="tapToStar" ref="refStarText" :maskClick="true" content="装备可能爆炸"></popup-confirm>
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import popupWords from '@/components/popup-words/popup-words.vue'
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	
	export default {
		components:{
			uniPopup,
			popupConfirm,
			popupWords
		},
		data() {
			return {
				quality:0,
				equipName:'',
				qualityName:'',
				level:0,
				maxLevel:0,
				typeText:'',
				limitText:'',
				initPropertyArray:[],
				basicPropertyArray:[],
				extraPropertyArray:[],
				wear:false,
				boostValue:0,
				successRate:0,
				strengthConsume:0,
				discipleId:0,
				equipId:0,
				totalBoost:0,
				dialogText:'',
				initialAttr:'',
				notOpenText1:'不可强化',
				iName:'',
				iValue1:'',
				iValue2:'',
				wearEquipId:0,
				tpObj:{},
				leObj:{},
				nameArray:['气血','灵力','神念','肉身','破甲','格挡','命中','躲闪','暴击','抗暴'],
				equipSe:'',
				equipSt:0,
				breakText:'',
				equipScore:0,
				jxInitPropertyArray:[],
				jxExtraPropertyArray:[],
				notOpenText2:'暂不开放',
				jxInfo1:null,
				jxInfo2:null,
				wordsNew:'',
				floorType:0,
				floorType0:0,
				floorType1:1,
				floorType2:2,
				floorInfo:{}
			}
		},
		onLoad(option) {
			_self = this
			
			let detail = _self.util.toDecodeUri(option)
			_self.wearEquipId = detail.wearEquipId
			_self.discipleId = detail.discipleId
			_self.fillCommonData(detail)
		},
		methods: {
			tapToStar() {
				_self.toCloseDialogStarText()
				_self.ajaxStar()
			},
			tapStar() {
				if(_self.handleFormulaSr()<100 && _self.floorType==_self.floorType0) {
					_self.toOpenDialogStarText()
				}else {
					_self.ajaxStar()
				}
			},
			tapCb(floorType) {
				if(_self.floorType==floorType) {
					_self.floorType = _self.floorType0
				}else {
					_self.floorType = floorType
				}
			},
			tapWh() {
				let wordObj = _self.jsonParse.getIntroWords('equip')
				if(wordObj) {
					_self.wordsNew = wordObj.content
					_self.$refs.refWords.open()
				}
			},
			handleFormulaSr() {
				return Math.ceil((1-0.2*_self.equipSt)*100)
			},
			handleFormulaJxProperty(value) {
				return Math.ceil(value*(1.1+0.05*_self.quality*_self.equipSt/3))
			},
			toOpenDialogWo() {
				_self.$refs.refWearOff.open()
			},
			toCloseDialogWo() {
				_self.$refs.refWearOff.close()
			},
			tapTakeOff(isOpen) {
				let disciples = getApp().globalData.disciples
				let discipleInfo = disciples[disciples.findIndex(item => item.id==_self.discipleId)]
				if(discipleInfo) {
					let tpObj = _self.util.parseProperty(discipleInfo.tp)
					
					let equips = getApp().globalData.equips
					let weInfo = equips[equips.findIndex(item => item.eid==_self.equipId)]
					let weBpObj = _self.util.parseProperty(weInfo.bp)  // 穿着装备属性
					let weEpObj = _self.util.parseProperty(weInfo.ep)  // 穿着装备属性
					
					
					let leObj = {}  // 新总属性
					for(let i=1;i<11;i++) {
						let iValue = tpObj[i]-weBpObj[i]
						if(weEpObj && weEpObj[i]) {
							iValue -= weEpObj[i]
						}
						leObj[i] = iValue
					}
					
					_self.tpObj = tpObj
					_self.leObj = leObj
					if(isOpen) {
						_self.toOpenDialogWo()
					} 
				}
			},
			tapWear(isOpen) {
				let disciples = getApp().globalData.disciples
				let discipleInfo = disciples[disciples.findIndex(item => item.id==_self.discipleId)]
				if(discipleInfo) {
					let tpObj = _self.util.parseProperty(discipleInfo.tp)
					
					let equips = getApp().globalData.equips
					let newEquip = equips[equips.findIndex(item => item.eid==_self.equipId)]
					let newBpObj = _self.util.parseProperty(newEquip.bp)  // 新装备属性
					let newEpObj = _self.util.parseProperty(newEquip.ep)  // 新装备属性
					
					let bpObj  // 原装备属性
					let epObj  // 原装备属性
					let wearEquipId = _self.wearEquipId
					if(wearEquipId) {
						let equipInfo = equips[equips.findIndex(item => item.eid==wearEquipId)]
						if(equipInfo) {
							bpObj = _self.util.parseProperty(equipInfo.bp)
							epObj = _self.util.parseProperty(equipInfo.ep)
						}
					}
					
					let neObj  //没穿装备的属性
					if(bpObj) {
						neObj = {}
						for(let i=1;i<11;i++) {
							let iValue = tpObj[i]-bpObj[i]
							if(epObj && epObj[i]) {
								iValue -= epObj[i]
							}
							neObj[i] = iValue
						}
					}else {
						neObj = JSON.parse(JSON.stringify(tpObj))
					}
					
					let leObj = {}  // 新总属性
					for(let i=1;i<11;i++) {
						let iValue = neObj[i]+newBpObj[i]
						if(newEpObj && newEpObj[i]) {
							iValue += newEpObj[i]
						}
						leObj[i] = iValue
					}
					
					_self.tpObj = tpObj
					_self.leObj = leObj
					if(isOpen) {
						_self.toOpenDialogWo()
					} 
				}
			},
			tapBack() {
				uni.navigateBack({
					delta:1
				})
			},
			fillCommonData(detail) {
				let quality = detail.equip.quality
				let equipSt = detail.st
				_self.level = detail.sl
				_self.equipName = detail.equip.name
				_self.wear = detail.w
				_self.equipId = detail.eid
				_self.quality = quality
				_self.maxLevel = _self.jsonParse.getEquipMaxLevel(detail.etid)
				_self.qualityName = _self.jsonParse.getEquipQualityName(quality)
				_self.jxInfo1 = _self.jsonParse.getEquipStarInfo(quality,equipSt)
				_self.jxInfo2 = _self.jsonParse.getEquipStarInfo(quality,equipSt+1)
				
				let dressOccupation = detail.equip.dressOccupation
				let typeText = _self.jsonParse.getEquipTypeName(detail.equip.type)
				if(dressOccupation!='无') {
					typeText = dressOccupation+typeText
				}
				_self.typeText = typeText
				
				_self.limitText = detail.equip.require.replace('=','>=')
				_self.successRate = detail.equip.successRate
				_self.strengthConsume = detail.equip.strengthConsume
				_self.equipSt = equipSt
				
				_self.initPropertyArray = _self.util.parseEquipProperty(detail.ip,'',2)
				_self.basicPropertyArray = _self.util.parseEquipProperty(detail.bp,'')
				_self.extraPropertyArray = _self.util.parseEquipProperty(detail.ep,'')
				_self.initialAttr = _self.util.parseEquipProperty(detail.ip,'')[0]
				_self.equipSe = _self.util.exchangeFR(detail.se)
				_self.equipScore = _self.util.getEquipScore(detail.bp,detail.ep)
				
				_self.jxInitPropertyArray = _self.util.parseEquipProperty(detail.ip,'',1)
				_self.jxExtraPropertyArray = _self.util.parseEquipProperty(detail.ep,'',1)
				
				try {
					let basicStr = _self.util.parseEquipProperty(detail.bp,'')[0]
					if(basicStr) {
						_self.iName = basicStr.substr(0,2)
						
						let iValue = parseInt(basicStr.substr(2,basicStr.length-2))
						let iInfo = _self.jsonParse.getEquipInfo(detail.etid,_self.level)
						if(iInfo) {
							let value = iValue-iInfo.boostValue
							let nInfo = _self.jsonParse.getEquipInfo(detail.etid,_self.level+1)
							if(nInfo) {
								_self.iValue2 = value+nInfo.boostValue
							}
						}
						_self.iValue1 = iValue
					}
				}catch(e) {}
				
				
			},
			ajaxStar() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'6_5',
					params:{
						equipId:_self.equipId,
						guarantee:_self.floorType
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.toCloseDialogStar()
						let disciple = resData.disciple
						_self.util.updateDiscipleData(disciple)
						
						let equip = resData.equip
						let rs = resData.rs
						if(rs==0) {
							let resultText = '提品失败<br>装备爆炸'
							_self.breakText = resultText
							_self.$refs.refBreakText.open()
							_self.util.deleteEquip(equip.eid)
						}else if(rs==1) {
							_self.showToast('提品成功')
							_self.util.updateEquip(equip)
							let equipInfo = _self.jsonParse.getEquipInfo(equip.etid,equip.sl)
							if(equipInfo) {
								equip.equip = equipInfo
								_self.fillCommonData(equip)
							}
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxBreak() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'6_4',
					params:{
						equipId:_self.equipId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let breakText = '装备已被分解'
						let gain = resData.gain
						if(gain) {
							breakText = '分解获得：'+_self.jsonParse.getMaterialArray(gain).toString()
						}
						_self.breakText = breakText
						_self.$refs.refBreakText.open()
						_self.util.deleteEquip(resData.removeEquipId)
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxFight() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'5_0',
					params:{
						"masterFormation":"1=1#4=2#7=3#9=5",   //玩家阵容
						"monsterFormation":"1=10000#2=10001#3=10002#4=10000#5=10001#6=10002#7=10000#9=10002"
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					
				}
				_self.$req.handleRequest(option)
			},
			ajaxStrength() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'6_3',
					params:{
						equipId:_self.equipId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.toCloseDialog()
						switch(resData.rs) {
							case 0:
								_self.showToast('蕴器失败')
								break;
								
							case 1:
								_self.showToast('蕴器成功')
								break;
						}
						// _self.$refs.refText.open()
						/**
						 * info蕴器成功失败都更新数据
						 */
						let info = resData.equip
						if(info) {
							_self.util.updateEquip(info)
							let equipInfo = _self.jsonParse.getEquipInfo(info.etid,info.sl)
							if(equipInfo) {
								info.equip = equipInfo
								_self.fillCommonData(info)
							}
						}
						_self.util.updateDiscipleData(resData.disciple)
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxTakeOff() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'6_2',
					params:{
						discipleId:_self.discipleId,
						equipId:_self.equipId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.wear = false
						_self.util.updateDiscipleData(resData.discipleView)
						_self.util.updateEquipWearStatus(resData.takeoffEquipId,false)
						
						_self.wearEquipId = 0
						
						_self.showToast('已脱下')
						_self.toCloseDialogWo()
						// _self.tapWear()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxWear() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'6_1',
					params:{
						discipleId:_self.discipleId,
						equipId:_self.equipId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.wear = true
						_self.util.updateDiscipleData(resData.discipleView)
						
						let takeoffEquipId = resData.takeoffEquipId
						if(takeoffEquipId) {
							_self.util.updateEquipWearStatus(takeoffEquipId,false)  // 取下的装备
						}
						_self.util.updateEquipWearStatus(resData.wearEquipId,true)  // 穿戴的装备
						
						_self.wearEquipId = resData.wearEquipId
						
						_self.showToast('已穿戴')
						_self.toCloseDialogWo()
						// _self.tapTakeOff()
					}
				}
				_self.$req.handleRequest(option)
			},
			tapJx() {
				_self.floorType = _self.floorType0
				let floorInfo = _self.jsonParse.getEquipFloorInfo(_self.quality,_self.equipSt)
				if(floorInfo) {
					_self.floorInfo = floorInfo
				}
				_self.$refs.refJx.open()
			},
			tapStrength() {
				_self.$refs.refStrength.open()
			},
			tapBreak() {
				this.$refs.refBreak.open()
			},
			toOpenDialog() {
				this.$refs.refDialog.open()
			},
			toCloseDialog() {
				this.$refs.refDialog.close()
			},
			toCloseDialogStar() {
				_self.$refs.refJx.close()
			},
			toCloseDialogStarText() {
				_self.$refs.refStarText.close()
			},
			toOpenDialogStarText() {
				_self.$refs.refStarText.open()
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.detailLayout {
		width: 100%;
		height: 418rpx;
		margin-top: 40rpx;
		display: flex;
		justify-content: center;
		line-height: 44rpx;
		font-size: 28rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-equip-detail-content-bg.png) center center no-repeat;background-size:680rpx 100%;
	}
	
	.bt1 {
		width: 460rpx;
		height: 88rpx;
		margin-top: 40rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		margin-left: 145rpx;
		margin-top: 50rpx;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt2 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		display: flex;
		flex: 1;
		justify-content: center;
		align-items: center;
		background:url(../../static/disciple-equip-detail-bt-bg2.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt3 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg2.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt4 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		display: flex;
		flex: 1;
		justify-content: center;
		align-items: center;
		color: #676767;
		background:url(../../static/building-disciple-recruit-bt-abandon.png) center center no-repeat;background-size:100% 100%;
	}
	
	.precipitatorDialog {
		width: 568rpx;
		height: 876rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogStrength {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btStrength {
		position: absolute;
		bottom: 50rpx;
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
