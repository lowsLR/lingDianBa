<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">命魂</block>
			<block slot="right">
				<view @tap="tapWh" class="iconRight">?</view>
			</block>
		</cu-custom>
		
		<scroll-view scroll-y="true" class="sv">
			<view style="width: 710rpx;margin-left: 20rpx;font-size: 30rpx;color: #FFFFFF;">
				<view v-for="(obj,key,index) in dataObj" :key="index" @tap="tapItem(obj)" style="display: flex;flex-direction: row;margin-top: 26rpx;">
					<image style="width: 56rpx;height: 56rpx;margin-top: 60rpx;" :src="'/static/life-soul-'+obj.type+'.png'"></image>
					<view style="display: flex;flex-direction: column;width: 620rpx;margin-left: 20rpx;justify-content: center;">
						<view style="display: flex;flex-direction: row;line-height: 70rpx;">
							<view style="display: flex;flex: 1;">{{obj.name}}</view>
							<view>激活本源数量：{{obj.count}}</view>
						</view>
						<progress-bar :pbWidth="620" :pbColor="typeObj[obj.type].color" :progress="obj.count" :maxProgress="maxCount"></progress-bar>
					</view>
				</view>
				
			</view>
		</scroll-view>
		
		<view style="margin-left: 30rpx;font-size: 30rpx;color: #FFFFFF;margin-top: 40rpx;">
			<view>活跃本源情况：{{hasCount}}/{{maxCount}}</view>
			<view style="color: #999999;margin-top: 20rpx;">注：点击命魂进度条，可进行命魂激活</view>
		</view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDialog.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogLayout" style="display: flex;align-items: center;color: #FFFFFF;flex-direction: column;">
				<view style="line-height: 130rpx;text-align: center;font-size: 36rpx;padding-top: 20rpx;color: #FFFFFF;">{{dialogObj.title}}</view>
				<view style="width: 488rpx;display: flex;flex-direction: column;font-size: 28rpx;padding-left: 16rpx;line-height: 60rpx;">
					<view style="display: flex;flex-direction: row;align-items: center;line-height: 42rpx;margin:10rpx 0;">
						<view style="display: flex;flex: 1;">{{dialogObj.obj1?dialogObj.obj1.value:''}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{dialogObj.obj2?dialogObj.obj2.value:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">本源数量：{{dialogObj.obj1?dialogObj.obj1.count:0}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{dialogObj.obj2?'本源数量：'+dialogObj.obj2.count:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;line-height: 42rpx;margin:10rpx 0;">
						<view style="display: flex;flex: 1;flex-direction: column;">
							命魂境界：<view style="display: flex;justify-content: flex-end;padding-right: 10rpx;">{{dialogObj.obj1?dialogObj.obj1.name:''}}</view>
						</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;flex-direction: column;">
							<block v-if="dialogObj.obj2">命魂境界：<view style="display: flex;justify-content: flex-end;padding-right: 10rpx;">{{dialogObj.obj2.name}}</view></block>
							<text v-else>notOpenText</text>
						</view>
					</view>
					
					<view v-if="dialogObj.obj2" class="mar-t-30" style="display: flex;flex-direction: row;">
						升级消耗：<view style="display: flex;flex: 1;">{{dialogObj.obj2.consume}}</view>
					</view>
				</view>
				
				<view @tap="tapActive" v-if="dialogObj.obj2" class="btn">激活</view>
				<view v-else class="btn" style="color: #666666;">{{notOpenText}}</view>
			</view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	import progressBar from '@/components/progress-bar/progress-bar.vue'
	var _self
	
	export default {
		components:{
			progressBar,
			popupWords
		},
		data() {
			return {
				discipleId:-1,
				maxCount:0,
				dataObj:{},
				typeObj:{
					1:{
						name:'血离命魂',
						color:'#FC0D1B'
					},
					2:{
						name:'灵飞命魂',
						color:'#6BCDFD'
					},
					3:{
						name:'魂契命魂',
						color:'#676CFB'
					},
					4:{
						name:'体谛命魂',
						color:'#FD6721'
					},
					5:{
						name:'锐殁命魂',
						color:'#FFFE9F'
					},
					6:{
						name:'盾阁命魂',
						color:'#99981D'
					},
					7:{
						name:'定巍命魂',
						color:'#CDFD34'
					},
					8:{
						name:'游天命魂',
						color:'#650965'
					},
					9:{
						name:'狂伤命魂',
						color:'#98340E'
					},
					10:{
						name:'山耆命魂',
						color:'#9ACA27'
					}
				},
				notOpenText:'暂未开放',
				dialogObj:{},
				hasCount:0,
				tapType:-1,
				wordsNew:''
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.discipleId = detail.discipleId
			
			_self.fillData()
		},
		methods: {
			tapWh() {
				let wordObj = _self.jsonParse.getIntroWords('life-soul')
				if(wordObj) {
					_self.wordsNew = wordObj.content
					_self.$refs.refWords.open()
				}
			},
			tapActive() {
				if(_self.hasCount<_self.maxCount) {
					_self.ajaxActive()
				}else {
					_self.showToast('点亮的本源数量达到上限')
				}
			},
			ajaxActive() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_40',
					params:{
						discipleId:_self.discipleId,
						soulKey:_self.dialogObj.type
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let discipleView = resData.discipleView
						_self.util.updateDiscipleData(discipleView)
						_self.fillData()
						_self.fillDialog()
					}
				}
				_self.$req.handleRequest(option)
			},
			fillData() {
				let disciples = getApp().globalData.disciples
				let disciple = disciples[disciples.findIndex(disciple => disciple.id==_self.discipleId)]
				if(disciple) {
					let maxCount = disciple.lsl
					_self.maxCount = maxCount
					
					let lsObj = {}
					let ls = disciple.ls
					let hasCount = 0
					if(ls) {
						let lsArray = ls.split('#')
						lsArray.forEach(item => {
							let itemArray = item.split('=')
							let i1 = parseInt(itemArray[1])
							hasCount += i1
							lsObj[itemArray[0]] = i1
						})
					}
					_self.hasCount = hasCount
					
					let dataObj = {}
					for(let i=1;i<11;i++) {
						let lsCount = lsObj[i]
						if(!lsCount) {
							lsCount = 0
						}
						
						let name = ''
						let inquireCount = lsCount
						if(inquireCount==0) {
							inquireCount = 1
						}
						let lifeSoulInfo = _self.jsonParse.getLifeSoulByCount(inquireCount)
						if(lifeSoulInfo) {
							name = lifeSoulInfo.name
						}
						
						dataObj[i] = {
							count:lsCount,
							name:name,
							type:i
						}
					}
					_self.dataObj = dataObj
				}
			},
			tapItem(obj) {
				_self.tapType = obj.type
				_self.fillDialog()
				_self.toOpenDialog()
			},
			fillDialog() {
				let obj = _self.dataObj[_self.tapType]
				let objCount = obj.count
				let objType = obj.type
				let objName = obj.name
				
				let obj1
				if(objCount==0) {
					let lsInfo = _self.jsonParse.getLifeSoulByCount(objCount+1)
					if(lsInfo) {
						let typeName = lsInfo['v'+objType].replace(/ /g,'').split('#')[0].split('+')[0]
						obj1 = {
							value:typeName+'：+0',
							count:objCount,
							name:objName
						}
					}
				}else {
					let lsInfo = _self.jsonParse.getLifeSoulByCount(objCount)
					if(lsInfo) {
						let textArray1 = lsInfo['v'+objType].replace(/ /g,'').split('#')
						let textArray2 = textArray1[0].split('+')
						
						let value = parseFloat(textArray2[1])
						if(value<1) {
							value = (value*100).toFixed(1)+'%'
						}
						obj1 = {
							value:textArray2[0]+'：+'+value,
							count:objCount,
							name:objName
						}
					}
				}
				
				let obj2
				let lsInfo = _self.jsonParse.getLifeSoulByCount(objCount+1)
				if(lsInfo) {
					let textArray1 = lsInfo['v'+objType].replace(/ /g,'').split('#')
					let textArray2 = textArray1[0].split('+')
					
					let value = parseFloat(textArray2[1])
					if(value<1) {
						value = (value*100).toFixed(1)+'%'
					}
					
					obj2 = {
						value:textArray2[0]+'：+'+value,
						count:lsInfo.count,
						name:lsInfo.name,
						consume:textArray1[1]
					}
				}
				
				let dialogObj = {
					title:_self.typeObj[objType].name,
					obj1:obj1,
					obj2:obj2,
					type:objType
				}
				_self.dialogObj = dialogObj
			},
			toOpenDialog() {
				_self.$refs.refDialog.open()
			},
			toCloseDialog() {
				_self.$refs.refDialog.close()
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 280rpx);
	}
	
	.dialogLayout {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btn {
		position: absolute;
		bottom: 50rpx;
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
