<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">灵园</block>
			<block slot="right">
				<view @tap="tapWh" class="iconRight">?</view>
			</block>
		</cu-custom>
		
		<scroll-view class="sv" scroll-y="true">
			<view v-if="landArray.length>0" style="display: flex; flex-direction: column; align-items: center;color: #A31B27;">
				<view class="itemLayout" v-for="(info,index) in landArray" :key="index">
					<view style="display: flex;width: 80rpx;writing-mode:vertical-rl;font-size: 34rpx;justify-content: center;align-items: center;font-weight: 500;margin-left: 20rpx;">{{info.name}}</view>
					<view style="display: flex;width: 334rpx;font-size: 28rpx;padding-left: 10rpx;align-items: center;">
						<view class="isEllipsis" style="line-height: 60rpx;">产出：{{info.outputRate}}{{nameObj[info.landType]}}/{{info.outputIntervalMinutes}}分钟</view>
					</view>
					<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;width: 220rpx;">
						<view @tap="tapPromote(index)" class="btPromote">晋升</view>
						<view style="display: flex;flex-direction: row;color: #666666;font-size: 32rpx;align-items: center;margin-top: 20rpx;">
							<image @tap="tapDivideServant(info,index)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-minus.png"></image>
							<view style="width: 90rpx;text-align: center;font-size: 26rpx;">{{info.servantCount}}/{{info.servantLimit}}</view>
							<image @tap="tapDivideServant(info,index,true)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-add.png"></image>
						</view>
					</view>
				</view>
			</view>
			<view v-else-if="loaded" class="noData">暂无数据</view>
		</scroll-view>
		
		<view style="text-align: center;font-size: 32rpx;color: #FFFFFF;line-height: 90rpx;">闲置仆役：{{freeServantCount}}</view>
		<view style="display: flex;flex-direction: row;justify-content: center;">
			<view @tap="ajaxRecruit" class="btFunc">招收仆役</view>
			<!-- <view @tap="making" class="btFunc mar-l-86">仆役遴选</view> -->
		</view>
		<!-- <view v-if="recruitConsume" style="width: 418rpx;line-height: 70rpx;text-align: center;color: #EEEEEE;font-size: 28rpx;">( 消耗{{recruitConsume}}灵石 )</view> -->
		<view v-if="recruitConsume" style="line-height: 70rpx;text-align: center;color: #EEEEEE;font-size: 28rpx;">( 消耗{{recruitConsume}}灵石 )</view>
		
		<uni-popup ref="refDetail" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDetail.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDetail" style="display: flex;justify-content: center;color: #FFFFFF;">
				<view style="width: 488rpx;margin-top: 40rpx;display: flex;flex-direction: column;font-size: 30rpx;padding-left: 16rpx;line-height: 60rpx;">
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">{{infoObj.name}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?nextObj.name:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">等级：{{infoObj.level}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'等级：'+nextObj.level:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">品质：{{jsonParse.getMaterialQualityName(infoObj.quality)}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'品质：'+jsonParse.getMaterialQualityName(nextObj.quality):notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">产量：{{infoObj.income}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'产量：'+nextObj.income:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">仆役上限：{{infoObj.servantLimit}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'仆役上限：'+nextObj.servantLimit:notOpenText}}</view>
					</view>
					
					<block v-if="nextObj">
						<view style="margin-top: 30rpx;">升级条件：{{infoObj.promoteCondiction}}</view>
						<view>升级概率：{{infoObj.promoteRate?util.keepTwoDecimal(infoObj.promoteRate*100):0}}%</view>
						<view style="display: flex;flex-direction: row;">
							升级消耗：<view style="display: flex;flex: 1;">{{infoObj.promoteConsume?infoObj.promoteConsume.replace(/#/g,', '):''}}</view>
						</view>
					</block>
					
				</view>
				
				<view v-if="nextObj" @tap="ajaxPromote" class="dialogBt">晋升</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refGain" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refGain.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogGain" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">灵园收获</view>
				<view class="isCenter" v-html="gainHtml" style="width: 480rpx;height: 500rpx;margin-bottom: 30rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;overflow: scroll;"></view>
				<view @tap="$refs.refGain.close()" class="bt1">确定</view>
			</view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
		<popup-confirm ref="refText" :showCancel="false" :content="dialogText"></popup-confirm>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	
	export default {
		components:{
			popupConfirm,
			popupWords
		},
		data() {
			return {
				freeServantCount:0,
				landArray:[],
				dialogText:'',
				loaded:false,
				nameObj:{
					1:'灵石',
					2:'木材',
					3:'矿石',
					4:'灵草',
					5:'灵粮'
				},
				notOpenText:'暂未开放',
				infoObj:{},
				nextObj:null,
				tapIndex:-1,
				recruitConsume:0,
				totalServantCount:0,
				gainHtml:'',
				wordsNew:'',
				keyWordsNew:''
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.toGetWordsNew()
				_self.ajaxList()
				_self.ajaxGain()
			})
		},
		methods: {
			tapWh() {
				let wordObj = _self.jsonParse.getIntroWords('land')
				if(wordObj) {
					_self.wordsNew = wordObj.content
					_self.$refs.refWords.open()
				}
			},
			toWordsNew(count) {
				let wordObj = _self.jsonParse.getNewWords('land')
				if(wordObj) {
					if(wordObj.count>count) {
						_self.wordsNew = wordObj.content
						_self.$refs.refWords.open()
						
						uni.setStorage({
						    key: _self.keyWordsNew,
						    data: count+1
						})
					}
				}
			},
			toGetWordsNew() {
				let keyWordsNew = 'wnl-'+getApp().globalData.sectView.sectId
				_self.keyWordsNew = keyWordsNew
				
				uni.getStorage({
				    key: keyWordsNew,
					success:function(res){
						_self.toWordsNew(res.data)
					},
				    fail:function(res){
						_self.toWordsNew(0)
					}
				})
			},
			handleFormulaConsume() {
				let totalServantCount = _self.totalServantCount
				_self.recruitConsume = parseInt((100+totalServantCount*totalServantCount/(totalServantCount/4+1)*25)/100)*100
			},
			fillDialog() {
				let info = _self.landArray[_self.tapIndex]
				if(info) {
					let landInfo = _self.jsonParse.getLandInfo(info.landType,info.level)
					if(landInfo) {
						_self.infoObj = {
							...landInfo,
							income:_self.handleFormulaIncome(landInfo.formulaIncome,info.servantCount)
						}
					}
					
					let nextObj = _self.jsonParse.getLandInfo(info.landType,info.level+1)
					if(nextObj) {
						nextObj.income = _self.handleFormulaIncome(nextObj.formulaIncome,info.servantCount)
					}
					_self.nextObj = nextObj
				}
			},
			handleFormulaIncome(text,servantCount) {
				try {
					return parseInt(parseFloat(text.split('*')[1])*servantCount)
				}catch(e) {}
			},
			tapPromote(index) {
				_self.tapIndex = index
				_self.fillDialog()
				_self.$refs.refDetail.open()
			},
			updateData(info) {
				let landInfo = _self.jsonParse.getLandInfo(info.landType,info.level)
				if(landInfo) {
					info.name = landInfo.name
				}
				info.outputIntervalMinutes = parseInt(info.outputIntervalSeconds/60)
			},
			doDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			tapDivideServant(info,index,isAdd) {
				let count = -1
				if(isAdd) {
					count = 1
				}
				let landType = info.landType
				if(count==-1 && info.servantCount==0) {
					_self.showToast('该灵地没有仆役')
				}else {
					_self.ajaxDivide(landType,count,index)
				}
			},
			handleResult(resData,index) {
				let land = resData.land
				_self.updateData(land)
				_self.landArray.splice(index,1,land)
			},
			ajaxPromote() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'2_4',
					params:{
						landType:_self.landArray[_self.tapIndex].landType
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						switch(resData.rs) {
							case 0:
								_self.showToast('灵地晋升失败')
								break;
								
							case 1:
								_self.showToast('灵地晋升成功')
								_self.handleResult(resData,_self.tapIndex)
								_self.fillDialog()
								break;
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxGain() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'2_2'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let gain = resData.gain
						if(gain) {
							let gainHtml = ''
							let materialObj = _self.jsonParse.parseHomeMaterial(gain)
							Object.keys(materialObj).map(key => {
								let obj = materialObj[key]
								gainHtml += obj.name+'*'+obj.count+'<br>'
							})
							if(gainHtml) {
								_self.gainHtml = gainHtml
								_self.$refs.refGain.open()
							}
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxRecruit(landType,count,index) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'2_5'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.freeServantCount = resData.freeServantCount
						_self.totalServantCount++
						_self.handleFormulaConsume()
						_self.showToast('招收成功')
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxDivide(landType,count,index) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'2_3',
					params:{
						landType:landType,
						count:count
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.freeServantCount = resData.freeServantCount
						_self.handleResult(resData,index)
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxList() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'2_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.loaded = true
					if(resData) {
						let lands = resData.lands
						_self.totalServantCount = lands.totalServantCount
						_self.freeServantCount = lands.freeServantCount
						_self.handleFormulaConsume()
						
						let landArray = lands.lands
						landArray.forEach((info)=>{
							_self.updateData(info)
						})
						_self.landArray = landArray
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 360rpx);
	}
	
	.itemLayout {
		display: flex;
		flex-direction: row;
		margin-top: 20rpx;
		
		width: 680rpx;
		height: 180rpx;
		background:url(../../static/land-item-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btPromote {
		width: 100rpx;
		height: 40rpx;
		line-height: 40rpx;
		font-size: 24rpx;
		text-align: center;
		background:url(../../static/land-item-bt-bg.png) center center no-repeat;background-size:100% 100%;
		color: #F1DABA;
	}
	
	.btFunc {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogDetail {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogBt {
		position: absolute;
		bottom: 50rpx;
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogGain {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	
</style>
