<template>
	<view class="container">
		<view class="loadText">{{loadText}}</view>
		<view class="progressLayout">
			<view :style="[{'width':bgWidth+'rpx'}]"></view>
			<image src="/static/load_cloud.png"></image>
		</view>
	</view>
	
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				progress:0,
				bgWidth:40,
				downloadTask:null,
				lInterval:null,
				loaded1:false,
				loaded2:false,
				loaded3:false,
				ajaxCount1:0,
				ajaxCount2:0,
				ajaxCount3:0,
				maxCount:4,
				delay:500,
				loadText:'',
				texts:['门人修真潜质越高，突破时增加属性越多','门人突破时，增加属性会有波动','可以不断重修门人，刷出最强属性','逐离门人时，有几率获得禁忌之物帝源浆','锻造的装备属性随机，有机会获得逆天属性','锻造成就越高，可打造出超越极限属性的装备','门派等级越高，每天可领取的供奉越多','主线地图中产出大量原材料','灵园的资源产出非常可观，记得要合理分配','宗门宝库中可以直接出售物品','分解装备会获得原材料以及大部分蕴器消耗','装备蕴器满级可以提品，装备有可能化为乌有','装备提品成功，初始属性提升，装备更有价值','每天有免费招收弟子的机会，不要忘记了']
			}
		},
		onLoad(option) {
			_self = this
			_self.fillLoadText()
			_self.$nextTick(function(){
				_self.ajaxData()
				_self.ajaxDiscipleList()
				_self.ajaxEquipList()
			})
			
			_self.toInterval()
		},
		onUnload() {
			_self.toClearInterval()
		},
		onHide() {
			_self.handleFail()
		},
		methods: {
			fillLoadText() {
				_self.loadText = _self.texts[_self.util.getRandom(_self.texts.length,0)]
			},
			toHomePage() {
				_self.redirectTo('/pages/home/home')
			},
			handleFail() {
				_self.toClearInterval()
				_self.util.clearLoginData()
				setTimeout(function() {
					uni.reLaunch({
						url:'/pages/login/login'
					})
				},200)
			},
			toInterval() {
				if(!_self.lInterval) {
					_self.lInterval = setInterval(function() {
						_self.bgWidth += 4
						if(_self.loaded1 && _self.loaded2 && _self.loaded3) {
							if(_self.bgWidth>=560) {
								_self.toClearInterval()
								_self.toHomePage()
							}
						}else {
							if(_self.bgWidth>500) {
								_self.fillLoadText()
								_self.toClearInterval()
							}
						}
					},20)
				}
			},
			toClearInterval() {
				if(_self.lInterval) {
					clearInterval(_self.lInterval)
					_self.lInterval = null
				}
			},
			isSuccess() {
				if(_self.loaded1 && _self.loaded2 && _self.loaded3) {
					_self.toInterval()
				}
			},
			isFail() {
				if(_self.ajaxCount1==_self.maxCount && _self.ajaxCount2==_self.maxCount && _self.ajaxCount3==_self.maxCount) {
					_self.showToast('加载失败')
					setTimeout(function() {
						_self.handleFail()
					},500)
				}
			},
			getAgain1() {
				_self.ajaxCount1++
				if(_self.ajaxCount1<_self.maxCount) {
					setTimeout(function() {
						_self.ajaxData()
					},_self.delay)
				}else {
					_self.isFail()
				}
			},
			getAgain2() {
				_self.ajaxCount2++
				if(_self.ajaxCount2<_self.maxCount) {
					setTimeout(function() {
						_self.ajaxDiscipleList()
					},_self.delay)
				}else {
					_self.isFail()
				}
			},
			getAgain3() {
				_self.ajaxCount3++
				if(_self.ajaxCount3<_self.maxCount) {
					setTimeout(function() {
						_self.ajaxEquipList()
					},_self.delay)
				}else {
					_self.isFail()
				}
			},
			ajaxData() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'1_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let sectView = resData.SectView
						if(sectView) {
							getApp().globalData.sectView = sectView
						}
						
						let materialObj = _self.util.getMaterialObj(resData.commonMaterials.materials)
						if(materialObj) {
							getApp().globalData.materialObj = materialObj
						}
						
						_self.loaded1 = true
						_self.isSuccess()
					}
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {
					_self.getAgain1()
				}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {
					_self.getAgain1()
				}
				_self.$req.handleRequest(option)
			},
			ajaxDiscipleList() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'1_3'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let disciples = resData.disciplesBackpack.disciples
						if(disciples) {
							getApp().globalData.disciples = disciples
						}
						
						_self.loaded2 = true
						_self.isSuccess()
					}
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {
					_self.getAgain2()
				}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {
					_self.getAgain2()
				}
				_self.$req.handleRequest(option)
			},
			ajaxEquipList() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'1_2'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let equips = resData.equipsBackpack.equips
						if(equips) {
							getApp().globalData.equips = equips
						}
						
						_self.loaded3 = true
						_self.isSuccess()
					}
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {
					_self.getAgain3()
				}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {
					_self.getAgain3()
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		display: flex;
		justify-content: center;
		background:url(../../static/load_bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.progressLayout {
		position: absolute;
		bottom: 140rpx;
		width: 600rpx;
		height: 32rpx;
		border-radius: 16rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
		-moz-box-shadow:0px 0px 10px #F9DB87;
		-webkit-box-shadow:0px 0px 10px #F9DB87;
		box-shadow:0px 0px 10px #F9DB87;
	}
	
	.progressLayout view {
		height: 100%;
		background-color: #F9DB87;
		border-top-left-radius: 20rpx;
		border-bottom-left-radius: 20rpx;
	}
	
	.progressLayout image {
		width: 127rpx;
		height: 52rpx;
		margin-left: -87rpx;
	}
	
	.loadText {
		position: absolute;
		color: #ecf0f1;
		font-size: 28rpx;
		bottom: 220rpx;
	}
	
</style>
