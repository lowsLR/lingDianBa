<template>
	<view class="container">
		<cuCustomScroll :isBack="true">
			<block slot="content">
				<bwScrollNav style="margin-left: 110rpx;" :tab-index="tabCurrentIndex" @tabChange="clickTab" :tab-bars="tabBars">
				</bwScrollNav>
			</block>
		</cuCustomScroll>
		
		<swiper id="swiper" class="swiper-box" :duration="300" :current="tabCurrentIndex" @change="swiperTab">
			<swiper-item>
				<scroll-view scroll-y="true" class="sv3">
					<view style="display: flex;flex-direction: column;align-items: center;">
						<view class="xdcItem" v-for="(item,index) in xdcList" :key="index">
							<image style="width: 100rpx;height: 100rpx;border-radius: 50%;margin: 0 26rpx;box-shadow: 0 0 10rpx #FFFFFF;" :src="util.getSectIconPath(item.sectIconId)"></image>
							<view style="display: flex;flex: 1;flex-direction: column;">
								<view style="font-size: 30rpx;">{{item.sectName}}</view>
								<view style="font-size: 26rpx;margin-top: 10rpx;color: #B3B3B3;">阵容评价：{{item.grade}}</view>
							</view>
							<view @tap="ajaxFight(item.rank)" class="btn">比斗</view>
						</view>
					</view>
				</scroll-view>
				<view @tap="ajaxQueue" class="rewardBt">阵容设置</view>
				<view style="display: flex;flex-direction: row;color: #FFFFFF;align-items: center;padding: 0 20rpx;font-size: 34rpx;height: 100rpx;">
					<view>今日剩余：10/10</view>
					<image style="width: 40rpx;height: 40rpx;vertical-align: top;margin-left: 16rpx;" src="/static/fight-field-add.png"></image>
					<view style="display: flex;flex: 1;justify-content: flex-end;">当前排名：{{xdRank?xdRank:'无'}}</view>
				</view>
			</swiper-item>
			<swiper-item>
				<view style="display: flex;justify-content: center;align-items: center;height: 140rpx;">
					<uni-segmented-control style="width: 650rpx;" :current="subTabIndex" :values="subItems" @clickItem="onClickItem" style-type="button" active-color="#CBBDAF"></uni-segmented-control>
				</view>
				
				<block v-if="[0,1].indexOf(subTabIndex)!=-1 && tabDatas[subTabIndex] && tabDatas[subTabIndex].length>0">
					<view class="listLayout height1" style="display: flex;flex-direction: column;align-items: center;">
						<view style="display: flex;flex-direction: row;width: 100%;line-height: 70rpx;color: #C7C4BE;font-size: 28rpx;border-bottom: solid 1px #666666;">
							<view style="display: flex;flex: 1;justify-content: center;flex: 1;">徽章</view>
							<view style="display: flex;flex: 1;justify-content: center;flex: 1.2;">门派</view>
							<view style="display: flex;flex: 1;justify-content: center;flex: 1.2;">掌门</view>
							<view style="display: flex;flex: 1;justify-content: center;flex: 1;">类别</view>
							<view style="display: flex;flex: 1;justify-content: center;flex: 1;">排行</view>
						</view>
						<scroll-view scroll-y="true" :scroll-top="scrollTop" class="sv sv1" style="display: flex;flex-direction: column;width: 670rpx;line-height: 100rpx;color: #DFDFDF;font-size: 30rpx;">
							<view class="item" v-for="(info,index) in tabDatas[subTabIndex]" :key="index">
								<view style="display: flex;flex: 1;justify-content: center;align-items: center;flex: 1;">
									<image style="width: 80rpx;height: 80rpx;border-radius: 50%;box-shadow: 0 0 10rpx #FFFFFF;" :src="util.getSectIconPath(info.sectIconId)"></image>
								</view>
								<view style="display: flex;flex: 1;justify-content: center;flex: 1.2;">{{info.sectName}}</view>
								<view style="display: flex;flex: 1;justify-content: center;flex: 1.2">{{info.masterName}}</view>
								<view style="display: flex;flex: 1;justify-content: center;flex: 1;">{{util.getSectTypeName(info.sectType)}}</view>
								<view style="display: flex;flex: 1;justify-content: center;flex: 1;">{{info.rank}}</view>
							</view>
						</scroll-view>
					</view>
					<view class="myRankText">
						当前排名：
						<text v-if="subTabIndex==0">{{xdRank?xdRank:(myRankObj[subTabIndex]?myRankObj[subTabIndex]:'无')}}</text>
						<text v-else>{{myRankObj[subTabIndex]?myRankObj[subTabIndex]:'无'}}</text>
					</view>
				</block>
				
				<block v-if="subTabIndex==2 && tabDatas[subTabIndex] && tabDatas[subTabIndex].length>0">
					<view class="listLayout height2" style="display: flex;flex-direction: column;align-items: center;">
						<view style="display: flex;flex-direction: row;width: 100%;line-height: 70rpx;color: #C7C4BE;font-size: 28rpx;border-bottom: solid 1px #666666;">
							<view style="display: flex;flex: 1;justify-content: center;flex: 1.2;">排名</view>
							<view style="display: flex;flex: 1;justify-content: center;flex: 3;">奖励</view>
						</view>
						<scroll-view scroll-y="true" class="sv sv2" style="display: flex;flex-direction: column;width: 670rpx;line-height: 100rpx;color: #DFDFDF;font-size: 30rpx;">
							<view class="item" v-for="(info,index) in tabDatas[subTabIndex]" :key="index">
								<view style="display: flex;flex: 1;justify-content: center;flex: 1.2;">{{info.range}}</view>
								<view style="display: flex;flex: 1;justify-content: center;flex: 3;">{{info.reward.replace(/#/g,', ')}}</view>
							</view>
						</scroll-view>
					</view>
					<view @tap="ajaxReward" class="rewardBt">领取榜单奖励</view>
				</block>
				
			</swiper-item>
		</swiper>
		
		<popup-confirm ref="refText" :showCancel="false" :content="dialogText"></popup-confirm>
		
	</view>
</template>

<script>
	import cuCustomScroll from '@/components/cu-custom/cu-custom-scroll.vue'
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	import bwScrollNav from '@/pages/components/bw-scroll-nav.vue'
	var _self
	
	export default {
		components:{
			cuCustomScroll,
			popupConfirm,
			bwScrollNav
		},
		data() {
			return {
				tabCurrentIndex:0,
				tabBars: [{
					name: '仙斗场',
					id: 1,
				}, {
					name: '仙斗榜',
					id: 2,
				}],
				tabDatas:{},
				pvpId:1,
				subTabIndex:0,
				subItems:['当前榜单','上届榜单','榜单奖励'],
				myRankObj:{
					0:0,  //以 xdRank 优先
					1:0
				},
				scrollTop:0,
				dialogText:'',
				xdcList:[],
				xdRank:0
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.ajaxOpponentList()
			})
		},
		methods: {
			tapFight(item) {
				console.log(JSON.stringify(item))
				_self.ajaxFight(item.rank)
			},
			doDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			goTop: function(e) {
				_self.scrollTop = 1
				_self.$nextTick(function() {
					_self.scrollTop = 0
				})
			},
			onClickItem(e) {
				_self.goTop()
				let eCurrent = e.currentIndex
				if (_self.subTabIndex != eCurrent) {
					_self.subTabIndex = eCurrent
					
					_self.loadRankList()
				}
			},
			loadRankList() {
				let subTabIndex = _self.subTabIndex
				if(!_self.tabDatas[subTabIndex]) {
					switch(subTabIndex) {
						case 0:
							_self.ajaxRankCurr(subTabIndex)
							break;
							
						case 1:
							_self.ajaxRankPre(subTabIndex)
							break;
							
						case 2:
							_self.loadPvpReward(subTabIndex)
							break;
					}
				}
			},
			loadPvpReward(subTabIndex) {
				let pvpArray = _self.jsonParse.getPvpRewardArrayById(_self.pvpId)
				_self.tabDatas[subTabIndex] = pvpArray
			},
			ajaxRankCurr(subTabIndex) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'12_10',
					params:{
						pvpId:_self.pvpId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.myRankObj[subTabIndex] = resData.myRank
						_self.tabDatas[subTabIndex] = resData.ranks
						_self.$forceUpdate()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxRankPre(subTabIndex) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'12_11',
					params:{
						pvpId:_self.pvpId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.myRankObj[subTabIndex] = resData.myRank
						_self.tabDatas[subTabIndex] = resData.ranks
						_self.$forceUpdate()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxReward() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'12_12',
					params:{
						pvpId:_self.pvpId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let gain = resData.gain
						if(gain) {
							let gainText = '奖励：'+_self.jsonParse.getMaterialArray(gain).toString()
							_self.doDialog(gainText)
						}else {
							_self.showToast('已领取')
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxOpponentList() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'12_3',
					params:{
						pvpId:_self.pvpId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.xdcList = resData.rivals
						_self.xdRank = resData.curRank
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxFight(challengeRank) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'12_5',
					params:{
						pvpId:_self.pvpId,
						challengeRank:challengeRank
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.navigateTo(_self.util.toEncodeUri('/pages/fight/fight',{
							resData:resData,
							typeText:'fight-field'
						}))
						
						let rivals = resData.rivals
						let newRank = resData.newRank
						if(newRank) {
							setTimeout(function() {
								if(rivals) {
									_self.xdcList = rivals
								}
								_self.xdRank = newRank
							},1000)
						}
						
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxQueue() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'12_1',
					params:{
						pvpId:_self.pvpId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let formation = resData.formation
						if(!formation) {
							formation = ''
						}
						_self.navigateTo(_self.util.toEncodeUri('/pages/fight-field/fight-settle-queue',{
							formation:formation,
							pvpId:_self.pvpId
						}))
					}
				}
				_self.$req.handleRequest(option)
			},
			swiperTab(e) {
				/*滑动切换*/
				let index = e.target.current || e.detail.current
				this.changeTab(index)
			},
			clickTab(e) {
				/*点击切换*/
				_self.changeTab(e.index)
			},
			changeTab(index) {
				/*切换tab*/
				if(_self.tabCurrentIndex!=index) {
					_self.tabCurrentIndex = index
					
					_self.loadRankList()
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-left: 86rpx;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogGain {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.swiper-box {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
	.icon-achievement {
		width: 250rpx;
		height: 250rpx;
	}
	
	.progressLayout {
		width: 400rpx;
		height: 32rpx;
		border-radius: 16rpx;
		margin: 10rpx 0 10rpx 6rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
		box-shadow:0px 0px 20rpx #F9DB87;
	}
	
	.progressLayout view {
		height: 100%;
		background-color: #F9DB87;
		border-radius: 20rpx;
	}
	
	.introView {
	    padding: 20rpx;
	    border-radius: 10rpx;
	    display: -webkit-inline-box;
	    display: -webkit-inline-flex;
	    display: -ms-inline-flexbox;
	    display: inline-flex;
	    max-width: 280rpx;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    -ms-flex-align: center;
	    align-items: center;
	    font-size: 32rpx;
	    line-height: 40rpx;
	    text-align: left;
		box-shadow: 0 0 20rpx #FFFFFF;
		color: #FFFFFF;
		background-color: #000000;
		opacity: 0.8;
		
		position: absolute;
		right: 320rpx;
		/* margin-top: calc(279px + var(--status-bar-height)); */
		
		/* top: var(--status-bar-height); */
	}
	
	.introView:after {
	    content: "";
	    top: 13px;
	    -webkit-transform: rotate(45deg);
	    -ms-transform: rotate(45deg);
	    transform: rotate(45deg);
	    position: absolute;
	    z-index: 100;
	    display: inline-block;
	    overflow: hidden;
	    width: 12px;
	    height: 12px;
	    left: auto;
	    right: -6px;
	    background-color: inherit;
	}
	
	.listLayout {
		margin-left: 40rpx;
		width: 670rpx;
		/* height: 600rpx; */
		border: solid 1px #666666;
		border-radius: 8rpx;
	}
	
	.height1 {
		max-height: calc(100vh - var(--status-bar-height) - 380rpx);
	}
	
	.sv1 {
		max-height: calc(100vh - var(--status-bar-height) - 380rpx - 80rpx);
	}
	
	.height2 {
		max-height: calc(100vh - var(--status-bar-height) - 420rpx);
	}
	
	.sv2 {
		max-height: calc(100vh - var(--status-bar-height) - 420rpx - 80rpx);
	}
	
	.sv3 {
		height: calc(100vh - var(--status-bar-height) - 100rpx - 240rpx);
	}
	
	.listLayout .sv .item {
		display: flex;
		flex-direction: row;
		border-bottom: solid 1px #666666;
	}
	
	.listLayout .sv .item:last-child {
		border-bottom: none;
	}
	
	.rewardBt {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		margin-left: 77rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.myRankText {
		line-height: 120rpx;
		text-align: center;
		font-size: 32rpx;
		color: #666666;
	}
	
	.xdcItem {
		width: 694rpx;
		height: 144rpx;
		margin-top: 28rpx;
		display: flex;
		align-items: center;
		color: #FFFFFF;
		background:url(../../static/fight-field-item.png) center center no-repeat;background-size:100% 100%;
	}
	
	.xdcItem .btn {
		width: 130rpx;
		height: 60rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 28rpx;
		margin: 0 26rpx;
		background:url(../../static/fight-field-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
