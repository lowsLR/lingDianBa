<template>
	<view class="container">
		<scroll-view scroll-y="true" :scroll-into-view="viewId" style="display: flex;max-height: 84vh;">
			<view class="textView" :id="idPre+index" v-for="(item,index) in textList" :key="index" :class=" indexShow >= index? 'dr':'dc'">
				{{item}}
			</view>
		</scroll-view>
		<view @tap="tapJump" class="jumpOver" :class="isShow?'dr':'dc'">跳过</view>
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				indexShow: 0,
				textList: [
					'作为穿越者，来到这个修真世界已经一年',
					'没有金手指，没有吊炸天的老爷爷',
					'就这样，苦逼逼的过着风餐露宿的生活',
					'今天，正当为晚上去哪里弄吃的而头痛',
					'一道光芒从远处疾驰而来，射中头部',
					'昏迷几天后醒来，脑海中多了许多的陌生记忆，让你震惊万分',
					'天墟之战，天外十八楼，道灵………',
					'而这些记忆的原本主人，叫做方羽',
					'获得方羽的记忆后，你出发去到贾家村，找到了贾小玉，带着贾小玉来到一水派，几番下来，成为了一水派的新掌门',
					'当然了，一水派这名字不好听，于是就将门派名字改了',
					'得知天墟情况的你，窥探到世界的一丝端倪，于是，你开始壮大门派，准备征战天墟',
					'传奇故事的主角，也从原来的方羽，变成xxx，也就是你',
					'此时，遥远的未知空间，在慢慢产生着异变',
					'……………'
				],
				cInterval:null,
				delay:1500,
				viewId:'',
				idPre:'id',
				isShow:false
			}
		},
		onLoad(option) {
			_self = this
			
			let textList = _self.textList
			textList.forEach((text,index) => {
				if(text.indexOf('xxx')!=-1) {
					_self.textList[index] = text.replace('xxx',option.name)
				}
			})
		},
		onUnload() {
			_self.toClearInterval()
		},
		onHide() {
			_self.toClearInterval()
		},
		onShow() {
			_self.setContent()
		},
		methods: {
			tapJump() {
				_self.navigateTo('/pages/load/load')
			},
			setContent() {
				if(_self.indexShow<_self.textList.length) {
					if(!_self.cInterval) {
						_self.cInterval = setInterval(function() {
							_self.indexShow++
							
							_self.$nextTick(function() {
								_self.viewId = _self.idPre+_self.indexShow
							})
							
							if(_self.indexShow==3) {
								_self.isShow = true
							}
							
							if (_self.indexShow > _self.textList.length - 1) {
								_self.toClearInterval()
								_self.tapJump()
							}
						}, _self.delay)
					}
				}
			},
			toClearInterval() {
				if(_self.cInterval) {
					clearInterval(_self.cInterval)
					_self.cInterval = null
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}

	.textView {
		padding: 0 60rpx;
		margin-top: 20rpx;
		color: #FFFFFF;
		font-size: 30rpx;
	}
	
	.dr {
		opacity: 1;
		display: block;
		animation: fadeIn .5s ease-in-out;
	}
	
	.dc {
		opacity: 0;
		display: none;
	}
	
	@keyframes fadeIn {
		0% {
			opacity: 0;
		}
		50% {
			opacity: 0.5;
		}
		100% {
			opacity: 1;
		}
	}	
	
	.jumpOver {
		position: absolute;
		bottom: 60rpx;
		right: 60rpx;
		font-size: 30rpx;
		color: #E5E5E5;
	}
	
</style>
