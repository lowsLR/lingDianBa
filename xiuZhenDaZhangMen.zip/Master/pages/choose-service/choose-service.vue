<template>
	<view class="container">
		<view @tap="toOpenGg" v-if="hasNotice" class="ggText">公告</view>
		<image class="iconLogo" src="/static/logo.png"></image>
		<view @tap="toOpenDialog" class="contentLayout">
			<block v-if="areaInfo.serverStatus==2">
				<image style="width: 52rpx;height: 52rpx;vertical-align: top;" src="../../static/choose-service-status-full.png"></image>
				<view style="font-size: 26rpx;color: #AB1D2A;">爆满</view>
			</block>
			<block v-else-if="areaInfo.serverStatus==1">
				<image style="width: 52rpx;height: 52rpx;vertical-align: top;" src="../../static/choose-service-status-fluent.png"></image>
				<view style="font-size: 26rpx;color: #17A555;">流畅</view>
			</block>
			<block v-else-if="areaInfo.serverStatus==0">
				<image style="width: 52rpx;height: 52rpx;vertical-align: top;" src="../../static/choose-service-status-maintain.png"></image>
				<view style="font-size: 26rpx;color: #999999;">维护</view>
			</block>
			<view style="width: 120rpx;text-align: center;">{{areaInfo.area?areaInfo.area:''}}</view>
			<view style="width: 200rpx;">{{areaInfo.name?areaInfo.name:''}}</view>
			<view style="font-size: 26rpx;padding-right: 6px;">换区</view>
			<image style="width: 16rpx;height: 24rpx;vertical-align: top;" src="/static/choose-service-arrow-right.png"></image>
		</view>
		<view class="bgBt mar-t-80" @tap="tapBegin">开始游戏</view>
		<text style="font-size: 30rpx;margin-top: 80rpx;" @tap="tapUrl" class="line" v-if="hasNotice && webTitle">{{webTitle}}</text>

		<view style="position: absolute;bottom: 20rpx;left: 30rpx;color: #FFFFFF;font-size: 30rpx;">{{version}}</view>

		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="toCloseDialog" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="height: 100rpx;padding-top: 20rpx;font-size: 36rpx;color: #FFFFFF;border-bottom: solid 1px #333333;width: 608rpx;display: flex;flex-direction: row;align-items: center;padding-right: 0rpx;">
					<view style="display: flex;flex: 1;justify-content: center;font-size: 40rpx;">选择服务器</view>
					<image style="width: 52rpx;height: 52rpx;" src="../../static/choose-service-status-full.png"></image>
					<view style="font-size: 26rpx;color: #AB1D2A;">爆满</view>
					<image style="width: 52rpx;height: 52rpx;" src="../../static/choose-service-status-fluent.png"></image>
					<view style="font-size: 26rpx;color: #17A555;">流畅</view>
					<image style="width: 52rpx;height: 52rpx;" src="../../static/choose-service-status-maintain.png"></image>
					<view class="mar-r-20" style="font-size: 26rpx;color: #999999;">维护</view>
				</view>
				<view style="display: flex;flex-direction: row;width: 608rpx;">
					<scroll-view scroll-y="true" style="height: 1010rpx;width: 190rpx;padding-left: 20rpx;display: flex;flex-direction: column;border-right: solid 1px #333333;">
						<view @tap="tapAreaName(name,index)" v-for="(name,index) in areaNameArray" :key="index" :class="areaSelect==index?'activeArea':''" class="areaLayout" style="">{{name}}</view> 
					</scroll-view>
					<scroll-view scroll-y="true" style="display: flex;flex: 1;flex-direction: column;align-items: center;height: 1010rpx;padding-left: 20rpx;">
						<view @tap="tapArea(info)" v-for="(info,index) in areaArray" :key="index" class="serviceBt" :class="areaClassObj[info.serverStatus]">
							<image style="width: 52rpx;height: 52rpx;vertical-align: top;margin-left: 10rpx;" :src="areaIconObj[info.serverStatus]"></image>
							<view>{{info.area}}</view>
							<view style="font-size: 32rpx;margin-left: 30rpx;">{{info.name}}</view>
						</view>
					</scroll-view>
				</view>


			</view>
		</uni-popup>
		
		<uni-popup ref="refGg" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refGg.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogGg" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{ggTitle}}</view>
				<scroll-view scroll-y="true" style="width: 480rpx;height: 620rpx;font-size: 30rpx;color: #EEEEEE;line-height: 60rpx;overflow: scroll;word-break: break-all;">
					<view v-html="contentHtml"></view>
					<text @tap="tapUrl" class="line" v-if="webTitle">{{webTitle}}</text>
				</scroll-view>
			</view>
		</uni-popup>

	</view>
</template>

<script>
	import zwf from '@/components/sunui-password/zw.vue'
	var _self

	export default {
		components: {
			zwf
		},
		data() {
			return {
				account: '',
				password: '',
				show: true,
				mac: '',
				clientId: '',
				areaInfo:{},
				areaNameArray:[],
				areaSelect:0,
				areaArray:[],
				areaObj:{},
				areaClassObj:{
					0:'btNormal',
					1:'btFluent',
					2:'btFull'
				},
				areaIconObj:{
					0:'/static/choose-service-status-maintain.png',
					1:'/static/choose-service-status-fluent.png',
					2:'/static/choose-service-status-full.png'
				},
				accountToken:'',
				hasNotice:false,
				ggTitle:'',
				contentHtml:'',
				webTitle:'',
				webUrl:'',
				version:''
			}
		},
		onLoad(option) {
			_self = this
			
			// #ifdef APP-PLUS
			plus.runtime.getProperty(plus.runtime.appid, function(inf) {
				_self.version = 'version: ' + inf.version.split('.').join('')
			})
			// #endif
			
			let detail = _self.util.toDecodeUri(option)
			_self.fillData(detail)
		},
		methods: {
			tapUrl() {
				// #ifdef APP-PLUS
				plus.runtime.openURL(_self.webUrl,function(err){
					_self.showToast('链接无效')
				})
				// #endif
			},
			toOpenGg() {
				_self.$refs.refGg.open()
			},
			parseContent(noticeData) {
				if(noticeData) {
					_self.ggTitle = noticeData.title
					let contentArray = noticeData.content.split("#")
					if(contentArray.length>0) {
						_self.contentHtml = contentArray[0].replace(/。/g,'<br>')
					}
					if(contentArray.length > 1){
						_self.webTitle = contentArray[1]
					}
					if(contentArray.length > 2){
						_self.webUrl = contentArray[2]
					}
				}
			},
			ajaxServerConnect(params) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmServerConnect
				option[_self.$req.REQUEST_OPTION.PARAMETER] = params
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if (resData) {
						getApp().globalData.sectToken = resData.sectToken
						getApp().globalData.avatarPre = resData.iconUrl
						switch (resData.setted) {
							case 0:
								_self.navigateTo(_self.util.toEncodeUri('/pages/settle/settle-data',{
									serverId:params.serverId
								}))
								break;
			
							case 1:
								_self.navigateTo('/pages/load/load')
								break;
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			tapBegin() {
				let areaInfo = _self.areaInfo
				getApp().globalData.gameUrlPre = areaInfo.url
				
				let params = {
					ts: getApp().globalData.serverTime,
					serverId: areaInfo.serverId,
					uuid: _self.util.generateUUID(),
					token:_self.accountToken
				}
				let sign = _self.util.accountSign(params)
				params['sign'] = sign
				
				_self.ajaxServerConnect(params)
			},
			tapArea(info) {
				_self.toCloseDialog()
				// if(info.serverStatus==0) {
				// 	_self.showToast('服务器维护中')
				// }else {
				// 	_self.areaInfo = info
				// }
				_self.areaInfo = info
			},
			tapAreaName(name,index) {
				_self.areaArray = _self.areaObj[name]
				_self.areaSelect = index
			},
			fillData(detail) {
				// #ifdef APP-PLUS
				_self.getDeviceInfo()
				_self.clientId = _self.util.getClientId()
				// #endif
				
				
				let hasNotice = detail.hasNotice
				if(hasNotice) {
					_self.parseContent(detail.noticeData)
				}
				_self.hasNotice = hasNotice
				_self.accountToken = detail.accountToken
				
				let serverInfoList = detail.serverInfoList
				let areaLength =  parseInt(serverInfoList.length/10)
				if(serverInfoList.length%10!=0) {
					areaLength++
				}
				let areaObj = {}
				let areaNameArray = []
				for(let i=0;i<areaLength;i++) {
					let startIndex = i*10
					let endIndex = 0
					if(i==areaLength-1) {
						endIndex = serverInfoList.length-1
					}else {
						endIndex = (i+1)*10-1
					}
					let areaName = (startIndex+1)+'区-'+(endIndex+1)+'区'
					areaNameArray.push(areaName)
					
					let listArray = []
					for(let j=startIndex;j<(endIndex+1);j++) {
						serverInfoList[j].area = (j+1)+'区'
						listArray.push(serverInfoList[j])
					}
					areaObj[areaName] = listArray
				}
				_self.areaNameArray = areaNameArray
				_self.areaObj = areaObj
				_self.areaArray = areaObj[areaNameArray[0]]
				
				let allLoginServerIds = detail.allLoginServerIds
				if(allLoginServerIds.length==0) {
					/**
					 * 没玩过，默认第一个不是维护的
					 */
					for(let i=0;i<serverInfoList.length;i++) {
						let info = serverInfoList[i]
						if(info.serverStatus!=0) {
							_self.areaInfo = info
							break
						}
					}
					if(!_self.areaInfo) {
						if(serverInfoList.length>0) {
							_self.areaInfo = serverInfoList[0]
						}
					}
				}else {
					let lastLoginServerId = detail.lastLoginServerId
					if(!lastLoginServerId) {
						lastLoginServerId = allLoginServerIds[0]
					}
					let areaInfo = serverInfoList[serverInfoList.findIndex(item => item.serverId==lastLoginServerId)]
					if(areaInfo) {
						_self.areaInfo = areaInfo
					}
				}
			},
			toCloseDialog() {
				_self.$refs.refDialog.close()
			},
			toOpenDialog() {
				_self.$refs.refDialog.open()
			},
			tapBack() {
				uni.navigateBack({
					delta: 1
				})
			},
			tapRegist() {
				let account = _self.account
				let pwd = _self.password
				if (account && pwd) {
					let params = {
						account: account,
						password: pwd,
						clientId: _self.clientId,
						mac: _self.mac,
						requestId: _self.util.generateUUID(),
						ts: getApp().globalData.serverTime
					}
					let sign = _self.util.accountSign(params)
					params['sign'] = sign
					_self.ajaxRegist(params)
				} else {
					_self.showToast('不能为空')
				}
			},
			ajaxRegist(params) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmAccountRegist
				option[_self.$req.REQUEST_OPTION.PARAMETER] = params
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.util.keepLoginData(params.account, params.password)
					_self.showToast('注册成功')
					setTimeout(function() {
						_self.tapBack()
					},800)
				}
				_self.$req.handleRequest(option)
			},
			getDeviceInfo() {
				plus.device.getInfo({
					success: function(res) {
						_self.mac = res.uuid
					}
				});
			},
			showPass(e) {
				this.show = e;
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		display: flex;
		flex-direction: column;
		align-items: center;
		background: url(../../static/home-bg.png) center center no-repeat;
		background-size: 750rpx 1550rpx;
	}

	.bgBt {
		width: 254rpx;
		height: 98rpx;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #AC202D;
		text-align: center;
		background: url(../../static/choose-service-bt-play.png) center center no-repeat;
		background-size: 100% 100%;
	}

	.contentLayout {
		width: 536rpx;
		height: 88rpx;
		line-height: 88rpx;
		font-size: 30rpx;
		color: #E6E6E6;
		display: flex;
		flex-direction: row;
		align-items: center;
		background: url(../../static/login-input-bg.png) center center no-repeat;
		background-size: 100% 100%;
	}

	.dialogLayout {
		width: 642rpx;
		height: 1150rpx;
		background: url(../../static/choose-service-dialog-bg.png) center center no-repeat;
		background-size: 100% 100%;
	}

	.mar-r-20 {
		margin-right: 20rpx;
	}

	.areaLayout {
		border-bottom: solid 1px #333333;
		font-size: 34rpx;
		line-height: 78rpx;
		text-align: center;
		color: #FFFFFF;
	}
	
	.areaLayout:first-child {
		margin-top: 20rpx;
	}
	
	.areaLayout:last-child {
		border-bottom: none;
	}

	.activeArea {
		width: 190rpx;
		height: 78rpx;
		color: #000000;
		background: url(../../static/choose-service-area-bg.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.serviceBt {
		width: 362rpx;
		height: 80rpx;
		margin-top: 20rpx;
		font-size: 30rpx;
		color: #FFFFFF;
		display: flex;
		flex-direction: row;
		align-items: center;
	}
	
	.btNormal {
		background: url(../../static/choose-service-bt-normal.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.btFull {
		background: url(../../static/choose-service-bt-full.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.btFluent {
		background: url(../../static/choose-service-bt-fluent.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.ggText {
		position: absolute;
		border: solid 1px #EEEEEE;
		width: 100rpx;
		height: 100rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		border-radius: 50%;
		color: #EEEEEE;
		font-size: 30rpx;
		margin-top: calc(30rpx + var(--status-bar-height));
		right: 30rpx;
	}
	
	.dialogGg {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.line {
		color: red;
		text-decoration: none;
		border-bottom: 1px solid red;
	}
	
</style>
