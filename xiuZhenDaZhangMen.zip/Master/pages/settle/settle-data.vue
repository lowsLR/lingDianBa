<template>
	<view class="container">
		<view class="topLayout">
			<view class="titleLayout">设置资料</view>
			
			<view style="display: flex;flex-direction: column;width: 300rpx;">
				<input v-model="masterName" type="text" placeholder="请输入昵称" class="inputLayout" />
				<view style="font-size: 24rpx;line-height: 50rpx;">*{{rule}}</view>
			</view>
		</view>
		
		<view class="mar-t-100" style="display: flex;flex-direction: row;align-items: center;">
			<view style="font-size: 30rpx;writing-mode:vertical-rl;width: 206rpx;display: flex;justify-content: center;align-items: center;letter-spacing: 8rpx;">性别</view>
			<view @tap="sex=sexType1" class="sexLayout" :class="sex==sexType1?'sexSelect':'sexNormal'">男</view>
			<view @tap="sex=sexType0" class="sexLayout" :class="sex==sexType0?'sexSelect':'sexNormal'">女</view>
		</view>
		
		<view class="mar-t-100" style="display: flex;flex-direction: row;align-items: center;">
			<view style="font-size: 30rpx;writing-mode:vertical-rl;width: 190rpx;display: flex;justify-content: center;align-items: center;letter-spacing: 8rpx;">头像</view>
			<view @tap="masterIcon=iconType0" class="avatarLayout" :class="masterIcon==iconType0?'avatarSelect':'avatarNormal'">
				<image mode="aspectFill" style="width:120rpx;height: 120rpx;border-radius: 50%;" :src="util.getAvatarUrl(sex,iconArray[sex][0])"></image>
			</view>
			<view @tap="masterIcon=iconType1" class="avatarLayout" :class="masterIcon==iconType1?'avatarSelect':'avatarNormal'">
				<image mode="aspectFill" style="width:120rpx;height: 120rpx;border-radius: 50%;" :src="util.getAvatarUrl(sex,iconArray[sex][1])"></image>
			</view>
		</view>
		
		<view @tap="tapNext" class="btNext mar-t-100">下一步</view>
	</view>
</template>

<script>
	var _self

	export default {
		data() {
			return {
				serverId: 0,
				sectName: '',
				sex:1,
				sexType0:0,
				sexType1:1,
				masterIcon:0,
				iconType0:0,
				iconType1:1,
				masterName:'',
				rule:'昵称仅限1-4位中文字符',
				iconArray:{
					0:[103,115],
					1:[101,102]
				}
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.serverId = detail.serverId
		},
		methods: {
			tapNext() {
				let masterName = _self.masterName.trim()
				if(masterName) {
					if(_self.util.isChinese(masterName) && masterName.length<=4) {
						_self.redirectTo(_self.util.toEncodeUri('/pages/settle/settle-sect',{
							masterName:masterName,
							sex:_self.sex,
							masterIconId:_self.iconArray[_self.sex][_self.masterIcon],
							serverId:_self.serverId
						}))
					}else {
						_self.showToast(_self.rule)
					}
				}else {
					_self.showToast('昵称不能为空')
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background: url(../../static/home-bg.png) center center no-repeat;
		background-size: 750rpx 1550rpx;
		
		color: #999999;
	}

	.topLayout {
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	
	.titleLayout {
		width: 336rpx;
		height: 74rpx;
		text-align: center;
		line-height: 74rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		letter-spacing: 10rpx;
		background: url(../../static/settle-title.png) center center no-repeat;
		background-size: 100% 100%;
		margin-bottom: 6vh;
		margin-top: calc(6vh + var(--status-bar-height));
	}
	
	.inputLayout {
		height: 78rpx;
		text-align: center;
		font-size: 34rpx;
		color: #FFFFFF;
		padding: 0 20rpx;
		background: url(../../static/login-input-bg.png) center center no-repeat;
		background-size: 300rpx 100%;
	}
	
	.sexLayout {
		width: 148rpx;
		height: 106rpx;
		line-height: 106rpx;
		text-align: center;
		font-size: 32rpx;
		color: #FFFFFF;
	}
	
	.sexLayout:last-child {
		margin-left: 40rpx;
	}
	
	.sexNormal {
		background: url(../../static/settle-sex-normal.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.sexSelect {
		background: url(../../static/settle-sex-select.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.avatarLayout {
		width: 176rpx;
		height: 176rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
	.avatarLayout:last-child {
		margin-left: 16rpx;
	}
	
	.avatarNormal {
		background: url(../../static/settle-avatar-normal.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.avatarSelect {
		background: url(../../static/settle-avatar-select.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.btNext {
		width: 204rpx;
		height: 91rpx;
		line-height: 91rpx;
		text-align: center;
		font-size: 32rpx;
		color: #FFFFFF;
		margin-left: 273rpx;
		background: url(../../static/settle-bt-confirm.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	
	
</style>
