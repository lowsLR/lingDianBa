<template>
	<view class="container">
		<view class="topLayout">
			<view class="titleLayout">设置门派</view>
			
			<view style="display: flex;flex-direction: column;width: 300rpx;">
				<input v-model="sectName" type="text" placeholder="输入门派名称" class="inputLayout" />
				<view style="font-size: 24rpx;line-height: 50rpx;">*{{rule}}</view>
			</view>
		</view>
		
		<view class="mar-t-30" style="display: flex;flex-direction: row;align-items: center;">
			<view style="font-size: 30rpx;writing-mode:vertical-rl;width: 90rpx;display: flex;justify-content: center;align-items: center;padding-left: 10rpx;letter-spacing: 8rpx;">选择徽章</view>
			<view style="display: flex;flex-direction: column;">
				<view style="display: flex;flex-direction: row;">
					<view @tap="sectIconId=iconType1" class="sectIconLayout" :class="sectIconId==iconType1?'sectIconSelect':'sectIconNormal'">
						<image style="width:120rpx;height: 120rpx;border-radius: 50%;" src="/static/badge/1.png"></image>
					</view>
					<view @tap="sectIconId=iconType2" class="sectIconLayout" :class="sectIconId==iconType2?'sectIconSelect':'sectIconNormal'">
						<image style="width:120rpx;height: 120rpx;border-radius: 50%;" src="/static/badge/2.png"></image>
					</view>
					<view @tap="sectIconId=iconType3" class="sectIconLayout" :class="sectIconId==iconType3?'sectIconSelect':'sectIconNormal'">
						<image style="width:120rpx;height: 120rpx;border-radius: 50%;" src="/static/badge/3.png"></image>
					</view>
				</view>
				<view style="display: flex;flex-direction: row;">
					<view @tap="sectIconId=iconType4" class="sectIconLayout" :class="sectIconId==iconType4?'sectIconSelect':'sectIconNormal'">
						<image style="width:120rpx;height: 120rpx;border-radius: 50%;" src="/static/badge/4.png"></image>
					</view>
					<view @tap="sectIconId=iconType5" class="sectIconLayout" :class="sectIconId==iconType5?'sectIconSelect':'sectIconNormal'">
						<image style="width:120rpx;height: 120rpx;border-radius: 50%;" src="/static/badge/5.png"></image>
					</view>
					<view @tap="sectIconId=iconType6" class="sectIconLayout" :class="sectIconId==iconType6?'sectIconSelect':'sectIconNormal'">
						<image style="width:120rpx;height: 120rpx;border-radius: 50%;" src="/static/badge/6.png"></image>
					</view>
				</view>
			</view>
			
		</view>
		
		<view class="mar-t-30" style="display: flex;flex-direction: row;align-items: center;">
			<view style="font-size: 30rpx;writing-mode:vertical-rl;width: 100rpx;display: flex;justify-content: center;align-items: center;letter-spacing: 8rpx;">门派方向</view>
			<view style="display: flex;flex-direction: row;justify-content: center;width: 590rpx;">
				<view @tap="sectType=sectType2" class="directionLayout" :class="sectType==sectType2?'directionSelect':'directionNormal'">魔</view>
				<view @tap="sectType=sectType1" class="directionLayout" :class="sectType==sectType1?'directionSelect':'directionNormal'">正</view>
			</view>
			
		</view>
		
		<view class="mar-t-30" style="display: flex;flex-direction: row;align-items: center;">
			<view style="font-size: 30rpx;writing-mode:vertical-rl;width: 100rpx;display: flex;justify-content: center;align-items: center;letter-spacing: 8rpx;">职业方向</view>
			<view style="display: flex;flex-direction: column;">
				<view style="display: flex;flex-direction: row;justify-content: center;">
					<view @tap="jobType=jobType1" class="jobLayout" :class="jobType==jobType1?'directionSelect':'directionNormal'">{{jobNames[0]}}</view>
					<view @tap="jobType=jobType2" class="jobLayout" :class="jobType==jobType2?'directionSelect':'directionNormal'">{{jobNames[1]}}</view>
					<view @tap="jobType=jobType3" class="jobLayout" :class="jobType==jobType3?'directionSelect':'directionNormal'">{{jobNames[2]}}</view>
					<view @tap="jobType=jobType4" class="jobLayout" :class="jobType==jobType4?'directionSelect':'directionNormal'">{{jobNames[3]}}</view>
				</view>
				<view style="width: 536rpx;border-radius: 6rpx;border: solid 1px #999999;padding: 8rpx;font-size: 28rpx;margin-left: 20rpx;text-align: center;">{{jobIntroObj[jobType]?jobIntroObj[jobType]:''}}</view>
			</view>
			
		</view>
		
		<view @tap="tapConfirm" class="btNext mar-t-30">确定</view>
	</view>
</template>

<script>
	var _self

	export default {
		data() {
			return {
				sectName: '',
				sectIconId:1,
				iconType1:1,
				iconType2:2,
				iconType3:3,
				iconType4:4,
				iconType5:5,
				iconType6:6,
				sectType:2,
				sectType1:1,
				sectType2:2,
				jobType:1,
				jobType1:1,
				jobType2:2,
				jobType3:3,
				jobType4:4,
				rule:'昵称仅限1-5位中文字符',
				optionDetail:null,
				jobNames:['剑修','体修','医修','魂修'],
				jobIntroObj:{}
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.optionDetail = detail
			
			let jobType1 = _self.jsonParse.getJobByName(_self.jobNames[0])
			let jobType2 = _self.jsonParse.getJobByName(_self.jobNames[1])
			let jobType3 = _self.jsonParse.getJobByName(_self.jobNames[2])
			let jobType4 = _self.jsonParse.getJobByName(_self.jobNames[3])
		
			let jobIntroObj = {}
			jobIntroObj[jobType1] = '一剑逍遥除魔去，我自傲立天地间'
			jobIntroObj[jobType2] = '力拔山兮气盖世，碎星破天舍我谁'
			jobIntroObj[jobType3] = '仁心醍醐渡众生，九渊不空不成仙'
			jobIntroObj[jobType4] = '以念御灵斩羁绊，大道之初始于魂'
			_self.jobIntroObj = jobIntroObj
			
			_self.jobType1 = jobType1
			_self.jobType2 = jobType2
			_self.jobType3 = jobType3
			_self.jobType4 = jobType4
		},
		methods: {
			ajaxSettle(params) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmServerSettle
				option[_self.$req.REQUEST_OPTION.PARAMETER] = params
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if (resData.success) {
						_self.navigateTo('/pages/open-plot/open-plot?name='+params.masterName)
					}
				}
				_self.$req.handleRequest(option)
			},
			tapConfirm() {
				let sectName = _self.sectName.trim()
				if(sectName) {
					if(_self.util.isChinese(sectName)) {
						let params = {
							..._self.optionDetail,
							jobId: _self.jobType,
							sectIconId: _self.sectIconId,
							sectName: sectName,
							sectType: _self.sectType,
							uuid: _self.util.generateUUID(),
							ts: getApp().globalData.serverTime
						}
						let sign = _self.util.accountSign(params)
						params['sign'] = sign
						_self.ajaxSettle(params)
						
					}else {
						_self.showToast(_self.rule)
					}
				}else {
					_self.showToast('门派名称不能为空')
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background: url(../../static/home-bg.png) center center no-repeat;
		background-size: 750rpx 1550rpx;
		
		color: #999999;
	}

	.topLayout {
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	
	.titleLayout {
		width: 336rpx;
		height: 74rpx;
		text-align: center;
		line-height: 74rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		letter-spacing: 10rpx;
		background: url(../../static/settle-title.png) center center no-repeat;
		background-size: 100% 100%;
		margin-bottom: 6vh;
		margin-top: calc(6vh + var(--status-bar-height));
	}
	
	.inputLayout {
		height: 78rpx;
		text-align: center;
		font-size: 34rpx;
		color: #FFFFFF;
		padding: 0 20rpx;
		background: url(../../static/login-input-bg.png) center center no-repeat;
		background-size: 300rpx 100%;
	}
	
	.directionLayout {
		width: 148rpx;
		height: 106rpx;
		line-height: 106rpx;
		text-align: center;
		font-size: 32rpx;
		color: #FFFFFF;
	}
	
	.directionLayout:last-child {
		margin-left: 40rpx;
	}
	
	.directionNormal {
		background: url(../../static/settle-sex-normal.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.directionSelect {
		background: url(../../static/settle-sex-select.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.sectIconLayout {
		width: 176rpx;
		height: 176rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-right: 30rpx;
	}
	
	.sectIconNormal {
		background: url(../../static/settle-avatar-normal.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.sectIconSelect {
		background: url(../../static/settle-avatar-select.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.btNext {
		width: 204rpx;
		height: 91rpx;
		line-height: 91rpx;
		text-align: center;
		font-size: 32rpx;
		color: #FFFFFF;
		margin-left: 273rpx;
		background: url(../../static/settle-bt-confirm.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.jobLayout {
		width: 148rpx;
		height: 106rpx;
		line-height: 106rpx;
		text-align: center;
		font-size: 32rpx;
		color: #FFFFFF;
	}
	
	.jobLayout:last-child {
		margin-right: 0;
	}
	
	
</style>
