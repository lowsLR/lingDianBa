<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">书信</block>
		</cu-custom>
		
		<scroll-view scroll-y="true" class="list">
			<view v-if="mLists.length>0" style="display: flex;flex-direction: column;align-items: center;font-size: 30rpx;">
				<view @tap="tapMail(item)" :class="[!item.hasGain&&item.hasBonus?'mbcF13426':!item.hasRead?'mbcFFFFFF':'mbc666666']" v-for="(item,index) in mLists" :key="index" class="item mbcF13426 isEllipsis" style="line-height: 80rpx;width: 650rpx;margin-top: 40rpx;padding: 0 20rpx;">
					【{{typeObj[item.mailType]}}】 {{item.title}}
				</view>
			</view>
			<view v-else-if="loaded" class="no-activity">暂无数据</view>
		</scroll-view>
		
		<uni-popup ref="refDetail" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDetail.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDetail" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{dialogInfo.title}}</view>
				<scroll-view scroll-y="true" class="sv" style="width: 440rpx;height: 500rpx;margin-bottom: 30rpx;font-size: 30rpx;color: #FFFFFF;line-height: 60rpx;">
					<view v-if="dialogInfo.bonusText">获得：{{dialogInfo.bonusText}}</view>
					<view>{{dialogInfo.content}}</view>
				</scroll-view>
				<view v-if="dialogInfo.hasBonus" style="display: flex;flex-direction: row;justify-content: center;margin-bottom: 30rpx;">
					<view v-if="dialogInfo.hasGain" class="dBtn1">已领取</view>
					<block v-else>
						<view @tap="$refs.refDetail.close()" class="dBtn1">取消</view>
						<view @tap="ajaxGet" class="dBtn2 mar-l-66">领取</view>
					</block>
					
				</view>
			</view>
		</uni-popup>
		
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				mLists:[],
				typeObj:{
					0:'系统',
					1:'个人'
				},
				dialogInfo:{},
				loaded:false
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.ajaxList()
			})
		},
		methods: {
			toOpenDialog() {
				_self.$refs.refDetail.open()
			},
			toCloseDialog() {
				_self.$refs.refDetail.close()
			},
			tapGet() {
				
			},
			tapMail(item) {
				console.log(JSON.stringify(item))
				_self.ajaxDetail(item.mailId)
			},
			arrSort(arr){
				let a1 = arr.filter(item => {return !item.hasGain&&item.hasBonus})
				a1.sort(function(a,b){
					return b['mailId'] - a['mailId'];
				})
				let a2 = arr.filter(item => {return !item.hasGain&&!item.hasRead&&!item.hasBonus})
				let a3 = arr.filter(item => {
					return !(!item.hasGain&&item.hasBonus) &&
					!(!item.hasGain&&!item.hasRead&&!item.hasBonus)
				})
				return [...a1,...a2,...a3];
			},
			ajaxGet() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'9_3',
					params:{
						mailId:_self.dialogInfo.mailId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.showToast('已领取')
						_self.toCloseDialog()
						_self.ajaxList(true)
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxDetail(mailId) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'9_2',
					params:{
						mailId:mailId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						// 6-8
						
						let mailFullView = resData.mailFullView
						let bonus = mailFullView.bonus   // 8:1:1#6:2:1
						
						let mBonus = ''  // 去掉装备、弟子  6-8，在其他字段获取
						let bonusArray = bonus.split('#')
						bonusArray.forEach(item => {
							let itemArray = item.split(':')
							if([6,8].indexOf(parseInt(itemArray[0]))==-1) {
								if(mBonus) {
									mBonus += '#'
								}
								mBonus += item
							}
						})
						
						let bonusText = ''
						if(mBonus) {
							bonusText = _self.jsonParse.getMaterialArray(mBonus).toString()
						}
						
						let discipleInfos = mailFullView.discipleInfos
						Object.keys(discipleInfos).map(key => {
							if(bonusText) {
								bonusText += ','
							}
							bonusText += key+'*'+discipleInfos[key]
						})
						
						let equipInfos = mailFullView.equipInfos
						Object.keys(equipInfos).map(key => {
							if(bonusText) {
								bonusText += ','
							}
							bonusText += key+'*'+equipInfos[key]
						})
						mailFullView.bonusText = bonusText
						_self.dialogInfo = mailFullView
						_self.toOpenDialog()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxList(hideLoading) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = hideLoading
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'9_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.mLists = _self.arrSort([...resData.system,...resData.personal])
						_self.loaded = true
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.list {
		overflow: scroll;
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
	.list .item:last-child {
		margin-bottom: 40rpx;
	}
	
	.dialogDetail {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dBtn1 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 34rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		text-align: center;
		color: #676767;
		background:url(../../static/building-disciple-recruit-bt-abandon.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dBtn2 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 34rpx;
		color: #FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
		text-align: center;
		background:url(../../static/building-disciple-recruit-bt-get.png) center center no-repeat;background-size:100% 100%;
	}
	
	.no-activity {
		width: 100%;
		padding-top: 200rpx;
		text-align: center;
		color: #666666;
		font-size: 32rpx;
	}
	
	
</style>
