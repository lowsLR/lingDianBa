<template>
	<view class="container">
		<image class="iconLogo" src="/static/logo.png"></image>
		<input type="text" v-model="account" class="inputLayout" placeholder="设置用户名" />
		
		<view>
			<sunui-password style="position: absolute;line-height: 88rpx;margin-left: 465rpx;" @change="showPass" />
			<input type="text" v-model="password" :password="show" class="inputLayout" placeholder="设置密码" />
		</view>
		<view class="bgBt mar-t-60" @tap="tapRegist">注册</view>
		<view class="bgBt mar-t-80" @tap="tapBack">返回登录</view>
		
		<popup-confirm ref="refText" @confirm="tapBack" :showCancel="false" content="注册成功"></popup-confirm>
	</view>
</template>

<script>
	import zwf from '@/components/sunui-password/zw.vue'
	var _self
	
	export default {
		components:{
			zwf
		},
		data() {
			return {
				account: '',
				password: '',
				show: true,
				mac:'',
				clientId:'',
				dialogText:''
			}
		},
		onLoad() {
			_self = this
			
			// #ifdef APP-PLUS
			_self.getDeviceInfo()
			_self.clientId = _self.util.getClientId()
			// #endif
		},
		methods: {
			tapBack() {
				uni.navigateBack({
					delta:1
				})
			},
			tapRegist() {
				let account = _self.account
				let pwd = _self.password
				if(account && pwd) {
					let params = {
						account:account,
						password:pwd,
						clientId:_self.clientId,
						mac:_self.mac,
						requestId:_self.util.generateUUID(),
						ts:getApp().globalData.serverTime
					}
					let sign = _self.util.accountSign(params)
					params['sign'] = sign
					_self.ajaxRegist(params)
				}else {
					_self.showToast('用户名或密码不能为空')
				}
			},
			ajaxRegist(params) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmAccountRegist
				option[_self.$req.REQUEST_OPTION.PARAMETER] = params
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.util.keepLoginData(params.account,params.password)
					_self.$refs.refText.open()
				}
				_self.$req.handleRequest(option)
			},
			getDeviceInfo(){
				plus.device.getInfo({
					success:function(res){
						_self.mac = res.uuid
					}
				});
			},
			showPass(e) {
				this.show = e;
			}
		}
	}
</script>

<style>
	
	.container {
		width: 750rpx;
		height: 100vh;
		display: flex;
		flex-direction: column;
		align-items: center;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.inputLayout {
		width: 353rpx;
		height: 88rpx;
		text-align: center;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-bottom: 50rpx;
		padding: 0 93rpx;
		background:url(../../static/login-input-bg.png) center center no-repeat;background-size: 536rpx 100%;
	}
	
	.bgBt {
		width: 536rpx;
		height: 88rpx;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #AC202D;
		text-align: center;
		background:url(../../static/login-bt-bg.png) center center no-repeat;background-size: 100% 100%;
	}
	

</style>
