<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">主线地图</block>
		</cu-custom>
		
		<scroll-view class="sv" scroll-y="true">
			<!-- <view v-for="(item,i1) in mapList" :key="i1" style="margin-bottom: 40rpx;">
				<view style="text-align: center;color: #FFF200;font-size: 34rpx;line-height: 100rpx;">{{item.chapterName}}</view>
				<button @tap="tapMap(info)" v-if="info.show" v-for="(info,i2) in item.data" :key="i2">{{info.mapName}}</button>
			</view> -->
			<view style="padding-bottom: 54rpx;display: flex;flex-direction: column;align-items: center;">
				<view style="margin-top: 54rpx;" v-for="(info,i1) in mapList" :key="i1">
					<view v-if="!info.isShow" style="font-size: 40rpx;" class="exp-view flex-cc qua" @tap="setShow(info.chapterName)">
						<view style="display: flex;flex: 1;justify-content: center;">
							{{info.chapterName}}
						</view>
						<uni-icons type="arrowdown" style="margin-right: 30rpx;position: absolute;right: 90rpx;color: #FFFFFF;"  size="28" />
					</view>
					
					<view v-else class="lv-view qua" @tap="setShow(info.chapterName)">
						<view class="listTitle" style="line-height: 120rpx;font-size: 40rpx;">
							{{info.chapterName}}
						</view>
						<uni-icons type="arrowup" style="margin-right: 30rpx;position: absolute;right: 90rpx;line-height: 120rpx;color: #FFFFFF;" size="28" />
						<view class="lv-view-ld flex-cc qua"
						style="margin-bottom: 26rpx;font-size: 30rpx;"
						v-for="(item,i2) in info.data"
						:key="i2"
						@tap.stop="tapMap(item)"
						:style="[{'opacity':(passedMaxId+1)<item.mapId?'0.3':''}]">
							{{item.mapName}}
						</view>
					</view>
				</view>
				
				<view style="margin-top: 54rpx;" v-for="(info,i1) in mapList" :key="i1">
					<view v-if="!info.isShow" style="font-size: 40rpx;" class="exp-view flex-cc qua" @tap="setShow(info.chapterName)">
						<view style="display: flex;flex: 1;justify-content: center;">
							{{info.chapterName}}
						</view>
						<uni-icons type="arrowdown" style="margin-right: 30rpx;position: absolute;right: 90rpx;color: #FFFFFF;"  size="28" />
					</view>
					
					<view v-else class="lv-view qua" @tap="setShow(info.chapterName)">
						<view class="listTitle" style="line-height: 120rpx;font-size: 40rpx;">
							{{info.chapterName}}
						</view>
						<uni-icons type="arrowup" style="margin-right: 30rpx;position: absolute;right: 90rpx;line-height: 120rpx;color: #FFFFFF;" size="28" />
						<view class="lv-view-ld flex-cc qua"
						style="margin-bottom: 26rpx;font-size: 30rpx;"
						v-for="(item,i2) in info.data"
						:key="i2"
						@tap.stop="tapMap(item)"
						:style="[{'opacity':(passedMaxId+1)<item.mapId?'0.3':''}]">
							{{item.mapName}}
						</view>
					</view>
				</view>
				
				
			</view>
		</scroll-view>
		
		<view style="display: flex;justify-content: center;align-items: center;height: 160rpx;position: absolute;bottom: 0;width: 100%;">
			<view @tap="tapQueue" style="width: 550rpx;height: 80rpx;border-radius: 40rpx;line-height: 80rpx;text-align: center;color: #FFFFFF;font-size: 32rpx;border: solid 1px #FFFFFF;">设置队列</view>
		</view>
		
		<uni-popup ref="refMapDetail" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refMapDetail.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogMapDetail" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{mapDetail.mapName}}</view>
				<scroll-view scroll-y="true" :style="[{'height':(mapDetail.xyLs==0&&mapDetail.xyXw==0)?'704rpx':'594rpx'}]" style="line-height: 54rpx;font-size: 28rpx;color: #818181;width: 468rpx;margin-bottom: 20rpx;">
					<view>进入消耗：{{mapDetail.enterConsumeText}}</view>
					<view>行走消耗：{{mapDetail.walkConsumeText}}</view>
					<view>通关条件：{{mapDetail.passCondiction}}</view>
					<view>地图规格：{{mapDetail.mapSpecification}}</view>
					<view>遇怪机率：{{mapDetail.monsterRate?util.keepTwoDecimal(mapDetail.monsterRate*100):0}}%</view>
					<view style="display: flex;flex-direction: row;line-height: 42rpx;margin-top: 12rpx;">
						掉落材料：
						<view style="display: flex;flex: 1;flex-direction: column;">
							{{mapDetail.dropMaterial?mapDetail.dropMaterial.replace(/#/g,', '):''}}
						</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 42rpx;margin-top: 12rpx;">
						剧情描述：
						<view style="display: flex;flex: 1;flex-direction: column;">
							<text v-html="mapDetail.description?mapDetail.description.replace(/\n/g,'<br>'):''"></text>
						</view>
					</view>
				</scroll-view>
				<view v-if="mapDetail.xyLs>0 && mapDetail.xyXw>0" style="display: flex;flex-direction: row;justify-content: center;margin-bottom: 20rpx;">
					<view @tap="tapXy(xyType1)" class="bt2">仙游<br>扣除100灵粮</view>
					<view @tap="tapXy(xyType2)" class="bt2 mar-l-66">仙游<br>扣除1000灵粮</view>
				</view>
				<view @tap="toEnterMap" class="bt1">进入地图</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refGain" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refGain.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogGain" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">仙游获得</view>
				<scroll-view scroll-y="true" style="width: 480rpx;height: 500rpx;margin-bottom: 30rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;">
					<view class="isCenter" v-html="gainHtml" style="height: 100%;"></view>
				</scroll-view>
				<view @tap="$refs.refGain.close()" class="bt1">确定</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refConfirm" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refConfirm.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogGain" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">仙游提示</view>
				<view class="isCenter" v-html="xyHtml" style="width: 480rpx;height: 500rpx;margin-bottom: 30rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;overflow: scroll;"></view>
				<view @tap="ajaxXy" class="bt1">确定</view>
			</view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	var _self
	
	export default {
		components:{
			popupWords
		},
		data() {
			return {
				mapList:[],
				passedMaxId:0,
				queueText:'',
				mapDetail:{},
				xyType1:1,
				xyType2:2,
				xyType:-1,
				gainHtml:'',
				wordsNew:'',
				keyWordsNew:'',
				xyHtml:''
			}
		},
		onLoad(option) {
			_self = this
			
			let mapList =  _self.jsonParse.getMapList()
			mapList.forEach((item)=>{
				item.isShow = false
			})
			_self.mapList = mapList
			_self.$nextTick(function(){
				_self.toGetWordsNew()
			})
		},
		onShow() {
			_self.getQueueValue()
			if(getApp().globalData.hasTime) {
				_self.$nextTick(function(){
					_self.ajaxPassed()
				})
			}
		},
		methods: {
			toOpenConfirm() {
				_self.$refs.refConfirm.open()
			},
			toCloseConfirm() {
				_self.$refs.refConfirm.close()
			},
			tapXy(xyType) {
				let llCount = 0
				switch(xyType) {
					case _self.xyType1:
						llCount = 100
						break;
						
					case _self.xyType2:
						llCount = 1000
						break;
				}
				_self.xyHtml = '必获得 '+_self.mapDetail.xyLs*llCount+'*灵石<br>必获得 '+_self.mapDetail.xyXw*llCount+'*修为<br>概率获得其他材料'
				_self.xyType = xyType
				_self.toOpenConfirm()
			},
			toWordsNew(count) {
				let wordObj = _self.jsonParse.getNewWords('map')
				if(wordObj) {
					if(wordObj.count>count) {
						_self.wordsNew = wordObj.content
						_self.$refs.refWords.open()
						
						uni.setStorage({
						    key: _self.keyWordsNew,
						    data: count+1
						})
					}
				}
			},
			toGetWordsNew() {
				let keyWordsNew = 'wnm-'+getApp().globalData.sectView.sectId
				_self.keyWordsNew = keyWordsNew
				
				uni.getStorage({
				    key: keyWordsNew,
					success:function(res){
						_self.toWordsNew(res.data)
					},
				    fail:function(res){
						_self.toWordsNew(0)
					}
				})
			},
			toOpenDialogMapDetail() {
				_self.$refs.refMapDetail.open()
			},
			toCloseDialogMapDetail() {
				_self.$refs.refMapDetail.close()
			},
			getQueueValue() {
				// 获取战斗队列  暂时的。。
				try {
				    const value = uni.getStorageSync(_self.util.getStorageQueueKey())
				    if (value) {
						_self.queueText = value
				    }
				} catch (e) {}
			},
			queueCallback(e) {
				_self.queueText = e.queueText
			},
			tapQueue() {
				_self.navigateTo('/pages/map/settle-queue')
			},
			ajaxXy() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'5_8',
					params:{
						mapId:_self.mapDetail.mapId,
						sweepType:_self.xyType
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.toCloseConfirm()
						
						let gain = resData.gain
						if(gain) {
							let gainHtml = ''
							let materialObj = _self.jsonParse.parseHomeMaterial(gain)
							Object.keys(materialObj).map(key => {
								let obj = materialObj[key]
								gainHtml += obj.name+'*'+obj.count+'<br>'
							})
							if(gainHtml) {
								_self.gainHtml = gainHtml
								_self.$refs.refGain.open()
							}
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxEnter(mapId) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'5_3',
					params:{
						mapId:mapId,
						formation:_self.queueText
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.toCloseDialogMapDetail()
						_self.navigateTo(_self.util.toEncodeUri('/pages/map/map',{
							mapId:mapId,
							resData:resData
						}))
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxPassed() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'5_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.passedMaxId = resData.passedMaxMapId
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxDetail(mapId) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'5_2',
					params:{
						mapId:mapId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						uni.showModal({
							title:'地图详情',
							content:JSON.stringify(resData),
							confirmText:'进入',
							success(res) {
								if(res.confirm) {
									let queueText = _self.queueText
									if(queueText) {
										// 判断queueText的弟子是否都存在
										let allExist = true
										let disciples = getApp().globalData.disciples
										let queueArray = queueText.split('#')
										queueArray.forEach((text,index)=>{
											let itemArray = text.split('=')
											let disciple = disciples[disciples.findIndex(item => item.id==parseInt(itemArray[1]))]
											if(!disciple) {
												allExist = false
											}
										})
										if(allExist) {
											_self.ajaxEnter(mapId)
										}else {
											_self.showToast('请先设置队列')
										}
									}else {
										_self.showToast('请先设置队列')
									}
								}
							}
						})
					}
				}
				_self.$req.handleRequest(option)
			},
			setShow(chapterName){
				let mapList = _self.mapList
				let mapInfo = mapList[mapList.findIndex(item => item.chapterName==chapterName)]
				if(mapInfo) {
					if(mapInfo.isShow) {
						mapInfo.isShow = false
					}else {
						mapList.forEach((item)=>{
							item.isShow = false
						})
						mapInfo.isShow = true
					}
				}
			},
			tapMap(info) {
				let mapId = info.mapId
				if(mapId<=_self.passedMaxId+1) {
					_self.mapDetail = info
					_self.toOpenDialogMapDetail()
				}else {
					_self.showToast('请先通关前置地图')
				}
			},
			toEnterMap() {
				let allExist = _self.util.queueExist(_self.queueText)
				if(allExist) {
					_self.ajaxEnter(_self.mapDetail.mapId)
				}else {
					_self.showToast('请先设置队列')
				}
			}
		}
	}
</script>

<style>
	
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.sv {
		height: calc(100vh - 100upx - var(--status-bar-height) - 160rpx);
	}
	
	.exp-view{
		width:570upx;
		height:98upx;
		border-radius:49upx;
		
		font-size:40upx;
		font-weight:500;
		line-height:81upx;
		
	}
	.lv-view{
		/* height:782upx; */
		width: 570upx;
		border-radius:49upx;
		overflow: hidden;
		display: flex;
		align-items: center;
		justify-content: flex-start;
		flex-direction: column;
		transition: all .3s ease-out;
	}
	.lv-view-ld{
		width:480upx;
		height:68upx;
		border-radius:34upx;
	}
	
	.flex-cc {
		display: flex; align-items: center; justify-content: center;
	}
	
	.qua {
		color: #FFFFFF;
		 box-shadow: 0 0 11px #FFFFFF;
	}
	
	.dialogMapDetail {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt2 {
		width: 190rpx;
		height: 88rpx;
		font-size: 24rpx;
		line-height: 34rpx;
		color: #FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg2.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogGain {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	
</style>
