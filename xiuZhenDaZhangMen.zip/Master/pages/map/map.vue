<template>
	<view class="container">
		<view class="topLayout">
			<image @tap="toOpenDialogLeave" class="iconBack" src="/static/icon-back.png"></image>
			
			<view style="text-align: right;color: #FFFFFF;font-size: 38rpx;line-height: 64rpx;padding-right: 24rpx;padding-top: 14rpx;">({{currPoint.x}},{{currPoint.y}})<text style="margin-left: 30rpx;">{{mapName}}</text></view>
			<view style="padding-right: 24rpx;font-size: 28rpx;text-align: right;color: #FFFFFF;">灵粮：{{llCount}}</view>
		</view>
		
		<!-- <view class="mapContainer" @tap="tapContainer">
			<view class="moveDot" :style="[{'height':perSize*yMax+'rpx', 'width':perSize*xMax+'rpx'}]" style="overflow: hidden;">
				<view :style="[{'transform':'translate('+(perSize*x1)+'rpx, '+(perSize*x2)+'rpx)', 'width':perSize+'rpx', 'height':perSize+'rpx'}]" style="background-color: #F13426;position: absolute;z-index: 1;transition: all 0.2s ease 0s;border-radius: 50%;"></view>
				<view style="transition: all 0.2s ease 0s;" :style="[{'transform':'translate('+(perSize*y1)+'rpx, '+(perSize*y2)+'rpx)'}]">
					<view v-for="y in yPoints" :key="y" :style="[{'width':(xCount*perSize)+'rpx'}]" style="display: flex;flex-direction: row;">
						<image @tap.stop="tapPoint(x,y)" v-for="x in xPoints" :key="x" :style="[{'width':perSize+'rpx', 'height':perSize+'rpx', 'opacity':sideArray.indexOf(x+_self.pointSplit+y)!=-1?'1':lightUpArray.indexOf(x+_self.pointSplit+y)!=-1?'1':'1'}]" style="display: flex;transition: all 0.2s ease 0s;opacity: 1;animation: asd 0.2s;" :src="mapObject[x+pointSplit+y]?'/static/'+mapObject[x+pointSplit+y].icon+'.png':vacancyInfo?'/static/'+vacancyInfo.icon+'.png':''"></image>
						<image @tap="tapPoint(x,y)" v-for="x in xPoints" :key="x" :style="[{'width':perSize+'rpx', 'height':perSize+'rpx', 'opacity':sideArray.indexOf(x+_self.pointSplit+y)!=-1?'1':lightUpArray.indexOf(x+_self.pointSplit+y)!=-1?'0.3':'0.1'}]" style="display: flex;transition: all 0.2s ease 0s;opacity: 1;animation: asd 0.2s;" :src="mapObject[x+pointSplit+y]?'/static/'+mapObject[x+pointSplit+y].icon+'.png':vacancyInfo?'/static/'+vacancyInfo.icon+'.png':''"></image>
					</view>
				</view>
			</view>
		</view> -->
		<view class="mapContainer" @tap="tapContainer">
			<view class="moveDot" :style="[{'height':perSize*yMax+'px', 'width':perSize*xMax+'px'}]" style="overflow: hidden;">
				<view :style="[{'transform':'translate('+(perSize*x1)+'px, '+(perSize*x2)+'px)', 'width':perSize+'px', 'height':perSize+'px'}]" style="background-color: #FFFF00;position: absolute;z-index: 1;transition: all 0.2s ease 0s;border-radius: 50%;box-shadow: 0 0 40rpx #FFFF00;opacity: 0.9;"></view>
				<view style="transition: all 0.2s ease 0s;" :style="[{'transform':'translate('+(perSize*y1)+'px, '+(perSize*y2)+'px)'}]">
					<view v-for="y in yPoints" :key="y" :style="[{'width':(xCount*perSize)+'px'}]" style="display: flex;flex-direction: row;">
						<!-- <image @tap.stop="tapPoint(x,y)" v-for="x in xPoints" :key="x" :style="[{'width':perSize+'px', 'height':perSize+'px', 'opacity':sideArray.indexOf(x+_self.pointSplit+y)!=-1?'1':lightUpArray.indexOf(x+_self.pointSplit+y)!=-1?'1':'1'}]" style="display: flex;transition: all 0.2s ease 0s;opacity: 1;animation: asd 0.2s;" :src="mapObject[x+pointSplit+y]?'/static/'+mapObject[x+pointSplit+y].icon+'.png':vacancyInfo?'/static/'+vacancyInfo.icon+'.png':''"></image> -->
						<image @tap.stop="tapPoint(x,y)" v-for="x in xPoints" :key="x" :style="[{'width':perSize+'px', 'height':perSize+'px', 'opacity':mapObject[x+pointSplit+y]&&mapObject[x+pointSplit+y].type==7? '1':sideArray.indexOf(x+pointSplit+y)!=-1?'1':lightUpArray.indexOf(x+_self.pointSplit+y)!=-1?'1':'0.1'}]" style="display: flex;transition: all 0.2s ease 0s;opacity: 1;animation: asd 0.2s;" :src="mapObject[x+pointSplit+y]?'/static/'+mapObject[x+pointSplit+y].icon+'.png':vacancyInfo?'/static/'+vacancyInfo.icon+'.png':''"></image>
					</view>
				</view>
			</view>
		</view>
		
		<uni-popup ref="refContinue" type="center" :custom="true" :mask-click="false">
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{continueInfo.title}}</view>
				<scroll-view scroll-y="true" :style="[{'height':(810-118*continueInfo.bts.length)+'rpx'}]" style="line-height: 50rpx;font-size: 28rpx;color: #818181;width: 490rpx;text-align: center;">
					<view style="height: 100%;" class="isCenter" v-html="util.exchangeLineBreak(continueInfo.text)"></view>
				</scroll-view>
				
				<view v-for="(info,index) in continueInfo.bts" :key="index" @tap="tapContinue(info)" class="dialogButton"><text :style="[{'color':jsonParse.getOperateColor(info.operate)}]">{{info.operate}}</text></view>
				
			</view>
		</uni-popup>
		
		<uni-popup ref="refChance" type="center" :custom="true" :mask-click="false">
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{chanceInfo.title}}</view>
				<scroll-view scroll-y="true" :style="[{'height':(810-118*chanceInfo.bts.length)+'rpx'}]" style="line-height: 50rpx;font-size: 28rpx;color: #818181;width: 490rpx;text-align: center;">
					<view style="height: 100%;" class="isCenter" v-html="util.exchangeLineBreak(chanceInfo.text)"></view>
				</scroll-view>
				
				<view v-for="(info,index) in chanceInfo.bts" :key="index" @tap="tapChance(info)" class="dialogButton"><text :style="[{'color':jsonParse.getOperateColor(info.operate)}]">{{info.operate}}</text></view>
				
			</view>
		</uni-popup>
		
		<uni-popup ref="refTask" type="center" :custom="true" :mask-click="false">
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{taskInfo.title}}</view>
				<scroll-view scroll-y="true" :style="[{'height':(810-118*taskInfo.bts.length)+'rpx'}]" style="line-height: 50rpx;font-size: 28rpx;color: #818181;width: 490rpx;text-align: center;">
					<view style="height: 100%;" class="isCenter" v-html="util.exchangeLineBreak(taskInfo.text)"></view>
				</scroll-view>
				
				<view v-for="(info,index) in taskInfo.bts" :key="index" @tap="tapTask(info)" class="dialogButton"><text :style="[{'color':jsonParse.getOperateColor(typeof info === 'object'?info.operate:typeof info === 'string'?info:'')}]">{{typeof info === 'object'?info.operate:typeof info === 'string'?info:''}}</text></view>
				
			</view>
		</uni-popup>
		
		
		
		<uni-popup ref="refMonster" type="center" :custom="true" :mask-click="false">
			<view class="dialogMonster" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">怪物信息</view>
				<view style="display: flex;flex-direction: column;width: 480rpx;height:468rpx;color: #dfe6e9;font-size: 30rpx;">
					<view style="display: flex;flex-direction: row;height: 156rpx;">
						<view @tap="tapMonster('7')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['7']?monsterObj['7'].name:'7'}}</view>
						<view @tap="tapMonster('8')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['8']?monsterObj['8'].name:'8'}}</view>
						<view @tap="tapMonster('9')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['9']?monsterObj['9'].name:'9'}}</view>
					</view>
					<view style="display: flex;flex-direction: row;height: 156rpx;">
						<view @tap="tapMonster('4')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['4']?monsterObj['4'].name:'4'}}</view>
						<view @tap="tapMonster('5')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['5']?monsterObj['5'].name:'5'}}</view>
						<view @tap="tapMonster('6')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['6']?monsterObj['6'].name:'6'}}</view>
					</view>
					<view style="display: flex;flex-direction: row;height: 156rpx;">
						<view @tap="tapMonster('1')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['1']?monsterObj['1'].name:'1'}}</view>
						<view @tap="tapMonster('2')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['2']?monsterObj['2'].name:'2'}}</view>
						<view @tap="tapMonster('3')" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{monsterObj['3']?monsterObj['3'].name:'3'}}</view>
					</view>
				</view>
				
				<view @tap="toCloseDialogMonster" class="dialogButton">返回</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refBusiness" type="center" :custom="true" :mask-click="false">
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{businessInfo.title}}</view>
				<scroll-view scroll-y="true" :style="[{'height':(810-118*businessInfo.bts.length)+'rpx'}]" style="line-height: 40rpx;font-size: 28rpx;color: #818181;width: 480rpx;text-align: center;">
					<view v-for="(info,key,index) in businessInfo.businessObj" :key="index" style="display: flex;flex-direction: row;margin-bottom: 30rpx;">
						<view class="bnLayout">{{key}}</view>
						<view style="display: flex;flex-direction: column;align-items: center;justify-content: center;flex: 1;height: 120rpx;">
							<view v-if="info.chooseCount>0" style="margin-bottom: 16rpx;">{{info.price1}}*{{info.price2*info.chooseCount}}</view>
							<view style="display: flex;flex-direction: row;color: #666666;font-size: 32rpx;">
								<image @tap="tapNumberChange(1,key)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-minus.png"></image>
								<view style="padding: 0 20rpx;">{{info.chooseCount}}/{{info.maxCount}}</view>
								<image @tap="tapNumberChange(2,key)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-add.png"></image>
							</view>
							
						</view>
					</view>
				</scroll-view>
				<view v-for="(text,index) in businessInfo.bts" :key="index" @tap="tapBusiness(text)" class="dialogButton"><text :style="[{'color':jsonParse.getOperateColor(text)}]">{{text}}</text></view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refSpecial" type="center" :custom="true" :mask-click="false">
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{specialInfo.title}}</view>
				<scroll-view scroll-y="true" style="height:690rpx;line-height: 50rpx;font-size: 28rpx;color: #818181;width: 490rpx;text-align: center;">
					<view style="height: 100%;" class="isCenter" v-html="specialInfo.text"></view>
				</scroll-view>
				
				<view v-if="specialInfo.btName" @tap="tapSpecial" class="dialogButton"><text :style="[{'color':jsonParse.getOperateColor(specialInfo.btName)}]">{{specialInfo.btName}}</text></view>
				<view v-else @tap="toCloseDialogSpecial" class="dialogButton">返回</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refMonsterDetail" type="center" :custom="true" :mask-click="false">
			<view class="dialogMonsterDetail" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{monsterInfo.name}}</view>
				<scroll-view scroll-y="true" style="line-height: 54rpx;font-size: 28rpx;color: #dfe6e9;height: 480rpx;width: 420rpx;">
					<view style="display: flex;flex-direction: row;">
						<view style="display: flex;flex-direction: column;flex: 1;">
							<view>气血：{{monsterInfo.p1}}</view>
							<view>神念：{{monsterInfo.p3}}</view>
							<view>破甲：{{monsterInfo.p5}}</view>
							<view>命中：{{monsterInfo.p7?parseInt(monsterInfo.p7*100)+'%':''}}</view>
							<view>暴击：{{monsterInfo.p9?parseInt(monsterInfo.p9*100)+'%':''}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;">
							<view>灵力：{{monsterInfo.p2}}</view>
							<view>肉身：{{monsterInfo.p4}}</view>
							<view>格挡：{{monsterInfo.p6}}</view>
							<view>躲闪：{{monsterInfo.p8?parseInt(monsterInfo.p8*100)+'%':''}}</view>
							<view>抗暴：{{monsterInfo.p10?parseInt(monsterInfo.p10*100)+'%':''}}</view>
						</view>
					</view>
					<block v-if="monsterInfo.dropRate">
						<view style="display: flex;flex-direction: row;margin-top: 30rpx;">
							掉落：
							<view style="display: flex;flex: 1;flex-direction: column;">
								{{monsterInfo.material?monsterInfo.material.replace(/#/g,', '):''}}
							</view>
						</view>
						<view>掉落概率：{{util.keepTwoDecimal(monsterInfo.dropRate*100)}}%</view>
					</block>
				</scroll-view>
				<view @tap="$refs.refMonsterDetail.close()" class="dialogButton">确定</view>
			</view>
		</uni-popup>
		
		<popup-confirm @confirm="tapLeave" ref="refLeave" content="确定要离开地图吗?"></popup-confirm>
		
	</view>
</template>

<script>
	import uniNumberBox from "@/components/uni-number-box/uni-number-box.vue"
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	
	export default {
		components:{
			uniPopup,
			uniNumberBox,
			popupConfirm
		},
		data() {
			return {
				mapId:-1,
				mapName:'',
				left:'left',
				right:'right',
				up:'up',
				down:'down',
				perSize:68,
				pointSplit:'-',
				canMove:true,
				xMax:11,
				yMax:11,
				xCount:10,
				yCount:10,
				x1:0,
				x2:0,
				y1:0,
				y2:0,
				walkConsume:0,
				mapObject:{},
				currPoint:{
					x:1,
					y:1
					
				},
				xPoints:[],
				yPoints:[],
				monsterRate:0,
				vacancyInfo:{},
				chanceInfo:{
					title:'',
					text:'',
					bts:[]
				},
				continueInfo:{
					title:'',
					text:'',
					bts:[]
				},
				taskInfo:{
					mainId:0,
					nextId:0,
					status:0,
					title:'',
					text:'',
					bts:[]
				},
				businessInfo:{
					title:'交易',
					businessObj:{},
					bts:['交易','取消']
				},
				monsterObj:{},
				specialInfo:{
					title:'',
					text:'',
					btName:'',
					btInfo:null
				},
				meetObstacleText:'障碍物无法移动',
				lightUpArray:[],
				sideArray:[],
				spaceTop:0,
				spaceBottom:0,
				spaceLeft:0,
				spaceRight:0,
				llCountInit:0,
				llCount:0,
				passed:false,
				mainTaskIdObj:{},
				taskStatusObj:{},
				monsterInfo:{},
				canTap:true,
				isFight:false
			}
		},
		onLoad(option) {
			_self = this
			_self.perSize = uni.upx2px(68)
			
			_self.initMap(_self.util.toDecodeUri(option))
			_self.updateData()
		},
		mounted() {
			let info = uni.createSelectorQuery().select(".moveDot");
			info.boundingClientRect(function(res) {
				if(res) {
					let spaceLeft = res.left
					let spaceRight = spaceLeft+res.width
					let spaceTop = res.top
					let spaceBottom = spaceTop+res.height
					
					_self.spaceLeft = spaceLeft
					_self.spaceRight = spaceRight
					_self.spaceTop = spaceTop
					_self.spaceBottom = spaceBottom
				}
	　　     }).exec();
		},
		methods: {
			tapLeave() {
				let consumeLl = _self.llCountInit-_self.llCount
				if(consumeLl>0) {
					_self.ajaxUpdate({},function() {
						_self.tapBack()
					})
				}else {
					_self.tapBack()
				}
			},
			handleTap() {
				let cTap = false
				if(_self.canTap) {
					cTap = true
					_self.canTap = false
					setTimeout(function() {
						_self.canTap = true
					},400)
				}
				return cTap
			},
			isMaterialEnough(text) {
				/**
				 * 物品是否足够
				 */
				let isEnough = true
				if(text) {
					let materialObj = getApp().globalData.materialObj
					let cObj = _self.util.getMaterialObj(text)
					Object.keys(cObj).map(key => {
						if(!(materialObj[key] && materialObj[key].count>=cObj[key].count)) {
							isEnough = false
						}
					})
				}
				return isEnough
			},
			updateWalkConsume() {
				let canWalk = true
				if(_self.walkConsume>0) {
					let remainCount = _self.llCount-_self.walkConsume
					if(remainCount<0) {
						canWalk = false
						_self.showToast('灵粮不足')
					}else {
						_self.llCount = remainCount
					}
				}
				return canWalk
			},
			updateData() {
				let materialObj = getApp().globalData.materialObj
				let llObj = materialObj['1-10006']
				if(llObj) {
					_self.llCountInit = llObj.count
					_self.llCount = llObj.count
				}
			},
			tapContainer(e) {
				let eDetail = e.detail
				if(eDetail) {
					const x = eDetail.x
					const y = eDetail.y
					let spaceLeft = _self.spaceLeft
					let spaceRight = _self.spaceRight
					let spaceTop = _self.spaceTop
					let spaceBottom = _self.spaceBottom
					if(spaceLeft || spaceRight || spaceTop || spaceBottom) {
						if(x<spaceLeft && y>spaceTop && y<spaceBottom) {
							_self.tapDirection(_self.left)
						}else if(x>spaceRight && y>spaceTop && y<spaceBottom) {
							_self.tapDirection(_self.right)
						}else if(y<spaceTop) {
							_self.tapDirection(_self.up)
						}else {
							_self.tapDirection(_self.down)
						}
					}
				}
			},
			tapNumberChange(type,key) {
				let itemInfo = _self.businessInfo.businessObj[key]
				let chooseCount = itemInfo.chooseCount
				switch(type) {
					case 1:
						if(chooseCount>0) {
							chooseCount--
						}
						break;
						
					case 2:
						if(chooseCount==itemInfo.maxCount) {
							_self.showToast('已是最大交易数')
						}else {
							chooseCount++
						}
						break;
				}
				if(chooseCount!=itemInfo.chooseCount) {
					itemInfo.chooseCount = chooseCount
				}
			},
			updateLightArray() {
				let sideArray = []
				
				let pointX = _self.currPoint.x
				let pointY = _self.currPoint.y
				let sidePoints = [{
					x:pointX,
					y:pointY
				},{
					x:pointX,
					y:pointY-1
				},{
					x:pointX,
					y:pointY+1
				},{
					x:pointX-1,
					y:pointY
				},{
					x:pointX-1,
					y:pointY-1
				},{
					x:pointX-1,
					y:pointY+1
				},{
					x:pointX+1,
					y:pointY
				},{
					x:pointX+1,
					y:pointY-1
				},{
					x:pointX+1,
					y:pointY+1
				}]
				sidePoints.forEach((data)=>{
					if(data.x>0 && data.x<=_self.xCount && data.y>0 && data.y<=_self.yCount) {
						const xyKey = data.x+_self.pointSplit+data.y
						sideArray.push(xyKey)
						if(_self.lightUpArray.indexOf(xyKey)==-1) {
							_self.lightUpArray.push(xyKey)
						}
					}
				})
				_self.sideArray = sideArray
			},
			tapContinueCallback(info,continueText) {
				if(info.continueId) {
					_self.continueInfo.text = continueText
					let continueBts = []
					let newButton = info.newButton
					newButton.forEach((bt)=>{
						let conArray = _self.jsonParse.getMapContinue(_self.mapId,info.continueId,bt)
						if(conArray.length>0) {
							let rateArray = []
							conArray.forEach((info)=>{
								rateArray.push(info.rate)
							})
							let conInfo = _self.randomData(conArray,rateArray)
							if(conInfo) {
								continueBts.push(conInfo)
							}
						}
					})
					_self.continueInfo.bts = continueBts
				}
			},
			tapContinue(info) {
				if(_self.handleTap()) {
					let result = info.result
					if(result=='关闭弹窗') {
						_self.toCloseDialogContinue()
					}else if(result.indexOf('信息')!=-1) {
						_self.updateMonsterData(result)
					}else {
						let continueText = _self.jsonParse.getMapTextById(info.finishTextId)
						if(result.indexOf('文本')!=-1) {
							continueText = _self.jsonParse.getMapTextById(_self.util.getTextId(result))
						}
						
						let mapPassed = 0
						let mapPassedBonus = ''
						let passBonus = info.passBonus
						if(passBonus) {
							let passBonusArray = passBonus.split('#')
							passBonusArray.forEach((pb)=>{
								if(continueText) {
									continueText += '<br>'
								}
								
								let mt = _self.jsonParse.getMapMaterialGainById(_self.util.getTextId(pb))
								if(mt) {
									continueText += '奖励 '+mt
									mapPassedBonus = _self.jsonParse.getMapMaterialGainById(_self.util.getTextId(pb),1)
								}else {
									continueText += pb
								}
								
								if(pb=='地图通关') {
									mapPassed = 1
								}
							})
						}
						
						let params = {}
						if(mapPassed) {
							params.passed = mapPassed
						}
						if(result.indexOf('消耗')!=-1) {
							// 查询消耗的东西是否拥有，内容格式：轻羽靴*1#灵基石*3   。。。。
							let consumeId = _self.util.getTextId(result)
							let materialConsume = _self.jsonParse.getMapMaterialConsumeById(consumeId)
							if(materialConsume) {
								continueText += '<br>消耗 '+materialConsume
								params.consume = _self.jsonParse.exchangeMapMaterialFormat(_self.jsonParse.getMapMaterialConsumeById(consumeId,1))
							}
							if(mapPassedBonus) {
								params.gain = _self.jsonParse.exchangeMapMaterialFormat(mapPassedBonus)
							}
						}else if(result.indexOf('物品')!=-1) {
							// 将获得这个物品
							let gainId = _self.util.getTextId(result)
							let materialGain = _self.jsonParse.getMapMaterialGainById(gainId)
							let requestGain
							if(materialGain) {
								continueText += '<br>获得 '+materialGain
								requestGain = _self.jsonParse.getMapMaterialGainById(gainId,1)
								if(mapPassedBonus) {
									requestGain += '#'+mapPassedBonus
								}
							}
							if(requestGain) {
								params.gain = _self.jsonParse.exchangeMapMaterialFormat(requestGain)
							}
						}else if(result.indexOf('战斗')!=-1) {
							console.log('战斗')
							params.monsterFormation = result.split('(')[1].replace(')','')
							// params.monsterFormation = '1:10000#3:10000'  // 暂时。。
							if(mapPassedBonus) {
								params.passGain = _self.jsonParse.exchangeMapMaterialFormat(mapPassedBonus)
							}
						}
						
						if(Object.keys(params).length>0) {
							_self.ajaxUpdate(params,function() {
								_self.tapContinueCallback(info,continueText)
							})
						}else {
							_self.tapContinueCallback(info,continueText)
						}
					}
				}
			},
			tapMonster(key) {
				let info = _self.monsterObj[key]
				if(info) {
					_self.monsterInfo = info
					_self.$refs.refMonsterDetail.open()
				}
			},
			toClearCurrPositionData() {
				const currKey = _self.currPoint.x+_self.pointSplit+_self.currPoint.y
				_self.mapObject[currKey].type = _self.vacancyInfo.type
				_self.mapObject[currKey].icon = _self.vacancyInfo.icon
			},
			toOpenDialogLeave() {
				_self.$refs.refLeave.open()
			},
			toCloseDialogBusiness() {
				_self.toClearCurrPositionData()
				_self.$refs.refBusiness.close()
			},
			toOpenDialogBusiness() {
				_self.$refs.refBusiness.open()
			},
			toCloseDialogMonster() {
				_self.$refs.refMonster.close()
			},
			toCloseDialogSpecial() {
				_self.toClearCurrPositionData()
				_self.$refs.refSpecial.close()
			},
			toCloseDialogChance(toClear) {
				_self.$refs.refChance.close()
				if(toClear) {
					// 清除位置信息
					_self.toClearCurrPositionData()
				}
			},
			toCloseDialogContinue() {
				_self.toClearCurrPositionData()
				_self.$refs.refContinue.close()
			},
			toOpenDialogTask() {
				_self.$refs.refTask.open()
			},
			toCloseDialogTask() {
				_self.toClearCurrPositionData()
				_self.$refs.refTask.close()
			},
			tapSpecial() {
				if(_self.handleTap()) {
					let btInfo = _self.specialInfo.btInfo
					if(btInfo) {
						let count = btInfo.count
						let countArray = count.split('-')
						if(countArray.length>1) {
							count = _self.getRandom(parseInt(countArray[1])+1,parseInt(countArray[0]))
						}else {
							count = parseInt(count)
						}
						
						switch(btInfo.type) {
							case "获得":
								let gainArray = _self.jsonParse.getMapSpecialMaterialArray(btInfo.quality)
								let gainInfo = gainArray[_self.getRandom(gainArray.length,0)]
								if(gainInfo) {
									/**
									 * 后台更新   更新成功弹出新文本
									 * 得到随机的材料，能拿到type和id，加上上边的count
									 * {"type":3,"id":30001,"name":"蕴灵草","quality":1,"gainWay":"地图中获得，商店购买","effectDescription":"可以进行丹药炼制","materialDescription":"蕴含灵气的药草，较为普遍，可用作炼制筑基丹的基础材料之一"}
									 */
									_self.ajaxUpdate({
										gain:gainInfo.type+':'+gainInfo.id+':'+count
									},function() {
										_self.specialInfo.text = _self.jsonParse.getMapTextById(btInfo.finishTextId)+'<br>获得 '+gainInfo.name+'*'+count
										_self.specialInfo.btName = ''
									})
								}
								break;
								
							case "扣除":
								let deductArray = []
								let materialObj = getApp().globalData.materialObj
								Object.keys(materialObj).map(key => {
									let obj = materialObj[key]
									if((obj.type==2 || obj.type==3) && obj.count>0) {
										let materialInfo = _self.jsonParse.getMaterialInfo(obj.type,obj.id)
										if(materialInfo && materialInfo.quality<=btInfo.quality) {
											deductArray.push({
												...obj,
												info:materialInfo
											})
										}
									}
								})
								if(deductArray.length>0) {  // 可能不存在
									let deductInfo = deductArray[_self.getRandom(deductArray.length,0)]
									if(deductInfo) {
										/**
										 * 后台更新   更新成功弹出新文本
										 * 扣除自身随机的材料，能拿到type和id
										 * {"type":7,"id":401,"count":1,info:{...}}
										 */
										if(count>deductInfo.count) {
											count = deductInfo.count
										}
										_self.ajaxUpdate({
											consume:deductInfo.type+':'+deductInfo.id+':'+count
										},function() {
											_self.specialInfo.text = _self.jsonParse.getMapTextById(btInfo.finishTextId)+'<br>扣除 '+deductInfo.info.name+'*'+count
											_self.specialInfo.btName = ''
										})
									}
								}else {
									// 如果扣除的不存在，直接显示配置的文本
									_self.specialInfo.text = _self.jsonParse.getMapTextById(btInfo.finishTextId)
									_self.specialInfo.btName = ''
								}
								break;
						}
					}
				}
			},
			tapBusiness(text) {
				if(_self.handleTap()) {
					switch(text) {
						case '交易':
							let priceObj = {}
							let businessText = ''
							let businessObj = _self.businessInfo.businessObj
							
							Object.keys(businessObj).forEach(function(key) {
								let itemObj = businessObj[key]
								let chooseCount = itemObj.chooseCount
								if(chooseCount>0) {
									let priceArray = itemObj.price.split('*')
									if(priceObj[priceArray[0]]) {
										priceObj[priceArray[0]].count += parseInt(priceArray[1])*chooseCount
									}else {
										priceObj[priceArray[0]] = {
											name:priceArray[0],
											count:parseInt(priceArray[1])*chooseCount
										}
									}
									businessText += itemObj.name+'*'+chooseCount+'#'
								}
							})
							
							let priceText = ''  // {"灵石":{"name":"灵石","count":140000}}
							Object.keys(priceObj).forEach(function(key) {
								let itemObj = priceObj[key]
								priceText += itemObj.name+'*'+itemObj.count+'#'
							})
							if(businessText) {
								let params = {}
								if(priceText) {
									priceText = priceText.substr(0,priceText.length-1)
									params.consume = _self.jsonParse.exchangeMapMaterialFormat(priceText)
								}
								businessText = businessText.substr(0,businessText.length-1)
								params.gain = _self.jsonParse.exchangeMapMaterialFormat(businessText)
								_self.ajaxUpdate(params,function() {
									_self.showToast('交易成功')
									_self.toCloseDialogBusiness()
								})
							}else {
								_self.showToast('无交易内容')
							}
							break;
						
						case '取消':
							_self.toCloseDialogBusiness()
							break;
					}
				}
			},
			tapTaskCallback(info,gainConsumeText,jumpNum,taskObj) {
				// 与后台交互  更新上边后显示下边内容
				if(taskObj) {
					_self.taskInfo.mainId = taskObj.mainId
					_self.taskInfo.nextId = taskObj.nextId
					_self.taskInfo.status = taskObj.status
				}
				
				let newButton = info.newButton
				if(newButton.length>0) {
					let taskBts = []
					newButton.forEach((text)=>{
						let taskInfo = _self.jsonParse.getMapTaskInfoByJumpNumber(_self.mapId,_self.taskInfo.mainId,_self.taskInfo.nextId,_self.taskInfo.status,jumpNum,text)
						if(taskInfo) {
							taskBts.push(taskInfo)
						}
					})
					if(taskBts.length>0) {
						_self.taskInfo.title = taskBts[0].name
						_self.taskInfo.text = taskBts[0].initText+gainConsumeText
						_self.taskInfo.bts = taskBts
					}
				}
			},
			tapTask(info,showDialog) {
				if(_self.handleTap()) {
					if(typeof info === 'object') {
						let result = info.result
						let jumpNum = info.jumpNumber
						if(jumpNum) {
							// 存在跳转的，result有数据需要解析
							let params = {}
							let tObj
							let gainConsumeText = ''
							let resultArray = result.split('-')
							resultArray.forEach((text)=>{
								if(text.indexOf('任务')!=-1) {
									let ids = _self.parseTaskIds(text)
									ids.forEach((num,index)=>{
										ids[index] = parseInt(num)
									})
									tObj = {
										mainId: ids[0],
										nextId: ids[1],
										status: ids[2]
									}
									let task = ids[0]+'-'+ids[1]+'='+ids[2]
									if(result.indexOf('战斗')!=-1) {
										params.passTask = task
									}else {
										params.task = task
									}
								}else if(text.indexOf('消耗')!=-1) {
									let consumeId = _self.util.getTextId(text)
									let materialConsume = _self.jsonParse.getMapMaterialConsumeById(consumeId)
									if(materialConsume) {
										gainConsumeText += '<br>消耗 '+materialConsume
										params.consume = _self.jsonParse.exchangeMapMaterialFormat(_self.jsonParse.getMapMaterialConsumeById(consumeId,1))
									}
								}else if(text.indexOf('物品')!=-1) {
									let gainId = _self.util.getTextId(text)
									let materialGain = _self.jsonParse.getMapMaterialGainById(gainId)
									if(materialGain) {
										gainConsumeText += '<br>获得 '+materialGain
										
										let gain = _self.jsonParse.exchangeMapMaterialFormat(_self.jsonParse.getMapMaterialGainById(gainId,1))
										if(result.indexOf('战斗')!=-1) {
											params.passGain = gain
										}else {
											params.gain = gain
										}
									}
								}else if(text.indexOf('战斗')!=-1) {
									params.monsterFormation = text.split('(')[1].replace(')','')
									// params.monsterFormation = '1:10000#3:10000'  // 暂时。。
								}
							})
							
							if(showDialog) {
								_self.tapTaskCallback(info,gainConsumeText,jumpNum,tObj)
							}else {
								if(Object.keys(params).length>0) {
									_self.ajaxUpdate(params,function() {
										_self.tapTaskCallback(info,gainConsumeText,jumpNum,tObj)
									})
								}else {
									_self.tapTaskCallback(info,gainConsumeText,jumpNum,tObj)
								}
							}
							// 进入地图时，状态为1的
							if(showDialog) {
								_self.toOpenDialogTask()
							}
						}else {
							if(result=='结束') {
								_self.taskInfo.title = info.name
								_self.taskInfo.text = info.finishText
								_self.taskInfo.bts = ['结束']
							}else if(result=='关闭弹窗') {
								_self.toCloseDialogTask()
							}else if(result.indexOf('信息')!=-1) {
								_self.updateMonsterData(result)
							}
						}
					}else if(typeof info === 'string') {
						switch(info) {
							case '结束':
								_self.toCloseDialogTask()
								break;
						}
					}
				}
			},
			updateMonsterData(result) {
				let monsterObj = {}
				let messageArray = result.split('(')[1].replace(')','').split('#')
				messageArray.forEach((item)=>{
					let data = item.split(':')
					monsterObj[data[0]] = _self.jsonParse.getMonsterInfoById(parseInt(data[1]))
				})
				_self.monsterObj = monsterObj
				_self.$refs.refMonster.open()
			},
			tapChanceCallback(info,continueText) {
				// 消耗-物品-战斗 后执行。。。
				_self.continueInfo.text = continueText
				let continueBts = []
				let newButton = info.newButton
				newButton.forEach((bt)=>{
					let conArray = _self.jsonParse.getMapContinue(_self.mapId,info.continueId,bt)
					if(conArray.length>0) {
						let rateArray = []
						conArray.forEach((info)=>{
							rateArray.push(info.rate)
						})
						let conInfo = _self.randomData(conArray,rateArray)
						if(conInfo) {
							continueBts.push(conInfo)
						}
					}
				})
				_self.continueInfo.title = _self.chanceInfo.title
				_self.continueInfo.bts = continueBts
				_self.toCloseDialogChance()
				_self.$refs.refContinue.open()
			},
			tapChance(info) {
				if(_self.handleTap()) {
					let result = info.result
					if(result=='关闭弹窗') {
						// 通过奖励可能有数据  比如：物品(10002)#地图通关
						let requestParams = {}
						let passBonus = info.passBonus
						if(passBonus) {
							let passBonusArray = passBonus.split('#')
							passBonusArray.forEach((pb)=>{
								if(pb=='地图通关') {
									requestParams.passed = 1
								}else {
									let mapPassedBonus = _self.jsonParse.getMapMaterialGainById(_self.util.getTextId(pb),1)
									if(mapPassedBonus) {
										// 灵元晶*3#魔元晶*3#精铁矿*8
										params.gain = _self.jsonParse.exchangeMapMaterialFormat(mapPassedBonus)
									}
								}
							})
						}
						if(Object.keys(requestParams).length>0) {
							_self.ajaxUpdate(requestParams,function() {
								_self.toCloseDialogChance(true)
							})
						}else {
							_self.toCloseDialogChance(true)
						}
					}else if(result.indexOf('信息')!=-1) {
						_self.updateMonsterData(result)
					}else {
						if(info.continueId) {
							let continueText = _self.jsonParse.getMapTextById(info.finishTextId)
							if(result.indexOf('文本')!=-1) {
								continueText = _self.jsonParse.getMapTextById(_self.util.getTextId(result))
							}
							
							// passBonus: 物品(10002)#地图通关
							let mapPassed = 0
							let mapPassedBonus = ''
							let passBonus = info.passBonus
							if(passBonus) {
								let passBonusArray = passBonus.split('#')
								passBonusArray.forEach((pb)=>{
									if(continueText) {
										continueText += '<br>'
									}
									
									let mt = _self.jsonParse.getMapMaterialGainById(_self.util.getTextId(pb))
									if(mt) {
										continueText += '奖励 '+mt
										mapPassedBonus = _self.jsonParse.getMapMaterialGainById(_self.util.getTextId(pb),1)
									}else {
										continueText += pb
									}
									
									if(pb=='地图通关') {
										mapPassed = 1
									}
								})
							}
							
							let params = {}
							if(mapPassed) {
								params.passed = mapPassed
							}
							if(result.indexOf('消耗')!=-1) {
								// 查询消耗的东西是否拥有，内容格式：轻羽靴*1#灵基石*3   。。。。
								let consumeId = _self.util.getTextId(result)
								let materialConsume = _self.jsonParse.getMapMaterialConsumeById(consumeId)
								if(materialConsume) {
									continueText += '<br>消耗 '+materialConsume
									params.consume = _self.jsonParse.exchangeMapMaterialFormat(_self.jsonParse.getMapMaterialConsumeById(consumeId,1))
								}
								if(mapPassedBonus) {
									params.gain = _self.jsonParse.exchangeMapMaterialFormat(mapPassedBonus)
								}
							}else if(result.indexOf('物品')!=-1) {
								// 将获得这个物品
								let gainId = _self.util.getTextId(result)
								let materialGain = _self.jsonParse.getMapMaterialGainById(gainId)
								let requestGain
								if(materialGain) {
									continueText += '<br>获得 '+materialGain
									requestGain = _self.jsonParse.getMapMaterialGainById(gainId,1)
									if(mapPassedBonus) {
										requestGain += '#'+mapPassedBonus
									}
								}
								if(requestGain) {
									params.gain = _self.jsonParse.exchangeMapMaterialFormat(requestGain)
								}
							}else if(result.indexOf('战斗')!=-1) {
								console.log('战斗')
								params.monsterFormation = result.split('(')[1].replace(')','')
								// params.monsterFormation = '1:10000#3:10000'  // 暂时。。
								if(mapPassedBonus) {
									params.passGain = _self.jsonParse.exchangeMapMaterialFormat(mapPassedBonus)
								}
							}
							
							if(Object.keys(params).length>0) {
								_self.ajaxUpdate(params,function() {
									_self.tapChanceCallback(info,continueText)
								})
							}else {
								_self.tapChanceCallback(info,continueText)
							}
						}
					}
				}
			},
			tapDirection(arrow) {
				let currX = _self.currPoint.x
				let currY = _self.currPoint.y
				switch(arrow) {
					case _self.left:
						currX--
						break;
						
					case _self.right:
						currX++
						break;
						
					case _self.up:
						currY--
						break;
						
					case _self.down:
						currY++
						break;
				}
				let currPoint = _self.mapObject[currX+_self.pointSplit+currY]
				if(currPoint) {
					if(currPoint.type==2) {
						_self.showToast(_self.meetObstacleText)
					}else if(_self.canMove && _self.updateWalkConsume()) {
						_self.canMove = false
						switch(arrow) {
							case _self.left:
								if(_self.x1>5) {
									_self.x1--
								}else {
									if(_self.y1<0) {
										_self.y1++
									}else {
										_self.x1--
									}
								}
								_self.currPoint.x--
								break;
							
							case _self.right:
								if(_self.x1==5 && _self.xCount>_self.xMax) {
									if(-_self.y1<(_self.xCount-_self.xMax)) {
										_self.y1--
									}else {
										_self.x1++
									}
								}else {
									_self.x1++
								}
								_self.currPoint.x++
								break;
								
							case _self.up:
								if(_self.x2>5) {
									_self.x2--
								}else {
									if(_self.y2<0) {
										_self.y2++
									}else {
										_self.x2--
									}
								}
								_self.currPoint.y--
								break;
								
							case _self.down:
								if(_self.x2==5 && _self.yCount>_self.yMax) {
									if(-_self.y2<(_self.yCount-_self.yMax)) {
										_self.y2--
									}else {
										_self.x2++
									}
								}else {
									_self.x2++
								}
								_self.currPoint.y++
								break;
						}
						_self.updateLightArray()
						
						setTimeout(function() {
							let canMoveDelay = 500
							
							if(currPoint.type==5) {
								_self.meetJump(currPoint.elementId,currPoint.textId)
								
							}else if(currPoint.type==4 || currPoint.type==7) {
								// 区别：如果通关地图，类型7不会出现
								_self.chanceInfo.text = _self.jsonParse.getMapTextById(currPoint.textId)
								_self.meetChance(currPoint.elementId)
							}else if(currPoint.type==6) {
								// 任务点
								_self.meetTaskPoint(currPoint.preTask)
							}else if(currPoint.type==8) {
								_self.meetBusiness(currPoint.elementId)
							}else if(currPoint.type==9) {
								// 特殊点
								_self.specialInfo.text = _self.jsonParse.getMapTextById(currPoint.textId)
								_self.meetSpecial(currPoint.elementId)
							}else {
								let masterObject
								const ps = [{
									x:currX-1,
									y:currY
								},{
									x:currX+1,
									y:currY
								},{
									x:currX,
									y:currY-1
								},{
									x:currX,
									y:currY+1
								}]
								// 触发点判别有2个怪物。。打完一个接续打另一个  这里记录可能遇到的所有怪，储存到全局
								ps.forEach((p)=>{
									const master = _self.mapObject[p.x+_self.pointSplit+p.y]
									if(master && master.type==3) {
										masterObject = master
									}
								})
								if(masterObject) {
									// 遇到怪物
									_self.meetMonster(masterObject.elementId)
									
									const masterKey = masterObject.x+_self.pointSplit+masterObject.y
									_self.mapObject[masterKey].type = _self.vacancyInfo.type
									_self.mapObject[masterKey].icon = _self.vacancyInfo.icon
								}else if(currPoint.type==1) {
									// 空格并且无怪物
									if(_self.monsterRate>0) {
										if(_self.whetherExcuteByRate(_self.monsterRate)) {
											// 概率遇怪
											_self.meetMonster(currPoint.elementId)
										}else {
											canMoveDelay = 0
										}
									}else {
										canMoveDelay = 0
									}
								}
							}
							
							if(canMoveDelay) {
								setTimeout(function() {
									_self.canMove = true
								},canMoveDelay)
							}else {
								_self.canMove = true
							}
						},200)
					}
				}
			},
			parseTaskIds(text) {
				return text.split('(')[1].replace(')','').split(',')
			},
			meetSpecial(elementId) {
				let specialArray = _self.jsonParse.getSpecialArray(_self.mapId,elementId)
				let rateArray = []
				specialArray.forEach((info)=>{
					rateArray.push(info.rate)
				})
				let specialInfo = _self.randomData(specialArray,rateArray)
				if(specialInfo) {
					_self.specialInfo.title = specialInfo.eventName
					_self.specialInfo.btName = specialInfo.bt
					_self.specialInfo.btInfo = specialInfo
					_self.$refs.refSpecial.open()
				}
			},
			meetBusiness(elementId) {
				let businessTitle = ''
				let businessObj = {}
				let businessArray = _self.jsonParse.getBusinessArray(_self.mapId,elementId)
				businessArray.forEach((info)=>{
					if(_self.whetherExcuteByRate(info.rate)) {
						let count = info.count
						if(count.indexOf('-')!=-1) {
							let countArray = count.split('-')
							if(countArray.length>1) {
								info.maxCount = _self.getRandom(parseInt(countArray[1])+1,parseInt(countArray[0]))
							}
						}else {
							info.maxCount = parseInt(count)
						}
						let priceArray = info.price.split('*')
						info.price1 = priceArray[0]
						info.price2 = parseInt(priceArray[1])
						
						info.chooseCount = 0
						businessObj[info.name] = info
						businessTitle = info.title
					}
				})
				_self.businessInfo.title = businessTitle
				_self.businessInfo.businessObj = businessObj
				_self.toOpenDialogBusiness()
			},
			meetTaskPoint(preTask) {
				// 解析前置任务状态，进地图后端会返回任务的状态，虚拟默认为0，进行中为1  任务(1,1)
				try {
					let ids = _self.parseTaskIds(preTask)
					let mainId = parseInt(ids[0])
					let nextId = parseInt(ids[1])
					let taskStatus = _self.taskStatusObj[mainId+'-'+nextId]
					if(!taskStatus) {
						taskStatus = 0
					}
					_self.taskInfo.mainId = mainId
					_self.taskInfo.nextId = nextId
					_self.taskInfo.status = taskStatus
					if(taskStatus==0) {
						let taskArray = _self.jsonParse.getMapTaskArray(_self.mapId,mainId,nextId,taskStatus)
						let taskObj = {}
						taskArray.forEach((info)=>{
							if(taskObj[info.operate]) {
								taskObj[info.operate].push(info)
							}else {
								taskObj[info.operate] = [info]
							}
						})
						let taskBts = []
						Object.keys(taskObj).forEach(function(key) {
							let typeArray = taskObj[key]
							if(typeArray.length==1) {
								taskBts.push(typeArray[0])
							}else {
								let isEnough = false    // 只可能出现下边任一情况，没有则是【其他】
								typeArray.forEach((item)=>{
									/**
									 * 判断限制条件   多种情况，每次添加新的需要加上。。
									 */
									const limitText = item.limit
									if(limitText.indexOf('*')!=-1) {
										/**
										 * 铁矿*50、相思玉*1、雷之虚相*1、灵秀玉佩*1
										 * exchangeData - 4:40029:1
										 */
										let exchangeData = _self.jsonParse.exchangeMapMaterialFormat(limitText)
										if(exchangeData) {
											isEnough = _self.isMaterialEnough(exchangeData)
											if(isEnough) {
												taskBts.push(item)
											}
										}
									}else if(limitText=='门派为正道') {
										if(getApp().globalData.sectView.sectType==1) {
											isEnough = true
											taskBts.push(item)
										}
									}else if(limitText=='门派为魔道') {
										if(getApp().globalData.sectView.sectType==2) {
											isEnough = true
											taskBts.push(item)
										}
									}else if(limitText=='其他' && !isEnough) {
										taskBts.push(item)
									}
								})
							}
						})
						if(taskBts.length>0) {
							_self.taskInfo.text = taskBts[0].initText
							_self.taskInfo.title = taskBts[0].name
							_self.taskInfo.bts = taskBts
							_self.toOpenDialogTask()
						}
					}else if(taskStatus==1) {
						let taskInfo = _self.jsonParse.getMapTaskInfo(_self.mapId,mainId,nextId)
						if(taskInfo) {
							_self.tapTask(taskInfo,true)
						}
					}
				}catch(e) {
					console.log(e.toString())
				}
			},
			meetChance(elementId) {
				let chanceArray = _self.jsonParse.getChanceArray(_self.mapId,elementId)
				let chanceObj = {}
				chanceArray.forEach((info)=>{
					if(chanceObj[info.operate]) {
						chanceObj[info.operate].push(info)
					}else {
						chanceObj[info.operate] = [info]
					}
				})
				let chanceBts = []
				Object.keys(chanceObj).forEach(function(key) {
					let typeArray = chanceObj[key]
					if(typeArray.length==1) {
						chanceBts.push(typeArray[0])
					}else {
						let rateArray = []
						typeArray.forEach((info)=>{
							rateArray.push(info.rate)
						})
						let chanceInfo = _self.randomData(typeArray,rateArray)
						if(chanceInfo) {
							chanceBts.push(chanceInfo)
						}
					}
				})
				
				if(chanceBts.length>0) {
					_self.chanceInfo.title = chanceBts[0].title
					_self.chanceInfo.bts = chanceBts
					_self.$refs.refChance.open()
				}
			},
			meetJump(elementId,textId) {
				let jumpArray = _self.jsonParse.getJumpArray(_self.mapId,elementId)
				if(jumpArray.length>0) {
					let rateArray = []
					jumpArray.forEach((info)=>{
						rateArray.push(info.rate)
					})
					
					let jumpInfo = _self.randomData(jumpArray,rateArray)
					if(jumpInfo) {
						_self.navigateTo(_self.util.toEncodeUri('/pages/map/map',{
							mapId:jumpInfo.targetMapId
						}))
					}
				}
			},
			meetMonster(elementId) {
				let fightArray = _self.jsonParse.getMapFight(_self.mapId,elementId)
				if(fightArray.length>0) {
					let rateArray = []
					fightArray.forEach((info)=>{
						rateArray.push(info.rate)
					})
					
					let fightInfo = _self.randomData(fightArray,rateArray)
					if(fightInfo) {
						_self.ajaxUpdate({
							monsterFormation:fightInfo.result.split('(')[1].replace(')','')
						})
					}
				}
			},
			tapPoint(x,y) {
				let direction = _self.down
				const currX = _self.currPoint.x
				const currY = _self.currPoint.y
				if(x<currX && y>=(currY-1) && y<=currY+1) {
					direction = _self.left
				}else if(x>currX && y>=(currY-1) && y<=currY+1) {
					direction = _self.right
				}else if(y<currY) {
					direction = _self.up
				}
				_self.tapDirection(direction)
			},
			whetherInitByWeek(appearDay) {
				let isOk = false
				
				let currDay = new Date().getDay()
				let dayArray = []
				let days = appearDay.split('#')
				days.forEach((text)=>{
					if(text.indexOf('-')!=-1) {
						let textArray = text.split('-')
						let t1 = parseInt(textArray[0])
						let t2 = parseInt(textArray[1])+1
						for(let i=t1;i<t2;i++) {
							dayArray.push(i)
						}
					}else {
						dayArray.push(parseInt(text))
					}
				})
				if(dayArray.indexOf(currDay)!=-1) {
					isOk = true
				}
				return isOk
			},
			whetherExcuteByRate(rate) {
				return _self.randomData([true,false],[rate,1-rate])
			},
			randomData(arr1, arr2) {
			    var sum = 0,
			        factor = 0,
			        random = Math.random();
			
			    for(var i = arr2.length - 1; i >= 0; i--) {
			        sum += arr2[i]; // 统计概率总和
			    }
			    random *= sum; // 生成概率随机数
			    for(var i = arr2.length - 1; i >= 0; i--) {
			        factor += arr2[i];
			        if(random <= factor) 
			          return arr1[i];
			    }
			    return null;
			},
			getRandom(m,n) {
				var num = Math.floor(Math.random()*(m - n) + n)
				return num
			},
			getPointArray(xRange, yRange,count,points) {
				let x = xRange
				const xArray = xRange.split('-')
				if(xArray.length>1) {
					x = _self.getRandom(parseInt(xArray[1])+1,parseInt(xArray[0]))
				}
				
				let y = yRange
				const yArray = yRange.split('-')
				if(yArray.length>1) {
					y = _self.getRandom(parseInt(yArray[1])+1,parseInt(yArray[0]))
				}
				
				const point = x+_self.pointSplit+y
				if(points.indexOf(point)==-1) {
					points.push(point)
					if(points.length==count) {
						return points
					}else {
						return _self.getPointArray(xRange,yRange,count,points)
					}
				}else {
					return _self.getPointArray(xRange,yRange,count,points)
				}
			},
			initMap(detail) {
				let resData = detail.resData
				_self.passed = resData.passed
				
				let tasks = resData.tasks
				if(tasks) {
					let taskStatusObj = {}
					let taskArray = tasks.split('#')
					taskArray.forEach((item)=>{
						let itemArray = item.split('=')
						taskStatusObj[itemArray[0]] = parseInt(itemArray[1])
					})
					_self.taskStatusObj = taskStatusObj
				}
				
				_self.mapId = detail.mapId
				let mapInfo = _self.jsonParse.getMapInfo(_self.mapId)
				if(mapInfo) {
					_self.mapName = mapInfo.mapName
					_self.walkConsume = mapInfo.walkConsume
					const specificationArray = mapInfo.mapSpecification.split('*')
					const s1 = parseInt(specificationArray[0])
					const s2 = parseInt(specificationArray[1])
					if(s1<_self.xMax) {
						_self.xMax = s1
					}
					if(s2<_self.yMax) {
						_self.yMax = s2
					}
					_self.xCount = s1
					_self.yCount = s2
					_self.monsterRate = mapInfo.monsterRate
					
					let elementArray = _self.jsonParse.getMapElement(_self.mapId)
					elementArray.sort(function(a,b){
						return a.priority - b.priority
					})
					
					let mapObject = {}
					for(let y=1;y<(_self.yCount+1);y++) {
						for(let x=1;x<(_self.xCount+1);x++) {
							let space = {
								...elementArray[0],
								x:x,
								y:y
							}
							mapObject[x+_self.pointSplit+y] = space
						}
					}
					_self.vacancyInfo = elementArray[0]
					
					// 默认index为0时为空位 。
					for(let index=0;index<elementArray.length;index++) {
						let info = elementArray[index]
						if(index>0 && _self.whetherExcuteByRate(info.initRate) && _self.whetherInitByWeek(info.appearDay)) {
							if(info.type==6) {
								/**
								 * 只包含一个主任务
								 * 设定：主任务ID相同，分任务ID从1开始
								 * preTask - 任务(10,2)
								 */
								let preTaskArray = info.preTask.split('(')[1].replace(')','').split(',')
								let pt0 = preTaskArray[0]
								let pt1 = preTaskArray[1]
								if(_self.mainTaskIdObj[pt0]) {
									continue
								}else {
									let statusKey = pt0+'-'+pt1
									let taskStatus = _self.taskStatusObj[statusKey]
									if(taskStatus) {
										if(taskStatus==2) {
											continue
										}else {
											_self.mainTaskIdObj[pt0] = '1'
										}
									}else {
										// if(pt1==1) {
										// 	_self.mainTaskIdObj[pt0] = '1'
										// }else {
										// 	continue
										// }
										_self.mainTaskIdObj[pt0] = '1'
									}
								}
							}else if(info.type==7 && _self.passed) {
								continue
							}
							let count = info.count
							let countArray = count.split('-')
							if(countArray.length>1) {
								// count = parseInt(countArray[1])  // 测试。。
								count = _self.getRandom(parseInt(countArray[1])+1,parseInt(countArray[0]))
							}else {
								count = parseInt(count)
							}
							
							if(count>0) {
								let points = _self.getPointArray(info.x,info.y,count,[])
								points.forEach((point)=>{
									let pArray = point.split(_self.pointSplit)
									mapObject[point] = {
										...info,
										x:pArray[0],
										y:pArray[1]
									}
								})
							}
						}
					}
					_self.mapObject = mapObject
					
					let yPoints = []
					let xPoints = []
					for(let x=1;x<(_self.xCount+1);x++) {
						xPoints.push(x)
					}
					for(let y=1;y<(_self.yCount+1);y++) {
						yPoints.push(y)
					}
					_self.yPoints = yPoints
					_self.xPoints = xPoints
					
					let x1 = 0
					let x2 = 0
					let y1 = 0
					let y2 = 0
					
					let orginPoints = mapInfo.initPoint.replace('(','').replace(')','').split(',')
					let orginX = parseInt(orginPoints[0])
					let orginY = parseInt(orginPoints[1])
					_self.currPoint.x = orginX
					_self.currPoint.y = orginY
					_self.updateLightArray()
					if(orginX>6) {
						if(_self.xCount>_self.xMax) {
							x1 = 5
							y1 = 5+1-orginX
							if(-y1>_self.xCount-_self.xMax) {
								y1 = -(_self.xCount-_self.xMax)
								x1 += orginX-5-1+y1
							}
						}else {
							x1 = orginX-1
						}
					}else {
						x1 = orginX-1
					}
					if(orginY>6) {
						if(_self.yCount>_self.yMax) {
							x2 = 5
							y2 = 5+1-orginY
							if(-y2>_self.yCount-_self.yMax) {
								y2 = -(_self.yCount-_self.yMax)
								x2 += orginY-5-1+y2
							}
						}else {
							x2 = orginY-1
						}
					}else {
						x2 = orginY-1
					}
					_self.x1 = x1
					_self.x2 = x2
					_self.y1 = y1
					_self.y2 = y2
				}
			},
			tapBt() {
				this.$refs.refText.open()
			},
			tapDiscipleProperty() {
				_self.navigateTo('/pages/disciple/disciple-property')
			},
			tapBreakThrough() {
				_self.navigateTo('/pages/disciple/disciple-break-through')
			},
			tapSkill() {
				_self.navigateTo('/pages/disciple/disciple-skill')
			},
			tapEquip() {
				_self.navigateTo('/pages/disciple/disciple-equip-list')
			},
			tapBack() {
				uni.navigateBack({
					delta:1
				})
			},
			ajaxUpdate(params,callback,hideLoading) {
				params.mapId = _self.mapId
				// 暂时处理
				if(params.monsterFormation) {
					params.monsterFormation = params.monsterFormation.replace(/:/g,'=')
					
					if(_self.isFight) {
						// 避免多次触发
						return
					}else {
						_self.isFight = true
					}
				}
				
				// 扣除消耗的灵粮
				let consumeLl = _self.llCountInit-_self.llCount
				if(consumeLl>0) {
					if(params.consume) {
						params.consume = params.consume+'#1:10006:'+consumeLl
					}else {
						params.consume = '1:10006:'+consumeLl
					}
				}
				
				/**
				 * 如果是战斗
				 * 获得物品和地图通关需要结果成功再发起请求 - 通过奖励
				 * passGain  passed
				 */
				let rewardParams = {}
				if(params.monsterFormation) {
					if(params.passGain) {
						rewardParams.gain = params.passGain
						delete params.passGain
					}
					if(params.passed) {
						rewardParams.passed = params.passed
						delete params.passed
					}
					if(params.passTask) {
						rewardParams.task = params.passTask
						delete params.passTask
					}
				}
				
				let isEnough = _self.isMaterialEnough(params.consume)
				if(isEnough) {
					var option = {}
					option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
					option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = hideLoading 
					option[_self.$req.REQUEST_OPTION.PARAMETER] = {
						cmd:'5_4',
						params:params
					}
					option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
						if(resData) {
							let gainItems = resData.gainItems
							let battleResult = resData.battleResult
							if(gainItems) {
								_self.util.addDiscipleArray(gainItems.disciples)
								_self.util.addEquipArray(gainItems.equips)
								_self.util.updateMaterialObj(gainItems.gain,false)
							}
							if(battleResult) {
								// 通过奖励
								if(Object.keys(rewardParams).length>0 && battleResult.win) {
									_self.ajaxUpdate(rewardParams,null,true)
								}
								
								let dropItems = resData.dropItems
								_self.util.addDiscipleArray(dropItems.disciples)
								_self.util.addEquipArray(dropItems.equips)
								_self.util.updateMaterialObj(dropItems.consume,true)
								_self.util.updateMaterialObj(dropItems.gain,false)
								
								_self.navigateTo(_self.util.toEncodeUri('/pages/fight/fight',{
									resData:resData,
									typeText:'map'
								}),function() {
									_self.isFight = false
								})
							}
							_self.updateData()
							if(callback) {
								if(battleResult) {
									setTimeout(function() {
										callback()
									},500)
								}else {
									callback()
								}
							}
						}
					}
					option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {
						_self.isFight = false
					}
					option[_self.$req.REQUEST_OPTION.ERROR] = function() {
						_self.isFight = false
					}
					_self.$req.handleRequest(option)
				}else {
					_self.isFight = false
					_self.showToast('物品不足')
				}
			},
			ajaxLeave() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'5_7',
					params:{
						mapId:_self.mapId
					}
					
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.tapBack()
				}
				_self.$req.handleRequest(option)
			},
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/map_bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout {
		width: 190rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-left: 124rpx;
		background:url(../../static/disciple-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.iconBack {
		width: 64rpx;
		height: 64rpx;
		margin-top: 18rpx;
		left: 24rpx;
		vertical-align: top;
		position: absolute;
	}
	
	.cententLayout {
		width: 100%;
		height: 680rpx;
		background:url(../../static/disciple-bg-character-image.png) center center no-repeat;background-size: 574rpx 100%;
	}
	
	.topLayout {
		padding-top: var(--status-bar-height);
	}
	
	.mapContainer {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
		height: 748rpx;
		height: calc(100vh - var(--status-bar-height) - 120rpx);
	}
	
	.dialogLayout {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogButton {
		width: 460rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		text-align: center;
		margin-top: 30rpx;
		background:url(../../static/map-dialog-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogMonster {
		width: 568rpx;
		height: 762rpx;
		background:url(../../static/market-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogMonsterDetail {
		width: 568rpx;
		height: 762rpx;
		background:url(../../static/market-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bnLayout {
		width: 226rpx;
		height: 120rpx;
		line-height: 40rpx;
		padding-top: 4rpx;
		font-size: 28rpx;
		color: #FFFFFF;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		
		background:url(../../static/disciple-equip-list-bg-item.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
