<template>
	<view class="container">
		<cu-custom :handleBack="true" :isBack="true" @handleBack="handleBack">
			<block slot="content">设置队列</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;align-items: center;">
			<view style="display: flex;flex-direction: column;width: 690rpx;margin: 34rpx 0;color: #818181;font-size: 30rpx;border: solid 1px #666666;border-radius: 10rpx;">
				<view style="display: flex;flex-direction: row;height: 160rpx;border-bottom: solid 1px #666666;">
					<view @tap="tapItem(1)" :class="activePosition==1?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{queueObj['1']?queueObj['1'].nm:'1'}}</view>
					<view @tap="tapItem(2)" :class="activePosition==2?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;border-left: solid 1px #666666;">{{queueObj['2']?queueObj['2'].nm:'2'}}</view>
					<view @tap="tapItem(3)" :class="activePosition==3?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;border-left: solid 1px #666666;">{{queueObj['3']?queueObj['3'].nm:'3'}}</view>
				</view>
				<view style="display: flex;flex-direction: row;height: 160rpx;border-bottom: solid 1px #666666;">
					<view @tap="tapItem(4)" :class="activePosition==4?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{queueObj['4']?queueObj['4'].nm:'4'}}</view>
					<view @tap="tapItem(5)" :class="activePosition==5?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;border-left: solid 1px #666666;">{{queueObj['5']?queueObj['5'].nm:'5'}}</view>
					<view @tap="tapItem(6)" :class="activePosition==6?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;border-left: solid 1px #666666;">{{queueObj['6']?queueObj['6'].nm:'6'}}</view>
				</view>
				<view style="display: flex;flex-direction: row;height: 160rpx;">
					<view @tap="tapItem(7)" :class="activePosition==7?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;">{{queueObj['7']?queueObj['7'].nm:'7'}}</view>
					<view @tap="tapItem(8)" :class="activePosition==8?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;border-left: solid 1px #666666;">{{queueObj['8']?queueObj['8'].nm:'8'}}</view>
					<view @tap="tapItem(9)" :class="activePosition==9?'c-FFFFFF':''" style="display: flex;flex: 1;justify-content: center;align-items: center;border-left: solid 1px #666666;">{{queueObj['9']?queueObj['9'].nm:'9'}}</view>
				</view>
			</view>
			
			<scroll-view v-if="Object.keys(queueObj).length>0" scroll-y="true" class="sv" style="border: solid 1px #666666;border-radius: 10rpx;width: 630rpx;color: #FF0000;font-size: 32rpx;color: #EEEEEE;padding: 0 30rpx;">
				<view style="display: flex;flex-direction: column;line-height: 60rpx;font-size: 30rpx;color: #FFFFFF;margin-top: 20rpx;">
					<view class="c-FFFFFF">
						修真境界：<text :class="'gr-'+greatRealm">{{greatRealmName}}</text><text style="margin-left: 30rpx;" :class="'sr-'+greatRealm+'-'+smallRealm">{{smallRealmName}}</text>
					</view>
					<view class="c-FFCC00">先天体质：<text :class="'m-'+physiqueQuality">{{physique}}</text></view>
				</view>
				
				<view style="display: flex;flex-direction: row;line-height: 60rpx;font-size: 30rpx;color: #FFFFFF;margin-top: 20rpx;">
					<view style="display: flex;flex-direction: column;flex: 1;">
						<view class="flex-row p-1">气血：<view class="width-80" :class="totalProperty?'m-'+totalProperty['1'].toString().length:''">{{totalProperty?totalProperty['1']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['1']+' )':''}}</text></view>
						<view class="flex-row p-3">神念：<view class="width-80" :class="totalProperty?'m-'+totalProperty['3'].toString().length:''">{{totalProperty?totalProperty['3']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['3']+' )':''}}</text></view>
						<view class="flex-row p-5">破甲：<view class="width-80" :class="totalProperty?'m-'+totalProperty['5'].toString().length:''">{{totalProperty?totalProperty['5']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['5']+' )':''}}</text></view>
						<view class="flex-row p-7">命中：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['7']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['7']*100)+'% )':''}}</text></view>
						<view class="flex-row p-9">暴击：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['9']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['9']*100)+'% )':''}}</text></view>
					</view>
					<view style="display: flex;flex-direction: column;flex: 1;">
						<view class="flex-row p-2">灵力：<view class="width-80" :class="totalProperty?'m-'+totalProperty['2'].toString().length:''">{{totalProperty?totalProperty['2']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['2']+' )':''}}</text></view>
						<view class="flex-row p-4">肉身：<view class="width-80" :class="totalProperty?'m-'+totalProperty['4'].toString().length:''">{{totalProperty?totalProperty['4']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['4']+' )':''}}</text></view>
						<view class="flex-row p-6">格挡：<view class="width-80" :class="totalProperty?'m-'+totalProperty['6'].toString().length:''">{{totalProperty?totalProperty['6']:''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+basicProperty['6']+' )':''}}</text></view>
						<view class="flex-row p-8">躲闪：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['8']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['8']*100)+'% )':''}}</text></view>
						<view class="flex-row p-10">抗暴：<view class="width-80 c-FFFF00">{{totalProperty?parseInt(totalProperty['10']*100)+'%':''}}</view><text class="c-cdc7c3">{{basicProperty?' ( '+parseInt(basicProperty['10']*100)+'% )':''}}</text></view>
					</view>
				</view>
				
			</scroll-view>
		</view>
		
		
		<view v-if="Object.keys(queueObj).length>0" style="width: 100%;display: flex;flex-direction: row;position: absolute;bottom: 40rpx;">
			<view @tap="tapReplace" class="btLayout1">替换</view>
			<view @tap="tapOff" class="btLayout1">下阵</view>
		</view>
		
		<popup-confirm @confirm="tapLeave" ref="refLeave" content="保存队列" :closeAction="true" @close="toBack"></popup-confirm>
	</view>
</template>

<script>
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	var _self
	
	export default {
		components:{
			uniPopup,
			popupConfirm
		},
		data() {
			return {
				discipleArray:[],
				queueObj:{},
				
				greatRealm:0,
				smallRealm:0,
				greatRealmName:'',
				smallRealmName:'',
				physique:'',
				physiqueQuality:0,
				basicProperty:null,
				totalProperty:null,
				
				activePosition:-1,
				queueText:'',
				queueChangeText:''
			}
		},
		onLoad() {
			_self = this
			_self.getQueueValue()
			
			let disciples = JSON.parse(JSON.stringify(getApp().globalData.disciples))  // 不改变全局数据
			let queueText = _self.queueText   // 保存的队列  1=id#2=id
			if(queueText) {
				let queueArray = queueText.split('#')
				queueArray.forEach((text,index)=>{
					let itemArray = text.split('=')
					let t0 = parseInt(itemArray[0])
					let t1 = parseInt(itemArray[1])
					
					let disciple = disciples[disciples.findIndex(item => item.id==t1)]
					if(disciple) {
						if(_self.activePosition==-1) {
							_self.activePosition = t0
							_self.fillData(disciple)
						}
						_self.queueObj[t0] = disciple
					}
				})
			}else {
				// 没有队列，默认上掌门  在第一个位置，并且保存数据
				let disciple = disciples[disciples.findIndex(item => item.pstn==1)]
				if(disciple) {
					_self.activePosition = 1
					_self.fillData(disciple)
					_self.queueObj['1'] = disciple
					
					let qText = '1='+disciple.id
					_self.queueText = qText
					_self.keepQueueValue(qText)
				}
			}
			uni.$on('choose',_self.chooseCallback)
		},
		onUnload() {
			uni.$off('choose',_self.chooseCallback)
		},
		methods: {
			toBack() {
				uni.navigateBack({
					delta:1
				})
			},
			tapLeave() {
				_self.keepQueueValue(_self.queueChangeText)
				_self.toBack()
			},
			handleBack() {
				let queueArray = []
				let queueObj = _self.queueObj
				Object.keys(queueObj).map(k => {
					let obj = queueObj[k]
					if(obj) {
						queueArray.push(k+'='+obj.id)
					}
				})
				let queueChangeText = queueArray.toString().replace(/,/g,'#')
				if(queueChangeText && queueChangeText!=_self.queueText) {
					/**
					 * 修改过队列，判断是否含有主角
					 * 不满足条件：toast
					 * 满足条件：弹框确认
					 * 首先获取主角的id
					 */
					let masterId = ''
					let disciples = getApp().globalData.disciples
					disciples.forEach((disciple)=>{
						if(_self.util.isMaster(disciple.pstn)) {
							masterId = disciple.id
						}
					})
					if(queueChangeText.indexOf('='+masterId)!=-1) {
						_self.queueChangeText = queueChangeText
						_self.$refs.refLeave.open()
					}else {
						_self.showToast('上阵队列需包含掌门')
					}
				}else {
					_self.toBack()
				}
			},
			keepQueueValue(value) {
				// 保存战斗队列
				try {
				    uni.setStorageSync(_self.util.getStorageQueueKey(), value)
				} catch (e) {}
			},
			getQueueValue() {
				// 获取战斗队列 
				try {
				    const value = uni.getStorageSync(_self.util.getStorageQueueKey())
				    if (value) {
						_self.queueText = value
				    }
				} catch (e) {}
			},
			tapReplace() {
				_self.toChoose(_self.activePosition)
			},
			tapOff() {
				delete _self.queueObj[_self.activePosition]
				
				let disciple
				let activePosition = -1
				for(let i=1;i<10;i++) {
					disciple = _self.queueObj[i]
					if(disciple) {
						activePosition = i
						break;
					}
				}
				
				_self.activePosition = activePosition
				if(disciple) {
					_self.fillData(disciple)
				}
				_self.$forceUpdate()
			},
			fillData(detail) {
				_self.greatRealmName = detail.realm.greatRealmName
				_self.smallRealmName = detail.realm.smallRealmName
				
				_self.greatRealm = detail.rm
				_self.smallRealm = detail.rml
				
				_self.basicProperty = _self.util.parseProperty(detail.bp)
				_self.totalProperty = _self.util.parseProperty(detail.tp)
				
				const physiqueInfo = _self.jsonParse.getPhysiqueGift(detail.ps)
				if(physiqueInfo) {
					_self.physique = physiqueInfo.name
					_self.physiqueQuality = physiqueInfo.quality
				}else {
					_self.physique = '无'
					_self.physiqueQuality = 1
				}
			},
			chooseCallback(e) {
				const key = e.key
				const disciple = e.disciple
				_self.activePosition = key
				_self.queueObj[key] = disciple
				_self.fillData(disciple)
				_self.$forceUpdate()
			},
			toChoose(key) {
				let discipleIds = []
				let queueObj = _self.queueObj
				Object.keys(queueObj).map(k => {
					if(queueObj[k]) {
						discipleIds.push(queueObj[k].id)
					}
				})
				_self.navigateTo(_self.util.toEncodeUri('/pages/map/settle-queue-choose',{
					key:key,
					discipleIds:discipleIds
				}))
			},
			tapItem(key) {
				let disciple = _self.queueObj[key]
				if(disciple) {
					if(key!=_self.activePosition) {
						_self.activePosition = key
						_self.fillData(disciple)
					}
				}else {
					console.log(_self.queueObj)
					if(Object.keys(_self.queueObj).length<4) {
						_self.toChoose(key)
					}else {
						_self.showToast('上阵总人数不超过4')
					}
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout1 {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-left: 86rpx;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout2 {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #999999;
		margin-left: 86rpx;
		background:url(../../static/skill-bt-normal.png) center center no-repeat;background-size:100% 100%;
	}
	
	.sv {
		height: calc(100vh - 830rpx - var(--status-bar-height));
	}
	
</style>
