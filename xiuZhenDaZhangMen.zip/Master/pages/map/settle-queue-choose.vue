<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">选择弟子</block>
		</cu-custom>
		
		<view class="listHeight" style="display: flex;flex-direction: column;align-items: center;overflow: scroll;">
			<block v-if="discipleArray.length>0">
				<view @tap="tapChoose(info)" v-for="(info,index) in discipleArray" :key="index" class="btLayout">{{info.nm}}</view>
			</block>
			<view v-else style="text-align: center;color: #666666;font-size: 30rpx;line-height: 200rpx;">暂无数据</view>
		</view>
		
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	var _self
	
	export default {
		components:{
			uniPopup
		},
		data() {
			return {
				discipleArray:[],
				key:'',
				discipleIds:[]
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.key = detail.key
			_self.discipleIds = detail.discipleIds
			
			_self.loadData()
		},
		methods: {
			loadData() {
				let discipleArray = []
				let disciples = getApp().globalData.disciples
				disciples.forEach((disciple)=>{
					if(_self.discipleIds.indexOf(disciple.id)==-1) {
						discipleArray.push(disciple)
					}
				})
				_self.discipleArray = discipleArray
			},
			tapChoose(disciple) {
				uni.$emit('choose', {
					key:_self.key,
					disciple:disciple
				})
				uni.navigateBack({
					delta:1
				})
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout:last-child {
		margin-bottom: 40rpx;
	}
	
	.dialogDisciple {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/build-disciple-choose-bt-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt2 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		display: flex;
		flex: 1;
		justify-content: center;
		align-items: center;
		background:url(../../static/disciple-equip-detail-bt-bg2.png) center center no-repeat;background-size:100% 100%;
	}
	
	.listHeight {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
</style>
