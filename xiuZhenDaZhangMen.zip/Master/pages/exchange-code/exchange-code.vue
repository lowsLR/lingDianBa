<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">兑换</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;align-items: center;">
			<input style="width: 550rpx;height: 90rpx;border-radius: 45rpx;padding: 0 20rpx;text-align: center;margin: 100rpx 0;" class="mbcFFFFFF" type="text" value="" v-model="code" placeholder="请输入激活码"/>
			<view @tap="tapExchange" class="dBt">确定</view>
		</view>
		
		<popup-confirm ref="refText" :showCancel="false" :content="dialogText"></popup-confirm>
	</view>
</template>

<script>
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	
	export default {
		components:{
			popupConfirm
		},
		data() {
			return {
				code:'',
				dialogText:''
			}
		},
		onLoad() {
			_self = this
		},
		methods: {
			toOpenDialog() {
				_self.$refs.refText.open()
			},
			toCloseDialog() {
				_self.$refs.refText.close()
			},
			doDialog(text) {
				_self.dialogText = text
				_self.toOpenDialog()
			},
			tapExchange() {
				let code = _self.code.trim()
				if(code) {
					_self.ajaxCode(code)
				}else {
					_self.showToast('兑换码不能为空')
				}
			},
			ajaxCode(code) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'15_1',
					params:{
						code:code
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.code = ''
						_self.toCloseDialog()
						
						let gain = resData.gain   // 6:1:1#8:1:1
						let mGain = ''  // 去掉弟子类型8，在 disciples 获取
						if(gain) {
							let gainArray = gain.split('#')
							gainArray.forEach(item => {
								let itemArray = item.split(':')
								if([8].indexOf(parseInt(itemArray[0]))==-1) {
									if(mGain) {
										mGain += '#'
									}
									mGain += item
								}
							})
						}
							
						let gainText = ''
						if(mGain) {
							gainText = _self.jsonParse.getMaterialArray(mGain).toString()
						}
						
						let disciples = resData.disciples
						disciples.forEach(disciple => {
							if(gainText) {
								gainText += ','
							}
							gainText += disciple.nm+'*1'
						})
						
						if(gainText) {
							_self.doDialog(gainText.replace(/,/g,', '))
						}else {
							_self.showToast('解析错误')
						}
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.dBt {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	
</style>
