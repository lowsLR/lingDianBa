<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">无极战境</block>
		</cu-custom>
		
		
		<view style="width: 630rpx;margin-left: 62rpx;color: #ecf0f1;font-size: 36rpx;margin-top: 46rpx;">
			<view style="display: flex;flex-direction: row;align-items: center;">
				<view style="width: 126rpx;">进度：</view>
				<progress-bar :pbWidth="500" pbColor="#FB0D1B" :progress="passedMaxLayerId" :maxProgress="layers"></progress-bar>
			</view>
			<view class="mar-t-50">最高纪录：{{name}}</view>
			<!-- <view class="mar-t-50">层数奖励：{{reward}}</view> -->
			<view class="mar-t-40" style="display: flex;flex-direction: row;line-height: 60rpx;">
				层数奖励：<view style="display: flex;flex: 1;">{{reward}}</view>
			</view>
		</view>
		
		<view class="mar-t-60" style="text-align: center;color: #FFFFFF;line-height: 80rpx;font-size: 32rpx;">规则如下</view>
		<view class="ruleLayout" style="display: flex;justify-content: center;">
			<view style="overflow: scroll;height: 290rpx;width: 580rpx;margin-top: 6rpx;margin-top: 30rpx;text-align: left;" v-html="introduction"></view>
		</view>
		
		<view style="width: 100%;display: flex;flex-direction: row;margin-top: 50rpx;justify-content: center;">
			<view @tap="tapEnter" class="btLayout1">进入战境</view>
			<view @tap="tapBonus" :style="[{'color':(gainedBonus || !passedMaxLayerId)?'#666666':'#FFFFFF'}]" class="btLayout1 mar-l-134">领取奖励</view>
		</view>
		<view v-if="costLl>0" style="width: 370rpx;text-align: center;line-height: 76rpx;font-size: 30rpx;color: #ecf0f1;">消耗 灵石*{{costLl}}</view>
		<view :class="costLl>0?'mar-t-20':'mar-t-50'" style="display: flex;justify-content: center;">
			<view @tap="tapQueue" class="btLayout1">设置阵容</view>
		</view>
		
		<popup-confirm ref="refText" :showCancel="false" :maskClick="true" :content="dialogText"></popup-confirm>
	</view>
</template>

<script>
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	import progressBar from '@/components/progress-bar/progress-bar.vue'
	var _self
	
	export default {
		components:{
			popupConfirm,
			progressBar
		},
		data() {
			return {
				introduction:'',
				dialogText:'',
				gainedBonus:false,
				passedMaxLayerId:0,
				layers:120,
				name:'无',
				reward:'无',
				queueText:'',
				costLl:0
			}
		},
		onLoad() {
			_self = this
			
			let wordObj = _self.jsonParse.getIntroWords('tower')
			if(wordObj) {
				_self.introduction = wordObj.content.replace(/\n/g,'<br>')
			}
		},
		onShow() {
			_self.getQueueValue()
			if(getApp().globalData.hasTime) {
				_self.$nextTick(function(){
					_self.ajaxData()
				})
			}
		},
		methods: {
			getQueueValue() {
				// 获取战斗队列
				try {
				    const value = uni.getStorageSync(_self.util.getStorageQueueKey())
				    if (value) {
						_self.queueText = value
				    }
				} catch (e) {}
			},
			tapQueue() {
				_self.navigateTo('/pages/map/settle-queue')
			},
			fillData() {
				let info = _self.jsonParse.getTowerInfoFromIntro(_self.passedMaxLayerId)
				_self.name = info.name
				_self.reward = info.reward
			},
			doDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			tapBonus() {
				if(!_self.passedMaxLayerId) {
					_self.showToast('暂无奖励，请先挑战无极战境')
				}else if(_self.gainedBonus) {
					_self.showToast('今天已经领取过奖励')
				}else {
					_self.ajaxBonus()
				}
			},
			tapEnter() {
				let allExist = _self.util.queueExist(_self.queueText)
				if(allExist) {
					_self.ajaxEnter()
				}else {
					_self.showToast('请先设置队列')
				}
			},
			ajaxData() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'16_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.costLl = resData.costLingshi
						_self.gainedBonus = resData.gainedBonus
						_self.passedMaxLayerId = resData.passedMaxLayerId
						_self.fillData()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxBonus() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'16_2'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let gain = resData.gain
						if(gain) {
							let gainText = '奖励：'+_self.jsonParse.getMaterialArray(gain).toString()
							_self.doDialog(gainText)
							
							_self.gainedBonus = true
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxEnter() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'16_3',
					params:{
						formation:_self.queueText
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.navigateTo(_self.util.toEncodeUri('/pages/climb-tower/climb-tower',{
							mapId:resData.curLayerId,
							passedMaxLayerId:_self.passedMaxLayerId
						}))
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.ruleLayout {
		width: 100%;
		height: 344rpx;
		text-align: center;
		line-height: 56rpx;
		font-size: 30rpx;
		color: #9A9A9A;
		background:url(../../static/climb-tower-rule.png) center center no-repeat;background-size:626rpx 100%;
		
	}
	
	.bt {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		display: flex;
		flex: 1;
		justify-content: center;
		align-items: center;
	}
	
	.btLayout1 {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
