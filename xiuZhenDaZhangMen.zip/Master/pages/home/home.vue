<template>
	<view class="homeContainer">
		<cu-custom>
			<block slot="left">
				<view :class="'sectTypeClass'+sectView.sectType" style="width: 64rpx;height: 64rpx;border-radius: 50%;margin-left: 24rpx;font-size: 34rpx;line-height: 64rpx;text-align: center;">{{util.getSectTypeName(sectView.sectType)}}</view>
			</block>
			<block slot="content">{{sectView.sectName}}</block>
			<block slot="right">
				<view style="display: flex;flex-direction: row;">
					<view :class="hasMessage?'hasMessage':''" @tap="tapMail" style="width: 64rpx;height: 64rpx;border-radius: 50%;border: solid 1px #666666;font-size: 34rpx;line-height: 64rpx;text-align: center;margin-right: 8rpx;">信</view>
					<view @tap="tapLevel" style="width: 64rpx;height: 64rpx;border-radius: 50%;margin-right: 24rpx;border: solid 1px #666666;font-size: 34rpx;line-height: 64rpx;text-align: center;">{{util.exchangeNumToFt(sectView.level)}}</view>
				</view>
				
			</block>
		</cu-custom>
		<view style="display: flex;flex-direction: row;margin-top: 30rpx;align-items: center;">
			<view style="display: flex;justify-content: center;align-items: center;width: 220rpx;height: 220rpx;">
				<image :src="util.getSectIconPath(sectView.sectIconId)" style="border-radius: 50%;width: 180rpx;height: 180rpx;color: #FFFFFF; box-shadow: 0 0 30rpx #FFFFFF;"></image>
			</view>
			<view style="background-color: #666666;height: 66rpx;width: 1px;"></view>
			<view>
				<view style="display: flex;flex-direction: row;">
					<view v-for="(id,index) in iconArray1" :key="index" style="display: flex;flex-direction: column;justify-content: center;margin-left: 20rpx;">
						<image @tap="showToast(nameObj[id]+'：'+materialObj[util.getMaterialKey(1,id)].count)" :src="'/static/home-icon-'+id+'.png'" style="width: 82rpx;height: 82rpx;border-radius: 50%;vertical-align: top;"></image>
						<view style="font-size: 28rpx;color: #FFFFFF;line-height: 52rpx;text-align: center;">{{materialObj[util.getMaterialKey(1,id)]?util.exchangeNum(materialObj[util.getMaterialKey(1,id)].count):'0'}}</view>
					</view>
				</view>
				<view style="display: flex;flex-direction: row;justify-content: center;align-items: center;">
					<view @tap="tapExchange" style="width: 50rpx;height: 50rpx;display: flex;justify-content: center;align-items: center;background-color: #FFFFFF;font-size: 28rpx;border-radius: 50%;color: #FFFFFF;background: rgb(255,255,255,0.4);margin-right: 10rpx;">商</view>
					<view @tap="showToast(nameObj[id]+'：'+materialObj[util.getMaterialKey(1,id)].count)" v-for="(id,index) in iconArray2" :key="index" :style="[{'margin-left':index==1?'10rpx':'0'}]" style="width: 210rpx;height: 46rpx;border-radius: 35rpx;border: solid 1px #CDCBCC;display: flex;flex-direction: row;align-items: center;background-color: rgb(255,255,255,0.2);">
						<view style="display: flex;flex: 1;height:100%;justify-content: center;align-items: center;color: #FFFFFF;font-size: 26rpx;">{{index==0?'修为':'仙石'}}:{{materialObj[util.getMaterialKey(1,id)]?util.exchangeNum(materialObj[util.getMaterialKey(1,id)].count):'0'}}</view>
						<view style="height: 100%;width: 38rpx;border-top-right-radius: 35rpx;border-bottom-right-radius: 35rpx;background-color: #CDCBCC;display: flex;align-items: center;justify-content: center;">
							<image style="height: 30rpx;width: 30rpx;vertical-align: top;" src="/static/home-icon-add.png"></image>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view style="width: 600rpx;margin-left: 75rpx;background: rgb(255,255,255,0.2);border-radius: 30rpx;height: 60rpx;line-height: 60rpx;text-align: center;font-size: 32rpx;color: #FFFFFF;margin-top: 20rpx;">
			{{sectView.motto?sectView.motto:''}}
		</view>
		<!-- <view @tap="tapAddMaterial" style="color: #FFFFFF;line-height: 60rpx;text-align: center;">添加物品</view> -->
		<view class="listLayout" style="display: flex;flex-direction: column;align-items: center;">
			<view style="display: flex;flex-direction: row;width: 100%;line-height: 80rpx;color: #C7C4BE;font-size: 28rpx;border-bottom: solid 1px #666666;">
				<view style="display: flex;flex: 1;justify-content: center;flex: 1;">职位</view>
				<view style="display: flex;flex: 1;justify-content: center;flex: 1;">姓名</view>
				<view style="display: flex;flex: 1;justify-content: center;flex: 1;">境界</view>
				<view style="display: flex;flex: 1;justify-content: center;flex: 1;">状态</view>
			</view>
			<scroll-view scroll-y="true" class="sv" style="display: flex;flex-direction: column;width: 670rpx;line-height: 90rpx;color: #DFDFDF;font-size: 30rpx;">
				<view class="item" @tap="tapDisciple(info)" v-for="(info,index) in disciples" :key="index">
					<view style="display: flex;flex: 1;justify-content: center;flex: 1;">{{info.pstnName}}</view>
					<view style="display: flex;flex: 1;justify-content: center;flex: 1;">{{info.nm}}</view>
					<view style="display: flex;flex: 1;justify-content: center;flex: 1;">{{info.realm?info.realm.greatRealmName:''}}</view>
					<view style="display: flex;flex: 1;justify-content: center;flex: 1;">{{util.getDiscipleStatusText(info.status)}}</view>
				</view>
			</scroll-view>
		</view>
		<view style="position: absolute;bottom: 30rpx;">
			<view style="width: 100%;display: flex;flex-direction: row;margin-top: 30rpx;">
				<view @tap="tapFunc(type1)" class="btLayout">宗门建筑</view>
				<view @tap="tapFunc(type2)" class="btLayout">历练大战</view>
				<view @tap="tapFunc(type3)" class="btLayout">灵园生产</view>
			</view>
			<view style="width: 100%;display: flex;flex-direction: row;margin-top: 30rpx;">
				<view @tap="tapFunc(type4)" class="btLayout">宗门宝库</view>
				<view @tap="tapFunc(type5)" class="btLayout">资源福利</view>
				<view @tap="tapNovel" class="btLayout">剧情小说</view>
			</view>
		</view>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	import {formatTimeToStr} from '@/common/date.js'
	var _self
	
	export default {
		components:{
			popupWords
		},
		data() {
			return {
				sectView: {
					sectId:0,
					sectName:'',
					sectIconId:0,
					sectType:1,
					level:1,
					motto:''
				},
				disciples:[],
				type1:1,
				type2:2,
				type3:3,
				type4:4,
				type5:5,
				iconArray1:[10002,10003,10004,10005,10006],
				iconArray2:[10007,10001],
				nameObj:{
					10001:'仙石',
					10002:'灵石',
					10003:'木材',
					10004:'矿石',
					10005:'灵草',
					10006:'灵粮',
					10007:'修为'
				},
				numberObj:{},
				loaded1:false,
				loaded2:false,
				load3:false,
				materialObj:{},
				canTap:true,
				keySign:'',
				wordsNew:'',
				keyWordsNew:'',
				hasMessage:false // 是否有未读邮件
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.toLoginSign()
				_self.toGetWordsNew()
			})
		},
		onShow() {
			_self.updateData()
			_self.updateDiscipleList()
			if(getApp().globalData.hasTime) {
				_self.$nextTick(function(){
					_self.ajaxMessage()
				})
			}
		},
		methods: {
			tapExchange() {
				_self.navigateTo('/pages/resource-merchant/resource-merchant')
			},
			ajaxMessage() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'1_100'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.hasMessage = resData.hasMailBonus
					}
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {}
				_self.$req.handleRequest(option)
			},
			toWordsNew(count) {
				let wordObj = _self.jsonParse.getNewWords('home')
				if(wordObj) {
					if(wordObj.count>count) {
						_self.wordsNew = wordObj.content
						_self.$refs.refWords.open()
						
						uni.setStorage({
						    key: _self.keyWordsNew,
						    data: count+1
						})
					}
				}
			},
			toGetWordsNew() {
				let keyWordsNew = 'wnh-'+getApp().globalData.sectView.sectId
				_self.keyWordsNew = keyWordsNew
				
				uni.getStorage({
				    key: keyWordsNew,
					success:function(res){
						_self.toWordsNew(res.data)
					},
				    fail:function(res){
						_self.toWordsNew(0)
					}
				})
			},
			toLoginSign() {
				let currDay = formatTimeToStr(getApp().globalData.serverTime, "yyyy-MM-dd")
				let keySign = 'ls-'+getApp().globalData.sectView.sectId+'-'+currDay
				_self.keySign = keySign
				
				uni.getStorage({
				    key: keySign,
				    fail:function(res){
						_self.ajaxSign()
					}
				})
			},
			toEnterPage(url) {
				if(_self.canTap) {
					_self.tapNo()
					_self.navigateTo(url,_self.tapYes)
				}
			},
			tapYes() {
				_self.canTap = true
			},
			tapNo() {
				_self.canTap = false
			},
			tapMail() {
				_self.toEnterPage('/pages/mail/mail')
			},
			tapLevel() {
				_self.toEnterPage('/pages/sect/sect')
			},
			tapAddMaterial() {
				_self.toEnterPage('/pages/home/material-add')
			},
			tapNovel() {
				_self.toEnterPage('/pages/novel/novel')
			},
			updateData() {
				let materialObj = getApp().globalData.materialObj
				if(materialObj) {
					_self.materialObj = materialObj
				}
				let sectView = getApp().globalData.sectView
				if(sectView) {
					_self.sectView = sectView
				}
			},
			updateDiscipleList() {
				_self.disciples = _self.util.getSortDisciples(_self)
				this.$forceUpdate()  // 强制刷新   发现招人新增之后，数据更新但页面数据没有全部更新
			},
			tapDisciple(disciple) {
				_self.toEnterPage(_self.util.toEncodeUri('/pages/disciple/disciple',{
					discipleId:disciple.id
				}))
			},
			tapFunc(type) {
				switch(type) {
					case _self.type1:
						_self.toEnterPage('/pages/building/building')
						break;
						
					case _self.type2:
						_self.toEnterPage('/pages/experience-list/experience-list')
						break;
						
					case _self.type3:
						_self.toEnterPage('/pages/land/land')
						break;
						
					case _self.type4:
						_self.toEnterPage('/pages/treasure/treasure')
						break;
						
					case _self.type5:
						_self.toEnterPage('/pages/shop/shop')
						break;
				}
			},
			ajaxSign() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'11_10'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						if(resData.rs==1) {
							uni.setStorage({
							    key: _self.keySign,
							    data: '1'
							})
						}
					}
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.homeContainer {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.listLayout {
		margin-top: 50rpx;
		margin-left: 40rpx;
		width: 670rpx;
		/* height: 600rpx; */
		border: solid 1px #666666;
		border-radius: 8rpx;
		
		max-height: calc(100vh - var(--status-bar-height) - 760rpx);
	}
	
	.listLayout .sv {
		max-height: calc(100vh - var(--status-bar-height) - 760rpx - 80rpx);
	}
	
	.listLayout .sv .item {
		display: flex;
		flex-direction: row;
		border-bottom: solid 1px #666666;
	}
	
	.listLayout .sv .item:last-child {
		border-bottom: none;
	}
	
	.btLayout {
		width: 204rpx;
		height: 91rpx;
		text-align: center;
		line-height: 91rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-left: 34rpx;
		background:url(../../static/home-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.sectTypeClass1 {
		color: #FFFF00;
		box-shadow: 0 0 10px #FFFF00;
	}
	
	.sectTypeClass2 {
		color: #FF0000;
		box-shadow: 0 0 10px #FF0000;
	}
	
	.hasMessage {
		animation: message 1s linear infinite;
	}
	@keyframes message {
		0% {
			box-shadow: 0 0 20upx #FFFFFF;
			color: #FFFFFF;
		}
		50% {
			box-shadow: 0 0 20upx #FF0000;
			color: #FF0000;
		}
		100% {
			box-shadow: 0 0 20upx #FFFFFF;
			color: #FFFFFF;
		}
	}
	
</style>
