<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">添加物品</block>
		</cu-custom>
		
		<textarea style="background-color: #FFFFFF;min-height: 100px;" v-model="dataText" placeholder="轻羽靴*1#灵羽靴*1" auto-height />
		<button @tap="tapAdd">添加</button>
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				dataText:''
			}
		},
		onLoad() {
			_self = this
		},
		methods: {
			tapAdd() {
				let dataText = _self.dataText
				if(dataText) {
					_self.ajaxAddMaterial(dataText)
				}else {
					_self.showToast('输入不能为空')
				}
			},
			ajaxAddMaterial(text) {
				// 单纯用于加数据
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'1000_-1',
					params:{
						materials:text
						// materials:'灵光佩*1#煞念手镯*1#护灵指环*1#虎阳玉佩*1#清灵手镯*1#天音戒*1',
						// materials:'轻羽靴*1#灵羽靴*1#金角靴*1#力斗靴*1#金光靴*1#逍遥云纹靴*1'
						// materials:'风灵袍*1#金阳甲*1#死寂幽魂衣*1#血战擎雷甲*1#碧纹魔魂衣*1#灵玉佩*1'
						// materials:'青锋剑*1#魂纹剑*1#秋水剑*1#魔水剑*1#煞灵剑*1#镇邪赤阳剑*1'
						// materials:'仙石*1000000#灵石*1000000#修为*1000000#矿石*1000000#灵草*1000000'
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.dataText = ''
					_self.showToast('添加成功')
				}
				_self.$req.handleRequest(option)
			},
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	
</style>
