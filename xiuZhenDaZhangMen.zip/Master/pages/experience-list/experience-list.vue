<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">历练列表</block>
		</cu-custom>
		
		<view class="listHeight" style="display: flex;flex-direction: column;align-items: center;overflow: scroll;">
			<view @tap="tapItem(item)" v-for="(item,index) in lists" :key="index" class="btLayout">{{item.name}}</view>
		</view>
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				lists:[{
					name:'主线地图',
					url:'/pages/map/map-list'
				},{
					name:'无极战境',
					url:'/pages/climb-tower/tower-intro'
				}]
			}
		},
		onLoad() {
			_self = this
			
		},
		methods: {
			tapItem(item) {
				let url = item.url
				if(url) {
					_self.navigateTo(url)
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout:last-child {
		margin-bottom: 40rpx;
	}
	
	.listHeight {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
</style>
