<template>
	<view style="container">
		<cu-custom :isBack="true">
			<block slot="content">
				<view class="cuu-title">
					<view class="first">道奴之影</view>
					<view class="second">古圣阁</view>
				</view>
			</block>
		</cu-custom>
		<!-- tar切换 -->
		<view style="display: flex;justify-content: center;align-items: center;height: 140rpx;">
			<uni-segmented-control
				style="width: 650rpx;"
				:current="current"
				:values="items"
				@clickItem="onClickItem"
				style-type="button"
				active-color="#CBBDAF"
			></uni-segmented-control>
		</view>

		<template v-if="current == 0">
			<view class="cl-layout">
				<view class="pic-title">
					<view class="pic"><image src="../../static/building-forge-formula-bright.png" mode=""></image></view>
					<view class="title">名称</view>
				</view>
				
				<!-- 重複的 -->
				<view class="pic-title">
					<view class="pic"><image src="../../static/building-forge-formula-bright.png" mode=""></image></view>
					<view class="title">名称</view>
				</view>
				<view class="pic-title">
					<view class="pic"><image src="../../static/building-forge-formula-bright.png" mode=""></image></view>
					<view class="title">名称</view>
				</view>
				<view class="pic-title">
					<view class="pic"><image src="../../static/building-forge-formula-bright.png" mode=""></image></view>
					<view class="title">名称</view>
				</view>
				<view class="pic-title">
					<view class="pic"><image src="../../static/building-forge-formula-bright.png" mode=""></image></view>
					<view class="title">名称</view>
				</view>
					<!-- 重複的 -->
			</view>
		</template>
	</view>
</template>

<script>
export default {
	data() {
		return {
			current: 0,
			items: ['材料', '门入']
		};
	},
	methods: {
		onClickItem(e) {
			let eCurrent = e.currentIndex;
			this.current = eCurrent;
		}
	}
};
</script>

<style scoped>
.container {
	width: 750rpx;
	height: 100vh;
	background: url(../../static/market-detail/other-black-bg.png) center center no-repeat;
	background-size: 750rpx 1550rpx;
}

.cuu-title {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: space-between;
	color: #ffffff;
}

.cuu-title .first {
	font-size: 30rpx;
}

.cuu-title .second {
	font-size: 36rpx;
}

.cl-layout {
	width: 100%;
	display: flex;
	align-items: center;
	flex-wrap: wrap;
}
.pic-title {
	display: flex;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	width: 33%;
}
.pic-title .pic image {
	width: 210rpx;
	height: 158rpx;
	display: block;
}
.pic-title .title {
	margin-top: 26rpx;
	font-size: 28rpx;
	color: #ffffff;
}

.pic-title:nth-child(n>3){
	margin-top: 50rpx;
}
</style>
