<template>
	<view class="container">
		<image class="bgImg" src="/static/uload-bg.png"></image>
		<view class="progressLayout">
			<view :style="[{'width':bgWidth+'rpx'}]"></view>
			<image src="/static/load_cloud.png"></image>
		</view>
	</view>
	
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				progress:0,
				bgWidth:40,
				downloadTask:null
			}
		},
		onLoad(option) {
			_self = this
			
			const wgtUrl = option.url
			this.$nextTick(function(){
				_self.toLoad(wgtUrl)
			})
		},
		onUnload() {
			if(this.downloadTask) {
				this.downloadTask.abort()
			}
		},
		methods: {
			toLoad(wgtUrl) {
				const downloadTask = uni.downloadFile({
				    url: wgtUrl,
				    success: (res) => {
				        if (res.statusCode === 200) {
				            plus.runtime.install(res.tempFilePath, {
				            	force: false  
				            }, function() {  
				            	console.log('install success...')
				            	plus.runtime.restart(); 
				            }, function(e) {  
				            	console.error('install fail...')
				            })
				        }
				    }
				})
				
				downloadTask.onProgressUpdate((res) => {
					_self.bgWidth = res.progress*5.2+40
				})
				
				_self.downloadTask = downloadTask
			}
		}
	}
</script>

<style>
	.container {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 100%;
	}
	
	.bgImg {
		width: 750rpx;
		height: 1334rpx;
	}
	
	.progressLayout {
		position: absolute;
		bottom: 180rpx;
		width: 600rpx;
		height: 32rpx;
		border-radius: 16rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
		-moz-box-shadow:0px 0px 10px #F9DB87;
		-webkit-box-shadow:0px 0px 10px #F9DB87;
		box-shadow:0px 0px 10px #F9DB87;
	}
	
	.progressLayout view {
		height: 100%;
		background-color: #F9DB87;
		border-top-left-radius: 20rpx;
		border-bottom-left-radius: 20rpx;
	}
	
	.progressLayout image {
		width: 127rpx;
		height: 52rpx;
		margin-left: -87rpx;
	}
	
</style>
