<template>
	<view style="container">
		<cu-custom :isBack="true"><block slot="content">剑修传承</block></cu-custom>
		<!-- 传承 -->
		<view class="cLayout" style="display: flex;justify-content: center;width: 100%;flex-direction: column;align-items: center;">
			<image @tap="tapItem" class="imgSize" src="/static/kendo-heritage/bayuan.png"></image>
			<image @tap="tapItem" class="imgSize mar-t-100" src="/static/kendo-heritage/dichen.png"></image>
		</view>
		<!-- 弹窗 -->

		<uni-popup ref="refKenDo" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refKenDo.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="layout">
				<view class="kendo-title">霸元</view>
				<view class="state">
					<view class="title">传承境界要求：</view>
					<view class="txt">化神境 圆气魄</view>
				</view>
				<view class="attribute">
					<view class="title">传承属性要求：</view>
					<view class="txt">
						<view>肉身>=850</view>
						<view>神念>=850</view>
					</view>
				</view>
				<view class="goods state">
					<view class="title">传承境界要求：</view>
					<view class="txt">化神境 圆气魄</view>
				</view>
				<view class="describe-txt">我辈何惧埋黄土，苍生悲鸣怒向天</view>
				<!-- 文字描述 -->
				<view class="describe">
					<view class="content">
						<scroll-view scroll-y="true" class="text">
							<view>暴击属性突出，</view>
							<view>其他方面均衡并不突出，</view>
							<view>属于高爆发型</view>
							<view>传承选择这个传承的人，</view>
							<view>追求的就是几率型的高爆发伤害</view>
						</scroll-view>
					</view>
				</view>
				<view class="heritage-layout" @tap="ajaxPromote"><view class="heritage">传承</view></view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	methods: {
		tapItem(e) {
			this.$refs.refKenDo.open();
		},
		ajaxPromote() {
			this.$refs.refKenDo.close();
		}
	}
};
</script>

<style scoped>
.container {
	width: 750rpx;
	height: 100vh;
	background: url(../../static/market-detail/other-black-bg.png) center center no-repeat;
	background-size: 750rpx 1550rpx;
}

.cLayout {
	height: calc(80vh - var(--status-bar-height) - 100rpx);
}

.imgSize {
	width: 360rpx;
	height: 360rpx;
}

.layout {
	width: 568rpx;
	height: 988rpx;
	background: url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;
	background-size: 100% 100%;
}

.heritage {
	width: 200rpx;
	height: 88rpx;
	background: url(../../static/disciple-property-bg-bt.png) center center no-repeat;
	background-size: 100% 100%;
	font-size: 32rpx;
	color: #ffffff;
	text-align: center;
	line-height: 88rpx;
}
.kendo-title {
	color: #ffffff;
	font-size: 32rpx;
	font-weight: 500;
	width: 100%;
	text-align: center;
	padding:55rpx 0;
}
.state,
.attribute {
	font-size: 30rpx;
	color: #ffffff;
	font-weight: 400;
	display: flex;
	align-items: center;
	width: 100%;
	padding-left: 63rpx;
	padding-bottom: 44rpx;
}

.state .title,
.attribute .title {
	width: 110px;
}
.attribute .txt {
	display: flex;
	flex-direction: column;
}

.describe-txt {
	width: 100%;
	color: #ffffcc;
	font-size: 26rpx;
	font-weight: 400;
	text-align: center;
	padding-bottom: 48rpx
}
.heritage-layout {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
	margin-top: 35rpx;
}

.describe {
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
}
.describe .content {
	width: 478rpx;
	height: 264rpx;
	display: flex;
	align-items: center;
	justify-content: center;
	background: url(../../static/kendo-heritage/text-bg.png) center center no-repeat;
	background-size: 100% 100%;
}
.describe .content .text {
	width: 394rpx;
	height: 201rpx;
	font-size: 26rpx;
	font-family: PingFang SC;
	font-weight: 400;
	color: rgba(204, 204, 204, 1);
	line-height: 44rpx;
	display: flex;
	align-items: center;
	justify-content: center;
}

.describe .content .text view{
	width: 100%;
	display: flex;
	align-items: center;
	justify-content: center;
}
.heritage {
	width: 200rpx;
	height: 88rpx;
	background: url(../../static/disciple-property-bg-bt.png) center center no-repeat;
	background-size: 100% 100%;
	font-size: 32rpx;
	color: #ffffff;
	text-align: center;
	line-height: 88rpx;
}
</style>
