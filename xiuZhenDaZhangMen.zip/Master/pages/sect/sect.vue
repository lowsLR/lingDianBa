<template>
	<view class="container">
		<cuCustomScroll :isBack="true">
			<block slot="content">
				<bwScrollNav :tab-index="tabCurrentIndex" @tabChange="clickTab" :tab-bars="tabBars">
				</bwScrollNav>
			</block>
		</cuCustomScroll>
		
		<swiper id="swiper" class="swiper-box" :duration="300" :current="tabCurrentIndex" @change="swiperTab">
			<swiper-item>
				<view style="display: flex;height: 480rpx;width: 750rpx;justify-content: center;align-items: center;">
					<image style="width: 300rpx;height: 300rpx;border-radius: 50%;color: #FFFFFF; box-shadow: 0 0 30rpx #FFFFFF;" :src="util.getSectIconPath(sectIconId)"></image>
				</view>
				
				<view style="line-height: 70rpx;font-size: 32rpx;color: #FFFFFF;margin-left: 86rpx;">
					<view>门派名称：{{sectName}}</view>
					<view>门派掌门：{{masterName}}</view>
					<view>门派等级：{{sectLevel}}</view>
					<view>门人数量：{{sectCount}}</view>
				</view>
				
				<view style="width: 100%;display: flex;flex-direction: row;margin-top: 100rpx;">
					<view @tap="ajaxGain" class="btLayout">领取供奉</view>
					<view @tap="tapUpgrade" class="btLayout">提升门派</view>
				</view>
			</swiper-item>
			
			<swiper-item>
				<view style="display: flex;width: 100%;align-items: center;flex-direction: column;">
					<view style="color: #666666;line-height: 100rpx;font-size: 28rpx;">成就概览</view>
					<view style="display: flex;flex-direction: row;">
						<image @tap="ajaxAchievement(typeAchievement3)" class="icon-achievement" src="/static/sect-achievement-dz.png"></image>
						<image @tap="ajaxAchievement(typeAchievement4)" class="icon-achievement mar-l-80" src="/static/sect-achievement-ld.png"></image>
					</view>
					<view style="display: flex;flex-direction: row;" class="mar-t-80">
						<image @tap="ajaxAchievement(typeAchievement1)" class="icon-achievement" src="/static/sect-achievement-pve.png"></image>
						<image @tap="ajaxAchievement(typeAchievement2)" class="icon-achievement mar-l-80" src="/static/sect-achievement-pvp.png"></image>
					</view>
				</view>
				
			</swiper-item>
			
			<swiper-item>
				<view style="display: flex;justify-content: center;padding-top: 40rpx;">
					<uni-segmented-control style="width: 650rpx;" :current="mixCurr" :values="mixItems" @clickItem="onClickItem" style-type="button" active-color="#CBBDAF"></uni-segmented-control>
				</view>
				
				<!-- 材料 -->
				<template v-if="mixCurr == 0">
					<!-- 原材料 -->
					<view class="rawMaterial">
						<view class="content">
							<view class="raw">原材料：</view>
							<view v-if="mixOriginObj" @tap="tapOrigin" class="colorOrange">{{mixOriginObj.name}}</view>
							<view v-else @tap="tapOrigin" class="add"></view>
							<view class="calculation" v-if="mixOriginObj" style="margin-left: 20rpx;">
								<view @tap="tapAddMinus(amType1)" class="subtraction"></view>
								<view class="num">
									<text>{{mixCount}}</text>
									/{{mixMaxCount}}
								</view>
								<view @tap="tapAddMinus(amType2)" class="addition"></view>
							</view>
						</view>
					</view>
				
					<!-- 获得 -->
					<view class="rawMaterial qxpadding">
						<view class="content">
							<view class="raw">融合获得：</view>
							<view class="colorOrange">{{mixResult?mixResult.result:''}}</view>
							<view v-if="mixResult" class="calculation">成功概率：{{parseInt(mixResult.rate*100)}}%</view>
						</view>
					</view>
				
					<!-- 描述 -->
					<view class="describe">
						<view class="content">
							<scroll-view scroll-y="true" class="scrollView">
								<view style="height: 100%;" class="isVerticleCenter" v-html="mixHtml"></view>
							</scroll-view>
						</view>
					</view>
				
					<view class="fusion">
						<view @tap="tapMix" v-if="mixOriginObj" class="content">融合</view>
						<view @tap="showToast('请选择融合「原材料」')" v-else class="content" style="color: #666666;">融合</view>
					</view>
				</template>
				
				<!-- 神兵 -->
				<template v-if="mixCurr == 1">
					<view class="selecter">
						<!-- 添加材料合成 -->
						<view class="synthesis">
							<view>
								<view class="add"></view>
								<view class="line"></view>
							</view>
							<view>
								<view class="add"></view>
								<view class="line"></view>
							</view>
							<view>
								<view class="add"></view>
								<view class="line"></view>
							</view>
							<view>
								<view class="add"></view>
								<view class="line"></view>
							</view>
						</view>
					</view>
					<view style="display: flex;align-items: center;flex-direction: column;">
						<view style="width: 486rpx;background-color: #FFB662;height: 2rpx;"></view>
						<view style="width: 2rpx;height: 40rpx;background-color: #FFB662;"></view>
					</view>
					
					<view class="marketBigPic"><view class="marketpic"></view></view>
					<view style="display: flex;justify-content: center;">
						<view style="width: 2rpx;height: 40rpx;background-color: #FFB662;"></view>
					</view>
					
					<view class="marketBigWhat"><view class="marketwhat"></view></view>
					<!-- 描述 -->
					<!-- <view class="describe-current1">
						<view class="content">
							<scroll-view scroll-y="true" class="scrollView"></scroll-view>
						</view>
					</view>
					<view class="consume"><view @tap="showToast('暂未开放')" class="content" style="color: #666666;">锻造</view></view> -->
				</template>
				
			</swiper-item>
		</swiper>
		
		<uni-popup ref="refGain" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refGain.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogGain" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">每日奖励</view>
				<view class="isCenter" v-html="gainHtml" style="width: 480rpx;height: 500rpx;margin-bottom: 30rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;overflow: scroll;"></view>
				<view @tap="$refs.refGain.close()" class="bt1">确定</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refUpgrade" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refUpgrade.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogGain" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">门派状况</view>
				<scroll-view scroll-y="true" class="sv" style="width: 420rpx;height: 500rpx;margin-bottom: 30rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;">
					<view v-if="!suInfo.hide1" style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 2;">{{suInfo.condiction1}}</view>
						<view class="c-FFFF00" style="display: flex;" v-if="suInfo.result1">满足</view>
						<view class="c-FF0000" style="display: flex;" v-else>不满足</view>
					</view>
					<view v-if="!suInfo.hide2" style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 2;">{{suInfo.condiction2}}</view>
						<view class="c-FFFF00" style="display: flex;" v-if="suInfo.result2">满足</view>
						<view class="c-FF0000" style="display: flex;" v-else>不满足</view>
					</view>
					<view v-for="(item,index) in mlArray" :key="index" style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 2;">{{item.name}}</view>
						<view class="c-FFFF00" style="display: flex;" v-if="item.result">满足</view>
						<view class="c-FF0000" style="display: flex;" v-else>不满足</view>
					</view>
				</scroll-view>
				<view @tap="ajaxUpgrade" v-if="(suInfo.hide1 || suInfo.result1) && (suInfo.hide2 || suInfo.result2) && suInfo.result3"  class="bt1">提升门派</view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refAchievement" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refAchievement.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogGain" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 130rpx;text-align: center;font-size: 36rpx;padding-top: 20rpx;color: #FFFFFF;">{{titleObj[typeAchievement]}}</view>
				<scroll-view scroll-y="true" class="sv" style="width: 500rpx;height: 600rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;">
					<view style="display: flex;flex-direction: column;justify-content: center;height: 100%;">
						<view v-for="(achievement,index) in achievementArray" :key="index">
							<view style="display: flex;flex-direction: row;width: 400rpx;">
								<view :style="[{'color':achievement.color}]" style="display: flex;flex: 1;">{{achievement.name}}</view>
								<view style="text-decoration: underline;" @tap="tapEffect($event,achievement.description)" :style="[{'color':achievement.color}]">效果</view>
							</view>
							<view style="display: flex;flex-direction: row;height: 32rpx;align-items: center;">
								<view class="progressLayout" :style="[{'box-shadow':'0px 0px 20rpx '+achievement.color}]">
									<view :style="[{'width':(achievement.progress/achievement.maxNum)*400+'rpx','background-color':achievement.color}]"></view>
								</view>
								<view :style="[{'color':achievement.color}]" style="font-size: 26rpx;margin-left: 20rpx;line-height: 30rpx;text-align: center;" v-html="achievement.eText.replace('以上','<br>以上')"></view>
							</view>
							<view :style="[{'width':(achievement.progress/achievement.maxNum)*400+'rpx','color':achievement.color}]" style="min-width: 40rpx;text-align: right;">{{achievement.progress}}</view>
						</view>
						
					</view>
				</scroll-view>
			</view>
		</uni-popup>
		
		<uni-popup ref="refIntro" type="top" :custom="true" :mask-click="true" maskOpacity="0">
			<view :style="[{'margin-top':introMt+'px'}]" class="introView" v-html="description"></view>
		</uni-popup>
		
		<popup-confirm ref="refText" :showCancel="false" :maskClick="true" :content="dialogText"></popup-confirm>
		
	</view>
</template>

<script>
	import cuCustomScroll from '@/components/cu-custom/cu-custom-scroll.vue'
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	import bwScrollNav from '@/pages/components/bw-scroll-nav.vue'
	var _self
	
	export default {
		components:{
			cuCustomScroll,
			popupConfirm,
			bwScrollNav
		},
		data() {
			return {
				sectName:'',
				masterName:'',
				sectLevel:'',
				sectCount:0,
				gainHtml:'',
				sectIconId:0,
				suInfo:{},
				mlArray:[],
				tabCurrentIndex:0,
				tabBars: [{
					name: '门派相关',
					id: 1,
				}, {
					name: '成就相关',
					id: 2,
				}, {
					name: '材料融合',
					id: 3,
				}],
				typeAchievement:1,
				typeAchievement1:1,
				typeAchievement2:2,
				typeAchievement3:3,
				typeAchievement4:4,
				achievementArray:[],
				description:'',
				introMt:0,
				titleObj:{
					1:'降妖成就',
					2:'仙斗成就',
					3:'锻造成就',
					4:'炼丹成就'
				},
				mixCurr:0,
				mixItems:['材料融合', '神兵锻造'],
				mixOriginObj:null,
				mixOriginId:0,
				mixResult:null,
				mixMaxCount:0,
				mixCount:1,
				amType1:1,
				amType2:2,
				dialogText:'',
				mixHtml:''
			}
		},
		onLoad() {
			_self = this
			_self.fillData()
		},
		onUnload() {
			uni.$off('mix',_self.mixCallback)
		},
		methods: {
			tapMix() {
				let mixResult = _self.mixResult
				if(mixResult) {
					_self.ajaxMix(mixResult.id)
				}
			},
			ajaxMix(combineId) {
				var option = {combineId}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'13_1',
					params:{
						combineId:combineId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let resultRs = '融合失败'
						if(resData.rs==1) {
							resultRs = '融合成功：'+_self.jsonParse.getMaterialArray(resData.gain).toString()
						}
						_self.doDialog(resultRs)
						_self.fillMixData()
					}
				}
				_self.$req.handleRequest(option)
			},
			doDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			tapAddMinus(type) {
				let mixCount = _self.mixCount
				switch(type) {
					case _self.amType1:
						mixCount--
						break;
						
					case _self.amType2:
						mixCount++
						break;
				}
				if(mixCount>0 && mixCount<=_self.mixMaxCount) {
					_self.mixCount = mixCount
					_self.getMixResult()
				}
			},
			mixCallback(e) {
				_self.mixOriginObj = e
				_self.fillMixData()
			},
			fillMixData() {
				/**
				 * 判断原材料是否存在且足够
				 * 选中最后一个
				 */
				let mixOriginObj = _self.mixOriginObj
				if(mixOriginObj) {
					let originArray = _self.jsonParse.getMMNArrayByName(mixOriginObj.name)
					
					let materialObj = getApp().globalData.materialObj
					let lmObj = materialObj[_self.util.getMaterialKey(mixOriginObj.type,mixOriginObj.id)]
					if(lmObj) {
						let lmCount = lmObj.count
						let originCount = originArray.length
						if(lmCount>0) {
							let mixMaxCount = lmCount
							if(lmCount>originCount) {
								mixMaxCount = originCount
							}
							_self.mixMaxCount = mixMaxCount
							_self.mixCount = mixMaxCount
							_self.getMixResult()
						}else {
							_self.mixOriginObj = null
							_self.mixResult = null
						}
					}else {
						_self.mixOriginObj = null
						_self.mixResult = null
					}
				}
			},
			getMixResult() {
				_self.mixResult = _self.jsonParse.getMixInfoByOrigin(_self.mixOriginObj.name,_self.mixCount)
			},
			tapOrigin() {
				uni.$on('mix',_self.mixCallback)
				_self.navigateTo('/pages/treasure/treasure-material')
			},
			onClickItem(e) {
				let eCurrent = e.currentIndex
				if (_self.mixCurr != eCurrent) {
					_self.mixCurr = eCurrent
				}
			},
			tapEffect(e,description) {
				console.log(e)
				_self.introMt = e.detail.y-20
				_self.description = description.replace(/\n/g,'<br>')
				_self.$refs.refIntro.open()
			},
			ajaxAchievement(type) {
				_self.typeAchievement = type
				
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'14_1',
					params:{
						type:type
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let achievements = resData.achievements
						let achievementArray = []
						achievements.forEach(achievement => {
							let info = _self.jsonParse.getAchievementInfo(achievement.aId, achievement.progress)
							if(info) {
								achievementArray.push(info)
							}
						})
						_self.achievementArray = achievementArray
						_self.$refs.refAchievement.open()
					}
				}
				_self.$req.handleRequest(option)
			},
			swiperTab(e) {
				/*滑动切换*/
				let index = e.target.current || e.detail.current
				this.changeTab(index)
			},
			clickTab(e) {
				/*点击切换*/
				_self.changeTab(e.index)
			},
			changeTab(index) {
				/*切换tab*/
				if(_self.tabCurrentIndex!=index) {
					_self.tabCurrentIndex = index
				}
			},
			fillSectDialog() {
				let suInfo = _self.jsonParse.getSectUpgradeInfo(_self.sectLevel)
				if(suInfo) {
					let judgeArray1
					let ja10
					let ja11
					let result1 = false
					let count1 = 0
					let judge1 = suInfo.judge1
					if(judge1.indexOf('#')!=-1) {
						judgeArray1 = judge1.split('#')
						ja10 = parseInt(judgeArray1[0])
						ja11 = parseInt(judgeArray1[1])
					}else {
						suInfo.hide1 = true
					}
					
					let judgeArray2
					let ja20
					let ja21
					let result2 = false
					let count2 = 0
					let judge2 = suInfo.judge2
					if(judge2.indexOf('#')!=-1) {
						judgeArray2 = judge2.split('#')
						ja20 = parseInt(judgeArray2[0])
						ja21 = parseInt(judgeArray2[1])
					}else {
						suInfo.hide2 = true
					}
					
					let disciples = getApp().globalData.disciples
					disciples.forEach(disciple => {
						let rm = disciple.rm
						if(rm==ja10) {
							count1++
						}else if(rm==ja20) {
							count2++
						}
					})
					if(count1>=ja11) {
						result1 = true
					}
					if(count2>=ja21) {
						result2 = true
					}
					suInfo.result1 = result1
					suInfo.result2 = result2
					
					let mlArray = []
					let materialLimit = suInfo.materialLimit  // 灵石*120000#木材*50000#灵草*50000#矿石*50000
					let array1 = materialLimit.split('#')
					let materialObj = getApp().globalData.materialObj
					
					let result3 = true
					let array2 = _self.jsonParse.exchangeMapMaterialFormat(materialLimit).split('#')
					array2.forEach((item,index) => {
						let itemArray = item.split(':')
						let i0 = parseInt(itemArray[0])
						let i1 = parseInt(itemArray[1])
						let i2 = parseInt(itemArray[2])
						
						let name = array1[index].replace('*','数量>=')
						let result = false
						let mObj = materialObj[_self.util.getMaterialKey(i0,i1)]
						if(mObj && mObj.count>=i2) {
							result = true
						}else {
							result3 = false
						}
						mlArray.push({
							name:name,
							result:result
						})
					})
					_self.mlArray = mlArray
					
					suInfo.result3 = result3
					_self.suInfo = suInfo
				}
			},
			tapUpgrade() {
				_self.fillSectDialog()
				_self.$refs.refUpgrade.open()
			},
			fillData() {
				let sectView = getApp().globalData.sectView
				_self.sectName = sectView.sectName
				_self.sectLevel = sectView.level
				_self.sectIconId = sectView.sectIconId
				
				let disciples = getApp().globalData.disciples
				disciples.forEach(disciple => {
					if(_self.util.isMaster(disciple.pstn)) {
						_self.masterName = disciple.nm
					}
				})
				_self.sectCount = disciples.length-1
				
				let wordObj = _self.jsonParse.getIntroWords('material-mix')
				if(wordObj) {
					_self.mixHtml = wordObj.content.replace(/\n/g,'<br>')
				}
			},
			ajaxUpgrade() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'10_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.showToast('已提升门派等级')
						let sectLevel = resData.sectLevel
						_self.sectLevel = sectLevel    // 提升之后需更新首页门派
						getApp().globalData.sectView.level = sectLevel  // 提升之后需更新首页门派
						_self.fillSectDialog()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxGain() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'10_2'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let gain = resData.gain
						if(gain) {
							let gainHtml = ''
							let materialObj = _self.jsonParse.parseHomeMaterial(gain)
							Object.keys(materialObj).map(key => {
								let obj = materialObj[key]
								gainHtml += obj.name+'*'+obj.count+'<br>'
							})
							if(gainHtml) {
								_self.gainHtml = gainHtml
								_self.$refs.refGain.open()
							}
						}
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-left: 86rpx;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogGain {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.swiper-box {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
	.icon-achievement {
		width: 250rpx;
		height: 250rpx;
	}
	
	.progressLayout {
		width: 400rpx;
		height: 32rpx;
		border-radius: 16rpx;
		margin: 10rpx 0 10rpx 6rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
		box-shadow:0px 0px 20rpx #F9DB87;
	}
	
	.progressLayout view {
		height: 100%;
		background-color: #F9DB87;
		border-radius: 20rpx;
	}
	
	.introView {
	    padding: 20rpx;
	    border-radius: 10rpx;
	    display: -webkit-inline-box;
	    display: -webkit-inline-flex;
	    display: -ms-inline-flexbox;
	    display: inline-flex;
	    max-width: 280rpx;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    -ms-flex-align: center;
	    align-items: center;
	    font-size: 32rpx;
	    line-height: 40rpx;
	    text-align: left;
		box-shadow: 0 0 20rpx #FFFFFF;
		color: #FFFFFF;
		background-color: #000000;
		opacity: 0.8;
		
		position: absolute;
		right: 320rpx;
		/* margin-top: calc(279px + var(--status-bar-height)); */
		
		/* top: var(--status-bar-height); */
	}
	
	.introView:after {
	    content: "";
	    top: 13px;
	    -webkit-transform: rotate(45deg);
	    -ms-transform: rotate(45deg);
	    transform: rotate(45deg);
	    position: absolute;
	    z-index: 100;
	    display: inline-block;
	    overflow: hidden;
	    width: 12px;
	    height: 12px;
	    left: auto;
	    right: -6px;
	    background-color: inherit;
	}
	
	/* 材料融合 */
	.rawMaterial {
		padding: 60rpx 50rpx;
		font-size: 30rpx;
		color: #ffffff;
	}
	.qxpadding {
		padding-top: 0;
		margin-top: 12rpx;
	}
	.rawMaterial .content {
		display: flex;
		align-items: center;
		flex-wrap: nowrap;
	}
	.rawMaterial .content > view {
		/* flex: 1; */
		/* border: 2rpx solid #f59; */
		box-sizing: border-box;
	}
	.rawMaterial .raw {
		/* margin-right: 20rpx; */
		width: 154rpx;
	}
	
	.rawMaterial .add {
		/* margin-right: 20rpx; */
		width: 238rpx;
		height: 74rpx;
		background: url(../../static/market-detail/market-detail-yellow-add.png) center center no-repeat;
		background-size: 100% 100%;
		/* margin: 0 20px; */
	}
	
	.rawMaterial .colorOrange {
		margin-right: 20rpx;
		width: 238rpx;
		height: 74rpx;
		background: url(../../static/market-detail/market-detail-yellow-msk.png) center center no-repeat;
		background-size: 100% 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #ffb662;
		font-size: 30rpx;
	}
	
	.rawMaterial .calculation {
		display: flex;
		align-items: center;
	}
	
	.rawMaterial .subtraction,
	.rawMaterial .addition {
		width: 40rpx;
		height: 40rpx;
	}
	
	.rawMaterial .subtraction {
		margin-right: 20rpx;
		background: url(../../static/market-detail-dialog-bt-minus.png) center center no-repeat;
		background-size: 100% 100%;
	}
	.rawMaterial .addition {
		background: url(../../static/market-detail-dialog-bt-add.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.rawMaterial .num {
		margin-right: 20rpx;
	}
	
	.rawMaterial .num > text {
	}
	
	.describe {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	
	.describe .content {
		width: 684rpx;
		height: 204rpx;
		font-size: 26rpx;
		color: #b3b3b3;
		background: url(../../static/market-detail/market-text-gral-msk.png) center center no-repeat;
		background-size: 100% 100%;
	
		font-family: PingFang SC;
		font-weight: 400;
		line-height: 42rpx;
	}
	.describe .scrollView {
		width: 644rpx;
		height: 152rpx;
		padding: 26rpx 0;
		margin-left: 20rpx;
	}
	
	.fusion {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 183rpx;
	}
	
	.fusion .content {
		width: 246rpx;
		height: 88rpx;
		font-size: 30rpx;
		color: #ffffff;
		display: flex;
		align-items: center;
		justify-content: center;
		background: url(../../static/disciple-property-bg-bt.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.selecter {
		margin-top: 40rpx;
		padding: 0 62rpx;
	}
	.selecter .synthesis {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	
	.selecter .synthesis > view {
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	
	.selecter .synthesis .add {
		width: 140rpx;
		height: 74rpx;
		background: url(../../static/market-detail/market-shenbing-yellow-min-add.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.selecter .synthesis .line {
		width: 2rpx;
		height: 40rpx;
		background-color: #FFB662;
	}
	
	.nopic {
		color: #fff200;
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
	}
	.marketBigPic,
	.marketBigWhat {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 100%;
	}
	
	.marketBigPic .marketpic {
		width: 238rpx;
		height: 74rpx;
		background: url(../../static/market-detail/market-shenbing-yellow-add.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.marketBigWhat .marketwhat {
		width: 238rpx;
		height: 74rpx;
		background: url(../../static/market-detail/market-shenbing-yellow-what.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
	.describe-current1 {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 97rpx;
	}
	
	.describe-current1 .content {
		width: 684rpx;
		height: 292rpx;
		font-size: 26rpx;
		color: #b3b3b3;
		background: url(../../static/market-detail/market-text-gral-msk.png) center center no-repeat;
		background-size: 100% 100%;
	
		font-family: PingFang SC;
		font-weight: 400;
		line-height: 42rpx;
	}
	
	.describe-current1 .content .scrollView {
		/* padding: 26rpx 39rpx;
		height: 240rpx; */
		width: 644rpx;
		height: 240rpx;
		padding: 26rpx 0;
		margin-left: 20rpx;
	}
	
	.consume {
		margin-top: 60rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.consume .content {
		width: 460rpx;
		height: 88rpx;
		font-size: 30rpx;
		color: #ffffff;
		display: flex;
		align-items: center;
		justify-content: center;
		background: url(../../static/market-detail/market-shenbing-black-msk.png) center center no-repeat;
		background-size: 100% 100%;
	}
	
</style>
