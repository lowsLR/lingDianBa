<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">锻器阁</block>
		</cu-custom>
	
		<view style="display: flex;flex-direction: column;line-height: 64rpx;font-size: 32rpx;color: #FFFFFF;margin-top: 50rpx;width: 620rpx;margin-left: 75rpx;">
			<view class="c-FFFFCC">锻造目标：{{infoObj.result?infoObj.result:''}}</view>
			<view class="c-FFFFCC">装备品质：<text v-html="qualityName"></text></view>
			<view class="c-CCFFFF">装备类型：{{equipTypeName}}</view>
			<view class="c-FFFF00">属性类型：{{equipObj.propertyType?equipObj.propertyType:''}}</view>
			<view class="c-00FFCC">基础属性：{{equipObj.initialRange?equipObj.initialRange:''}}</view>
			<view class="c-00FFCC">附加属性：{{equipObj.extraRange?equipObj.extraRange:''}}</view>
			<view class="c-00FFCC">附加条数：{{extraNum}}</view>
			<view class="c-FFFF00">成功概率：{{infoObj.rate?parseInt(infoObj.rate*100):''}}%</view>
			<view class="c-99CCFF">经验增加：{{infoObj.gainExp?infoObj.gainExp:0}}</view>
			<view class="c-CCCC00">所需水平：{{requireLevel}}</view>
			<view class="c-CCCC00" style="display: flex;flex-direction: row;">
				所需材料：<view style="display: flex;flex: 1;">{{infoObj.material?infoObj.material.replace(/#/g,', '):''}}</view>
			</view>
			<view class="c-FFFF00">锻造门人：{{disciple?disciple.nm:''}}</view>
			<view class="c-FFFF00">锻造水平：{{forgeLevel}}</view>
		</view>
		
		<view @tap="ajaxForge" class="btLayout">锻造</view>
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				infoObj:{},
				equipObj:{},
				qualityName:'',
				extraNum:'',
				requireLevel:'',
				forgeLevel:'',
				equipTypeName:'',
				disciple:null
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.infoObj = detail.info
			_self.disciple = detail.disciple
			_self.fillData()
		},
		methods: {
			ajaxForge() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'4_10',
					params:{
						discipleId:_self.disciple.id,
						formulaId:_self.infoObj.id
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						
					}
				}
				_self.$req.handleRequest(option)
			},
			fillData(disciple) {
				let equipInfo = _self.jsonParse.getEquipInitialInfoByName(_self.infoObj.result)
				if(equipInfo) {
					_self.equipObj = equipInfo
				}
				
				_self.qualityName = _self.jsonParse.getEquipQualityNameWithColor(_self.infoObj.quality)
				_self.extraNum = _self.jsonParse.getEquipExtraNumberByQuality(_self.infoObj.quality)
				_self.equipTypeName = _self.jsonParse.getEquipTypeNameByEquipName(_self.infoObj.result)
				
				_self.requireLevel = _self.jsonParse.getAlchemyForgeName(_self.infoObj.require,2)  // 1:炼丹、2：铸造
				_self.forgeLevel = _self.jsonParse.getAlchemyForgeName(_self.disciple.zl,2)
				
			},
			tapForge() {
				_self.navigateTo('/pages/building/building-disciple-choose')
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 442rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-left: 154rpx;
		margin-top: 100rpx;
		background:url(../../static/building-forge-pavilion-bt-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
