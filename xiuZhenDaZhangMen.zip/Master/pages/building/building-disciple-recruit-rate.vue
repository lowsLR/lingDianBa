<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">概率一览</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;align-items: center;">
			<view style="width: 620rpx;box-shadow: 0 0 20rpx #7B7B7B;margin-top: 60rpx;font-size: 30rpx;">
				<block v-if="showLeft">
					<view style="display: flex;flex-direction: row;height: 84rpx;">
						<view style="display: flex;flex: 1;color: #FFFFFF;justify-content: center;align-items: center;">人阵概率</view>
						<view @tap="showLeft=false" style="display: flex;flex: 1;color: #7B7B7B;justify-content: center;align-items: center;box-shadow: 0 0 20rpx #7B7B7B;">天阵概率</view>
					</view>
					<view style="display: flex;flex-direction: row;height: 150rpx;line-height: 54rpx;color: #FFFFFF;">
						<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;flex: 1;">
							<view>{{rateArray1[0]?rateArray1[0]:''}}</view>
							<view>{{rateArray1[2]?rateArray1[2]:''}}</view>
						</view>
						<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;flex: 1;">
							<view>{{rateArray1[1]?rateArray1[1]:''}}</view>
							<view>{{rateArray1[3]?rateArray1[3]:''}}</view>
						</view>
					</view>
				</block>
				<block v-else>
					<view style="display: flex;flex-direction: row;height: 84rpx;">
						<view @tap="showLeft=true" style="display: flex;flex: 1;color: #7B7B7B;justify-content: center;align-items: center;box-shadow: 0 0 20rpx #7B7B7B;">人阵概率</view>
						<view style="display: flex;flex: 1;color: #FFFFFF;justify-content: center;align-items: center;">天阵概率</view>
					</view>
					<view style="display: flex;flex-direction: row;height: 150rpx;line-height: 54rpx;color: #FFFFFF;">
						<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;flex: 1;">
							<view>{{rateArray2[0]?rateArray2[0]:''}}</view>
							<view>{{rateArray2[2]?rateArray2[2]:''}}</view>
						</view>
						<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;flex: 1;">
							<view>{{rateArray2[1]?rateArray2[1]:''}}</view>
							<view>{{rateArray2[3]?rateArray2[3]:''}}</view>
						</view>
					</view>
				</block>
			</view>
			
			<view class="bLayout" style="display: flex;flex-direction: row;width: 620rpx;margin-top: 60rpx;overflow: scroll;">
				<view style="display: flex;flex-direction: column;flex: 1;;">
					<view @tap="tapDisciple(info)" v-for="(info,index) in discipleArray" :key="index" v-if="index%2==0" :style="[{'color':info.nameColor}]" class="btLayout">{{info.name}}</view>
				</view>
				<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-end;">
					<view @tap="tapDisciple(info)" v-for="(info,index) in discipleArray" :key="index" v-if="index%2==1" :style="[{'color':info.nameColor}]" class="btLayout">{{info.name}}</view>
				</view>
			</view>
		</view>
		
		<popup-disciple ref="refDisciple"></popup-disciple>
	</view>
</template>

<script>
	import popupDisciples from '@/components/popup-disciple/popup-disciple.vue'
	var _self
	
	export default {
		data() {
			return {
				discipleArray:[],
				showLeft:true,
				rateArray1:[],
				rateArray2:[]
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.parseData(detail)
			_self.discipleArray = _self.jsonParse.getSpecialDiscipleArrayFromHire()
		},
		methods: {
			tapDisciple(info) {
				_self.$refs.refDisciple.open(info)
			},
			parseData(config) {
				let rateArray1 = []
				let config1 = config['1']
				config1.forEach((info)=>{
					let discipleQualityInfo = _self.jsonParse.getDiscipleQuality(info.intelligenceId)
					if(discipleQualityInfo) {
						rateArray1.push(discipleQualityInfo.name+'：'+_self.util.keepTwoDecimal(info.rate*100)+'%')
					}
				})
				_self.rateArray1 = rateArray1
				
				let rateArray2 = []
				let config2 = config['2']
				config2.forEach((info)=>{
					let discipleQualityInfo = _self.jsonParse.getDiscipleQuality(info.intelligenceId)
					if(discipleQualityInfo) {
						rateArray2.push(discipleQualityInfo.name+'：'+_self.util.keepTwoDecimal(info.rate*100)+'%')
					}
				})
				_self.rateArray2 = rateArray2
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 276rpx;
		height: 78rpx;
		text-align: center;
		line-height: 78rpx;
		font-size: 30rpx;
		color: #FFFFFF;
		margin-bottom: 40rpx;
		background:url(../../static/building-disciple-recruit-rate-bt-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bLayout {
		height: calc(100vh - var(--status-bar-height) - 100rpx - 354rpx);
	}
	
</style>
