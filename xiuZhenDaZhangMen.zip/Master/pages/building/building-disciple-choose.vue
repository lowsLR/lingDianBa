<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">选择弟子</block>
		</cu-custom>
		
		<view class="listHeight" style="display: flex;flex-direction: column;align-items: center;overflow: scroll;">
			<view @tap="tapChoose(info)" v-for="(info,index) in discipleArray" :key="index" class="btLayout">{{info.nm}}</view>
		</view>
		
		<uni-popup ref="refChoose" type="center" :custom="true" :mask-click="true">
			<image style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDisciple" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">风炮德（剑修）</view>
				<scroll-view scroll-y="true" style="line-height: 40rpx;font-size: 24rpx;color: #818181;height: 680rpx;width: 460rpx;margin-bottom: 40rpx;text-align: center;">
					<view style="display: flex;flex-direction: row;">
						<view style="width: 140rpx;height: 200rpx;border-radius: 4rpx;border: solid 1px #818181;margin-top: 10rpx;"></view>
						<view style="display: flex;flex: 1;margin-left: 26rpx;text-align: left;">就弗兰克萨考虑升级的就弗兰克萨考虑升级的就弗兰克萨考虑升级的就弗兰克萨考虑升级的就弗兰克萨考虑升级的就弗兰克萨考虑升级的虑升级的</view>
					</view>
					
					<view style="display: flex;flex-direction: row;margin-top: 50rpx;width: 460rpx;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>性别：男</view>
							<view>特殊体质：须叟灵体</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>资质：百年之才</view>
							<view>特殊体质：特殊天赋</view>
						</view>
					</view>
					
					<view style="display: flex;flex-direction: row;margin-top: 50rpx;width: 460rpx;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>初始气血：10000</view>
							<view>初始肉身：10000</view>
							<view>初始破甲：10000</view>
							<view>初始命中：15%</view>
							<view>初始暴击：15%</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>初始灵力：10000</view>
							<view>初始神念：10000</view>
							<view>初始格挡：10000</view>
							<view>初始躲闪：15%</view>
							<view>初始抗暴：15%</view>
						</view>
					</view>
					
				</scroll-view>
				
				<view class="bt1">确定</view>
				
			</view>
		</uni-popup>
		
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	var _self
	
	export default {
		components:{
			uniPopup
		},
		data() {
			return {
				discipleArray:[]
			}
		},
		onLoad() {
			_self = this
			_self.loadData()
		},
		methods: {
			loadData() {
				// let discipleArray = []
				// let disciples = getApp().globalData.disciples
				// disciples.forEach((disciple)=>{
				// 	if(disciple.pstn==2) {  // 筛选出弟子(剔除掌门)
				// 		discipleArray.push(disciple)
				// 	}
				// })
				// _self.discipleArray = discipleArray
				
				_self.discipleArray = getApp().globalData.disciples
			},
			tapDiscipleRecruit() {
				_self.$refs.refChoose.close()
				_self.navigateTo('/pages/building/building-disciple-recruit')
			},
			tapChoose(info) {
				// _self.$refs.refChoose.open()
				uni.$emit('choose', info)
				uni.navigateBack({
					delta:1
				})
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout:last-child {
		margin-bottom: 40rpx;
	}
	
	.dialogDisciple {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/build-disciple-choose-bt-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt2 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		display: flex;
		flex: 1;
		justify-content: center;
		align-items: center;
		background:url(../../static/disciple-equip-detail-bt-bg2.png) center center no-repeat;background-size:100% 100%;
	}
	
	.listHeight {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
</style>
