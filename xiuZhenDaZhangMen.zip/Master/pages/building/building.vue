<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">宗门建筑</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;align-items: center;">
			<view v-if="info.type!=4" v-for="(info,index) in builds" :key="index" @tap="tapItem(info)" class="btLayout">{{info.name}}</view>
		</view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDialog.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<block v-if="_self.infoObj.type==1">
					<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{infoObj.name}}</view>
					<image style="width: 320rpx;height: 320rpx;margin-top: 30rpx;margin-bottom: 44rpx;" src="/static/building-icon-1.png"></image>
					
					<view @tap="tapDiscipleRecruit" class="bt1">招收门人</view>
					<view @tap="tapPromote(type1)" class="bt1 mar-t-30">升级</view>
				</block>
				<block v-if="_self.infoObj.type==2">
					<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{infoObj.name}}</view>
					<image style="width: 320rpx;height: 320rpx;margin-top: 30rpx;margin-bottom: 44rpx;" src="/static/building-icon-2.png"></image>
					
					<view @tap="tapForgeHall(type2,name2)" class="bt1">{{name2}}</view>
					<view @tap="tapPromote(type2)" class="bt1 mar-t-30">升级</view>
				</block>
				<block v-if="_self.infoObj.type==3">
					<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{infoObj.name}}</view>
					<image style="width: 320rpx;height: 320rpx;margin-top: 30rpx;margin-bottom: 44rpx;" src="/static/building-icon-3.png"></image>
					
					<view @tap="tapForgeHall(type3,name3)" class="bt1">{{name3}}</view>
					<view @tap="tapPromote(type3)" class="bt1 mar-t-30">升级</view>
				</block>
			</view>
		</uni-popup>
		
		<uni-popup ref="refDetail" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDetail.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDisciple" style="display: flex;justify-content: center;color: #FFFFFF;">
				<view style="width: 488rpx;margin-top: 40rpx;display: flex;flex-direction: column;font-size: 30rpx;padding-left: 16rpx;line-height: 60rpx;">
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">{{infoObj.name}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?nextObj.name:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">等级：{{infoObj.level}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'等级：'+nextObj.level:notOpenText}}</view>
					</view>
					<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
						<view style="display: flex;flex: 1;">品质：{{jsonParse.getMaterialQualityName(infoObj.quality)}}</view>
						<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
						<view style="display: flex;flex: 1;">{{nextObj?'品质：'+jsonParse.getMaterialQualityName(nextObj.quality):notOpenText}}</view>
					</view>
					<block v-if="infoObj.type==1">
						<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
							<view style="display: flex;flex: 1;">门人上限：{{infoObj.doorCap}}</view>
							<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
							<view style="display: flex;flex: 1;">{{nextObj?'门人上限：'+nextObj.doorCap:notOpenText}}</view>
						</view>
						<view style="display: flex;flex-direction: row;line-height: 70rpx;align-items: center;">
							<view style="display: flex;flex: 1;">仆役上限：{{infoObj.servantCap}}</view>
							<image style="width: 78rpx;height: 46rpx;margin-right: 20rpx;" src="/static/arrow-right.png"></image>
							<view style="display: flex;flex: 1;">{{nextObj?'仆役上限：'+nextObj.servantCap:notOpenText}}</view>
						</view>
					</block>
					
					<view style="margin-top: 30rpx;">成功率：{{nextObj?(infoObj.successRate?util.keepTwoDecimal(infoObj.successRate*100)+'%':'0%'):notOpenText}}</view>
					<view v-if="infoObj.type==2">额外铸造加成：{{nextObj?(infoObj.successRate?util.keepTwoDecimal(infoObj.promoteRate*100)+'%':'0%'):notOpenText}}</view>
					<view v-if="infoObj.type==3">额外炼丹加成：{{nextObj?(infoObj.successRate?util.keepTwoDecimal(infoObj.promoteRate*100)+'%':'0%'):notOpenText}}</view>
					<view v-if="[2,3].indexOf(infoObj.type)!=-1">下级获得配方：{{nextObj?infoObj.gainFormula:'无'}}</view>
					<view style="display: flex;flex-direction: row;">
						升级消耗：<view style="display: flex;flex: 1;">{{nextObj?(infoObj.strengthConsume?infoObj.strengthConsume.replace(/#/g,', '):''):notOpenText}}</view>
					</view>
				</view>
				
				<view v-if="nextObj" @tap="ajaxPromote" class="btPromote">提升等级</view>
			</view>
		</uni-popup>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	var _self
	
	export default {
		components:{
			uniPopup,
			popupWords
		},
		data() {
			return {
				type1:1,
				type2:2,
				type3:3,
				type4:4,
				builds:[],
				name2:'锻造殿',
				name3:'炼丹殿',
				infoObj:{},
				nextObj:null,
				notOpenText:'暂未开放',
				wordsNew:'',
				keyWordsNew:''
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.toGetWordsNew()
				_self.ajaxData()
			})
		},
		methods: {
			toWordsNew(count) {
				let wordObj = _self.jsonParse.getNewWords('build')
				if(wordObj) {
					if(wordObj.count>count) {
						_self.wordsNew = wordObj.content
						_self.$refs.refWords.open()
						
						uni.setStorage({
						    key: _self.keyWordsNew,
						    data: count+1
						})
					}
				}
			},
			toGetWordsNew() {
				let keyWordsNew = 'wnb-'+getApp().globalData.sectView.sectId
				_self.keyWordsNew = keyWordsNew
				
				uni.getStorage({
				    key: keyWordsNew,
					success:function(res){
						_self.toWordsNew(res.data)
					},
				    fail:function(res){
						_self.toWordsNew(0)
					}
				})
			},
			toCloseDialog() {
				_self.$refs.refDialog.close()
			},
			toOpenDialog() {
				_self.$refs.refDialog.open()
			},
			toCloseDialogDetail() {
				_self.$refs.refDetail.close()
			},
			toOpenDialogDetail() {
				_self.$refs.refDetail.open()
			},
			tapPromote() {
				_self.nextObj = _self.jsonParse.getBuilding(_self.infoObj.type,_self.infoObj.level+1)
				_self.toOpenDialogDetail()
			},
			ajaxPromote() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'4_2',
					params:{
						buildType:_self.infoObj.type
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						switch(resData.rs) {
							case 1:
								let bInfo = resData.buildInfo
								let buildInfo = _self.jsonParse.getBuilding(bInfo.buildingType,bInfo.level)
								if(buildInfo) {
									_self.builds.splice(_self.builds.findIndex(item => item.type==buildInfo.type),1,buildInfo)
								}
								
								let infoObj
								_self.builds.forEach((build)=>{
									if(build.type==_self.infoObj.type) {
										infoObj = build
									}
								})
								if(infoObj) {
									_self.infoObj = infoObj
									_self.nextObj = _self.jsonParse.getBuilding(_self.infoObj.type,_self.infoObj.level+1)
								}
								_self.showToast('升级建筑成功')
								break;
								
							case 2:
								_self.showToast('升级建筑失败')
								break;
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxData() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'4_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let builds = resData.builds
						builds.forEach((info,index)=>{
							builds[index] = _self.jsonParse.getBuilding(info.buildingType,info.level)
						})
						_self.builds = builds
					}
				}
				_self.$req.handleRequest(option)
			},
			tapDiscipleRecruit() {
				_self.toCloseDialog()
				_self.navigateTo('/pages/building/building-disciple-recruit')
			},
			tapForgeHall(type,name) {
				_self.toCloseDialog()
				_self.navigateTo(_self.util.toEncodeUri('/pages/building/building-forge-hall',{
					buildType:type,
					name:name
				}))
			},
			tapItem(info) {
				_self.infoObj = info
				_self.toOpenDialog()
				
				// _self.$refs.refDetail.open()
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogDisciple {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt1 {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt2 {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		color: #FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
		background:url(../../static/disciple-equip-detail-bt-bg2.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogLayout {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btPromote {
		position: absolute;
		bottom: 50rpx;
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
