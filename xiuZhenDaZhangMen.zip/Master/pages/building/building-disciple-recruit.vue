<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">招收门人</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: row;width: 700rpx;margin-left: 25rpx;margin-top: 20rpx;">
			<view style="display: flex;flex: 1;flex-direction: column;align-items: center;">
				<image @tap="tapHire(recuritType1,typeObj['1'])" style="height: 280rpx;width: 280rpx;vertical-align: top;" src="/static/building-disciple-recruit-people.png"></image>
				<view style="text-align: center;color: #9A9A9A;font-size: 30rpx;">
					消耗：
					<text v-if="cd1==0">免费</text>
					<text v-else>{{consume1}}</text>
				</view>
				<view v-if="cd1>0" style="text-align: center;color: #9A9A9A;font-size: 30rpx;">免费：{{cdTime1}}</view>
			</view>
			<view style="display: flex;flex: 1;flex-direction: column;align-items: center;">
				<image @tap="tapHire(recuritType2,typeObj['2'])" style="height: 280rpx;width: 280rpx;vertical-align: top;" src="/static/building-disciple-recruit-sky.png"></image>
				<view style="text-align: center;color: #9A9A9A;font-size: 30rpx;">
					消耗：
					<text v-if="cd2==0">免费</text>
					<text v-else>{{consume2}}</text>
				</view>
				<view v-if="cd2>0" style="text-align: center;color: #9A9A9A;font-size: 30rpx;">免费：{{cdTime2}}</view>
			</view>
		</view>
		<view @tap="tapRate" class="btRate">概率一览</view>
		<view class="ruleLayout" style="display: flex;justify-content: center;">
			<view style="overflow: scroll;height: 330rpx;width: 510rpx;margin-top: 6rpx;margin-top: 30rpx;text-align: left;" v-html="introduction"></view>
		</view>
		
		<view style="width: 100%;display: flex;flex-direction: row;margin-top: 50rpx;justify-content: center;">
			<!-- <view @tap="tapHire(recuritType3,typeObj['3'])" class="btLayout1">天道恩赐</view>
			<view @tap="tapSsdt" class="btLayout1 mar-l-86">三生道台</view> -->
			<view @tap="tapSsdt" class="btLayout1">三生道台</view>
		</view>
		<view v-if="tdScore>=0" style="text-align: center;color: #9A9A9A;font-size: 30rpx;line-height: 110rpx;">天道积分：{{tdScore}}</view>
		
		
		<!-- <view @tap="tapHire(recuritType3,typeObj['3'])" class="btTdec">天道恩赐</view> -->
		
		<uni-popup ref="refDisciple" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDisciple.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDisciple" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{dialog.name}}（{{dialog.jobName}}）</view>
				<scroll-view scroll-y="true" style="line-height: 54rpx;font-size: 28rpx;color: #EEEEEE;height: 800rpx;width: 480rpx;margin-bottom: 40rpx;">
					<view style="display: flex;flex-direction: row;margin-top: 10rpx;justify-content: center;">
						<image v-if="dialog.icon>100" style="width: 140rpx;height: 190rpx;" :src="dialog.avatarUrl?dialog.avatarUrl:''"></image>
						<view v-else style="width: 140rpx;height: 190rpx;margin-top: 6rpx;background-color: #AFA07D;border-radius: 10rpx;display: flex;justify-content: center;align-items: center;">
							<image style="width: 140rpx;height: 140rpx;" :src="dialog.avatarUrl?dialog.avatarUrl:''"></image>
						</view>
					</view>
					
					<view class="mar-t-30">特殊体质：{{dialog.physique}}</view>
					<view>特殊天赋：{{dialog.gift}}</view>
					<view style="display: flex;flex-direction: row;">
						<view style="display: flex;flex: 1;">性别：{{dialog.sex}}</view>
						<view style="display: flex;flex: 1;">资质：{{dialog.qualification}}</view>
					</view>
					<!-- <view style="display: flex;flex-direction: row;">
						<view style="display: flex;flex: 1;">特殊体质：{{dialog.physique}}</view>
						<view style="display: flex;flex: 1;">特殊天赋：{{dialog.gift}}</view>
					</view> -->
					
					<view class="mar-t-30" style="display: flex;flex-direction: row;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>初始气血：{{dialog.property['1']?dialog.property['1']:''}}</view>
							<view>初始神念：{{dialog.property?dialog.property['3']:''}}</view>
							<view>初始破甲：{{dialog.property?dialog.property['5']:''}}</view>
							<view>初始命中：{{dialog.property?parseInt(dialog.property['7']*100)+'%':''}}</view>
							<view>初始暴击：{{dialog.property?parseInt(dialog.property['9']*100)+'%':''}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>初始灵力：{{dialog.property?dialog.property['2']:''}}</view>
							<view>初始肉身：{{dialog.property?dialog.property['4']:''}}</view>
							<view>初始格挡：{{dialog.property?dialog.property['6']:''}}</view>
							<view>初始躲闪：{{dialog.property?parseInt(dialog.property['8']*100)+'%':''}}</view>
							<view>初始抗暴：{{dialog.property?parseInt(dialog.property['10']*100)+'%':''}}</view>
						</view>
					</view>
					
					<!-- <view style="display: flex;flex-direction: row;margin-top: 50rpx;width: 460rpx;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>性别：{{dialog.sex}}</view>
							<view>特殊体质：{{dialog.physique}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>资质：{{dialog.qualification}}</view>
							<view>特殊体质：{{dialog.gift}}</view>
						</view>
					</view> -->
					
					<!-- <view style="display: flex;flex-direction: row;margin-top: 50rpx;width: 460rpx;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>初始气血：{{dialog.property['1']?dialog.property['1']:''}}</view>
							<view>初始神念：{{dialog.property?dialog.property['3']:''}}</view>
							<view>初始破甲：{{dialog.property?dialog.property['5']:''}}</view>
							<view>初始命中：{{dialog.property?parseInt(dialog.property['7']*100)+'%':''}}</view>
							<view>初始暴击：{{dialog.property?parseInt(dialog.property['9']*100)+'%':''}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>初始灵力：{{dialog.property?dialog.property['2']:''}}</view>
							<view>初始肉身：{{dialog.property?dialog.property['4']:''}}</view>
							<view>初始格挡：{{dialog.property?dialog.property['6']:''}}</view>
							<view>初始躲闪：{{dialog.property?parseInt(dialog.property['8']*100)+'%':''}}</view>
							<view>初始抗暴：{{dialog.property?parseInt(dialog.property['10']*100)+'%':''}}</view>
						</view>
					</view> -->
					
				</scroll-view>
				
				<!-- <view style="display: flex;flex-direction: row;width: 460rpx;">
					<view class="bt bt1">舍弃</view>
					<view class="bt bt2" style="margin-left: 80rpx;">收入门下</view>
				</view> -->
			</view>
		</uni-popup>
		
		<popup-confirm ref="refText" @confirm="ajaxHire" :content="dialogText" :maskClick="true"></popup-confirm>
	</view>
</template>

<script>
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	
	export default {
		components:{
			popupConfirm
		},
		data() {
			return {
				recuritType1:1,
				recuritType2:2,
				recuritType3:3,
				cd1:-1,
				cd2:-1,
				interval1:null,
				interval2:null,
				cdTime1:'--:--:--',
				cdTime2:'--:--:--',
				consume1:'',
				consume2:'',
				config:null,
				dialog:{
					icon:0,
					name:'',
					avatarUrl:'',
					description:'',
					sex:'',
					qualification:'',
					physique:'',
					gift:'',
					jobName:'',
					property:{}
				},
				introduction:'1.人阵招人与天阵招人是获得门人弟子的重要途径<br>2.人阵招人每次消耗三万灵石，必然获得一名弟子与一点天道积分，每八个小时可进行一次免费招人<br>3.天阵招人每次消耗二百仙石，必然获得一名弟子与十点天道积分，每二十四小时可进行一次免费招人<br>4.人阵招人与天阵招人的概率以及可能出现的弟子，请查看概率一览<br>5.招收到的弟子有普通弟子与剧情人物，剧情人物有特殊头像<br>6.天道积分可在三生道台中换取各种物品与弟子',
				typeObj:{
					1:'人阵招人',
					2:'天阵招人',
					3:'天道恩赐'
				},
				recruitType:0,
				dialogText:'',
				tdScore:-1
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.ajaxData()
			})
		},
		onUnload() {
			_self.toClearInterval()
		},
		onShow() {
			_self.getTdScore()
		},
		methods: {
			toInterval() {
				if(_self.cd1>0) {
					if(!_self.interval1) {
						_self.interval1 = setInterval(function() {
							_self.cd1--
							_self.cdTime1 = _self.getdjs(_self.cd1*1000)
							
							if(_self.cd1<=0) {
								clearInterval(_self.interval1)
								_self.interval1 = null
							}
						},1000)
					}
				}
				if(_self.cd2>0) {
					if(!_self.interval2) {
						_self.interval2 = setInterval(function() {
							_self.cd2--
							_self.cdTime2 = _self.getdjs(_self.cd2*1000)
							
							if(_self.cd2<=0) {
								clearInterval(_self.interval2)
								_self.interval2 = null
							}
						},1000)
					}
				}
			},
			toClearInterval() {
				if(_self.interval1) {
					clearInterval(_self.interval1)
					_self.interval1 = null
				}
				if(_self.interval2) {
					clearInterval(_self.interval2)
					_self.interval2 = null
				}
			},
			getdjs(cha_haomiao){
				//计算出相差天数
				var leave0 = cha_haomiao % (30 * 24 * 3600 * 1000);
				var days = Math.floor(leave0 / (24 * 3600 * 1000));
				//计算小时数
				var leave1 = leave0 % (24 * 3600*1000);     //计算天数后剩余的毫秒数
				var hours = Math.floor(leave1 / (3600*1000))+days*24;
				//计算相差分钟数
				var leave2 = leave1 % (3600*1000);         //计算小时数后剩余的毫秒数
				var minutes = Math.floor(leave2 / (60*1000) );
				//计算相差秒数
				var leave3 = leave2 % (60*1000);       //计算分钟数后剩余的毫秒数
				var seconds = Math.round(leave3/1000);
							
				var ltime=(hours<10?("0"+String(hours)):String(hours))+':'+(minutes<10?"0":String(minutes).substr(0,1))+(minutes<10?minutes:String(minutes).substr(1,1))+':'+(seconds<10?"0":String(seconds).substr(0,1))+(seconds<10?seconds:String(seconds).substr(1,1));
				
				return ltime
			},
			tapSsdt() {
				_self.navigateTo(_self.util.toEncodeUri('/pages/shop/market-detail',{
					name:'三生道台',
					marketType:101,
					level:101
				}))
			},
			getTdScore() {
				// 通过名称获取对应的 materialType 和 id  天道积分*1 => 1:10008:1
				let text = _self.jsonParse.exchangeMapMaterialFormat('天道积分*1')
				if(text) {
					let textArray = text.split(':')
					let materialObj = getApp().globalData.materialObj
					let tdObj = materialObj[_self.util.getMaterialKey(textArray[0],textArray[1])]
					if(tdObj) {
						_self.tdScore = tdObj.count
					}
				}
			},
			tapHire(recruitType,name) {
				_self.recruitType = recruitType
				_self.dialogText = name
				_self.$refs.refText.open()
			},
			tapRate() {
				if(_self.config) {
					_self.navigateTo(_self.util.toEncodeUri('/pages/building/building-disciple-recruit-rate',_self.config))
				}else {
					_self.ajaxData()
				}
			},
			ajaxHire() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_2',
					params:{
						recruitType:_self.recruitType
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let disciple = resData.disciple
						_self.util.addDisciple(disciple)
						
						// 更新天道积分
						_self.getTdScore()
						
						let dialogObj = {}
						let qualification = ''
						let discipleQualityInfo = _self.jsonParse.getDiscipleQuality(disciple.itgc)
						if(discipleQualityInfo) {
							qualification = discipleQualityInfo.name
						}
						dialogObj.qualification = qualification
						dialogObj.name = disciple.nm
						dialogObj.jobName = _self.jsonParse.getNameByJob(disciple.job)
						dialogObj.sex = _self.util.getNameBySex(disciple.sex)
						dialogObj.property = _self.util.parseProperty(disciple.bp)
						dialogObj.physique = _self.jsonParse.getPhysiqueGiftName(disciple.ps)
						dialogObj.gift = _self.jsonParse.getPhysiqueGiftName(disciple.gs)
						dialogObj.icon = disciple.icon
						_self.util.getAvatarUrl(disciple.sex,disciple.icon,url => {
							dialogObj.avatarUrl = url
							_self.dialog = dialogObj
							_self.$refs.refDisciple.open()
						})
						
						// 处理cd   人阵招人和天阵招人
						if([1,2].indexOf(_self.recruitType)!=-1) {
							let resultCd = resData.cd
							if(resultCd>0) {
								switch(_self.recruitType) {
									case 1:
										_self.cd1 = resultCd
										break;
										
									case 2:
										_self.cd2 = resultCd
										break;
								}
								_self.toInterval()
							}
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxData(hideLoading) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = hideLoading
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'3_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let config = resData.config
						let config1 = config['1'][0]
						let consumeInfo1 = config1.consume[0]
						let materialInfo1 = _self.jsonParse.getMaterialInfo(consumeInfo1.materialType,consumeInfo1.materialId)
						if(materialInfo1) {
							_self.consume1 = consumeInfo1.count+materialInfo1.name
						}
						_self.recuritType1 = config1.recruitType
						
						let config2 = config['2'][0]
						let consumeInfo2 = config2.consume[0]
						let materialInfo2 = _self.jsonParse.getMaterialInfo(consumeInfo2.materialType,consumeInfo2.materialId)
						if(materialInfo2) {
							_self.consume2 = consumeInfo2.count+materialInfo2.name
						}
						_self.recuritType2 = config2.recruitType
						
						let config3 = config['3'][0]
						_self.recuritType3 = config3.recruitType
						
						_self.config = config
						
						let cd = resData.cd
						_self.cd1 = cd['1']
						_self.cd2 = cd['2']
						_self.toInterval()
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btRate {
		width: 198rpx;
		height: 56rpx;
		text-align: center;
		line-height: 56rpx;
		font-size: 30rpx;
		color: #9A9A9A;
		margin-top: 40rpx;
		margin-left: 276rpx;
		background:url(../../static/building-disciple-recruit-bg-bt1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.ruleLayout {
		width: 100%;
		height: 388rpx;
		text-align: center;
		line-height: 56rpx;
		font-size: 30rpx;
		color: #9A9A9A;
		margin-top: 50rpx;
		background:url(../../static/building-disciple-recruit-bg-rule.png) center center no-repeat;background-size:562rpx 100%;
	}
	
	.btTdec {
		width: 442rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-left: 154rpx;
		margin-top: 50rpx;
		background:url(../../static/building-disciple-recruit-bg-bt2.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogDisciple {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt {
		width: 190rpx;
		height: 88rpx;
		font-size: 34rpx;
		line-height: 88rpx;
		display: flex;
		flex: 1;
		justify-content: center;
		align-items: center;
	}
	
	.bt1 {
		color: #676767;
		background:url(../../static/building-disciple-recruit-bt-abandon.png) center center no-repeat;background-size:100% 100%;
	}
	
	.bt2 {
		color: #FFFFFF;
		background:url(../../static/building-disciple-recruit-bt-get.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout1 {
		width: 246rpx;
		height: 88rpx;
		text-align: center;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		background:url(../../static/disciple-property-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
