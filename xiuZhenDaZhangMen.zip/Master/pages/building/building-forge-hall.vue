<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">{{name}}</block>
		</cu-custom>
		
		<!-- <scroll-view class="sv" scroll-y="true"> -->
			<view class="listHeight" style="display: flex;flex-direction: column;align-items: center;overflow: scroll;">
				<view @tap="tapItem(text)" v-for="(text,index) in formulaArray" :key="index" class="btLayout">{{text}}</view>
			</view>
		<!-- </scroll-view> -->
		
		<image @tap="tapChoose" :style="[{'background-color':disciple&&masterIcon<=100?'#AD9E7C':''}]" mode="aspectFill" style="position: fixed;bottom: 77rpx;right: 77rpx;border-radius: 50%;height: 140rpx;width: 140rpx;background-color: #FFFFFF;" :src="avatarUrl?avatarUrl:'/static/building-forge-hall-add.png'"></image>
		
		<view v-if="showTip" class="tipView">{{tipText}}</view>
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	var _self
	
	export default {
		components:{
			uniPopup
		},
		data() {
			return {
				formulaArray:[],
				buildType:0,
				name:'',
				disciple:null,
				masterIcon:-1,
				avatarUrl:'',
				tipText:'',
				showTip:false,
				showTipTime:1000
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			const buildType = detail.buildType
			_self.buildType = buildType
			_self.name = detail.name
			_self.formulaArray = _self.jsonParse.getDirectionArrayByType(detail.buildType)
			switch(buildType) {
				case 2:
					_self.tipText = '请选择锻造弟子'
					break;
					
				case 3:
					_self.tipText = '请选择炼丹弟子'
					break;
			}
			
		},
		onUnload() {
			uni.$off('choose',_self.chooseCallback)
		},
		methods: {
			chooseCallback(disciple) {
				_self.disciple = disciple
				_self.masterIcon = disciple.icon
				_self.util.getAvatarUrl(disciple.sex,disciple.icon,url => {
					_self.avatarUrl = url
				})
			},
			tapChoose() {
				uni.$on('choose',_self.chooseCallback)
				_self.navigateTo('/pages/building/building-disciple-choose')
			},
			tapItem(text) {
				let disciple = _self.disciple
				if(disciple) {
					_self.navigateTo(_self.util.toEncodeUri('/pages/building/building-forge-formula-list',{
						direction:text,
						disciple:disciple,
						buildType:_self.buildType
					}))
				}else {
					if(!_self.showTip) {
						_self.showTip = true
						setTimeout(function() {
							_self.showTip = false
						},_self.showTipTime)
					}
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout:last-child {
		margin-bottom: 40rpx;
	}
	
	.tipView {
	    padding: 20rpx;
	    border-radius: 10rpx;
	    display: -webkit-inline-box;
	    display: -webkit-inline-flex;
	    display: -ms-inline-flexbox;
	    display: inline-flex;
	    max-width: 280rpx;
	    -webkit-box-align: center;
	    -webkit-align-items: center;
	    -ms-flex-align: center;
	    align-items: center;
	    font-size: 32rpx;
	    line-height: 40rpx;
	    text-align: left;
		box-shadow: 0 0 20rpx #FFFF00;
		color: #FFFFFF;
		background-color: #000000;
		color: #FFFFFF;
		
		position: absolute;
		right: 250rpx;
		bottom: 100rpx;
	}
	
	.tipView:after {
	    content: "";
	    top: 13px;
	    -webkit-transform: rotate(45deg);
	    -ms-transform: rotate(45deg);
	    transform: rotate(45deg);
	    position: absolute;
	    z-index: 100;
	    display: inline-block;
	    overflow: hidden;
	    width: 12px;
	    height: 12px;
	    left: auto;
	    right: -6px;
	    background-color: inherit;
	}
	
	.listHeight {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
</style>
