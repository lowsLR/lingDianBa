<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">资源商人</block>
		</cu-custom>
		<!-- 商人头像 -->
		<view class="merchant">
			<image src="/static/resource-merchant/shangren.png" mode=""></image>
			<view class="text">每天资源兑换比例会有浮动，记得来看看哦！</view>
		</view>

		<!-- 兑换 -->
		<scroll-view scroll-y="true" class="sv">
			<view v-if="hasExchange" class="resource">
				<view class="layout" v-if="(exchangeLimitMap[obj.id]-exchangeCountMap[obj.id])>0" v-for="(obj,key,index) in materialObj" :key="key">
					<image :src="'/static/resource-merchant/icon-'+nameObj[obj.name]+'.png'" mode="" class="left"></image>
					<view class="midden">
						<view class="jianimg mar-r-16">
							<image @tap="tapAddMinus(amType1,obj.id)" src="/static/resource-merchant/screrion.png" mode=""></image>
						</view>

						<!-- 滑轮 -->
						<view class="hualun">
							<view style="text-align: center;color: #FFFFFF;font-size: 26rpx;margin-bottom: -14rpx;" :class="chooseCountObj[obj.id]==0?'isHidden':''">兑换 {{obj.name}}*{{chooseCountObj[obj.id]*rateObj[obj.id]}}</view>
							<slider @change="sliderChange($event,obj)" :value="chooseCountObj[obj.id]" step="1" :max="exchangeLimitMap[obj.id]-exchangeCountMap[obj.id]" block-size="10" activeColor="#999999" backgroundColor="transparent" />
							<view style="text-align: center;color: #FFFFFF;font-size: 26rpx;margin-top: -14rpx;" :class="chooseCountObj[obj.id]==0?'isHidden':''">消耗 仙石*{{chooseCountObj[obj.id]*10}}</view>
						</view>

						<view class="add mar-l-16">
							<image @tap="tapAddMinus(amType2,obj.id)" src="/static/resource-merchant/add.png" mode=""></image>
						</view>
					</view>
					<view class="right">
						<text>兑换</text>
						<image @tap="tapExchance(obj)" src="/static/resource-merchant/duihuan-btn.png" mode=""></image>
					</view>
				</view>
			</view>
			<view v-else style="text-align: center;color: #666666;font-size: 36rpx;padding-top: 100rpx;">暂无兑换</view>
		</scroll-view>
		
		<popup-confirm @confirm="ajaxExchange" :maskClick="true" ref="refExchange" :content="exchangeText"></popup-confirm>
	</view>
</template>

<script>
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	var _self
	export default {
		components:{
			popupConfirm
		},
		data() {
			return {
				num: '',
				perConsume:10  ,// 固定每次消耗10仙石
				rateObj:{},
				exchangeCountMap:{},
				exchangeLimitMap:{},
				nameObj:{
					'灵石':10002,
					'木材':10003,
					'矿石':10004,
					'灵草':10005,
					'灵粮':10006
				},
				materialObj:{},
				chooseCountObj:{},
				amType1:1,
				amType2:2,
				exchangeText:'',
				chooseId:-1,
				hasExchange:true
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.ajaxConfig()
			})
		},
		methods: {
			showExchange() {
				let exchangeLimitMap = _self.exchangeLimitMap
				let exchangeCountMap = _self.exchangeCountMap
				
				let hasExchange = false
				Object.keys(exchangeLimitMap).forEach(key => {
					if((exchangeLimitMap[key]-exchangeCountMap[key])>0) {
						hasExchange = true
					}
				})
				_self.hasExchange = hasExchange
			},
			doDialog(text) {
				_self.exchangeText = text
				_self.$refs.refExchange.open()
			},
			tapExchance(obj) {
				let chooseId = obj.id
				let chooseCount = _self.chooseCountObj[chooseId]
				if(chooseCount>0) {
					_self.chooseId = chooseId
					let exchangeText = '兑换 '+obj.name+'*'+chooseCount*_self.rateObj[chooseId]+'<br>消耗 仙石*'+chooseCount*10
					_self.doDialog(exchangeText)
				}else {
					_self.showToast('请选择兑换次数')
				}
			},
			tapAddMinus(type,id) {
				let chooseCount = _self.chooseCountObj[id]
				let chooseCountLimit = _self.exchangeLimitMap[id] - _self.exchangeCountMap[id]
				switch(type) {
					case _self.amType1:
						chooseCount--
						break;
						
					case _self.amType2:
						chooseCount++
						break;
				}
				if(chooseCount<0) {
					chooseCount = 0
				}else if(chooseCount>chooseCountLimit) {
					chooseCount = chooseCountLimit
				}
				_self.chooseCountObj[id] = chooseCount
			},
			getMaterialObj() {
				let materialObj = _self.materialObj
				if(Object.keys(materialObj).length==0) {
					_self.materialObj = _self.jsonParse.getExchangeMaterialObj()
				}
			},
			ajaxConfig() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'8_10'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let exchangeLimitMap = resData.exchangeLimitMap
						let exchangeCountMap = resData.exchangeCountMap
						let chooseCountObj = {}
						Object.keys(exchangeLimitMap).forEach(key => {
							if(!exchangeCountMap[key]) {
								exchangeCountMap[key] = 0
							}
							chooseCountObj[key] = 0
						})
						_self.chooseCountObj = chooseCountObj
						_self.exchangeCountMap = exchangeCountMap
						_self.exchangeLimitMap = exchangeLimitMap
						_self.rateObj = resData.rate
						
						_self.getMaterialObj()
						_self.showExchange()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxExchange() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'8_11',
					params:{
						resourceExchangeId:_self.chooseId,
						exchangeCount:_self.chooseCountObj[_self.chooseId]
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.showToast('兑换成功')
						
						let exchangeLimitMap = _self.exchangeLimitMap
						let exchangeCountMap = resData.exchangeCountMap
						let chooseCountObj = {}
						Object.keys(exchangeLimitMap).forEach(key => {
							if(!exchangeCountMap[key]) {
								exchangeCountMap[key] = 0
							}
							chooseCountObj[key] = 0
						})
						_self.chooseCountObj = chooseCountObj
						_self.exchangeCountMap = exchangeCountMap
						_self.showExchange()
					}
				}
				_self.$req.handleRequest(option)
			},
			sliderChange(e,info) {
				_self.chooseCountObj[info.id] = e.detail.value
			}
		}
	};
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background: url(../../static/home-bg.png) center center no-repeat;
		background-size: 750rpx 1550rpx;
	}

	.fontSize {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: space-around;
	}

	.boldFont {
		font-size: 34rpx;
		font-weight: bold;
		color: rgba(255, 255, 255, 1);
	}

	.linerFont {
		color: #cccccc;
		font-size: 30rpx;
		font-weight: 400;
	}

	.merchant {
		padding: 49rpx 54rpx;
		display: flex;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		line-height: 52rpx;
	}

	.merchant image {
		width: 252rpx;
		height: 344rpx;
		background: rgba(0, 0, 0, 1);
		display: block;
	}

	.merchant .text {
		width: 303rpx;
		height: 80rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		line-height: 52rpx;
		margin-left: 62rpx;
		padding-top: 60rpx;
	}

	.resource {
		padding: 30rpx;
	}

	.resource .layout {
		display: flex;
		align-items: center;
		margin-bottom: 50rpx;
	}

	.resource .left {
		width: 120rpx;
		height: 120rpx;
		display: block;
		flex-shrink: 0;
	}

	.resource .right {
		width: 160rpx;
		height: 78rpx;
		text-align: center;
		line-height: 78rpx;
		font-size: 30rpx;
		color: #ffb662;
		position: relative;
	}

	.right image {
		width: 100%;
		height: 78rpx;
		display: block;
		position: absolute;
		top: 0;
		left: 0;
	}

	.resource .midden {
		flex: 1;
		display: flex;
		align-items: center;
		margin: 0 20rpx;
	}

	.midden .jianimg image,
	.midden .add image {
		width: 40rpx;
		height: 40rpx;
		display: block;
		flex-shrink: 0;

	}

	.midden .hualun {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.midden .hualun .num {
		font-size: 24rpx;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		margin-bottom: -30rpx;
		margin-left: 10rpx;
	}

	.resource .layout:nth-child(2) {
		/* margin: 60rpx 0; */
	}
	
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 100rpx - 442rpx);
	}
	
	.isHidden {
		visibility: hidden;
	}
	
</style>
