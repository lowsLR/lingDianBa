<template>
	<view class="container">
		<view class="status_bar">
			<view class="top_view"></view>
		</view>
		<!-- 怪 -->
		<view class="fight-main">
			<view class="target-view">
				<view class="target-view-column" v-for="(i,ti) in 3" :key="ti">
					<view class="target-view-item" v-for="(n,tn) in 3" :key="ti+tn">
						<view class="dz-view-list flex-ccc" :class="[glist[ti][tn]&&glist[ti][tn].isShake?' animation-shake':'']">
							<view v-if="glist[ti][tn]!=null" class="man-view flex-ccc">
								<view class="progress-view pro-br">
									<text>{{glist[ti][tn].curHp}}</text>
									<view class="bg-red" :style="[{ width:glist[ti][tn].hpload?glist[ti][tn].hpload+'%':'0%'}]">
									</view>
								</view>
								<view class="progress-view pro-bb">
									<text>{{glist[ti][tn].curMp}}</text>
									<view class="bg-blue" :style="[{ width:glist[ti][tn].mpload?glist[ti][tn].mpload+'%':'0%'}]">
									</view>
								</view>
								<text class="text-nowrap" :class="[glist[ti][tn].fsnum?'f'+st.fsnum:'']">{{glist[ti][tn].name}}</text>
						
								<view v-if="glist[ti][tn].isxlist" class="bloodview" :class="[glist[ti][tn].xlist&&glist[ti][tn].xlist.xc]">
									<text :class="[glist[ti][tn].xlist&&glist[ti][tn].xlist.isbj?'isbj':'']">
										{{glist[ti][tn].xlist.xc=='red'?'-':'+'}}{{glist[ti][tn].xlist.num > 0 ? glist[ti][tn].xlist.num : 'miss'}}
									</text>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<!-- <view class="vs-main"> -->
				<view class="vs-view">
				</view>
			<!-- </view> -->
			
			<!-- 人 -->
			<view class=" self-view">
				<view class="self-view-column" v-for="(i,inum) in 3" :key="inum">
					<view class="self-view-item" v-for="(n,nnum) in 3" :key="inum+nnum">
						<view class="dz-view-list flex-ccc" :class="[slist[inum][nnum]&&slist[inum][nnum].isShake?' animation-shake':'']">
							<view v-if="slist[inum][nnum]!=null" class="man-view flex-ccc">
								<view class="progress-view pro-br">
									<text>{{slist[inum][nnum].curHp}}</text>
									<view class="bg-red" :style="[{ width:slist[inum][nnum].hpload?slist[inum][nnum].hpload+'%':'0%'}]">
									</view>
								</view>
								<view class="progress-view pro-bb">
									<text>{{slist[inum][nnum].curMp}}</text>
									<view class="bg-blue" :style="[{ width:slist[inum][nnum].mpload?slist[inum][nnum].mpload+'%':'0%'}]">
									</view>
								</view>
								<text class="text-nowrap" :class="[slist[inum][nnum].fsnum?'f'+st.fsnum:'']">{{slist[inum][nnum].name}}</text>
						
								<view v-if="slist[inum][nnum].isxlist" class="bloodview" :class="[slist[inum][nnum].xlist&&slist[inum][nnum].xlist.xc]">
									<text :class="[slist[inum][nnum].xlist&&slist[inum][nnum].xlist.isbj?'isbj':'']">
										{{slist[inum][nnum].xlist.xc=='red'?'-':'+'}}{{slist[inum][nnum].xlist.num > 0 ? slist[inum][nnum].xlist.num : 'miss'}}
									</text>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 文字 -->
			<view class="que-data ">
				<view class="h100 ">
					<scroll-view scroll-y="true" id="scrollview" :scroll-top="scrollTop" :scroll-with-animation="true" class="h100">
						<!-- :style="{height:solHeight+'rpx'}" -->
						<view class="hall-view">
							<view class="text-view1 main-item" v-for="(item,index) in clist" :key="'c'+index">
								<text class="c-FFFFFF" v-for="(items,indexs) in item.mb">
									<!-- <text>{{item.skillRange}}{{item.attackType}}</text> -->
									<text class="c-FFFF00">{{item.name}}</text>
									使用了
									<text class="c-99FFFF">{{item.skills}}</text>
									<text v-if="items.miss">
										<text v-if="item.attackType != '恢复'">可惜灵力紊乱，无法造成伤害</text>
										<text v-else>可惜灵力紊乱，无法恢复气血</text>
									</text>
									<text v-else>
										<text v-if="items.crit">
											<text class="c-FFFF00">灵力狂暴之下，对</text>
											<text class="c-FF0000">{{items.name}}</text>
											<text v-if="item.attackType != '恢复'">
												<text class="c-99FFFF">造成了</text>
												<text class="c-FF0000">{{items.cnumber}}伤害</text>
											</text>
											<text v-else class="">
												<text class="c-33FF33"> 恢复了</text>
												<text class="c-33FF99">{{items.cnumber}}气血</text>
											</text>
										</text>
										<text v-else>
											<text class="c-FFFF00">，对</text>
											<text class="c-FF0000">{{items.name}}</text>
											<text v-if="item.attackType != '恢复'">
												<text class="c-99FFFF">造成了</text>
												<text class="c-FF0000">{{items.cnumber}}伤害</text>
											</text>
											<text v-else class="">
												<text class="c-33FF33"> 恢复了</text>
												<text class="c-33FF99">{{items.cnumber}}气血</text>
											</text>
										</text>
									</text>
								</text>
							</view>
						</view>
					</scroll-view>
				</view>
			</view>
		
			<view class="" style="width: 100%;height: 60rpx;">
				
			</view>
		</view>
		
		<!-- <view class="page-foot">
			<view class="flex-ca">
				<view class="flex1 listView mbcFF0000 mar-t32" @tap="skip">
					跳过
				</view>
				<view class="flex1 listView mbcFF0000 mar-t32" @tap="jieshu">
					结束
				</view>
				<view class=" flex1 listView mbcFF0000 mar-t32" @tap="kais">
					开始
				</view>
				<view class="flex1 listView mbcFF0000 mar-t32" @tap="suspend">
					暂停
				</view>
				<view class="flex1 listView mbcFF0000 mar-t32" @tap="nextRound">
					下回
				</view>
				<view class="flex1 listView mbcFF0000 mar-t32" @tap="startSelfMotion">
					自动
				</view>
				<view class="flex1 listView mbcFF0000 mar-t32" @tap="setSpeed(speed)">
					速度X{{speed}}
				</view>
			</view>
		</view> -->
		
		<uni-popup ref="refResult" type="center" :custom="true" :mask-click="false">
			<view class="dialogResult" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{resultInfo.title}}</view>
				<view :class="resultInfo.isCenter?'isCenter':'isVerticleCenter'" v-html="resultInfo.html?resultInfo.html:''" style="width: 460rpx;height: 210rpx;margin-bottom: 30rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;overflow: scroll;"></view>
				<view @tap="tapClose" class="btClose">关闭</view>
			</view>
		</uni-popup>
		
		<popup-confirm @confirm="tapClose" ref="refFightField" :content="fightFieldText" :showCancel="false"></popup-confirm>
	</view>
</template>

<script>
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	let that;
	
	export default {
		components:{
			popupConfirm
		},
		data() {
			return {
				glist: [], //怪物数组
				slist: [], //我方数组
				blist: [], //战斗解析数组
				test: '',
				clist: [], //战斗文本数组
				round: 0, //回合数
				timing: 1000, //回合时间
				speed: 2, //速度
				win: false, //胜负
				exp: 0, //获得经验
				solHeight: 130, //预留的高度
				scrollTop: 0, //底部滚动距离
				isend: false, //是否结束 
				bcast: null, //setTimeout
				isBcast: false, //是否在执行
				fs: ['', '', '', '', '20', '18', '16', '14', '14', '14', '14'],
				resultDialog:{
					bt:'',
					content:''
				},
				dropItems:{},
				typeText:'',
				resultInfo:{},
				fightFieldText:''
			}
		},
		onUnload() {
			that.glist = [];
			that.slist = [];
			that.blist = [];
			that.clist = [];
			if (that.bcast) {
				clearTimeout(that.bcast);
			}
			that.bcast = null;
		},
		onLoad(option) {
			that = this;
			let detail = that.util.toDecodeUri(option)
			let resData = detail.resData
			that.typeText = detail.typeText
			that.dropItems = resData.dropItems
			that.setlist(resData.battleResult)
			uni.getSystemInfo({
				success: (e) => {
					let h = e.screenHeight;
					that.solHeight = h - 64 - 130 - 160 - 50;
				}
			})
		},
		onShow() {
			if (that.round == 0 && !that.isBcast) {
				that.startSelfMotion();
				/*音乐*/
			} else if (that.round <= that.blist.length && that.isBcast) {
				that.selfMotion();
			} else {
				that.jieshu();
			}
		},
		onBackPress(options) {
			// #ifdef APP-PLUS
			if (!that.isend && options.from == 'backbutton') {
				plus.nativeUI.toast('战斗中。。。');
				return true;
			}
			// #endif
		},
		methods: {
			tapClose() {
				if(that.typeText=='fight-field') {
					uni.navigateBack({
						delta: 1
					})
				}else {
					if(that.win) {
						uni.navigateBack({
							delta: 1
						})
					}else {
						uni.navigateBack({
							delta: 2
						})
					}
				}
			},
			toBack(delta) {
				uni.navigateBack({
					delta:delta
				})
			},
			/*设置速度*/
			setSpeed(e) {
				switch (e) {
					case 1:
						that.timing = 1000;
						that.speed = 2;
						break;
					case 2:
						that.timing = 500;
						that.speed = 4;
						break;
					case 4:
						that.timing = 2000;
						that.speed = 1;
						break;
					default:
						break;
				}
				// that.timing = 1000;
			},
			/*开始执行战斗*/
			startSelfMotion() {
				if (!that.isBcast) {
					that.isBcast = true;
					that.selfMotion();
				} else {
					console.log("执行中。");
				}
			},
			//自动开始
			selfMotion() {
				that.bcast = setTimeout(() => {
					if (that.round >= that.blist.length) {
						console.log('战斗结束')
						clearTimeout(that.bcast);
						that.jieshu();
						return;
					}
					that.kais();
					that.round++;
					that.selfMotion();
				}, that.timing)
			},
			//下回合
			nextRound() {
				clearTimeout(that.bcast);
				that.round++;
				console.log("进入下一回合")
				that.kais();
			},
			//开始
			kais() {
				if (that.round >= that.blist.length) {
					console.log('战斗结束')
					clearTimeout(that.bcast);
					that.jieshu();
					return;
				}
				that.broadcast(that.blist, that.round);
				setTimeout(() => {
					that.scrollToBottom();
				}, 100)
			},
			//暂停
			suspend() {
				that.isBcast = false;
				clearTimeout(that.bcast);
			},
			//结束
			jieshu() {
				console.log("结束")
				that.isend = true;
				clearInterval(that.bcast);
				
				let typeText = that.typeText
				if(typeText=='map') {
					let title = '战败'
					let isCenter = true
					let contentHtml = '道友你太过弱鸡<br>去提升下实力吧'
					if (that.win) {
						let gain = that.dropItems.gain
						if(gain) {
							let cHtml = ''
							let oHtml = ''
							let gainArray = that.jsonParse.getMaterialArray(gain)
							gainArray.forEach(item => {
								if(item.indexOf('灵石')!=-1) {
									if(cHtml) {
										cHtml += '<br>'
									}
									cHtml += '获得灵石：'+item.split('*')[1]
								}else if(item.indexOf('修为')!=-1) {
									if(cHtml) {
										cHtml += '<br>'
									}
									cHtml += '获得修为：'+item.split('*')[1]
								}else {
									if(oHtml) {
										oHtml += ', '
									}
									oHtml += item
								}
							})
							if(oHtml) {
								cHtml += '<br>获得：'+oHtml
							}
							contentHtml = cHtml
						}
						title = '获胜'
						isCenter = false
					}
					that.resultInfo = {
						title:title,
						html:contentHtml,
						isCenter:isCenter
					}
					that.$refs.refResult.open()
				}else if(typeText=='break-through') {
					let content = '挑战失败'
					if (that.win) {
						content = '挑战成功'
					}
					that.resultInfo = {
						title:'',
						html:content,
						isCenter:true
					}
					that.$refs.refResult.open()
				}else if(typeText=='fight-field') {
					let content = '挑战失败'
					if (that.win) {
						content = '挑战成功'
					}
					that.fightFieldText = content
					that.$refs.refFightField.open()
				}
			},
			/*抖动*/
			gshake(index,ai) {
				that.glist[index][ai].isShake = true;
				setTimeout(function() {
					that.glist[index][ai].isShake = false;
				}, (that.timing - 100))
			},
			sshake(index,ai) {
				// console.log(index,ai);
				// console.log(that.slist[index])
				that.slist[index][ai].isShake = true;
				setTimeout(function() {
					that.slist[index][ai].isShake = false;
				}, (that.timing - 100))
			},
			getfighting() {
				that.$req.reqcmd({
					cmd: '10_0',
				}, {}, function(res) {
					console.log("战斗数据", res.data)
					that.setlist(res.battleResult);
				}, function(err) {
					console.log("处理err")
				})
			},
			/*战斗数据设置*/
			setlist(res) {
				console.log("战斗数据", res);
				that.win = res.win;
				that.exp = res.exp;
				let sarr = res.self,
					tarr = res.target,
					barr = res.battleData;
				sarr.forEach((item, index) => {
						item.forEach((items,indexs) => {
							if (items != null) {
							let sname = items.name;
							items.isShake = false;
							items.isxlist = false;
							items.hpload = parseInt((items.curHp / items.maxHp) * 100);
							items.mpload = parseInt((items.curMp / items.maxMp) * 100);
						}
					})
				})
				// tarr = tarr.filter(item => item != null);
				tarr.forEach((item, index) => {
					item.forEach((items,indexs) => {
						if(items != null){
							items.isShake = false;
							items.isxlist = false;
							items.hpload = parseInt((items.curHp / items.maxHp) * 100);
							items.mpload = parseInt((items.curMp / items.maxMp) * 100);
						}
					})
				})
				that.slist = sarr;
				that.glist = tarr;
				console.log("我方",that.slist)
				console.log("敌方",that.glist)
				// console.log(JSON.stringify(that.glist))
				that.fighting(barr);
			},
			/*战斗回合解析*/
			fighting(arr) {
				console.log("战斗数据",arr);
				arr.forEach((item, index) => {
					let arra = item.a.split("#");
					let jsonp = []
					arra.forEach((items, index) => {
						let arrtest = items.split("=");
						jsonp.push(arrtest[1]);
					})
					arr[index].aarr = jsonp
					let mbarr = []
					item.sl.forEach((items, index) => {
						let slarr = items.split("#");
						let sljson = [];
						slarr.forEach((itemss, index) => {
							let sltest = itemss.split("=");
							sljson.push(sltest[1]);
						})
						mbarr.push(sljson);
					})
					arr[index].mbarr = mbarr
				})
				that.blist = arr;
			},
			/*战斗特效和文字*/
			broadcast(arr, i) {
				console.log("战斗抖动和文字",arr[i])
				let cjson = {};
				let str, cs, index,ind1;
				if (arr[i].aarr[0] == 1) {
					let ai = arr[i].aarr[1];
					ind1 = ai <= 3?0:ai <= 6?1:2;
					index = that.glist[ind1].findIndex(item => item && (item.cellId == arr[i].aarr[1]))
					cs = that.glist[ind1][index];
					that.gshake(ind1,index);
					cs.curHp = arr[i].aarr[3];
					cs.hpload = that.returnPercent(arr[i].aarr[3], cs.maxHp);
					cs.curMp = arr[i].aarr[5];
					cs.mpload = that.returnPercent(arr[i].aarr[5], cs.maxMp);
					that.glist[ind1][index] = cs;
					
				// 	that.glist[ind1][index].curHp = arr[i].aarr[3];
				// 	that.glist[ind1][index].hpload = that.returnPercent(arr[i].aarr[3], that.glist[ind1][index].maxHp);
				// 	that.glist[ind1][index].curMp = arr[i].aarr[5];
				// 	that.glist[ind1][index].mpload = that.returnPercent(arr[i].aarr[5], that.glist[ind1][index].maxMp);
					
				} else {
					let ai = arr[i].aarr[1];
					ind1 = ai <= 3?0:ai <= 6?1:2;
					index = that.slist[ind1].findIndex(item => item && (item.cellId == arr[i].aarr[1]))
					cs = that.slist[ind1][index];
					that.sshake(ind1,index);
					
					cs.curHp = arr[i].aarr[3];
					cs.hpload = that.returnPercent(arr[i].aarr[3], cs.maxHp);
					cs.curMp = arr[i].aarr[5];
					cs.mpload = that.returnPercent(arr[i].aarr[5], cs.maxMp);
					that.slist[ind1][index] = cs;
					// that.slist[ind1][index].curHp = arr[i].aarr[3];
					// that.slist[ind1][index].hpload = that.returnPercent(arr[i].aarr[3], that.slist[ind1][index].maxHp);
					// that.slist[ind1][index].curMp = arr[i].aarr[5];
					// that.slist[ind1][index].mpload = that.returnPercent(arr[i].aarr[5], that.slist[ind1][index].maxMp);
				}
				cjson.name = cs.name;
				let jineng = that.jsonParse.getSkillInfo(parseInt(arr[i].aarr[2]));
				// console.log("使用的技能详情：",jineng);
				cjson.skills = jineng.skillName;
				cjson.skillRange = jineng.skillRange;
				cjson.attackType = jineng.attackType;
				cjson.cm = arr[i].aarr[4];
				let carr = [];
				arr[i].mbarr.forEach((item, index) => {
					let ss, indexs, carrjson = {},
						xarr = [],ind2,
						xcolor, isbj = false;
					if (jineng.attackType == '恢复') {
						xcolor = 'green';
					} else {
						xcolor = 'red';
					}
					carrjson.miss = eval(item[2].toLowerCase());
					carrjson.crit = eval(item[3].toLowerCase());
					carrjson.cnumber = item[4];
					if (carrjson.crit) {
						isbj = carrjson.crit
					}
					ind2 = item[1] <= 3?0:item[1] <= 6?1:2;
					if (item[0] ==  1) {
						indexs = that.glist[ind2].findIndex(items => items && items.cellId == item[1]);
						ss = that.glist[ind2][indexs];
						that.glist[ind2][indexs].curHp = item[5];
						that.glist[ind2][indexs].hpload = that.returnPercent(item[5], that.glist[ind2][indexs].maxHp);
						// xarr.push(item[3])
						that.glist[ind2][indexs].isxlist = true;
						that.glist[ind2][indexs].xlist = {
							num: item[4],
							xc: xcolor,
							isbj: isbj
						};
						setTimeout(function() {
							that.glist[ind2][indexs].isxlist = false;
							that.glist[ind2][indexs].xlist = null;
						}, (that.timing - 150));
						// that.gshake(indexs);
						// that.glist[indexs].curMp = arr[i].aarr[4];
					} else {
						indexs = that.slist[ind2].findIndex(items => items && items.cellId == item[1]);
						ss = that.slist[ind2][indexs];
						// that.sshake(indexs);
						that.slist[ind2][indexs].curHp = item[5];
						that.slist[ind2][indexs].hpload = that.returnPercent(item[5], that.slist[ind2][indexs].maxHp);
						// that.slist[indexs].curMp = arr[i].aarr[4];
						that.slist[ind2][indexs].isxlist = true;
						that.slist[ind2][indexs].xlist = {
							num: item[4],
							xc: xcolor,
							isbj: isbj
						};
						setTimeout(function() {
							that.slist[ind2][indexs].isxlist = false;
							that.slist[ind2][indexs].xlist = null;
						}, (that.timing - 150));
						// xarr.push(item[3])
						// that.slist[indexs].xlist = xarr;
						// setTimeout(function() {that.slist[indexs].xlist = []}, 900);
					}
					carrjson.name = ss.name;
					carrjson.ch = item[4];
					carrjson.mh = item[5];
					carr.push(carrjson);
				})
				cjson.mb = carr;
				that.clist.push(cjson);
			},
			/*返回百分比*/
			returnPercent(x, d) {
				return parseInt((parseInt(x) / parseInt(d)) * 100);
			},
			skip() {
				var pages = getCurrentPages(); //当前页
				var beforePage = pages[pages.length - 2]; //上个页面
				if (that.win) {
					try {
						// #ifdef H5
						beforePage.fightOver()
						// #endif
						// #ifndef H5
						beforePage.$vm.fightOver()
						// #endif
					} catch (e) {}
					this.toBack(1);
				} else {
					// 战败 退出当前页面和上一页地图
					uni.navigateBack({
						delta: 2
					})
				}
			},
			towerSkip() {
				if (that.win) {
					this.toBack(1)
				} else {
					uni.navigateBack({
						delta: 2
					})
				}
			},
			/*滑动到底部*/
			scrollToBottom: function() {
				let query = uni.createSelectorQuery();
				query.in(this).selectAll('.main-item').boundingClientRect();
				query.in(this).select('#scrollview').boundingClientRect();
				query.exec((res) => {
					let mitemHeight = 0;
					res[0].forEach((rect) => mitemHeight = mitemHeight + rect.height + 40)
					if (mitemHeight > that.solHeight) {
						that.scrollTop = (mitemHeight + 100)
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	// @import '../../common/master.css';
	page{
		height: 100%;
		background-color: #000000;
	}
	/*顶部导航兼容*/
	.status_bar {  
	    height: var(--status-bar-height);  
	    width: 100%;  
	    background-color: #F8F8F8;  
	}  
	.top_view {
	    height: var(--status-bar-height);  
	    width: 100%;  
	    position: fixed;  
	    background-color: #000000;  
	    top: 0;  
	    z-index: 999;  
	}
	.container {
		
		height: auto;
		min-height: 100%;
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
		view{
			box-sizing: border-box !important;
		}
		.fight-main{
			flex: 1;
			display: flex;
			flex-direction: column;
			// align-items: flex-start;
			padding-top: 66rpx;
			// justify-content: flex-start;
			// text-align: center;
			.vs-main{
				width: 100%;
				text-align: center;
			}
			.vs-view{
				width:620rpx;
				height:1px;
				background-color:#666666;
				margin: 50rpx auto;
			}
			.target-view{
				flex: 1;
				display: flex;
				flex-direction: column-reverse;
				justify-content: flex-start;
				align-items: center;
				.target-view-column{
					// flex: 1;
					display: flex;
					// justify-content: flex-start;
					// align-items: flex-start;
					.target-view-item{
						width: 200rpx;
						height: 120rpx;
						// border:2rpx solid white;
						border-left:2rpx solid #6A020A;
						border-top:2rpx solid #6A020A;
						&:nth-child(3){
							border-right:2rpx solid #6A020A;
						}
					}
					&:nth-child(1){
						border-bottom:2rpx solid #6A020A;
					}
				}
				
			}
			.self-view{
				flex: 1;
				display: flex;
				flex-direction: column;
				justify-content: flex-start;
				align-items: center;
				.self-view-column{
					// flex: 1;
					display: flex;
					.self-view-item{
						width: 200rpx;
						height: 120rpx;
						// background-color: red;
						border-left:2rpx solid white;
						border-top:2rpx solid white;
						&:nth-child(3){
							border-right:2rpx solid white;
						}
					}
					&:nth-child(3){
						border-bottom:2rpx solid white;
					}
				}
				
			}
			.que-data {
				flex: 1;
				width:658rpx;
				height: calc(100vh - 66rpx - 720rpx - 100rpx - 60rpx - 50rpx - 60rpx - var(--status-bar-height));
				border:2rpx solid rgba(255, 255, 255, 1);
				// border-radius: 8rpx;
				padding: 30rpx;
				margin-top: 50rpx;
			}
			
		}
	}
	
	
	.red {
		color: #FF0000;
	}

	.green {
		color: #09BB07;
	}

	.listView {
		font-size: 30upx;
	}

	.animation-boxshow {
		/*DAA520*/
		box-shadow: 0 0 50upx #FFFFFF;
		animation-duration: .5s;
		animation-timing-function: ease-out;
		animation-fill-mode: both;
		/* animation: boxAnimation 0.4s infinite linear; */
	}

	@keyframes boxAnimation {
		0% {
			box-shadow: 0 0 50upx #FFFFFF;
		}

		50% {
			box-shadow: 0 0 0upx #FFFFFF;
		}

		100% {
			box-shadow: 0 0 50upx #FFFFFF;
		}
	}

	.progress-view {
		width: 80%;
		overflow: hidden;
		// height: 20upx;
		display: inline-flex;
		align-items: center;
		// width: 100%;
		position: relative;
		padding: 4rpx;
		border-radius: 10upx;
		margin-bottom: 4rpx;
	}

	.pro-bb {
		border: 1px solid blue;
	}

	.pro-br {
		border: 1px solid #FF0000;
	}

	.progress-view text {
		width: 100%;
		text-align: center;
		z-index: 1;
	}

	.progress-view view {
		width: 0;
		height: 100% !important;
		align-items: center;
		display: flex;
		justify-items: flex-end;
		justify-content: space-around;
		font-size: 20upx;
		color: #FFFFFF;
		transition: width 0.6s ease;
		position: absolute;
		left: 0;
		top: 0;
	}

	.bg-red {
		background-color: #FF0000;
	}

	.bg-blue {
		background-color: blue;
	}

	

	.h230 {
		height: 230rpx;
	}

	.gw-main,
	.xs-main {
		height: 25vh;
		width: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.gs-view {
		width: 100%;
		display: flex;
		flex-wrap: wrap-reverse;
		align-items: center;
		justify-content: space-between;

	}

	.gs-view>.g-list {}

	.gs-view .g-list-view {
		width: 150rpx;
		height: 150rpx;
		border: 2rpx solid rgba(255, 255, 255, 1);
		border-radius: 50%;
		flex-shrink: 0;
		position: relative;
	}
	.g-list-view-zwf{
		width: 150rpx;
		height: 150rpx;
	}
	.xs-view {
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		justify-content: space-between;
	}

	.xs-view,
	.dz-view {
		width: 100%;
	}

	 .xs-view-list,
	 .dz-view-list {
		width: 100%;
		height: 100%;
		font-size: 22rpx;
		font-weight: 500;
		color: rgba(255, 255, 255, 1);
		line-height: 1.2;

	}

	.man-view {
		width: 100%;
		// height: 100%;
		// padding: 10rpx;
		position: relative;
		flex: 1;
	}

	/*飘血特效*/
	.man-view>.bloodview,
	.g-list-view>.bloodview {
		position: absolute;
		top: -15upx;
		transition: all .3s ease-out;
		animation: piaoxue 1s linear 1;
		animation-fill-mode: forwards;
		font-weight: 600;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: flex-end;
		min-height: 40upx;
	}

	.isbj {
		font-weight: 900 !important;
		/* font-size: 36rpx; */
		transition: all .3s ease-out;
		animation: baoji 1s linear 1;
		animation-fill-mode: forwards;
		color: #FFFF00;
		/* position: absolute; */
		/* top: -10upx; */
	}

	/*暴击特效*/
	@keyframes baoji {
		0% {
			font-size: 50rpx;
		}

		50% {
			font-size: 50rpx;
		}

		100% {
			font-size: 22rpx;
		}
	}

	/*飘血特效*/
	@keyframes piaoxue {
		0% {
			top: -15upx;
			opacity: 1;
		}

		50% {
			top: -25upx;
			opacity: 1;
		}

		70% {
			top: -35upx;
			opacity: 0.9;
		}

		100% {
			top: -45upx;
			opacity: 0;
		}
	}

	.xs-view .xs-view-list {
		border-radius: 50%;
		border: 2rpx solid rgba(255, 242, 0, 1);
	}

	.xs-view .dz-view-list {
		border-radius: 14rpx;
		border: 2rpx solid rgba(255, 0, 0, 1);
	}

	

	.clist-height {
		/* width: 100%; */
		/* height: calc(50vh - 130rpx - 162rpx -50rpx); */
		height: 328rpx;
	}

	.jg-view {
		font-size: 40rpx;
		font-weight: 500;
		color: rgba(255, 0, 0, 1);
		line-height: 81rpx;
		width: 100%;
		margin: 10rpx 0;
	}

	.bor-t {
		height: 1px;
		width: 260rpx;
		background-color: rgba(255, 255, 255, 0.5);
	}

	.test {
		background-color: #000000;
		border: 1px solid #000000;
		color: rgba(1, 1, 1, 1);
	}

	.page-scroll-Y {
		height: 380rpx;
	}

	.dimg {
		width: 70rpx;
		height: 70rpx;
	}

	.dimg image {
		width: 70rpx;
		height: 70rpx;
		border-radius: 50%;
	}

	.listView {
		display: flex;
		align-items: center;
		justify-content: space-around;
		position: relative;
	}

	.d-text {
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
		line-height: 1;
		color: #FFFFFF;

		font-size: 26rpx;
		font-weight: 500;
		line-height: 37rpx;

	}

	.d-name {
		font-size: 36rpx;
		font-weight: 500;
		line-height: 81rpx;
	}

	.d-type-zwf {
		width: 98rpx;
		height: 98rpx;
	}

	.d-type {
		width: 98rpx;
		height: 98rpx;
		border-radius: 50%;
		position: absolute;
		right: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 50%;
		font-size: 36rpx;
		font-weight: 500;
		line-height: 37rpx;
	}
	
	.flex-ccc{
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
	}
	
	.page-foot{
		position: fixed;
		bottom: 0;
		width: 100%;
		padding-bottom: 32upx;
		background-color: #000000;
	}
	.flex-start{
			-webkit-flex: 1;
			flex: 1;
			
			-webkit-justify-content: center;
			justify-content: center;
			-webkit-align-items: flex-start;
			align-items: flex-start;
		}
	.flex-ss{
		display: flex;
		align-items: flex-start;
		justify-content: flex-start;
	}
	.flex-caw{
		display: flex;
		align-items: center;
		justify-content: space-around;
		flex-wrap: wrap;
	}
	.flex-jc-fs{
		display: flex;
		align-items: center;
		justify-content: flex-start;
	}
	.flex-cc{
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.flex-cfs{
		display: flex;
		align-items: center;
		justify-content: flex-start;
	}
	.flex-fsfs{
		display: flex;
		align-items: flex-start;
		justify-content: flex-start;
	}
	.flex-fsc{
		display: flex;
		align-items: flex-start;
		justify-content: center;
	}
	.flex-cs{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.flex-cb{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.flex-ca{
		display: flex;
		align-items: center;
		justify-content: space-around;
	}
	.flex-ccc{
		display: flex;
		align-items: center;
		justify-content: center;
		flex-direction: column;
	}
	.flex-cbw{
		display: flex;
		align-items: center;
		justify-content:space-between;
		flex-wrap: wrap;
	}
	.flex-ee{
		display: flex;
		align-items: flex-end;
		justify-content: flex-end;
	}
	.flex-ce{
		display: flex;
		align-items: center;
		justify-content: flex-end;
	}
	.flex-acc{
		display: flex;
		align-items: space-around;
		justify-content: center;
		flex-direction: column;
	}
	.flex-cbc{
		display: flex;
		align-items: center;
		justify-content: space-between;
		flex-direction: column;
	}
	.flex-bbc{
		display: flex;
		align-items: space-between;
		justify-content: space-between;
		flex-direction: column;
	}
	
	.flex-fr {
		display: flex; 
		flex-direction: row;
	}
	
	.listView{
		width:564upx;
		height:98upx;
		border-radius:49px;
		font-size:40upx;
		font-weight:500;
		line-height:81upx;
		display: flex;
		align-items: center;
		justify-content: center;
		transition: all .3s ease-out;
	}
	.mbcFF0000{color: #FF0000;box-shadow: 0 0 20upx #FF0000;}
	.mar-t32{margin-top: 32upx;}
	.h100{height: 100%;}
	.text-view1,.text-view2,.text-view3{
		display: flex;
		align-items: center;
		justify-content: flex-start;
		flex-wrap: wrap;
	}
	.text-view1>text,.text-view2>text,.text-view3>text{
		font-size:26upx;
		font-weight:500;
		line-height:1.8;
		
	}
	.text-view1>text{
		width: 100%
	}
	.text-view2>text{
		width: 50%;
	}
	.text-view3>text{
		width: 33%;
	}
	.c-000000{color: #000000;}
	.c-F9D03E{color:#F9D03E}
	.c-F45600{color:#F45600}
	.c-76F4E7{color:#76F4E7}
	.c-00AEEF{color:#00AEEF}
	.c-7A0026{color:#7A0026}
	.c-92278F{color:#92278F}
	.c-2E3192{color:#2E3192}
	.c-EC008C{color:#EC008C}
	.c-FFF9BC{color:#FFF9BC}
	.c-FFDE00{color:#FFDE00;}
	.c-FFFFFF{color:#FFFFFF;}
	.c-FFF200{color:#FFF200;}
	.c-FF000A{color:#FF000A;}
	.c-FFFFCC{color:#FFFFCC;}
	.c-FF0000{color:#FF0000;}
	.c-009900{color:#009900 !important;}
	.c-FF5A00{color:#FF5A00 !important;}
	.c-FFE75F{color:#FFE75F !important;}
	.c-99FFCC{color:#99FFCC;}
	.c-F13426{color:#F13426 !important;}
	.c-7BFFF2{color:#7BFFF2 !important;}
	.c-4066FA{color:#4066FA;}
	.c-666666{color:#666666;}
	.c-FFD700{color:#FFD700;}
	.c-CC6633{color:#CC6633;}
	.c-CCFF00{color:#CCFF00;}
	.c-A5FB49{color:#A5FB49;}
	.c-FFFF00{color:#FFFF00;}
	.c-33FF33{color:#33FF33;}
	.c-99FFFF{color:#99FFFF;}
	.c-33FF99{color:#33FF99;}
	.c-FF2D2D{color:#FF2D2D;}
	.c-D0D0D0{color:#D0D0D0;}
	.c-7B7B7B{color:#7B7B7B;}
	.mbc7B7B7B{color: #7B7B7B;box-shadow: 0 0 20upx #7B7B7B;}
	.mbcD0D0D0{color: #D0D0D0;box-shadow: 0 0 20upx #D0D0D0;}
	.mbc006600{color: #006600;box-shadow: 0 0 20upx #006600;}
	.mbcFFFF00{color: #FFFF00;box-shadow: 0 0 20upx #FFFF00;}
	.mbc3300FF{color: #3300FF;box-shadow: 0 0 20upx #3300FF;}
	.mbcCC0000{color: #CC0000;box-shadow: 0 0 20upx #CC0000;}
	.mbcC0C0C0{color: #C0C0C0;box-shadow: 0 0 20upx #C0C0C0;}
	.mbc66FFFF{color: #66FFFF;box-shadow: 0 0 20upx #66FFFF;}
	.mbcFFDE00{color: #FFDE00;box-shadow: 0 0 20upx #FFDE00;}
	.mbcFFFFCC{color: #FFFFCC;box-shadow: 0 0 20upx #FFFFCC;}
	.mbcFFFFFF{color: #FFFFFF;box-shadow: 0 0 20upx #FFFFFF;}
	.mbcFF0000{color: #FF0000;box-shadow: 0 0 20upx #FF0000;}
	.mbc009900{color: #009900;box-shadow: 0 0 20upx #009900;}
	.mbcFF5A00{color: #FF5A00;box-shadow: 0 0 20upx #FF5A00;}
	.mbcFFE75F{color: #FFE75F;box-shadow: 0 0 20upx #FFE75F;}
	.mbc99FFCC{color: #99FFCC;box-shadow: 0 0 20upx #99FFCC;}
	.mbcF13426{color: #F13426;box-shadow: 0 0 20upx #F13426;}
	.mbc7BFFF2{color: #7BFFF2;box-shadow: 0 0 20upx #7BFFF2;}
	.mbc4066FA{color: #4066FA;box-shadow: 0 0 20upx #4066FA;}
	.mbc666666{color: #666666;box-shadow: 0 0 20upx #666666;}
	.mbcFFD700{color: #FFD700;box-shadow: 0 0 20upx #FFD700;}
	.mbcCC6633{color: #CC6633;box-shadow: 0 0 20upx #CC6633;}
	.mbcCCFF00{color: #CCFF00;box-shadow: 0 0 20upx #CCFF00;}
	.mbcA5FB49{color: #A5FB49;box-shadow: 0 0 20upx #A5FB49;}
	
	.mbc92F4C3{color: #92F4C3;box-shadow: 0 0 20upx #92F4C3;}
	.mbcF9D03E{color: #F9D03E;box-shadow: 0 0 20upx #F9D03E;}
	.mbcFF000A{color: #FF000A;box-shadow: 0 0 20upx #FF000A;}
	.mbcFFF200{color: #FFF200;box-shadow: 0 0 20upx #FFF200;}
	.mbcFFF9BC{color: #FFF9BC;box-shadow: 0 0 20upx #FFF9BC;}
	.mbcEC008C{color: #EC008C;box-shadow: 0 0 20upx #EC008C;}
	.mbc2E3192{color: #2E3192;box-shadow: 0 0 20upx #2E3192;}
	.mbc92278F{color: #92278F;box-shadow: 0 0 20upx #92278F;}
	.mbc7A0026{color: #7A0026;box-shadow: 0 0 20upx #7A0026;}
	.mbc00AEEF{color: #00AEEF;box-shadow: 0 0 20upx #00AEEF;}
	.mbc76F4E7{color: #76F4E7;box-shadow: 0 0 20upx #76F4E7;}
	.mbcF45600{color: #F45600;box-shadow: 0 0 20upx #F45600;}
	
	.mbc95A5A6{color: #95A5A6;box-shadow: 0 0 20upx #95A5A6;}
	.mbcE9E3AE{color: #E9E3AE;box-shadow: 0 0 20upx #E9E3AE;}
	.mbc996600{color: #996600;box-shadow: 0 0 20upx #996600;}
	.mbc8F2C8C{color: #8F2C8C;box-shadow: 0 0 20upx #8F2C8C;}
	
	
	[class*=animation-] {
	    animation-duration: .5s;
	    animation-timing-function: ease-out;
	    animation-fill-mode: both
	}
	.animation-shake {
	    animation-name: shake
	}
	@keyframes shake {
	
	    0%,
	    100% {
	        transform: translateX(0)
	    }
	
	    10% {
	        transform: translateX(-9px)
	    }
	
	    20% {
	        transform: translateX(8px)
	    }
	
	    30% {
	        transform: translateX(-7px)
	    }
	
	    40% {
	        transform: translateX(6px)
	    }
	
	    50% {
	        transform: translateX(-5px)
	    }
	
	    60% {
	        transform: translateX(4px)
	    }
	
	    70% {
	        transform: translateX(-3px)
	    }
	
	    80% {
	        transform: translateX(2px)
	    }
	
	    90% {
	        transform: translateX(-1px)
	    }
	}
	
	.dialogResult {
		width: 568rpx;
		height: 512rpx;
		background:url(../../static/dialog-568-512.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btClose {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
</style>
