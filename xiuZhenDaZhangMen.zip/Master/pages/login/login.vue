<template>
	<view class="container">
		<image class="iconLogo" src="/static/logo.png"></image>
		<input type="text" v-model="account" class="inputLayout" placeholder="用户名" />

		<view>
			<sunui-password style="position: absolute;line-height: 88rpx;margin-left: 465rpx;" @change="showPass" />
			<input type="text" v-model="password" :password="show" class="inputLayout" placeholder="密码" />
		</view>
		<view class="bgBt mar-t-60" @tap="tapLogin">登录</view>
		<!-- <view style="font-size: 28rpx;color: #666666;text-align: right;margin-right: 214rpx;width: 100%;line-height: 70rpx;"><text>忘记密码</text></view> -->

		<view class="bgBt mar-t-80" @tap="navigateTo('/pages/regist/regist')">注册</view>
	</view>
</template>

<script>
	import zwf from '@/components/sunui-password/zw.vue'
	var _self

	export default {
		components: {
			zwf
		},
		data() {
			return {
				account: '',
				password: '',
				show: true,
				version: '',
				clientId: ''
			}
		},
		onLoad() {
			_self = this
			var that = this
			// #ifdef APP-PLUS
			plus.runtime.getProperty(plus.runtime.appid, function(inf) {
				that.version = 'version: ' + inf.version.split('.').join('')
			})

			_self.clientId = _self.util.getClientId()
			// #endif
		},
		onShow() {
			_self.util.getLoginData((res) => {
				_self.account = res.account
				_self.password = res.password
			})
		},
		methods: {
			ajaxServerList(lData) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmServerServerList
				option[_self.$req.REQUEST_OPTION.LOADING_2] = true
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if (resData) {
						/**
						 * 签名验证
						 */
						const ts = resData.ts
						let signText = 'uuid=' + resData.uuid + '&ts=' + ts + '&'
						let serverInfoList = resData.serverInfoList
						serverInfoList.forEach((info) => {
							signText += info.serverId + '=' + info.url + '&'
						})
						signText += 'key=sXda0ln#1'
						const sign = _self.util.toMd5(signText)
						if (sign == resData.sign && serverInfoList.length > 0) {
							_self.showToast('登录成功')  // 如果在ajaxLogin弹，loading会消失
							
							resData.accountToken = lData.token
							resData.hasNotice = lData.hasNotice
							resData.noticeData = lData.noticeData
							_self.redirectTo(_self.util.toEncodeUri('/pages/choose-service/choose-service',resData))
						}else {
							_self.showToast('处理错误')
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxLogin(params) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmAccountLogin
				option[_self.$req.REQUEST_OPTION.LOADING_1] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = params
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					_self.util.keepLoginData(_self.account, _self.password)
					
					let accountToken = resData.token
					getApp().globalData.accountToken = accountToken
					_self.ajaxServerList(resData)
				}
				_self.$req.handleRequest(option)
			},
			tapLogin() {
				let account = _self.account
				let pwd = _self.password
				if (account && pwd) {
					let params = {
						account: account,
						passwordMd5: _self.util.toMd5(pwd),
						clientId: _self.clientId,
						requestId: _self.util.generateUUID(),
						ts: getApp().globalData.serverTime
					}
					let sign = _self.util.accountSign(params)
					params['sign'] = sign
					_self.ajaxLogin(params)
				} else {
					_self.showToast('用户名或密码不能为空')
				}
			},
			showPass(e) {
				this.show = e;
			},

			toLogin() {
				uni.hideKeyboard()
			},
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		display: flex;
		flex-direction: column;
		align-items: center;
		background: url(../../static/home-bg.png) center center no-repeat;
		background-size: 750rpx 1550rpx;
	}

	.inputLayout {
		width: 353rpx;
		height: 88rpx;
		text-align: center;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-bottom: 50rpx;
		padding: 0 93rpx;
		background: url(../../static/login-input-bg.png) center center no-repeat;
		background-size: 536rpx 100%;
	}

	.bgBt {
		width: 536rpx;
		height: 88rpx;
		line-height: 88rpx;
		font-size: 34rpx;
		color: #AC202D;
		text-align: center;
		background: url(../../static/login-bt-bg.png) center center no-repeat;
		background-size: 100% 100%;
	}

</style>
