<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">{{name}}</block>
		</cu-custom>
		
		<view v-if="items.length>0" style="display: flex;justify-content: center;align-items: center;height: 140rpx;">
			<uni-segmented-control style="width: 650rpx;" :current="current" :values="items" @clickItem="onClickItem" style-type="button" active-color="#CBBDAF"></uni-segmented-control>
		</view>
		
		<scroll-view v-if="datas[sellLocation]" scroll-y="true" class="sv">
			<block v-if="datas[sellLocation].length>0">
				<view v-for="(array,i1) in datas[sellLocation]" :key="i1" style="display: flex;flex-direction: row;margin-bottom: 10rpx;">
					<view @tap="tapItem(info)" v-for="(info,i2) in array" :key="i2" class="itemLayout" :class="info.sellTime==0?'c-FFFFFF':'c-666666'">
						<view style="width: 200rpx;text-align: center;" :class="[sellLocation==4?'fs-24':'','m-'+info.quality]">{{info.productName}}</view>
					</view>
				</view>
			</block>
			<view v-else style="text-align: center;color: #666666;font-size: 30rpx;line-height: 200rpx;">暂无数据</view>
		</scroll-view>
		<view v-else-if="loaded" style="text-align: center;color: #666666;font-size: 30rpx;line-height: 200rpx;">{{notOpenText}}</view>
		
		<uni-popup ref="refDialog" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDialog.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogLayout" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;" :class="'m-'+dialogInfo.quality">{{dialogInfo.name}}</view>
				<scroll-view scroll-y="true" style="line-height: 44rpx;font-size: 26rpx;color: #818181;height: 390rpx;width: 460rpx;border-bottom: solid 1px #333333;">
					<block v-if="sellLocation==2">
						<view style="color: #A31B27;">售价：{{dialogInfo.consume}}</view>
						<view>品级：{{dialogInfo.qualityName}}</view>
						<view>类型：{{dialogInfo.type}}</view>
						<view>基础属性：{{dialogInfo.basicProperty}}</view>
						<view>附加属性：{{dialogInfo.extraProperty}}</view>
					</block>
					<block v-else>
						<view style="color: #A31B27;">售价：{{dialogInfo.consume}}</view>
						<view>品级：{{dialogInfo.qualityName}}</view>
						<view style="padding-top: 10rpx;"><text style="color: transparent;">空格</text>{{dialogInfo.description}}</view>
					</block>
				</scroll-view>
				
				<view style="display: flex;flex-direction: row;color: #666666;font-size: 32rpx;justify-content: flex-end;width: 460rpx;margin: 26rpx 0;">
					<image @tap="tapAddMinus(1)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-minus.png"></image>
					<view style="padding: 0 20rpx;">{{dialogInfo.buyCount}}/{{dialogInfo.todayRemainBuyCount}}</view>
					<image @tap="tapAddMinus(2)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-add.png"></image>
				</view>
				
				<view @tap="tapBuy" class="dialogBt">购买</view>
				
			</view>
		</uni-popup>
		
		<uni-popup ref="refDisciple" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refDisciple.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogDisciple" style="display: flex;flex-direction: column;align-items: center;">
				<scroll-view scroll-y="true" style="line-height: 54rpx;font-size: 28rpx;color: #FEFEFE;height: 720rpx;width: 480rpx;padding-top: 50rpx;">
					<view style="display: flex;flex-direction: row;">
						<view style="display: flex;flex: 1;flex-direction: column;line-height: 64rpx;font-size: 30rpx;">
							<view>姓名：{{dialogInfo.name}}</view>
							<view>性别：{{dialogInfo.sex}}</view>
							<view>身份：{{dialogInfo.identity}}</view>
							<view>时代：{{dialogInfo.era}}</view>
						</view>
						<image style="width: 182rpx;height: 247rpx;margin-left: 26rpx;vertical-align: top;" :src="dialogInfo.avatarUrl?dialogInfo.avatarUrl:''"></image>
						
					</view>
					
					<view class="mar-t-20" style="">天赋：{{dialogInfo.specialGift}}</view>
					<view style="display: flex;flex-direction: row;">
						<view style="display: flex;flex: 1;">资质：{{dialogInfo.qualification}}</view>
						<view style="display: flex;flex: 1;">体质：{{dialogInfo.specialPhysique}}</view>
					</view>
					
					<view class="mar-t-30" style="display: flex;flex-direction: row;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>初始气血：{{dialogInfo.p1}}</view>
							<view>初始神念：{{dialogInfo.p3}}</view>
							<view>初始破甲：{{dialogInfo.p5}}</view>
							<view>初始命中：{{dialogInfo.p7}}</view>
							<view>初始暴击：{{dialogInfo.p9}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>初始灵力：{{dialogInfo.p2}}</view>
							<view>初始肉身：{{dialogInfo.p4}}</view>
							<view>初始格挡：{{dialogInfo.p6}}</view>
							<view>初始躲闪：{{dialogInfo.p8}}</view>
							<view>初始抗暴：{{dialogInfo.p10}}</view>
						</view>
					</view>
					<view class="mar-t-20" v-html="dialogInfo.description?util.exchangeLineBreak(dialogInfo.description):''"></view>
				</scroll-view>
				
				<!-- <view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{dialogInfo.name}}</view>
				<scroll-view scroll-y="true" style="line-height: 40rpx;font-size: 24rpx;color: #818181;height: 620rpx;width: 460rpx;text-align: center;">
					<view style="display: flex;flex-direction: row;margin-top: 10rpx;">
						<image style="width: 140rpx;height: 190rpx;margin-top: 6rpx;" :src="dialogInfo.avatarUrl?dialogInfo.avatarUrl:''"></image>
						<scroll-view scroll-y="true" style="display: flex;flex: 1;margin-left: 26rpx;text-align: left;height: 200rpx;"><text v-html="dialogInfo.description?util.exchangeLineBreak(dialogInfo.description):''"></text></scroll-view>
					</view>
					
					<view style="display: flex;flex-direction: row;margin-top: 50rpx;width: 460rpx;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>性别：{{dialogInfo.sex}}</view>
							<view>体质：{{dialogInfo.specialPhysique}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>资质：{{dialogInfo.qualification}}</view>
							<view>天赋：{{dialogInfo.specialGift}}</view>
						</view>
					</view>
					
					<view style="display: flex;flex-direction: row;margin-top: 50rpx;width: 460rpx;">
						<view style="display: flex;flex-direction: column;flex: 1.1;align-items: flex-start;">
							<view>初始气血：{{dialogInfo.p1}}</view>
							<view>初始神念：{{dialogInfo.p3}}</view>
							<view>初始破甲：{{dialogInfo.p5}}</view>
							<view>初始命中：{{dialogInfo.p7}}</view>
							<view>初始暴击：{{dialogInfo.p9}}</view>
						</view>
						<view style="display: flex;flex-direction: column;flex: 1;align-items: flex-start;">
							<view>初始灵力：{{dialogInfo.p2}}</view>
							<view>初始肉身：{{dialogInfo.p4}}</view>
							<view>初始格挡：{{dialogInfo.p6}}</view>
							<view>初始躲闪：{{dialogInfo.p8}}</view>
							<view>初始抗暴：{{dialogInfo.p10}}</view>
						</view>
					</view>
					
				</scroll-view> -->
				
				<view style="display: flex;flex-direction: row;color: #666666;font-size: 32rpx;justify-content: flex-end;width: 460rpx;margin: 18rpx 0;">
					<image @tap="tapAddMinus(1)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-minus.png"></image>
					<view style="padding: 0 20rpx;">{{dialogInfo.buyCount}}/{{dialogInfo.todayRemainBuyCount}}</view>
					<image @tap="tapAddMinus(2)" style="width: 40rpx;height: 40rpx;" src="/static/market-detail-dialog-bt-add.png"></image>
				</view>
				
				<view @tap="tapBuy" class="dialogBt">购买 ({{dialogInfo.consume}})</view>
			</view>
		</uni-popup>
		
		<popup-confirm ref="refBuy" @confirm="ajaxBuy" :content="dialogBuyText" maskOpacity="0.8"></popup-confirm>
		<popup-confirm ref="refText" :showCancel="false" :content="dialogText"></popup-confirm>
	</view>
</template>

<script>
	import uniPopup from "@/components/uni-popup/uni-popup.vue"
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	import uniSegmentedControl from "@/components/uni-segmented-control/uni-segmented-control.vue"
	var _self
	
	export default {
		components:{
			uniPopup,
			popupConfirm,
			uniSegmentedControl
		},
		data() {
			return {
				name:'',
				items: [],
				locations:[],
				current: 0,
				listArray:[],  // [[1,1,1],[1,1]]
				loaded:false,
				marketType:1,
				sellLocation:1,
				datas:{},
				dialogInfo:{},
				dialogBuyText:'',
				dialogText:'',
				tapInfo:null,
				types:{
					'材料':1,
					'装备':2,
					'丹药':3,
					'配方':4,
					'特殊':5,
					'弟子':6,
					'门人':6
				},
				maxBuyCount:200,
				notOpenText:'暂未开放'
			}
		},
		onLoad(option) {
			_self = this
			let detail = _self.util.toDecodeUri(option)
			_self.name = detail.name
			_self.marketType = detail.marketType
			
			let items = _self.jsonParse.getMarketDetailTabNames(detail.level)
			if(items.length>0) {
				_self.items = items
				
				let locations = []
				items.forEach(name => {
					let location = _self.types[name]
					if(location) {
						locations.push(location)
					}
				})
				if(locations.length>0) {
					_self.sellLocation = locations[0]
					_self.locations = locations
				}
				
				_self.$nextTick(function(){
					_self.ajaxList()
				})
			}else {
				_self.loaded = true
			}
		},
		methods: {
			doTextDialog(text) {
				_self.dialogText = text
				_self.$refs.refText.open()
			},
			doBuyDialog(text) {
				_self.dialogBuyText = text
				_self.$refs.refBuy.open()
			},
			tapBuy() {
				let buyText = '物品：'+_self.dialogInfo.name+'<br>数量：'+_self.dialogInfo.buyCount
				_self.doBuyDialog(buyText)
			},
			tapAddMinus(type) {
				// 限制：一次最多200个
				let buyCount = _self.dialogInfo.buyCount
				switch(type) {
					case 1:
						if(buyCount>1) {
							buyCount--
						}
						break;
						
					case 2:
						if(buyCount==_self.dialogInfo.todayRemainBuyCount || buyCount==_self.maxBuyCount) {
							_self.showToast('已是最大购买数')
						}else {
							buyCount++
						}
						break;
				}
				if(buyCount!=_self.dialogInfo.buyCount) {
					_self.dialogInfo.buyCount = buyCount
				}
			},
			toCloseDialog() {
				_self.$refs.refDialog.close()
			},
			toOpenDialog() {
				_self.$refs.refDialog.open()
			},
			toOpenDialogDisciple() {
				_self.$refs.refDisciple.open()
			},
			toCloseDialogDisciple() {
				_self.$refs.refDisciple.close()
			},
			tapItem(info) {
				_self.tapInfo = info
				if(info.sellTime==0) {
					let productMaterialArray = info.productMaterial.split(':')
					let materialType = parseInt(productMaterialArray[0])
					if(materialType<6) {
						// 1-5情况
						let materialInfo = _self.jsonParse.getMaterialInfo(materialType,parseInt(productMaterialArray[1]))
						if(materialInfo) {
							_self.ajaxDetail(info,materialInfo)
						}
					}else if(materialType==6) {
						let equipInfo = _self.jsonParse.getExchangeEquipInfo(info.productName,1)
						if(equipInfo) {
							_self.ajaxDetail(info,equipInfo)
						}
					}else if(materialType==7) {
						let formulaInfo = _self.jsonParse.getFormulaInfo(info.productName)
						if(formulaInfo) {
							formulaInfo.materialDescription = formulaInfo.description.replace(/的配方/g,'。')
							_self.ajaxDetail(info,formulaInfo)
						}
					}else if(materialType==8) {
						let discipleInfo = _self.jsonParse.getSpecialDiscipleByName(info.productName)
						if(discipleInfo) {
							_self.util.getAvatarUrl(discipleInfo.sex,discipleInfo.icon,url => {
								discipleInfo.avatarUrl = url
								_self.ajaxDetail(info,discipleInfo)
							})
						}
					}
				}else {
					_self.showToast('暂不出售')
				}
			},
			onClickItem(e) {
				let eCurrent = e.currentIndex
				if (_self.current != eCurrent) {
					_self.current = eCurrent
					_self.sellLocation = _self.locations[eCurrent]
					
					if(!_self.datas[_self.sellLocation]) {
						_self.ajaxList()
					}
				}
			},
			addQuality(info) {
				let mtArray = _self.jsonParse.getMaterialArray(info.productMaterial,3)
				if(mtArray.length>0) {
					info.quality = mtArray[0].quality
				}
			},
			ajaxList() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'8_1',
					params:{
						marketType:_self.marketType,
						sellLocation:_self.sellLocation
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let listArray = []
						let items = resData.items
						items.forEach((info,index)=>{
							if(index%3==0) {
								let itemArray = []
								
								_self.addQuality(info)
								itemArray.push(info)
								if(index+2<items.length) {
									let info1 = items[index+1]
									let info2 = items[index+2]
									_self.addQuality(info1)
									_self.addQuality(info2)
									itemArray.push(info1)
									itemArray.push(info2)
								}else if(index+1<items.length) {
									let info1 = items[index+1]
									_self.addQuality(info1)
									itemArray.push(info1)
								}
								listArray.push(itemArray)
							}
						})
						_self.datas[_self.sellLocation] = listArray
						_self.$forceUpdate()
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxDetail(info,material) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'8_2',
					params:{
						exchangeId:info.exchangeId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let todayRemainBuyCount = resData.fullView.todayRemainBuyCount
						_self.tapInfo.todayRemainBuyCount = todayRemainBuyCount
						if(todayRemainBuyCount>0) {
							let buyCount = todayRemainBuyCount
							if(buyCount>_self.maxBuyCount) {
								buyCount = _self.maxBuyCount
							}
							
							let consume = _self.jsonParse.getMaterialArray(info.consumeMaterial,1).toString()
							let dialogInfo = {
								quality:info.quality,
								name:info.productName,
								exchangeId:info.exchangeId,
								todayRemainBuyCount:todayRemainBuyCount,
								buyCount:buyCount,
								consume:consume
							}
							if(_self.sellLocation<6) {
								if(_self.sellLocation==2) {
									dialogInfo.qualityName = _self.jsonParse.getEquipQualityName(material.quality)
									dialogInfo.basicProperty = material.basicProperty
									dialogInfo.extraProperty = material.extraProperty.replace(/#/g,', ')
									dialogInfo.type = material.type
								}else {
									dialogInfo.description = material.materialDescription
									dialogInfo.qualityName = _self.jsonParse.getMaterialQualityName(material.quality)
								}
								_self.dialogInfo = dialogInfo
								_self.toOpenDialog()
							}else if(_self.sellLocation==6) {
								// 弟子
								let dialogDisciple = {
									...material,
									...dialogInfo
								}
								_self.dialogInfo = dialogDisciple
								_self.toOpenDialogDisciple()
							}
						}else {
							_self.showToast('今天购买已达到上限')
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			ajaxBuy() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'8_3',
					params:{
						exchangeId:_self.dialogInfo.exchangeId,
						count:_self.dialogInfo.buyCount
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.showToast('购买成功')
						let todayRemainBuyCount = _self.tapInfo.todayRemainBuyCount-_self.dialogInfo.buyCount
						if(todayRemainBuyCount>0) {
							_self.dialogInfo.buyCount = 1
							_self.dialogInfo.todayRemainBuyCount = todayRemainBuyCount
							_self.tapInfo.todayRemainBuyCount = todayRemainBuyCount
						}else {
							_self.toCloseDialogDisciple()
							_self.toCloseDialog()
						}
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogLayout {
		width: 568rpx;
		height: 762rpx;
		background:url(../../static/market-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogBt {
		width: 442rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #A31B27;
		background:url(../../static/market-detail-dialog-bt-buy.png) center center no-repeat;background-size:100% 100%;
	}
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 100rpx - 140rpx);
	}
	
	.itemLayout {
		width: 226rpx;
		height: 120rpx;
		margin-left: 19rpx;
		line-height: 40rpx;
		padding-top: 4rpx;
		font-size: 28rpx;
		/* color: #000000; */
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		
		background:url(../../static/disciple-equip-list-bg-item.png) center center no-repeat;background-size:100% 100%;
	}
	
	.dialogDisciple {
		width: 568rpx;
		height: 988rpx;
		background:url(../../static/disciple-equip-detail-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.fs-24 {
		font-size: 24rpx;
	}
	
	
</style>
