<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">坊市</block>
		</cu-custom>
		
		<view class="listHeight" style="display: flex;flex-direction: column;align-items: center;overflow: scroll;">
			<view v-for="(info,index) in lists" :key="index" @tap="tapItem(info)" class="btLayout" :class="_self.sectLevel>=info.level?'c-FFFFFF':'c-666666'">{{info.name}}</view>
		</view>
		
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				lists:[{
					name:'一级坊市',
					marketType:1,
					level:1
				},{
					name:'二级坊市',
					marketType:2,
					level:2
				},{
					name:'三级坊市',
					marketType:3,
					level:3
				},{
					name:'四级坊市',
					marketType:4,
					level:4
				},{
					name:'五级坊市',
					marketType:5,
					level:5
				},{
					name:'六级坊市',
					marketType:6,
					level:6
				}],
				sectLevel:-1
			}
		},
		onLoad() {
			_self = this
			_self.sectLevel = getApp().globalData.sectView.level
		},
		methods: {
			tapItem(info) {
				if(_self.sectLevel>=info.level) {
					_self.navigateTo(_self.util.toEncodeUri('/pages/shop/market-detail',info))
				}else {
					_self.showToast('门派等级不够')
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	.btLayout:last-child {
		margin-bottom: 40rpx;
	}
	
	.listHeight {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}
	
	
</style>
