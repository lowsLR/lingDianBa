<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">充值</block>
		</cu-custom>
		
		<view style="display: flex;justify-content: center;align-items: center;height: 140rpx;">
			<uni-segmented-control style="width: 650rpx;" :current="current" :values="items" @clickItem="onClickItem" style-type="button" active-color="#CBBDAF"></uni-segmented-control>
		</view>
		
		<scroll-view scroll-y="true" class="sv">
			<view style="display: flex;flex-direction: column;align-items: center;">
				<block v-if="item.rechargeType==currType" v-for="(item,index) in rechargeItems" :key="index">
					<view v-if="item.rechargeType==1" @tap="tapItem2(item)" style="width: 660rpx;border-radius: 10rpx;border: solid 1px #8C8B8D;margin-bottom: 25rpx;display: flex;flex-direction: column;align-items: center;color: #FFFFFF;padding: 10rpx 20rpx;">
						<view style="font-size: 42rpx;" :class="'rmb-'+item.price">{{item.goodsName}}</view>
						<view style="font-size: 32rpx;text-align: center;" :class="'rmb-'+item.price">{{item.countText}}</view>
						<view style="font-size: 30rpx;">￥ {{item.price}}</view>
					</view>
					<view v-if="item.rechargeType==2" @tap="tapItem2(item)" style="width: 660rpx;border-radius: 10rpx;border: solid 1px #8C8B8D;margin-bottom: 25rpx;display: flex;flex-direction: row;color: #FFFFFF;height: 180rpx;">
						<view style="display: flex;flex: 1;justify-content: center;align-items: center;" :class="'rmb-'+item.price">{{item.goodsName}}</view>
						<view style="display: flex;justify-content: center;align-items: center;padding: 0 40rpx;flex-direction: column;line-height: 60rpx;">
							<view style="font-size: 32rpx;text-align: center;" :class="'rmb-'+item.price">每日限购 {{item.todayBuyCount}} / {{item.dailyBuyLimit}}</view>
							<view style="font-size: 30rpx;">￥ {{item.price}}</view>
						</view>
					</view>
				</block>
			</view>
		</scroll-view>
		
		<uni-popup ref="refBuy" type="center" :custom="true" :mask-click="true">
			<image @tap="$refs.refBuy.close()" style="width: 48rpx;height: 48rpx;position: absolute;right: -12rpx;margin-top: -12rpx;" src="/static/dialog-close.png"></image>
			<view class="dialogBuy" style="display: flex;flex-direction: column;align-items: center;">
				<view style="line-height: 100rpx;padding-top: 30rpx;font-size: 36rpx;color: #FFFFFF;">{{buyInfo.goodsName}}</view>
				<view class="isCenter" v-html="buyInfo.countText?buyInfo.countText.replace(/,/g,'<br>'):''" style="width: 480rpx;height: 500rpx;margin-bottom: 30rpx;font-size: 32rpx;color: #FFFFFF;line-height: 70rpx;overflow: scroll;"></view>
				<view v-if="buyInfo.todayBuyCount<buyInfo.dailyBuyLimit" @tap="tapItem1(buyInfo)" class="buyBtn">购买(￥{{buyInfo.price}})</view>
				<view v-else class="buyBtn c-xg">每日限购</view>
			</view>
		</uni-popup>
		
		<loading ref="refLoading" :loadingText="loadingText"></loading>
		<popup-confirm ref="refGain" :showCancel="false" :content="gainText"></popup-confirm>
	</view>
</template>

<script>
	import loading from '@/components/loading/loading.vue'
	import popupConfirm from '@/components/popup-confirm/popup-confirm.vue'
	import uniSegmentedControl from "@/components/uni-segmented-control/uni-segmented-control.vue"
	import pay from '@/common/pay.js'
	var iapChannel
	var _self
	
	export default {
		components:{
			loading,
			popupConfirm,
			uniSegmentedControl
		},
		data() {
			return {
				rechargeItems:[],
				goodsIds:[],
				orderNo:'',
				initOrder:false,
				payInfo:{},
				queryCount:0,
				maxCount:15,
				loopInterval:3,
				loadingText:'',
				gainText:'',
				payReceiptCount:0,
				maxPayReceiptCount:3,
				tapInfo:{},
				current: 0,
				items:['普通充值','充值礼包'],
				typeArray:[1,2],
				currType:-1,
				buyInfo:{}
			}
		},
		onLoad() {
			_self = this
			_self.currType = _self.typeArray[0]
			_self.$nextTick(function(){
				_self.ajaxList()
			})
			// #ifdef APP-PLUS
			pay.getIapChannel(function(channel) {
				iapChannel = channel
			})
			// #endif
		},
		methods: {
			onClickItem(e) {
				let eCurrent = e.currentIndex
				if (_self.current != eCurrent) {
					_self.current = eCurrent
					_self.currType = _self.typeArray[eCurrent]
				}
			},
			getDetailAgain() {
				_self.queryCount++
				if(_self.queryCount<_self.maxCount) {
					setTimeout(function() {
						_self.ajaxOrderDetail()
					},_self.loopInterval*1000)
				}else {
					_self.$refs.refLoading.close()
				}
			},
			ajaxOrderDetail() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'999_4',
					params:{
						orderNo:_self.orderNo
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						if(resData.orderStatus==2) {
							_self.$refs.refLoading.close()
							// _self.gainText = '购买成功<br>'+_self.jsonParse.getMaterialArray(resData.gain).toString()
							_self.gainText = '购买成功：'+_self.tapInfo.goodsName
							_self.$refs.refGain.open()
							
							// 更新购买数量
							let rechargeItems = _self.rechargeItems
							rechargeItems.forEach(item => {
								if(item.rechargeId==_self.tapInfo.rechargeId) {
									item.todayBuyCount++
								}
							})
						}else {
							_self.getDetailAgain()
						}
					}else {
						_self.getDetailAgain()
					}
				}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {
					_self.getDetailAgain()
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {
					_self.getDetailAgain()
				}
				_self.$req.handleRequest(option)
			},
			sendPayReceiptAgain() {
				_self.payReceiptCount++
				if(_self.payReceiptCount<_self.maxPayReceiptCount) {
					setTimeout(function() {
						_self.ajaxApplePayReceipt()
					},_self.loopInterval*1000)
				}else {
					_self.$refs.refLoading.close()
				}
			},
			ajaxApplePayReceipt() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = true
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'999_3',
					params:{
						orderNo:_self.orderNo,
						transactionId:_self.payInfo.transactionIdentifier,
						receipt:_self.payInfo.transactionReceipt
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						_self.queryCount = 0
						_self.loopInterval = resData.loopInterval
						
						_self.loadingText = '正在查询订单'
						setTimeout(function() {
							_self.ajaxOrderDetail()
						},resData.loopDelay*1000)
					}else {
						_self.sendPayReceiptAgain()
					}
				}
				option[_self.$req.REQUEST_OPTION.ERROR] = function() {
					_self.sendPayReceiptAgain()
				}
				option[_self.$req.REQUEST_OPTION.HANDLE_ERROR_CODE] = function() {
					_self.sendPayReceiptAgain()
				}
				_self.$req.handleRequest(option)
			},
			ajaxPreOrder(item) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'999_2',
					params:{
						rechargeId:item.rechargeId
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						switch(resData.rs) {
							case 0:
								_self.showToast('下单失败')
								break;
								
							case 1:
								_self.loadingText = '处理中'
								_self.$refs.refLoading.open()
								_self.orderNo = resData.orderNo
								pay.toSendRequest(iapChannel,item.goodsId,function(info) {
									if(info) {
										// 发送结果到后端，轮训
										_self.payInfo = info
										_self.payReceiptCount = 0
										_self.ajaxApplePayReceipt()
									}else {
										_self.$refs.refLoading.close()
										_self.showToast('支付失败')
									}
								})
								break;
						}
					}
				}
				_self.$req.handleRequest(option)
			},
			toCloseDialogBuy() {
				_self.$refs.refBuy.close()
			},
			toOpenDialogBuy() {
				_self.$refs.refBuy.open()
			},
			tapItem2(item) {
				_self.buyInfo = item
				_self.toOpenDialogBuy()
			},
			tapItem1(item) {
				_self.tapInfo = item
				if(iapChannel) {
					_self.toCloseDialogBuy()
					
					if(_self.initOrder) {
						_self.ajaxPreOrder(item)
					}else {
						pay.toRequestOrder(iapChannel,_self.goodsIds,function(initSuccess) {
							_self.initOrder = initSuccess
							if(initSuccess) {
								_self.ajaxPreOrder(item)
							}
						})
					}
				}else {
					_self.showToast('暂不支持')
				}
			},
			ajaxList(hideLoading) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.LOADING_HIDE] = hideLoading
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd:'999_1'
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if(resData) {
						let goodsIds = []
						let rechargeItems = resData.rechargeItems
						rechargeItems.forEach((item)=>{
							goodsIds.push(item.goodsId)
							
							let textType = 2
							if(item.rechargeType==2)  {
								textType = 0
							}
							item.countText = _self.jsonParse.getMaterialArray(item.items,textType).toString()
						})
						_self.goodsIds = goodsIds
						_self.rechargeItems = rechargeItems
					}
				}
				_self.$req.handleRequest(option)
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.sv {
		height: calc(100vh - var(--status-bar-height) - 100rpx - 140rpx);
	}
	
	.c-0 {
		color: #FFFFFF;
	}
	
	.c-1 {
		color: #29F82F;
	}
	
	.c-2 {
		color: #2874C4;
	}
	
	.c-3 {
		color: #ED5399;
	}
	
	.c-4 {
		color: #F2AE2C;
	}
	
	.c-5 {
		color: #e67e22;
	}
	
	.c-6 {
		color: #9b59b6;
	}
	
	.c-7 {
		color: #800408;
	}
	
	.dialogBuy {
		width: 568rpx;
		height: 798rpx;
		background:url(../../static/building-dialog-bg.png) center center no-repeat;background-size:100% 100%;
	}
	
	.buyBtn {
		width: 442rpx;
		height: 98rpx;
		font-size: 34rpx;
		line-height: 98rpx;
		color: #FFFFFF;
		text-align: center;
		background:url(../../static/disciple-equip-detail-bt-bg1.png) center center no-repeat;background-size:100% 100%;
	}
	
	.buyBtn.c-xg {
		color: #666666;
	}
	
</style>
