<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">资源福利</block>
			<block slot="right">
				<view @tap="tapExchange" style="width: 64rpx;height: 64rpx;border-radius: 50%;margin-right: 24rpx;border: solid 1px #666666;font-size: 34rpx;line-height: 64rpx;text-align: center;">兑</view>
			</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;align-items: center;">
			<view v-for="(item,index) in lists" :key="index" @tap="tapItem(item)" class="btLayout">{{item.name}}</view>
		</view>
		
		<popup-words ref="refWords" :cHtml="wordsNew"></popup-words>
	</view>
</template>

<script>
	import popupWords from '@/components/popup-words/popup-words.vue'
	var _self
	
	export default {
		components:{
			popupWords
		},
		data() {
			return {
				lists:[{
					name:'充值',
					type:1
				},{
					name:'逛逛坊市',
					type:2
				},{
					name:'活动集锦',
					type:3
				},{
					name:'仙宝阁',
					type:4
				}],
				wordsNew:'',
				keyWordsNew:''
			}
		},
		onLoad() {
			_self = this
			_self.$nextTick(function(){
				_self.toGetWordsNew()
			})
		},
		methods: {
			tapExchange() {
				_self.navigateTo('/pages/exchange-code/exchange-code')
			},
			toWordsNew(count) {
				let wordObj = _self.jsonParse.getNewWords('shop')
				if(wordObj) {
					if(wordObj.count>count) {
						_self.wordsNew = wordObj.content
						_self.$refs.refWords.open()
						
						uni.setStorage({
						    key: _self.keyWordsNew,
						    data: count+1
						})
					}
				}
			},
			toGetWordsNew() {
				let keyWordsNew = 'wns-'+getApp().globalData.sectView.sectId
				_self.keyWordsNew = keyWordsNew
				
				uni.getStorage({
				    key: keyWordsNew,
					success:function(res){
						_self.toWordsNew(res.data)
					},
				    fail:function(res){
						_self.toWordsNew(0)
					}
				})
			},
			tapItem(info) {
				switch(info.type) {
					case 1:
						_self.navigateTo('/pages/shop/recharge')
						break;
						
					case 2:
						_self.navigateTo('/pages/shop/market')
						break;
						
					case 3:
						_self.navigateTo('/pages/activity/activity-details')
						break;
						
					case 4:
						_self.navigateTo(_self.util.toEncodeUri('/pages/shop/market-detail',{
							name:'仙宝阁',
							marketType:100,
							level:100
						}))
						break;
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	
</style>
