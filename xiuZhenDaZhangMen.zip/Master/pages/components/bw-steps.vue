<template>
	<view class="uni-steps">
		<view class="uni-steps__row">
			
			<view class="uni-steps__row-container">
				<view 
				class="steps-main-view uni-steps__row-line-item"
				v-for="(item,index) in options" :key="index">
					<!-- 
					&&index!==0 ?activeColor:index===0
					 -->
					 <block v-if="index > 0">
					<view 
					class="uni-steps__row-line"
					:style="{backgroundColor:index<=active?activeColor:''}">
						
							<view class="chargeView" :class="[direction==='column'?'uni-steps__column-check':'uni-steps__row-check']" v-if="index <= active">
								<image class="activeImg" src="../../static/activity/chargeY.png" mode=""></image>
							</view>
							<view class="chargeView" :class="[direction==='column'?'uni-steps__column-check':'uni-steps__row-check']" v-else>
								<image class="activeImg" src="../../static/activity/chargeN.png" mode=""></image>
							</view>
							
					</view>
					</block>
					<!-- <view :class="[direction==='column'?'uni-steps__column-line':'uni-steps__row-line',direction==='column'?'uni-steps__column-line--after':'uni-steps__row-line--after']" :style="{backgroundColor:index<active&&index!==options.length-1?activeColor:index===options.length-1?'transparent':deactiveColor}"></view> -->
				<!-- 	<view class="chargeView" :class="[direction==='column'?'uni-steps__column-check':'uni-steps__row-check']" v-if="index <= active">
						<image class="activeImg" src="../../static/activity/chargeY.png" mode=""></image>
					</view>
					<view class="chargeView" :class="[direction==='column'?'uni-steps__column-check':'uni-steps__row-check']" v-else>
						<image class="activeImg" src="../../static/activity/chargeN.png" mode=""></image>
					</view> -->
					
				</view>
				<!-- <view class="">
					
				</view> -->
				
				
			</view>
			<view class="setps-text uni-steps__row-text-container" >
				<view 
				class="uni-steps__row-text"
				v-for="(item,index) in options" :key="index">
					<text :style="{color:index<=active?activeColor:deactiveColor}" 
					class="uni-steps__row-title">{{item.title}}</text>
					<text :style="{color:index<=active?activeColor:deactiveColor}" 
					class="uni-steps__row-desc">{{item.desc}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// import uniIcons from '../uni-icons/uni-icons.vue'
	import uniIcons from '../../components/uni-icons/uni-icons.vue'
	export default {
		name: 'UniSteps',
		components: {
			uniIcons
		},
		props: {
			direction: {
				// 排列方向 row column
				type: String,
				default: 'row'
			},
			activeColor: {
				// 激活状态颜色
				type: String,
				default: '#1aad19'
			},
			deactiveColor: {
				// 未激活状态颜色
				type: String,
				default: '#999999'
			},
			active: {
				// 当前步骤
				type: Number,
				default: 0
			},
			options: {
				type: Array,
				default () {
					return []
				}
			} // 数据
		},
		data() {
			return {}
		}
	}
</script>

<style scoped>
	.uni-steps {
		/* #ifndef APP-NVUE */
		display: flex;
		width: 100%;
		/* #endif */
		/* #ifdef APP-NVUE */
		flex: 1;
		/* #endif */
		flex-direction: column;
	}

	.uni-steps__row {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
	}

	.uni-steps__column {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row-reverse;
	}

	.uni-steps__row-text-container {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		justify-content: space-between;
	}

	.uni-steps__column-text-container {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		flex: 1;
	}

	.uni-steps__row-text {
		/* #ifndef APP-NVUE */
		display: inline-flex;
		/* #endif */
		flex: 1;
		flex-direction: column;
	}

	.uni-steps__column-text {
		padding: 6px 0px;
		border-bottom-style: solid;
		border-bottom-width: 1px;
		border-bottom-color: #e5e5e5;
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
	}

	.uni-steps__row-title {
		font-size: 28rpx;
		line-height: 16px;
		text-align: center;
	}

	.uni-steps__column-title {
		font-size: 28rpx;
		text-align: left;
		line-height: 18px;
	}

	.uni-steps__row-desc {
		font-size: 12px;
		line-height: 14px;
		text-align: center;
	}

	.uni-steps__column-desc {
		font-size: 24rpx;
		text-align: left;
		line-height: 18px;
	}

	.uni-steps__row-container {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		position: relative;
		/* text-align: left; */
		/* justify-content: flex-start; */
		position: relative;
		left: -20px;
	}

	.uni-steps__column-container {
		/* #ifndef APP-NVUE */
		display: inline-flex;
		/* #endif */
		width: 30px;
		flex-direction: column;
	}

	.uni-steps__row-line-item {
		/* #ifndef APP-NVUE */
		display: inline-flex;
		/* #endif */
		flex-direction: row;
		flex: 1;
		height: 14px;
		line-height: 14px;
		align-items: center;
		justify-content: center;
		position: absolute;
	}

	.uni-steps__column-line-item {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
		flex: 1;
		align-items: center;
		justify-content: center;
	}

	.uni-steps__row-line {
		flex: 1;
		height: 8rpx;
		background-color: #999;
	}
	.uni-steps__row-line:first-child{
		border-top-left-radius: 55px;
		border-bottom-left-radius: 55px;
	}
	.uni-steps__column-line {
		width: 1px;
		background-color: #999;
	}

	.uni-steps__row-line--after {
		transform: translateX(1px);
	}

	.uni-steps__column-line--after {
		flex: 1;
		transform: translate(0px, 1px);
	}

	.uni-steps__row-line--before {
		transform: translateX(-1px);
	}

	/* .uni-steps__column-line--before {
		height: 6px;
		transform: translate(0px, -1px);
	} */

	/* .uni-steps__row-circle {
		width: 5px;
		height: 5px;
		border-radius: 100px;
		background-color: #999;
		margin: 0px 3px;
	} */

	.uni-steps__column-circle {
		width: 5px;
		height: 5px;
		border-radius: 100px;
		background-color: #999;
		margin: 4px 0px 5px 0px;
	}

	.uni-steps__row-check {
		margin: 0px 6px;
	}

	.uni-steps__column-check {
		height: 14px;
		line-height: 14px;
		margin: 2px 0px;
	}
	.steps-main-view{
		position: relative;
	}
	
	.setps-text{
		padding-top: 17rpx;
	}
	.chargeView{
		position: absolute;
		/* left: -32rpx; */
		right: -32rpx;
		top: -35rpx;
	}
	.activeImg{
		/* position: absolute; */
		width:60rpx;
		height:90rpx;
	}
</style>