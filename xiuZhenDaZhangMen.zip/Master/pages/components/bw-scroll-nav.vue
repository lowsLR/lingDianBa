<template>
	<view>
		<scroll-view id="nav-bar" class="nav-bar" scroll-x scroll-with-animation :scroll-left="scrollLeft">
			<view 
			 v-for="(item,index) in tabBars" :key="index"
				class="uni-tab-item"
				:id="'tab'+index"
				@tap="change(index)"
			>
			<text class="uni-tab-item-title"
			:class="[tabIndex === index ? 'uni-tab-item-title-active' : '']"
			>{{item.name}}</text>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		props: {
			tabBars: {
				type: Array,
				default: function(e) {
					return [];
				}
			},
			tabIndex: {
				type: Number,
				default: 0
			}
		},
		watch:{
			tabIndex(newVal){
				this.change(newVal)
			}
		},
		data() {
			return {
				scrollLeft:0,
			}
		},
		onLoad() {
			
		},
		methods: {
			async change(index, e) {
				let ret = {
					index: index
				};
			
				this.$emit('tabChange', ret);
				//计算宽度相关
				let tabBarScrollLeft = 0;
				try{
					 tabBarScrollLeft = tabBar.scrollLeft;
				}catch(e){
					 
				}
				let width = 0; 
				let nowWidth = 0;
				//获取可滑动总宽度
				for (let i = 0; i <= index; i++) {
					let result = await this.getElSize('tab' + i);
					width += result.width;
					if(i === index){
						nowWidth = result.width;
					}
				}
				setTimeout(()=>{
					if (width - nowWidth/2 > this.windowWidth / 2) {
						//如果当前项越过中心点，将其放在屏幕中心
						this.scrollLeft = width - nowWidth/2 - this.windowWidth / 2;
					}else{
						this.scrollLeft = 0;
					}
				}, 300)
			},
			getElSize(id) { //得到元素的size
			    return new Promise((res, rej) => {
						let el = uni.createSelectorQuery().in(this).select('#' + id);
						el.fields({
							size: true,
							scrollOffset: true,
							rect: true
						}, (data) => {
							res(data);
						}).exec();
			    })
			}
		}
	}
</script>

<style>
	
	
	.nav-bar{
			/* width: calc(100vw - 112upx); */
			flex: 1;
			width: 100%;
			position: relative;
			z-index: 99999;
			height: 100upx;
			box-sizing: border-box;
			flex-direction: row;
			white-space: nowrap;
			padding-left: 10upx;
			z-index: 998;
			justify-content: flex-start;
		}
		
		.uni-tab-item {
			display: inline-block;
			flex-wrap: nowrap;
			height: 100upx;
			padding-left: 30upx;
			padding-right: 30upx;
			position: relative;
			
			font-size:30upx;
			/* color:rgba(204,204,204,1); */
			color: #CCCCCC;
			/* font-weight:400; */
			z-index: 998;
		}
		
		.uni-tab-item-title {
			flex-wrap: nowrap;
			white-space: nowrap;
			line-height:100upx;
			font-family:PingFang SC;
		}
		.uni-tab-item-title-active{
			font-size:38upx;
			font-family:PingFang SC;
			/* font-weight:bold; */
			color:rgba(255,255,255,1);
		}
		
</style>
