<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">活动列表</block>
		</cu-custom>
		
		<view style="display: flex;flex-direction: column;align-items: center;">
			<view v-for="(item,index) in lists" :key="index" @tap="tapItem(item)" class="btLayout">{{item.name}}</view>
		</view>
		
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				lists:[{
					name:'连续登陆领奖励',
					type:1
				},{
					name:'累计充值领福利',
					type:2
				}]
			}
		},
		onLoad() {
			_self = this
		},
		methods: {
			tapItem(info) {
				_self.navigateTo('/pages/activity/activity-details?type='+info.type);
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.btLayout {
		width: 596rpx;
		height: 98rpx;
		text-align: center;
		line-height: 98rpx;
		font-size: 34rpx;
		color: #FFFFFF;
		margin-top: 40rpx;
		background:url(../../static/building-bg-bt.png) center center no-repeat;background-size:100% 100%;
	}
	
	
</style>
