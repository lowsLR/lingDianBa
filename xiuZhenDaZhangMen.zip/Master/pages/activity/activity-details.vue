<template>
	<view class="container">
		<cuCustomScroll :isBack="true">
			<block slot="content">
				<bwScrollNav style="margin-left: 90rpx;" :tab-index="tabCurrentIndex" @tabChange="clickTab" :tab-bars="tabBars">
				</bwScrollNav>
			</block>
		</cuCustomScroll>
		<swiper id="swiper" class="swiper-box" :duration="300" :current="tabCurrentIndex" @change="swiperTab">
			<!-- v-for="tabItem in tabBars" :key="tabItem.id" -->
			<!-- 直播 -->

			<!-- <swiper-item>
					<view class="activity-view">
						<view class="no-activity">
							暂无福利
						</view>
					</view>
				</swiper-item> -->
			<swiper-item>
				<view v-if="loginNavs.length>0" class="activity-view login-main">
					<!-- 头部切换 -->
					<view class="login-view-top">
						<view v-if="loginNavs.length>0" class="login-view-nav">
							<view v-for="(name,index) in loginNavs" :key="index" class="login-view-navView" :class="[loginViewNavIndex==index?'login-view-navView-act':'']"
							 @tap="setNavIndex(index)">
								{{name}}
							</view>
						</view>
					</view>

					<block v-if="loginViewNavIndex==index" v-for="(lData,index) in loginArray" :key="index">
						<view class="login-view-dateView">
							<view class="login-view-dateItem" v-for="(item,index) in dateList" :class="[lData.obj.activityData.currentScore >= (index+1)?'signInType-1':'signInType-3']"
							 :key="index">
								{{item.id}}
							</view>
						</view>

						<view class="activity-describe">
							<view class="content">
								<view>
									活动时间：
									<text v-if="lData.obj.forever">永久有效</text>
									<text v-else>{{lData.obj.activityTime&&lData.obj.activityTime[0].replace(/-/g,'/')}} - {{lData.obj.activityTime&&lData.obj.activityTime[1].replace(/-/g,'/')}}</text>
								</view>
								<view style="display: flex;flex-direction: row;">
									活动描述：<view style="display: flex;flex: 1;">{{lData.obj.description||''}}</view>
								</view>
							</view>
							
						</view>

						<scroll-view scroll-y="true" class="reward-scroll-view">
							<block v-if="lData.gainRecords.length>0">
								<view class="rewardView" v-for="(item,index) in lData.gainRecords" :class="[(item.hasGain || !item.canGain)?'opacity05':'']" :key="item.levelName+index">
									<view class="rewardView-text">
										<view class="rewardView-Title">
											登录{{item.levelName}}
										</view>
										<view class="rewardView-reward">
											{{item.arrStr}}
										</view>
									</view>
									
									<view class="rewardView-but rewardView-but-bg1">
										<text v-if="item.hasGain">{{text2}}</text>
										<block v-else>
											<text @tap="getReward(item)" v-if="item.canGain">{{text1}}</text>
											<text v-else>{{text1}}</text>
										</block>
									</view>

								</view>
							</block>
							<block v-else>
								<view class="no-activity">
									暂无数据
								</view>
							</block>
						</scroll-view>
					</block>
				</view>
				<view v-else style="text-align: center;color: #666666;font-size: 34rpx;padding-top: 100rpx;">{{notOpenText}}</view>
			</swiper-item>
			<swiper-item>
				<view v-if="load2" class="activity-view login-main">
					<!-- 累充福利 -->
					<view class="chargeMoney-view">
						<view class="chargeTig">
							<text space="emsp">已累计充值 </text>
							<text space="emsp" style="color: #FDD974;margin-left: 10rpx;">{{rewCurrentScore}}</text>
							<view @tap="tapRecharge" class="chargeBut">充值</view>
						</view>
						<bw-steps :options="rScoreArray" active-color="#FDD974" :active="rewCurrentScoreIndex" />
					</view>
					<view class="activity-describe">
						<view class="content">
							<view>
								活动时间：
								<text v-if="actReward.forever">永久有效</text>
								<text v-else>{{actReward.activityTime&&actReward.activityTime[0].replace(/-/g,'/')}} - {{actReward.activityTime&&actReward.activityTime[1].replace(/-/g,'/')}}</text>
							</view>
							<view style="display: flex;flex-direction: row;">
								活动描述：<view style="display: flex;flex: 1;" v-html="actReward.description?actReward.description.replace(/\n/g,'<br>'):''"></view>
							</view>
						</view>
					</view>

					<scroll-view scroll-y="true" class="charge-scroll-view">

						<view class="rewardView" v-for="(item,index) in rewGainRecords" :class="[(item.hasGain || !item.canGain)?'opacity05':'']" :key="item.levelName+index">
							<view class="rewardView-text">
								<view class="rewardView-Title">
									{{item.levelName}}
								</view>
								<view class="rewardView-reward">
									{{item.arrStr}}
								</view>
							</view>
							<view class="rewardView-but rewardView-but-bg1">
								<text v-if="item.hasGain">{{text2}}</text>
								<block v-else>
									<text @tap="getReward(item)" v-if="item.canGain">{{text1}}</text>
									<text v-else>{{text1}}</text>
								</block>
							</view>
							
						</view>

					</scroll-view>
				</view>
				<view v-else style="text-align: center;color: #666666;font-size: 34rpx;padding-top: 100rpx;">{{notOpenText}}</view>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
	import cuCustomScroll from '../../components/cu-custom/cu-custom-scroll.vue'
	import bwScrollNav from '../components/bw-scroll-nav.vue'

	import bwSteps from '../components/bw-steps.vue'
	var _self;
	export default {
		components: {
			cuCustomScroll,
			bwScrollNav,
			bwSteps
		},
		data() {
			return {
				active: 1,
				rScoreArray: [],
				loginViewNavIndex: 0, //登录活动的选择下标
				tabCurrentIndex: 0, //滑块的下标
				dateList: [{
						id: 1,
						type: 1
					},
					{
						id: 2,
						type: 1
					},
					{
						id: 3,
						type: 2
					},
					{
						id: 4,
						type: 3
					},
					{
						id: 5,
						type: 3
					},
					{
						id: 6,
						type: 3
					},
					{
						id: 7,
						type: 3
					},
				],
				tabBars: [{
					name: '登录活动',
					id: 2,
				}, {
					name: '累计福利',
					id: 3,
				}],
				optyoe: 1,
				actLogin: {},
				actReward: {},
				loginCurrentScore: 0,
				loginGainRecords: [],
				rewGainRecords: [],
				rewCurrentScore: 0,
				rewCurrentScoreIndex: 0, //活动进度
				actLoginSt: '', //登录活动开始时间
				actLoginEt: '', //登录活动结束时间
				loginNavs: [],
				loginArray: [],
				text1:'领取',
				text2:'已领取',
				load2:false,
				notOpenText:'暂未开放'
			}
		},
		onLoad(op) {
			_self = this;
			// _self.optyoe = op.type;
			// this.tabCurrentIndex = op.type==1?0:1;
			_self.getActivities();
		},
		methods: {
			tapRecharge() {
				_self.redirectTo('/pages/shop/recharge')
			},
			/*领取奖励*/
			getReward(item) {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd: '11_2',
					params:{
						activityId:item.activityId,
						scoreLevel:item.scoreLevel
					}
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if (resData) {
						item.hasGain = true
						let gain = resData.gain
						if(gain) {
							let gainStr = _self.jsonParse.getMaterialArray(gain).toString()
							_self.showToast('恭喜获得：'+gainStr)
						}
					}
				}
				_self.$req.handleRequest(option)

			},
			/*查看活动列表*/
			getActivities() {
				var option = {}
				option[_self.$req.REQUEST_OPTION.URL] = _self.$req.REQUEST_URL.jmRequestCmd
				option[_self.$req.REQUEST_OPTION.PARAMETER] = {
					cmd: '11_1',
				}
				option[_self.$req.REQUEST_OPTION.SUCCESS] = function(resData) {
					if (resData) {
						let loginNavs = []
						let loginArray = []

						let activities = resData.activities
						
						activities.forEach(activity => {
							let activityType = activity.activityType
							let activityData = activity.activityData

							switch (activityType) {
								case 1:
									let gainRecords1 = activityData.gainRecords
									gainRecords1.forEach((item, index) => {
										item.activityId = activity.activityId
										item.arrStr = _self.jsonParse.getMaterialArray(item.bonus).toString();
									})

									loginNavs.push(activity.name)
									loginArray.push({
										gainRecords:gainRecords1,
										obj: activity
									})
									break;

								case 2:
									_self.load2 = true
									let rScoreArray = [{title:0}]
									let gainRecords2 = activityData.gainRecords
									gainRecords2.forEach((item, index) => {
										item.activityId = activity.activityId
										item.arrStr = _self.jsonParse.getMaterialArray(item.bonus).toString();
										
										rScoreArray.push({
											title:item.scoreLevel
										})
									})
									_self.rewGainRecords = gainRecords2
									_self.rScoreArray = rScoreArray
									
									_self.actReward = activity
									let rScore = activityData.currentScore
									_self.rewCurrentScore = rScore
									_self.rewCurrentScoreIndex = 0
									
									let rewCurrentScoreIndex = 0
									rScoreArray.forEach((item,index) => {
										if(rScore>=item.title) {
											rewCurrentScoreIndex = index
										}
									})
									_self.rewCurrentScoreIndex = rewCurrentScoreIndex
									break;
							}
						})
						_self.loginNavs = loginNavs
						_self.loginArray = loginArray
					}
				}
				_self.$req.handleRequest(option)
			},

			/*设置登录下标*/
			setNavIndex(i) {
				this.loginViewNavIndex = i;
			},
			/*滑动切换*/
			swiperTab(e) {
				let i = e.target.current || e.detail.current;
				this.changeTab(i);
			},
			/*点击切换*/
			clickTab(e) {
				this.changeTab(e.index);

			},
			/*切换tab*/
			changeTab(i) {
				if (this.tabCurrentIndex === i) {
					return;
				}
				this.tabCurrentIndex = i;



			},
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		/* min-height: 100vh; */
		/* height: auto../../static/home-bg.pngstatic/disciple-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
		display: flex;
		flex-direction: column;
	}
	.swiper-box {
		flex: 1;
		height: calc(100% - 100rpx - var(--status-bar-height));
		/* width: 100%;
		 */
		color: #FFFFFF;
	}

	.swiper-box {
		height: calc(100vh - var(--status-bar-height) - 100rpx);
	}

	.activity-view {
		flex: 1;
		height: 100%;
		color: #FFFFFF;
		padding: 0 23rpx;
		display: flex;
		justify-content: flex-start;
		flex-direction: column;
	}

	.no-activity {
		width: 100%;
		margin-top: 200rpx;
		text-align: center;
		color: #666666;
	}

	/*登录活动*/
	.login-main {
		padding-top: 33rpx;
	}

	.login-view-top {
		display: flex;
		flex-direction: column;

	}

	.login-view-nav {
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.login-view-navView {
		width: 313rpx;
		height: 68rpx;
		/* background:rgba(0,0,0,1); */
		border: 1rpx solid rgba(153, 153, 153, 1);
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(153, 153, 153, 1);
		display: flex;
		justify-content: center;
		align-items: center;


	}

	.login-view-navView-act {
		background: rgba(203, 189, 174, 1);
		/* border:1rpx solid rgba(139,139,139,1); */
		color: rgba(0, 0, 0, 1) !important;
	}

	.login-view-dateView {
		/* flex: 1; */

		width: calc(704rpx - 110rpx);
		height: calc(317rpx - 68rpx);
		display: flex;
		justify-content: center;
		flex-wrap: wrap;
		align-items: center;
		margin-top: 20rpx;
		padding: 34rpx 55rpx;
		background: url(../../static/activity/login-activity.png) center center no-repeat;
		background-size: 704rpx 317rpx;

	}

	.login-view-dateItem {
		width: 131rpx;
		height: 130rpx;
		/* background-color: yellow; */
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.login-view-dateItem-bgimg {
		width: 96rpx;
		height: 94rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		/* background-color: #22AAFF; */
	}

	.signInType-1 {
		background: url(../../static/activity/hasS.png) center center no-repeat;
		background-size: 100% 100%;
		color: rgba(253, 217, 116, 1);
		/* opacity:0.4; */
	}

	.signInType-2 {
		background: url(../../static/activity/hasD.png) center center no-repeat;
		background-size: 100% 100%;
		color: rgba(253, 217, 116, 1);
	}

	.signInType-3 {
		background: url(../../static/activity/hasN.png) center center no-repeat;
		background-size: 100% 100%;
		color: rgba(128, 128, 128, 1);
	}

	.activity-describe {
		width: calc(100% - 48rpx);
		height:calc(204rpx - 32rpx);
		padding: 16rpx 24rpx;
		background: url(../../static/activity/des-border.png) center center no-repeat;
		background-size: 100% 100%;
		margin-bottom: 34rpx;
	}
	
	.activity-describe .content {
		padding: 10rpx 0;
		height:calc(204rpx - 52rpx);
		overflow: scroll;
	}

	.activity-describe view {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(179, 179, 179, 1);
		line-height: 42rpx;
	}

	.reward-scroll-view {
		height: calc(100vh - 100rpx - var(--status-bar-height) - 33rpx - 68rpx - 317rpx - 20rpx - 204rpx - 34rpx);
		padding-bottom: 42rpx;
	}

	.charge-scroll-view {
		height: calc(100vh - 100rpx - var(--status-bar-height) - 33rpx - 140rpx - 78rpx - 20rpx - 204rpx - 34rpx);
		padding-bottom: 42rpx;
	}

	.rewardView {
		width: calc(684rpx - 26rpx);
		/* height:calc(112rpx - 20rpx); */
		padding: 20rpx 26rpx;
		background: url(../../static/activity/des-border.png) center center no-repeat;
		background-size: 100% 100%;
		margin-bottom: 24rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.rewardView-text {
		flex: 1;
		/* display: flex; */

	}

	.rewardView-Title {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(253, 217, 116, 1);
		line-height: 42rpx;
	}

	.rewardView-reward {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(204, 204, 204, 1);
		line-height: 42rpx;
	}

	.rewardView-but {
		width: 110rpx;
		height: 50rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(253, 217, 116, 1);
		line-height: 26rpx;

	}

	.rewardView-but-bg1 {
		background: url(../../static/activity/receive-but.png) center center no-repeat;
		background-size: 100% 100%;
	}

	.rewardView-but-bg2 {
		background: url(../../static/activity/nreceive-but.png) center center no-repeat;
		background-size: 100% 100%;
	}


	.opacity05 {
		opacity: 0.5;
	}


	/*累充*/
	.chargeMoney-view {
		/* padding: 39rpx 44rpx; */
		margin-bottom: 50rpx;
	}

	.chargeTig {
		padding: 0 30rpx 44rpx 30rpx;
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	.chargeTig text {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(255, 255, 255, 1);
		line-height: 42rpx;
	}

	.chargeBut {

		width: 110rpx;
		height: 50rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: rgba(253, 217, 116, 1);
		line-height: 26rpx;
		margin-left: 37rpx;
		background: url(../../static/activity/nreceive-but.png) center center no-repeat;
		background-size: 100% 100%;

	}
</style>
