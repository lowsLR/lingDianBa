<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">剧情小说</block>
		</cu-custom>
		
		<view class="cLayout" style="display: flex;justify-content: center;width: 100%;flex-direction: column;align-items: center;">
			<image @tap="tapItem(type1)" class="imgSize" src="/static/novel-logo-1.png"></image>
			<image @tap="tapItem(type2)" class="imgSize mar-t-100" src="/static/novel-logo-2.png"></image>
		</view>
	</view>
</template>

<script>
	var _self
	
	export default {
		data() {
			return {
				lists:[{
					name:'主线地图',
					url:'/pages/map/map-list'
				}],
				type1:1,
				type2:2
			}
		},
		onLoad() {
			_self = this
			
		},
		methods: {
			tapItem(type) {
				switch(type) {
					case _self.type1:
						_self.navigateTo('/pages/novel/novel-list/novel-list')
						break;
						
					case _self.type2:
						_self.navigateTo('/pages/novel/novel-figure')
						break;
				}
			}
		}
	}
</script>

<style>
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.cLayout {
		height: calc(80vh - var(--status-bar-height) - 100rpx);
	}
	
	.imgSize {
		width: 360rpx;
		height: 360rpx;
	}
	
</style>
