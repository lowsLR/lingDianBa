<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">人物志</block>
		</cu-custom>
		
		<scroll-view class="sv" scroll-y="true">
			<view style="padding-bottom: 54rpx;display: flex;flex-direction: column;align-items: center;">
				<view style="margin-top: 54rpx;" v-for="(info,i1) in discipleList" :key="i1">
					<view v-if="!info.toShow" style="font-size: 40rpx;" class="exp-view flex-cc qua" :class="colorClassObj1[info.zy]" @tap="setShow(info.zy)">
						<view style="display: flex;flex: 1;justify-content: center;">
							{{info.zy}}
						</view>
						<uni-icons type="arrowdown" style="margin-right: 30rpx;position: absolute;right: 90rpx;color: #FFFFFF;" :class="colorClassObj2[info.zy]"  size="28" />
					</view>
					
					<view v-else class="lv-view qua" :class="colorClassObj1[info.zy]" @tap="setShow(info.zy)">
						<view class="listTitle" style="line-height: 120rpx;font-size: 40rpx;">
							{{info.zy}}
						</view>
						<uni-icons type="arrowup" style="margin-right: 30rpx;position: absolute;right: 90rpx;line-height: 120rpx;color: #FFFFFF;" :class="colorClassObj2[info.zy]" size="28" />
						
						<view v-if="i2<Math.ceil(info.data.length/2)" v-for="(item,i2) in info.data" :key="i2" style="display: flex;flex-direction: row;margin-bottom: 26rpx;font-size: 30rpx;width: 480rpx;">
							<view @tap.stop="tapItem(info.data[i2*2])" class="qua flex-cc" style="width: 220rpx;height: 68rpx;border-radius: 34rpx;"  :style="[{'color':info.data[i2*2]?info.data[i2*2].nameColor:'inherit'}]">{{info.data[i2*2]?info.data[i2*2].name:''}}</view>
							<view @tap.stop="tapItem(info.data[i2*2+1])" v-if="info.data[i2*2+1]" class="qua flex-cc mar-l-40" style="width: 220rpx;height: 68rpx;border-radius: 34rpx;"  :style="[{'color':info.data[i2*2+1]?info.data[i2*2+1].nameColor:'inherit'}]">{{info.data[i2*2+1]?info.data[i2*2+1].name:''}}</view>
						</view>
						
					</view>
				</view>
				
				
			</view>
		</scroll-view>
		
		<popup-disciple ref="refDisciple"></popup-disciple>
	</view>
</template>

<script>
	import popupDisciples from '@/components/popup-disciple/popup-disciple.vue'
	var _self
	
	export default {
		components:{
			popupDisciples
		},
		data() {
			return {
				discipleList:[],
				colorClassObj1:{
					'正面人物':'qua-1',
					'反面人物':'qua-2'
				},
				colorClassObj2:{
					'正面人物':'c-1',
					'反面人物':'c-2'
				}
			}
		},
		onLoad(option) {
			_self = this
			let discipleList = _self.jsonParse.getSpecialDiscipleArrayFromNovel()
			discipleList.forEach((item)=>{
				item.toShow = false
			})
			_self.discipleList = discipleList
		},
		methods: {
			tapItem(info) {
				if(info) {
					_self.$refs.refDisciple.open(info)
				}
			},
			setShow(zy){
				let discipleList = _self.discipleList
				let disciple = discipleList[discipleList.findIndex(item => item.zy==zy)]
				if(disciple) {
					if(disciple.toShow) {
						disciple.toShow = false
					}else {
						discipleList.forEach((item)=>{
							item.toShow = false
						})
						disciple.toShow = true
					}
				}
			}
		}
	}
</script>

<style>
	
	.container {
		width: 750rpx;
		height: 100vh;
		background:url(../../static/home-bg.png) center center no-repeat;background-size:750rpx 1550rpx;
	}
	
	.sv {
		height: calc(100vh - 100rpx - var(--status-bar-height));
	}
	
	.exp-view{
		width:570upx;
		height:98upx;
		border-radius:49upx;
		
		font-size:40upx;
		font-weight:500;
		line-height:81upx;
		
	}
	.lv-view{
		/* height:782upx; */
		width: 570upx;
		border-radius:49upx;
		overflow: hidden;
		display: flex;
		align-items: center;
		justify-content: flex-start;
		flex-direction: column;
		transition: all .3s ease-out;
	}
	
	.flex-cc {
		display: flex; align-items: center; justify-content: center;
	}
	
	.qua {
		color: #FFFFFF;
		 box-shadow: 0 0 11px #FFFFFF;
	}
	
	.qua-1 {
		color: #FFFF00;
		box-shadow: 0 0 11px #FFFF00;
	}
	
	.qua-2 {
		color: #FF0000;
		box-shadow: 0 0 11px #FF0000;
	}
	
	.c-1 {
		color: #FFFF00!important;
	}
	
	.c-2 {
		color: #FF0000!important;
	}
	
</style>
