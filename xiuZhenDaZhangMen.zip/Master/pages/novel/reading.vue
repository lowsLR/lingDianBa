<template>
	<view class="container">
		<cu-custom :isBack="true">
			<block slot="content">天墟纪</block>
			<block slot="right"><view @tap="showToll" class="right-header">録</view></block>
		</cu-custom>
		<scroll-view
			:style="{ 'background-color': currentTheme.backgroundColor }"
			@click="contentTapHandler"
			@scroll="scrollChange"
			class="scroll"
			:scroll-top="scrollTop"
			:scroll-with-animation="scrollAnimation"
			scroll-y="true"
		>
			<view class="title-section">
				<text class="title" :style="{ color: currentTheme.color }">{{ chapterTitle }}</text>
			</view>
			<view class="content-section">
				<text class="content" :style="{ 'font-size': fontSize, color: currentTheme.color }">{{ content }}</text>
				<!-- <u-parse :content="content"/> -->
			</view>
			<!-- <view class="bottom-section">
				<button @click="bottomBtnHandler('pre')" class="bottom-btn" :class="{ 'bottom-night-btn': isNight }" type="primary">上一章</button>
				<button @click="bottomBtnHandler('chapters')" class="bottom-btn" :class="{ 'bottom-night-btn': isNight }" type="primary">目录</button>
				<button @click="bottomBtnHandler('next')" class="bottom-btn" :class="{ 'bottom-night-btn': isNight }" type="primary">下一章</button>
			</view> -->

			<!-- 点击加载下一章 -->
			<view class="bottom-section">
				<view @click="bottomBtnHandler('next')" class="bottom-btn" :class="{ 'bottom-night-btn': isNight }" type="primary">点击加载下一章</view>
			</view>
		</scroll-view>
		<view @click="maskHandler" class="slider-mask" :class="{ 'slider-show-mask': sliderShow }">
			<view @click="sliderHandler" class="slider-section" :class="{ 'slider-show-section': sliderShow }">
				<ss-sliderbar :isNightTheme="isNight" @chapterItemTap="chapterItemHandler" :currentChapter="currentChapter" :chapterList="directoryList"></ss-sliderbar>
			</view>
		</view>
		<view class="tool-section" :class="{ 'tool-show-section': toolShow }">
			<ss-toolbar
				@toolSliderChange="toolSliderChangeHandler"
				:chapter="chapter"
				@themeTap="themeHandler"
				@functionBtnTap="functionBtnHandler"
				@chapterBtnTap="chapterBtnHandler"
				:isNight="isNight"
			></ss-toolbar>
		</view>
		<view class="set-section" :class="{ 'set-show-section': setShow }">
			<ss-setbar :isNightTheme="isNight" @brightChange="brightChangeHandler" @fontSizeChange="fontSizeChangeHandler"></ss-setbar>
		</view>
	</view>
</template>

<script>
import ssSliderbar from '@/components/ss-sliderbar/ss-sliderbar.vue';
import ssToolbar from '@/components/ss-toolbar/ss-toolbar.vue';
// import Json from '@/static/novel/novel-master.js';
import uParse from '@/components/gaoyia-parse/parse.vue';
import ssSetbar from '@/components/ss-setbar/ss-setbar.vue';
import testJson from '@/static/novel/novel-master-confirm.js';
var that;
export default {
	components: {
		ssSliderbar,
		ssToolbar,
		uParse,
		ssSetbar
	},
	data() {
		return {
			chapterList: [], //小说数据
			directoryList: [], //目录数据
			directoryTiele: {},
			chapter: {},
			sliderShow: false,
			toolShow: false,
			setShow: false,
			screenWidth: 0,
			screenHeight: 0,
			content: '',
			chapterTitle: '',
			currentChapter: 0, // 当前的章节数 默认从0开始
			fontSize: '17px',
			nightTheme: {
				backgroundColor: '#161616',
				color: '#4f5050'
			},
			dayTheme: {
				backgroundColor: '#f7f7f7',
				color: '#333'
			},
			// 默认采用白天的主题样式
			currentTheme: {
				backgroundColor: '#f7f7f7',
				color: '#333'
			},
			// 是否为夜间模式
			// 默认值为false
			isNight: false,
			scrollAnimation: true, //滚动是否过度
			lastScrollY: 0, // 用来判断电子书的滑动方向
			scrollTop: 0
		};
	},
	onLoad(options) {
		// console.log(options, '---跳转过来接收了什么？');
		that = this;
		that.calculateScreenSize();

		that.nightTrue();
		// that.init();
		try {
			let v = uni.getStorageSync('readData');

			// 记录一下传过来的下标变化,若变化就scrollTop设置为0
			if (v.currentChapter !== options.index) {
				// console.log(v, 'v==>是什么？');
				uni.removeStorageSync('readData');

				let rd = {
					lastScrollY: 0,
					currentChapter: options.index,
					fontSize: that.fontSize
				};
				uni.setStorageSync('readData', rd);
				v = uni.getStorageSync('readData');
				if (v) {
					that.getEbookChapterList(v.currentChapter);
					that.scrollTop = v.lastScrollY;
					that.fontSize = v.fontSize;
				} else {
					that.getEbookChapterList();
				}
			} else {
				if (v) {
					that.getEbookChapterList(v.currentChapter);
					that.scrollTop = v.lastScrollY;
					that.fontSize = v.fontSize;
				} else {
					that.getEbookChapterList();
				}
			}
		} catch (e) {
			that.getEbookChapterList();
		}
	},
	onUnload() {
		let rd = {
			lastScrollY: that.lastScrollY,
			currentChapter: that.currentChapter,
			fontSize: that.fontSize
		};
		uni.setStorageSync('readData', rd);
	},
	methods: {
		// 小说数据获取
		init() {
			var arr = testJson.test;
			var newArr = [];
			for(var v in arr){
				var nowArr = arr[v].chapterList;
				for(var i = 0;i<nowArr.length;i++){
					newArr.push(nowArr[i])
				}
			}
			that.chapterList = newArr

			// console.log(newArr,"==》testJson.test")
		},
		nightTrue() {
			uni.getStorage({
				key: 'nightMode',
				success: res => {
					// console.log(res.data, '22222jajsdhadja');
					if (res.data == true) {
						this.themeHandler(true);
					} else {
						this.themeHandler(false);
					}
				}
			});

			// console.log(,"diyicijinrushishenm")
		},

		showToll() {
			console.log('点击目录');
			that.toolShow = !that.toolShow;
			that.setShow = false;
		},
		calculateScreenSize() {
			var info = uni.getSystemInfoSync();
			that.screenHeight = info.safeArea.height;
			that.screenWidth = info.safeArea.width;
		},
		getEbookChapterList(num = 0) {
			// that.$request.get('/mock/5df5ddd06fffb769a4b0a3b5/example/ebook/chapters').then(res => {
			// 	console.log('紅樓夢章节目录:' + JSON.stringify(res));
			// 	that.chapterList = res.data.data;
			// 	that.chapter = that.chapterList[0];
			// 	console.log('章節內容:' + JSON.stringify(that.chapter));
			// 	that.chapterTitle = that.chapterList[0].title;
			// 	that.getChapterContent(that.chapterList[0].number);
			// })

			// that.chapterList = Json.chapterList;
			// let arr = Json.chapterList;

			this.init()
			let arr = that.chapterList;
			let darr = [];
			arr.forEach(item => {
				darr.push({ title: item.title });
			});
			that.directoryList = darr;
			that.initBook(num);
		},
		initBook(i) {
			that.currentChapter = i;
			that.chapter = that.directoryList[i];
			that.chapterTitle = that.chapter.title;
			// console.log(that.chapterTitle);
			that.getChapterContent(i);
			// that.$nextTick(function(){
			// 	that.$forceUpdate();
			// })
		},
		/*动态设置章节*/
		setEBook(i) {
			that.currentChapter = i;
			that.chapter = that.directoryList[i];
			that.chapterTitle = that.chapter.title;
			that.getChapterContent(i);
			that.scrollAnimation = false;
			that.scrollTop = that.lastScrollY;
			that.$nextTick(function() {
				that.scrollTop = 0;
				that.$forceUpdate();
			});
			console.log('i里面有什么内容==>', i);

		},
		getChapterContent(num) {
			// let param = {
			// 	num: num
			// };
			// that.$request.get('/mock/5df5ddd06fffb769a4b0a3b5/example/ebook/chpater/content').then(res => {
			// 	console.log('获取的章节内容' + JSON.stringify(res.data));
			// 	that.content = res.data.content;
			// })
			that.content = that.chapterList[num].content;
			let obj = { piece: '', chapter: '', ready: true };
			let arr = testJson.test;
			for (var v in arr) {
				var nowArr = arr[v].chapterList;
				for (var i = 0; i < nowArr.length; i++) {
					if (nowArr[i].title == that.chapterList[num].title) {
						obj = { piece: v, chapter: i, ready: true };
					}
				}
			}
			// console.log(that.isready , '==>test');
			// 全局监听阅读张数
			uni.$emit('novel', { msg: obj });
		},
		
		chapterItemHandler(index) {
			if (that.currentChapter == index) {
				return;
			}
			that.setEBook(index);
			// var chapter = that.chapterList[index];
			// that.showToast('章节ID:' + chapter.number)
		},
		chapterBtnHandler(btnType) {
			switch (btnType) {
				case 'pre':
					if (that.currentChapter > 0) {
						that.setEBook(--that.currentChapter);
					} else {
						that.showToast('已经是第一章了！');
					}
					break;
				case 'next':
					if (that.currentChapter < that.chapterList.length - 1) {
						that.setEBook(++that.currentChapter);
					} else {
						that.showToast('已经是最后一章了！');
					}
					break;
			}
		},
		contentTapHandler(e) {
			let xMid = that.screenWidth / 2;
			let yMid = that.screenHeight / 2;
			let x = e.detail.x;
			let y = e.detail.y;
			// 这里设置屏幕中心200区域为可点区域
			// 点击可以弹出底部工具栏
			if (x > xMid - 200 && x < xMid + 200 && (y < yMid + 200 && y > yMid - 200)) {
				that.toolShow = !that.toolShow;
				that.setShow = false;
			}
		},
		maskHandler() {
			that.sliderShow = false;
		},
		sliderHandler() {},
		functionBtnHandler(type) {
			switch (type) {
				case 'chapters':
					that.toolShow = false;
					setTimeout(function() {
						that.sliderShow = true;
						that.$nextTick(function() {
							that.$forceUpdate();
						});
					}, 0.3);
					break;
				case 'set':
					that.toolShow = false;
					setTimeout(function() {
						that.setShow = true;
					}, 0.3);
					that.$nextTick(function() {
						that.$forceUpdate();
					});
					break;
			}
		},
		/**
		 * 主题变换按钮
		 * 点击事件
		 */
		themeHandler(isNight) {
			// 记录主题状态
			uni.setStorage({
				key: 'nightMode',
				data: isNight
			});
			// console.log('记录主题状态？', isNight);

			that.isNight = isNight;

			if (isNight) {
				// 夜间主题模式
				uni.setNavigationBarColor({
					frontColor: '#ffffff',
					backgroundColor: that.nightTheme.backgroundColor,
					animation: {
						duration: 400,
						timingFunc: 'easeIn'
					},
					fail: function(res) {
						console.log('导航栏颜色失败:' + JSON.stringify(res));
					}
				});
				that.currentTheme = that.nightTheme;
			}else {
				// 白天主题模式
				uni.setNavigationBarColor({
					frontColor: '#000000',
					backgroundColor: that.dayTheme.backgroundColor,
					animation: {
						duration: 400,
						timingFunc: 'easeIn'
					},
					fail: function(res) {
						console.log('导航栏颜色失败:' + JSON.stringify(res));
					}
				});
				that.currentTheme = that.dayTheme;
			}
		},
		bottomBtnHandler(type) {
			switch (type) {
				case 'pre':
					if (that.currentChapter > 0) {
						that.setEBook(--that.currentChapter);
					} else {
						that.showToast('已经是第一章了！');
					}
					break;
				case 'chapters':
					that.sliderShow = true;
					break;
				case 'next':
					if (that.currentChapter < that.chapterList.length - 1) {
						that.setEBook(++that.currentChapter);
					} else {
						that.showToast('已经是最后一章了！');
					}
					break;
			}
		},
		toolSliderChangeHandler(value) {
			console.log('我获取的值为:' + value);
		},
		// 监听电子书滑动事件
		scrollChange(e) {
			let laterScrollTop = e.detail.scrollTop;
			let ty = laterScrollTop - that.lastScrollY;
			if (ty < 0) {
				// console.log('向上滑动');
			} else {
				that.toolShow = false;
			}
			that.lastScrollY = laterScrollTop;
		},
		/**
		 * 电子书阅读页面监听
		 * 字体变化
		 */
		fontSizeChangeHandler(fontSize) {
			that.fontSize = fontSize + 'px';
			console.log('fontSize变化了:' + that.fontSize);
		},
		/**
		 * 电子书阅读页面监听
		 * 屏幕亮度变化
		 */
		brightChangeHandler(bright) {
			let value = bright / 100;
			uni.setScreenBrightness({
				value: value,
				success: function() {}
			});
		}
	}
};
</script>

<style lang="scss">
.container {
	// position: absolute;
	// left: 0upx;
	// bottom: 0upx;
	// right: 0upx;
	// top: 0upx;
	width: 750rpx;
	height: 100vh;
	.scroll {
		// position: absolute;
		// height: 100%;
		// left: 0upx;
		// bottom: 0upx;
		// right: 0upx;
		// top: 88upx;
		height: calc(100vh - 100rpx - var(--status-bar-height));
		.content-section {
			padding: 0upx 32upx;
		}

		.title-section {
			padding: 20upx 32upx;
			font-size: 24px;
			font-weight: 600;
		}

		// .bottom-section {
		// 	margin-top: 50upx;
		// 	display: flex;
		// 	justify-content: space-around;
		// 	align-items: center;
		// 	padding-bottom: 20upx;

		// 	.bottom-btn {
		// 		width: 200upx;
		// 		height: 70upx;
		// 		color: #000;
		// 		line-height: 70upx;
		// 		border-radius: 10upx;
		// 		background-color: #fff;
		// 		font-size: $uni-font-size-lg;
		// 	}

		// 	.bottom-night-btn {
		// 		background-color: #333;
		// 		color: #808080;
		// 	}
		// }
		.bottom-section {
			padding: 20upx 0;
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: center;
			color: #808080;
			font-size: $uni-font-size-lg;
			background-color: transparent;
			.bottom-night-btn {
				background-color: transparent;
				color: #4f5050;
			}
		}
	}

	.slider-mask {
		position: fixed;
		top: calc(100rpx + var(--status-bar-height));
		left: 0upx;
		bottom: 0upx;
		right: 0upx;
		display: flex;
		transition: 0.7s;
		background-color: rgba(0, 0, 0, 0);
		visibility: hidden;
		animation-delay: 0.2s;

		.slider-section {
			height: 100%;
			width: 80%;
			transform: translateX(-100%);
			transition: 0.3s;
		}

		.slider-show-section {
			transform: translateX(0);
		}
	}

	.slider-show-mask {
		visibility: visible;
		background-color: rgba(0, 0, 0, 0.5);
	}

	.set-section {
		position: fixed;
		height: 200upx;
		left: 0upx;
		bottom: 0upx;
		right: 0upx;
		transform: translateY(100%);
		transition: 0.3s;
	}

	.set-show-section {
		transform: translateY(0);
	}

	.tool-section {
		position: fixed;
		height: 300upx;
		left: 0upx;
		bottom: 0upx;
		right: 0upx;
		transform: translateY(100%);
		transition: 0.3s;
	}

	.tool-show-section {
		transform: translateY(0);
	}
}
.right-header {
	width: 64rpx;
	height: 64rpx;
	border-radius: 50%;
	margin-right: 24rpx;
	border: solid 1px #666666;
	font-size: 34rpx;
	line-height: 64rpx;
	text-align: center;
}
</style>
