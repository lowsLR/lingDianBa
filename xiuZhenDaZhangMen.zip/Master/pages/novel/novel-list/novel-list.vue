<template>
	<view class="container">
		<cu-custom :isBack="true"><block slot="content">天墟纪</block></cu-custom>

		<scroll-view scroll-y="true" class="scrollHeight">
			<view class="scroll-layout">
				<!-- 小说大提纲 -->
				<block v-for="(items, indexs) in chapterList" :key="items.name">
					<view class="novel-content">
						<view class="title-arrow" @tap.stop="toShow(items.name)">
							<view class="title">{{ items.name }}</view>
							<block v-if="items.showOrHidden">
								<uni-icons type="arrowup" style="margin-right: 0rpx;position: absolute;right: 90rpx;top:0;color: #FFFFFF;" size="28" />
							</block>

							<block v-if="!items.showOrHidden">
								<uni-icons type="arrowdown" style="margin-right: 0rpx;position: absolute;right: 90rpx;top:0;color: #FFFFFF;" size="28" />
							</block>
						</view>

						<view class="list-content" v-if="items.showOrHidden">
							<!-- <scroll-view scroll-y="true" class="scrollh"> -->
							<view class="list">
								<block v-for="(item, index) in items.chapterList" :key="index">
									<view @tap="Chapter(item.ready, indexs, index, item.title)" :class="{ active: item.ready != 'false' }">
										<text class="kong"></text>
										<text class="title">{{ item.title }}</text>
									</view>
								</block>
							</view>
							<!-- </scroll-view> -->
						</view>
					</view>
				</block>
				<!-- 测试 -->
				<!-- <view style="width:100%;max-height: 400px;background: none;">
					<view @tap="testscroll" style="height: 60px;text-align: center;line-height: 60px;color: #fff;background-color: #0033CC;">
						{{ testShow ? '我展开了' : '我关闭了' }}
					</view>
						<block v-if="testShow">
							<view style="height: 200px;background: red;"></view>
							<view style="height: 300px;background: #A31B27;"></view>
							<view style="height: 400px;background: #A2FFF6;"></view>
						</block>
				</view> -->
			</view>
		</scroll-view>
	</view>
</template>

<script>
import testJson from '@/static/novel/novel-master-confirm.js';
// import test from '@/static/novel/test.js';
/*
	小说的json格式
		[
			{name:'第一部',chapterList:[{},{}],showOrHidden:false},
			{name:'第二部',chapterList:[{},{}],showOrHidden:false}
		]
	*/
export default {
	data() {
		return {
			//阅读记录
			isready: [],
			flag: true,
			// 小说数据
			chapterList: [],
			//小说插件的阅读记录
			novelDate: {},
			//测试滚动
			testShow: false
		};
	},
	onLoad() {
		// console.log(test,"===>test")
		uni.$on('novel', data => {
			this.novelDate = data.msg;
			console.log(this.novelDate, '==>监听接受到');
			this.isready.push(this.novelDate);
			this.chapterList[data.msg.piece].chapterList[data.msg.chapter].ready = true;
			uni.setStorage({
				key: 'isReady',
				data: this.isready
			});
		});
		// 初始化()
		this.init();
	},
	onUnload() {
		uni.$off('novel');
	},
	methods: {
		init() {
			// uni.removeStorage({
			//     key: 'isReady',
			//     success: function (res) {
			//         console.log('success');
			//     }
			// });

			this.chapterList = testJson.test;
			uni.getStorage({
				key: 'isReady',
				success: res => {
					console.log(res.data, '==>存在阅读数据');
					this.isready = res.data;
					// this.isread.push.apply(this.isready, this.novelDate);
					this.isready.forEach((item, index) => {
						this.chapterList[item.piece].chapterList[item.chapter].ready = true;
						// console.log(item)
					});
				}
			});
			this.chapterList.forEach(item => {
				item.showOrHidden = false;
			});
			// console.log(this.chapterList, '小説數據');
		},
		toShow(e) {
			var flag = this.flag;
			let discipleList = this.chapterList;
			let disciple = discipleList[discipleList.findIndex(item => item.name == e)];
			// console.log(disciple,"==>disciple")
			if (disciple) {
				if (flag) {
					if (!disciple.showOrHidden) {
						discipleList.forEach(item => {
							item.showOrHidden = false;
						});
						disciple.showOrHidden = true;

						this.testShow = false;
					} else {
						discipleList.forEach(item => {
							item.showOrHidden = false;
						});
						// disciple.showOrHidden = false;
						this.testShow = true;
					}
					this.flag = false;
				} else {
					discipleList.forEach(item => {
						item.showOrHidden = false;
					});
					disciple.showOrHidden = true;
					this.flag = true;
				}
			}
		},
		//跳转到小说插件页面
		Chapter(ready, piece, i, title) {
			console.log(ready);
			// 根据下标查询所在位置添加阅读标识
			let index = parseInt(title.replace(/[^0-9]/gi, '') - 1);
			// // 判断一下是否阅读了
			// console.log(piece,i)

			if (title !== '持续更新中......') {
				if (ready == 'false') {
					let obj = { piece: piece, chapter: i, ready: true };
					this.isready.push(obj);
					if (obj.piece && obj.chapter) {
						uni.setStorage({
							key: 'isReady',
							data: this.isready
						});
					}
					this.chapterList[piece].chapterList[i].ready = true;
					// console.log(this.chapterList[piece].chapterList[i])
				}
				// 跳转小说页面
				uni.navigateTo({
					url: `/pages/novel/reading?piece=${piece}&index=${index}`,
					success: () => {
						//页面跳转后是否将小说列表隐藏起来
						this.chapterList.forEach(item => {
							item.showOrHidden = false;
						});
					}
				});
			}
		},
		//测试滚动
		testscroll() {
			var flag = this.flag;
			if (flag) {
				this.flag = false;
				this.testShow = true;
				this.chapterList.forEach(item => {
					item.showOrHidden = false;
				});
			} else {
				this.flag = true;
				this.testShow = false;
			}
		}
	}
};
</script>

<style scoped>
.container {
	width: 750rpx;
	height: 100vh;
	background: url(../../../static/market-detail/other-black-bg.png) center center no-repeat;
	background-size: 750rpx 1550rpx;
	overflow: hidden;
}

.scrollHeight {
	height: calc(100vh - 100rpx - var(--status-bar-height));
	color: #ffffff;
	/* padding: 30rpx 0; */
	/* border: 1px solid #f59; */
}

.scroll-layout {
	display: flex;
	align-items: center;
	justify-content: center;
	flex-direction: column;
	margin-top: 30rpx;
}
.novel-content {
	width: 651rpx;
	border: 1rpx solid rgba(255, 255, 255, 1);
	border-radius: 44rpx;
	overflow: hidden;
	margin-bottom: 30rpx;
}

.title-arrow {
	text-align: center;
	height: 89rpx;
	line-height: 89rpx;
	position: relative;
}
.list-content {
}
.scrollh {
	max-height: calc(100vh - 400rpx - var(--status-bar-height));
}
.list-content .list {
	text-align: center;
	font-size: 28rpx;
	color: #cccccc;
}
.list-content .list .active {
	color: red !important;
}
.list-content .list view {
	border-bottom: 1px solid;
	border-color: #333333;
	padding: 23rpx 0;
	display: flex;
	align-items: center;
	/* justify-content: center; */
}
.list-content .list view:last-child {
	border-bottom: 0;
}

.list view > .kong {
	width: 200rpx;
}
</style>
