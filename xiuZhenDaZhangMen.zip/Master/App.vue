<script>
	import Vue from 'vue'
	var timer
	export default {
		globalData:{
			accountToken:'',
			sectToken:'',
			serverTime:0,
			disciples:[],
			equips:[],
			gameUrlPre:'',
			materialObj:{},
			sectView:{},
			hasTime:false,
			avatarPre:''
		},
		onLaunch: function() {
			console.log('App Launch')
			
			// #ifdef APP-PLUS
			this.$req.toUpdate()
			// #endif
			
			uni.getSystemInfo({
				success: function(e) {
					Vue.prototype.windowWidth = e.windowWidth; 
				}
			})
		},
		onShow: function() {
			console.log('App Show')
			this.$req.getServerTime(0, (ts)=>{
				if(ts) {
					this.$options.globalData.hasTime = true
					this.$options.globalData.serverTime = ts
					if(!timer) {
						timer = setInterval(()=>{
							this.$options.globalData.serverTime += 1000
						},1000)
					}
				}
			})
		},
		onHide: function() {
			console.log('App Hide')
			if(timer) {
				clearInterval(timer)
				timer = null
				
				this.$options.globalData.hasTime = false
			}
		}
	}
</script>

<style>
	@import './common/app.css';
	/*每个页面公共css */
	page {
		background-color: #000000;
	}
	
	/* 修改默认的滑块样式 */
	
	uni-slider{
		margin: 20rpx 10rpx;
	}
	
	uni-slider .uni-slider-handle-wrapper {
		position: relative;
		height: 10rpx !important;
		border-radius: 0;
		/* background-color: #e9e9e9; */
		-webkit-tap-highlight-color: transparent;
		border:1px solid rgba(153,153,153,1);
	}
	
	
	uni-slider .uni-slider-thumb{
		background: url(./static/resource-merchant/huakuai.png) center center no-repeat;
		background-size: 100% 100%;
		border-radius: 0;
	}
	
	::-webkit-scrollbar {
	       width: 0;
	       height: 0;
	       color: transparent;
	}
</style>
