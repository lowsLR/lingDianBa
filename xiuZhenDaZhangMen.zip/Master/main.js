import Vue from 'vue'
import App from './App'

import req from '@/api/req'
import util from '@/common/util'
import jsonParse from '@/common/json-parse'


import cuCustom from './components/cu-custom/cu-custom.vue'
Vue.component('cu-custom',cuCustom)

Vue.config.productionTip = false


Vue.prototype.navigateTo = function(url,callback){
	uni.navigateTo({
		url: url,
		animationType: 'zoom-fade-out',
		animationDuration: 300,
		complete: () => {
			if(callback) {
				callback()
			}
		}
	})
}
Vue.prototype.redirectTo = function(url){
	uni.redirectTo({
		url:url
	})
}
Vue.prototype.showToast = function(title){
	uni.showToast({
		title: title,
		icon:'none',
		duration:2000
	})
}
Vue.prototype.making = function(){
	uni.showToast({
		title: '制作中',
		icon:'none',
		duration:2000
	})
}

Vue.prototype.$req = req
Vue.prototype.util = util
Vue.prototype.jsonParse = jsonParse

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
