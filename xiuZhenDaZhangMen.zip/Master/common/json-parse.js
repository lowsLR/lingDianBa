import building from '@/static/json/building-defines.json'
import material from '@/static/json/material-defines.json'
import materialType from '@/static/json/material-type-defines.json'
import realm from '@/static/json/realm-exchange-defines.json'
import equipStrength from '@/static/json/equip-strength-defines.json'
import equipInitial from '@/static/json/equip-initial-defines.json'
import equipInitialRate from '@/static/json/equip-initial-rate-defines.json'
import equipIFloor from '@/static/json/equip-floor-defines.json'
import equipType from '@/static/json/equip-type-defines.json'
import masterProperty from '@/static/json/master-property-defines.json'
import discipleProperty from '@/static/json/disciple-property-defines.json'
import discipleSpecial from '@/static/json/disciple-special-defines.json'
import physiqueGift from '@/static/json/physique-gift-defines.json'
import quality from '@/static/json/quality-defines.json'
import alchemyForge from '@/static/json/alchemy-forge-defines.json'
import discipleQuality from '@/static/json/disciple-quality-defines.json'
import skill from '@/static/json/skill-defines.json'
import map from '@/static/json/map-defines.json'
import mapElement from '@/static/json/map-element-defines.json'
import mapTask from '@/static/json/map-task-defines.json'
import mapText from '@/static/json/map-text-defines.json'
import mapBusiness from '@/static/json/map-business-defines.json'
import mapJump from '@/static/json/map-jump-defines.json'
import mapChance from '@/static/json/map-chance-defines.json'
import mapFight from '@/static/json/map-fight-defines.json'
import mapSpecial from '@/static/json/map-special-defines.json'
import mapContinue from '@/static/json/map-continue-defines.json'
import mapOperateColor from '@/static/json/map-operate-color-defines.json'
import mapMaterialGain from '@/static/json/map-material-gain-defines.json'
import mapMaterialConsume from '@/static/json/map-material-consume-defines.json'
import monster from '@/static/json/monster-defines.json'
import breakThrough from '@/static/json/disciple-break-through-defines.json'
import land from '@/static/json/land-defines.json'
import formulaTable from '@/static/json/formula-table-defines.json'
import inherited from '@/static/json/inherited-defines.json'
import exchangeEquip from '@/static/json/exchange-equip-defines.json'
import exchange from '@/static/json/exchange-defines.json'
import exchangeMaterial from '@/static/json/exchange-material-defines.json'
import sectUpgrade from '@/static/json/sect-upgrade-defines.json'
import wordsNew from '@/static/json/words-new-defines.json'
import wordsIntro from '@/static/json/words-intro-defines.json'
import sectAchievement from '@/static/json/sect-achievement-defines.json'
import equipStar from '@/static/json/equip-star-defines.json'
import pvpReward from '@/static/json/pvp-reward-defines.json'
import materialMix from '@/static/json/material-mix-defines.json'
import alchemyForgeAccess from '@/static/json/alchemy-forge-access-defines.json'
import discipleLifeSoul from '@/static/json/disciple-life-soul-defines.json'

import tower from '@/static/json/tower-defines.json'
import towerElement from '@/static/json/tower-element-defines.json'
import towerText from '@/static/json/tower-text-defines.json'
import towerBusiness from '@/static/json/tower-business-defines.json'
import towerChance from '@/static/json/tower-chance-defines.json'
import towerFight from '@/static/json/tower-fight-defines.json'
import towerBuff from '@/static/json/tower-buff-defines.json'
import towerContinue from '@/static/json/tower-continue-defines.json'
import towerReward from '@/static/json/tower-reward-defines.json'
import towerMaterialGain from '@/static/json/tower-material-gain-defines.json'
import towerMaterialConsume from '@/static/json/tower-material-consume-defines.json'

/**
 * 获取建筑信息
 */
const getBuilding = (type,level) => {
	return building[building.findIndex(item => item.type==type && item.level==level)]
}

/**
 * 首页解析物品
 */
const parseHomeMaterial = (text) => {
	let materialObj = {}
	text.split('#').forEach((item)=>{
		let itemArray = item.split(':')
		itemArray.forEach((num,index)=>{
			itemArray[index] = parseInt(num)
		})
		let info = material[material.findIndex(item => item.type==itemArray[0] && item.id==itemArray[1])]
		if(info) {
			info.count = itemArray[2]
			materialObj[info.name] = info
		}
	})
	return materialObj
}

const getRealm = (greatRealm,smallRealm) => {
	return realm[realm.findIndex(item => item.greatRealm==greatRealm && item.smallRealm==smallRealm)]
}

/**
 * 弟子详情  获取穿戴情况
 */
const parseWearEquip = (text) => {
	let equipObject = {}
	let equipArray = text.split('#')
	equipArray.forEach((info)=>{
		let infoArray = info.split('=')
		let equipInfo = equipStrength[equipStrength.findIndex(item => item.type==parseInt(infoArray[0]) && item.id==parseInt(infoArray[1]))]
		if(equipInfo) {
			equipObject[equipInfo.type] = equipInfo
		}
	})
	return equipObject
}

/**
 * 获取装备信息
 */
const getEquipInfo = (id,level) => {
	return equipStrength[equipStrength.findIndex(item => item.id==id && item.level==level)]
}

/**
 * 1234：武器、衣服、配饰、鞋子
 */
const getEquipTypeName = (type) => {
	let name = ''
	let info = equipType[equipType.findIndex(item => item.type==type)]
	if(info) {
		name = info.name
	}
	return name
}

/**
 * 物品类型：剑修武器  青锋剑
 * 多个，只拿一个
 */
const getEquipTypeNameByEquipName = (name) => {
	let result = ''
	let info = equipStrength[equipStrength.findIndex(item => item.name==name)]
	if(info) {
		let dressOccupation = info.dressOccupation
		if(dressOccupation=='无') {
			dressOccupation = ''
		}
		result = dressOccupation+getEquipTypeName(info.type)
	}
	return result
}

/**
 * 获取体质或天赋名称
 */
const getPhysiqueGiftName = (id) => {
	let name = '无'
	let info = physiqueGift[physiqueGift.findIndex(item => item.id==id)]
	if(info) {
		name = info.name
	}
	return name
}

/**
 * 获取体质或天赋
 */
const getPhysiqueGift = (id) => {
	return physiqueGift[physiqueGift.findIndex(item => item.id==id)]
}

/**
 * 获取物品品质
 */
const getMaterialQualityName = (qua) => {
	let text = ''
	let info = quality[quality.findIndex(item => item.quality==qua && item.type=='物品')]
	if(info) {
		text = info.text
	}
	return text
}

/**
 * 获取装备品质
 */
const getEquipQualityName = (qua) => {
	let text = ''
	let info = quality[quality.findIndex(item => item.quality==qua && item.type=='装备')]
	if(info) {
		text = info.text
	}
	return text
}

/**
 * 获取装备品质 带颜色
 */
const getEquipQualityNameWithColor = (qua) => {
	let text = ''
	let info = quality[quality.findIndex(item => item.quality==qua && item.type=='装备')]
	if(info) {
		text = '<span style=color:'+info.color+';>'+info.text+'</span>'
	}
	return text
}

/**
 * 获取装备最大等级
 */
const getEquipMaxLevel = (equipId) => {
	let maxLevel = 0
	let equipArray = []
	equipStrength.forEach((info)=>{
		if(info.id==equipId) {
			equipArray.push(info)
		}
	})
	
	if(equipArray.length>0) {
		equipArray.sort(function(a,b){
			return b.level-a.level
		})
		maxLevel = equipArray[0].level
	}
	return maxLevel
}

/**
 * 获取装备当前等级提升的属性数值
 */
const getEquipTotalBoostValue = (equipId,level) => {
	let totalValue = 0
	equipStrength.forEach((info)=>{
		if(info.id==equipId && info.level<level) {
			totalValue += info.boostValue
		}
	})
	return totalValue
}

/**
 * 获取炼丹或铸造对应等级
 */
const getAlchemyForgeName = (id,type) => {
	let typeText = ''
	switch(type) {
		case 1:
			typeText = '炼丹品级'
			break;
			
		case 2:
			typeText = '铸造品级'
			break;
	}
	let name = ''
	let info = alchemyForge[alchemyForge.findIndex(item => item.type==typeText && item.id==id)]
	if(info) {
		name = info.name
	}
	return name
}

/**
 * 获取炼丹或铸造对应升级经验
 */
const getAlchemyForgeExt = (id,type) => {
	let typeText = ''
	switch(type) {
		case 1:
			typeText = '炼丹品级'
			break;
			
		case 2:
			typeText = '铸造品级'
			break;
	}
	let ext = 0
	let info = alchemyForge[alchemyForge.findIndex(item => item.type==typeText && item.id==id)]
	if(info) {
		ext = info.ext
	}
	return ext
}

/**
 * 获取材料信息
 */
const getMaterialInfo = (mt,materialId) => {
	return material[material.findIndex(item => item.type==mt && item.id==materialId)]
}

/**
 * 通过资质获取弟子资质、品质
 */
const getDiscipleQuality = (id) => {
	return discipleQuality[discipleQuality.findIndex(item => item.id==id)]
}

/**
 * 获取招人页面 特殊弟子数组
 */
const getSpecialDiscipleArrayFromHire = () => {
	let discipleArray = []
	discipleSpecial.forEach(disciple => {
		if(disciple.isShow) {
			discipleArray.push(disciple)
		}
	})
	discipleArray.sort(function(a,b){
		return b.quality-a.quality
	})
	return discipleArray
}

/**
 * 获取小说人物志 特殊弟子类型对象
 */
const getSpecialDiscipleArrayFromNovel = () => {
	let discipleObj = {}
	discipleSpecial.forEach(disciple => {
		let zy = disciple.zhenYing
		if(discipleObj[zy]) {
			discipleObj[zy].data.push(disciple)
		}else {
			discipleObj[zy] = {
				zy:zy,
				data:[disciple]
			}
		}
	})
	
	let discipleArray = []
	Object.keys(discipleObj).forEach(function(key) {
		let itemObj = discipleObj[key]
		itemObj.data.sort(function(a,b){
			return b.quality-a.quality
		})
		discipleArray.push(itemObj)
	})
	return discipleArray
}

/**
 * 通过特殊弟子名称获取特殊弟子
 */
const getSpecialDiscipleByName = (name) => {
	return discipleSpecial[discipleSpecial.findIndex(item => item.name==name)]
}

/**
 * 获取弟子渡劫成功率
 */
const getDisciplePromoteRate = (greatRealm,smallRealm,rCount) => {
	let rate = 0
	let info = masterProperty[masterProperty.findIndex(item => item.greatRealm==greatRealm && item.smallRealm==smallRealm && item.rCount==rCount)]
	if(info) {
		rate = info.successRate
	}
	return rate
}

/**
 * 所有指定技能系ID的数组
 */
const getSkillArrayById = (id) => {
	let skillArray = []
	skill.forEach((info)=>{
		if(info.id==id) {
			skillArray.push(info)
		}
	})
	return skillArray
}

/**
 * 指定技能id获取其最大等级
 */
const getSkillMaxLayerLevel = (id,skillId) => {
	let maxLayerLevel = 0
	let info = skill[skill.findIndex(item => item.id==id && item.skillId==skillId)]
	if(info) {
		maxLayerLevel = info.maxLevel
	}
	return maxLayerLevel
}

/**
 * 指定技能id的技能信息
 */
const getSkillInfo = (skillId) => {
	return skill[skill.findIndex(item => item.skillId==skillId)]
}

/**
 * 获取地图列表
 */
const getMapList = () => {
	let mapObj = {}
	map.forEach((info)=>{
		if(mapObj[info.chapterId]) {
			mapObj[info.chapterId].data.push(info)
		}else {
			mapObj[info.chapterId] = {
				chapterName:info.chapterName,
				data:[info]
			}
		}
	})
	
	let mapList = []
	Object.keys(mapObj).forEach(function(key) {
		mapList.push(mapObj[key])
	})
	return mapList
	
}

/**
 * 通过地图id获取地图详情
 */
const getMapInfo = (mapId) => {
	return map[map.findIndex(info => info.mapId == mapId)]
}

/**
 * 通过地图id获取地图元素
 */
const getMapElement = (mapId) => {
	let elementArray = []
	mapElement.forEach((ele)=>{
		if(ele.mapId==mapId) {
			elementArray.push(ele)
		}
	})
	return elementArray
}

/**
 * 通过地图ID和元素ID获取地图战斗信息
 */
const getMapFight = (mapId,elementId) => {
	let fightArray = []
	mapFight.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			fightArray.push(info)
		}
	})
	return fightArray
}

/**
 * 通过地图接续事件
 */
const getMapContinue = (mapId,continueId,operate) => {
	let conArray = []
	mapContinue.forEach((con)=>{
		if(con.mapId==mapId && con.eventId==continueId && con.operate==operate) {
			conArray.push(con)
		}
	})
	return conArray
}

/**
 * 获取地图指定 任务ID-分任务ID-状态的数组
 */
const getMapTaskArray = (mapId,mainId,nextId,status) => {
	let taskArray = []
	mapTask.forEach((info)=>{
		if(info.mapId==mapId && info.mainId==mainId && info.nextId==nextId && info.status==status) {
			taskArray.push(info)
		}
	})
	return taskArray
}

/**
 * 进地图时任务是进行中情况
 * 获取地图指定任务 任务信息  任务状态为0，结果含有[任务]，仅有一条
 */
const getMapTaskInfo = (mapId,mainId,nextId) => {
	return mapTask[mapTask.findIndex(info => info.mapId==mapId && info.mainId==mainId && info.nextId==nextId && info.status==0 && info.result.indexOf('任务')!=-1)]
}

/**
 * 通过跳转编号和按钮确定任务信息
 */
const getMapTaskInfoByJumpNumber = (mapId,mainId,nextId,status,jumpNumber,btName) => {
	return mapTask[mapTask.findIndex(item => item.mapId==mapId && item.mainId==mainId && item.nextId==nextId && item.status==status && item.number==jumpNumber && item.operate==btName)]
}

/**
 * 通过id获取地图获得的物品
 */
const getMapMaterialGainById = (id,type) => {
	let text = ''
	let info = mapMaterialGain[mapMaterialGain.findIndex(item => item.id==id)]
	if(info) {
		if(type==1) {
			text = info.text
		}else {
			text = info.text.replace(/#/g,',')
		}
	}
	return text
}

/**
 * 通过id获取地图消耗的物品
 */
const getMapMaterialConsumeById = (id,type) => {
	let text = ''
	let info = mapMaterialConsume[mapMaterialConsume.findIndex(item => item.id==id)]
	if(info) {
		if(type==1) {
			text = info.text
		}else {
			text = info.text.replace(/#/g,',')
		}
	}
	return text
}

/**
 * 通过怪物id获取怪物信息  怪物ID：暂时写法，方便测试
 */
const getMonsterInfoById = (id) => {
	return monster[monster.findIndex(item => item.id==id)]
}

/**
 * 通过id获取地图text
 */
const getMapTextById = (textId) => {
	let text = ''
	const textInfo = mapText[mapText.findIndex(info => info.textId == textId)]
	if(textInfo) {
		text = textInfo.text
	}
	return text
}

/**
 * 获取指定地图元素id的交易物品
 */
const getBusinessArray = (mapId,elementId) => {
	let businessArray = []
	mapBusiness.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			businessArray.push(info)
		}
	})
	return businessArray
}

/**
 * 跳转数组
 */
const getJumpArray = (mapId,elementId) => {
	let jumpArray = []
	mapJump.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			jumpArray.push(info)
		}
	})
	return jumpArray
}

/**
 * 解析获取的物品
 * 1-5、6、7、8  物品表，装备表，配方表，弟子出售表
 */
const getMaterialArray = (text,type) => {
	let materialArray = []
	if(text) {
		let textArray = text.split('#')
		textArray.forEach((item)=>{
			let infoArray = item.split(':')
			let i0 = parseInt(infoArray[0])
			let i1 = parseInt(infoArray[1])
			let i2 = parseInt(infoArray[2])
			
			let mInfo = material[material.findIndex(item => item.type==i0 && item.id==i1)]
			if(!mInfo && i0==6) {
				mInfo = equipInitial[equipInitial.findIndex(item => item.id==i1)]
			}
			if(!mInfo && i0==7) {
				mInfo = formulaTable[formulaTable.findIndex(item => item.id==i1)]
			}
			if(!mInfo && i0==8) {
				mInfo = discipleSpecial[discipleSpecial.findIndex(item => item.id==i1)]
			}
			
			if(mInfo) {
				if(type==1) {
					materialArray.push(i2+mInfo.name)
				}else if(type==2) {
					materialArray.push(mInfo.name+' x'+i2)
				}else if(type==3) {
					materialArray.push(mInfo)
				}else {
					materialArray.push(mInfo.name+'*'+i2)
				}
			}
		})
	}
	return materialArray
}

/**
 * 获得机缘信息数组
 */
const getChanceArray = (mapId,elementId) => {
	let chanceArray = []
	mapChance.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			chanceArray.push(info)
		}
	})
	return chanceArray
}

/**
 * 获得特殊点信息数组
 */
const getSpecialArray = (mapId,elementId) => {
	let specialArray = []
	mapSpecial.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			specialArray.push(info)
		}
	})
	return specialArray
}

/**
 * 获取地图操作的颜色
 */
const getOperateColor = (name) => {
	let color = '#FFFFFF'
	let info = mapOperateColor[mapOperateColor.findIndex(info => info.name==name)]
	if(info) {
		color = info.color
	}
	return color
}

/**
 * 弟子破极限
 */
const getBreakThroughArray = () => {
	return breakThrough
}

/**
 * 判断是进行大境界突破还是小境界
 */
const breakThroughByGreatRealm = (greatRealm,smallRealm,rCount) => {
	let isGreat = true
	let greatRealmArray = []
	masterProperty.forEach((info)=>{
		if(info.greatRealm==greatRealm && info.rCount==rCount) {
			greatRealmArray.push(info)
		}
	})
	if(greatRealmArray.length>0) {
		greatRealmArray.sort(function(a,b) {
			return b.smallRealm-a.smallRealm
		})
		if(greatRealmArray[0].smallRealm>smallRealm) {
			isGreat = false
		}
	}
	return isGreat
}

/**
 * 获取灵地信息
 */
const getLandInfo = (landType,level) => {
	return land[land.findIndex(info => info.id==landType && info.level==level)]
}

/**
 * 获取配方指定配方类型的所有配方方向数组
 */
const getDirectionArrayByType = (buildType) => {
	let buildName = ''
	switch(buildType) {
		case 2:
			buildName = '锻造配方'
			break;
			
		case 3:
			buildName = '炼丹配方'
			break;
	}
	
	let directionArray = []
	if(buildName) {
		formulaTable.forEach((item)=>{
			if(item.type==buildName) {
				let direction = item.direction
				if(directionArray.indexOf(direction)==-1) {
					directionArray.push(direction)
				}
			}
		})
	}
	return directionArray
}

/**
 * 获取指定配方方向的数组
 */
const getFormulaArrayByDirection = (direction) => {
	let formulaArray = []
	formulaTable.forEach((item)=>{
		if(item.direction==direction) {
			formulaArray.push(item)
		}
	})
	return formulaArray
}

/**
 * 通过装备名获取装备初始化概率信息
 */
const getEquipInitialInfoByName = (name) => {
	return equipInitial[equipInitial.findIndex(info => info.name==name)]
}

/**
 * 装备聚星保底
 */
const getEquipFloorInfo = (quality,level) => {
	return equipIFloor[equipIFloor.findIndex(info => info.quality==quality && info.level==level)]
}

/**
 * 通过装备附加条数
 */
const getEquipExtraNumberByQuality = (quality) => {
	let extraNumber = ''
	let info = equipInitialRate[equipInitialRate.findIndex(info => info.quality==quality)]
	if(info) {
		let minNum = -1
		let maxNum = -1
		for(let i=0;i<7;i++) {
			let item = info['rate'+i]
			if(item>0) {
				if(minNum==-1) {
					minNum = i
				}
				maxNum = i
			}
		}
		extraNumber = minNum+'-'+maxNum
	}
	return extraNumber
}

/**
 * 特殊点的获取
 * 获取锻造材料、炼丹材料的数组
 */
const getMapSpecialMaterialArray = (quality) => {
	let materialArray = []
	material.forEach((item)=>{
		if((item.type==2 || item.type==3) && item.quality<=quality) {
			materialArray.push(item)
		}
	})
	return materialArray
}

/**
 * 地图获取消耗物品的格式转换
 * 可能类型 - 1-5、6、7  从物品表、装备初始化表和配方表中获取
 *  黑天剑鞘（损）*1#灵石*30000 => 1:10001:10
 */
const exchangeMapMaterialFormat = (text) => {
	let resultArray = []
	if(text) {
		let textArray = text.split('#')
		textArray.forEach((item)=>{
			let result = ''
			let itemArray = item.split('*')
			let name = itemArray[0]
			let count = itemArray[1]
			for(let i=0;i<material.length;i++) {
				let ml = material[i]
				if(ml.name==name) {
					result = ml.type+':'+ml.id+':'+count
					resultArray.push(result)
					break;
				}
			}
			if(!result) {
				for(let i=0;i<equipInitial.length;i++) {
					let ei = equipInitial[i]
					if(ei.name==name) {
						result = '6:'+ei.id+':'+count
						resultArray.push(result)
						break;
					}
				}
			}
			if(!result) {
				for(let i=0;i<formulaTable.length;i++) {
					let ft = formulaTable[i]
					if(ft.name==name) {
						result = '7:'+ft.id+':'+count
						resultArray.push(result)
						break;
					}
				}
			}
			if(!result) {
				for(let i=0;i<discipleSpecial.length;i++) {
					let ds = discipleSpecial[i]
					if(ds.name==name) {
						result = '8:'+ds.id+':'+count
						resultArray.push(result)
						break;
					}
				}
			}
		})
	}
	return resultArray.toString().replace(/,/g,'#')
}

/**
 * 通过物品名称获取物品信息
 * 凝金丹
 */
const getMaterialInfoByName = (name) => {
	let materialInfo
	if(name) {
		for(let i=0;i<material.length;i++) {
			let ml = material[i]
			if(ml.name==name) {
				materialInfo = ml
				break;
			}
		}
		if(!materialInfo) {
			for(let i=0;i<equipInitial.length;i++) {
				let ei = equipInitial[i]
				if(ei.name==name) {
					materialInfo = ei
					break;
				}
			}
		}
		if(!materialInfo) {
			for(let i=0;i<formulaTable.length;i++) {
				let ft = formulaTable[i]
				if(ft.name==name) {
					materialInfo = ft
					break;
				}
			}
		}
		if(!materialInfo) {
			for(let i=0;i<discipleSpecial.length;i++) {
				let ds = discipleSpecial[i]
				if(ds.name==name) {
					materialInfo = ds
					break;
				}
			}
		}
	}
	return materialInfo
}

/**
 * 通过物品名称获取物品类型
 */
const getMaterialTypeByName = (name) => {
	let mt = 0
	let info = materialType[materialType.findIndex(item => item.name==name)]
	if(info) {
		mt = info.type
	}
	return mt
}

/**
 * 通过物品类型获取物品名称
 */
const getMaterialNameByType = (type) => {
	let name = ''
	let info = materialType[materialType.findIndex(item => item.type==type)]
	if(info) {
		name = info.name
	}
	return name
}

/**
 * 获取职业
 */
const getNameByJob = (job) => {
	let name = ''
	let info = inherited[inherited.findIndex(item => item.id==job)]
	if(info) {
		name = info.name
	}
	return name
}

const getJobByName = (name) => {
	let id = 0
	let info = inherited[inherited.findIndex(item => item.name==name)]
	if(info) {
		id = info.id
	}
	return id
}

/**
 * 兑换整合装备的
 * 兑换装备表
 */
const getExchangeEquipInfo = (name,type) => {
	let source = ''
	switch(type) {
		case 1:
			source = '坊市'
			break;
	}
	return exchangeEquip[exchangeEquip.findIndex(item => item.name==name && item.source==source)]
}

/**
 * 通过门派ID获取资源兑换信息
 */
const getExchangeMaterialObj = () => {
	let materialObj = {}
	let sectLevel = getApp().globalData.sectView.level
	exchangeMaterial.forEach(material => {
		if(material.sectLevel==sectLevel) {
			materialObj[material.id] = material
		}
	})
	return materialObj
}

/**
 * 指定配方名称找到对应的信息
 */
const getFormulaInfo = (name) => {
	return formulaTable[formulaTable.findIndex(item => item.name==name)]
}

/**
 * 兑换整合装备的
 * 兑换配置表
 */
const getExchangeMaterialInfo = (name,sourceType) => {
	let source = ''
	switch(sourceType) {
		default:
			source = '坊市'
			break;
	}
	return exchange[exchange.findIndex(item => item.name==name && item.source.indexOf(source)!=-1)]
}

/**
 * 获取主角基础属性配置表对应信息
 */
const getMasterProperty = (greatRealm,smallRealm,rCount) => {
	return masterProperty[masterProperty.findIndex(item => item.greatRealm==greatRealm && item.smallRealm==smallRealm && item.rCount==rCount)]
}

/**
 * 获取弟子基础属性配置表对应信息
 */
const getDiscipleProperty = (id,greatRealm,rCount) => {
	return discipleProperty[discipleProperty.findIndex(item => item.greatRealm==greatRealm && item.id==id && item.rCount==rCount)]
}

/**
 * 门派等级提升
 */
const getSectUpgradeInfo = (level) => {
	return sectUpgrade[sectUpgrade.findIndex(item => item.level==level)]
}

/**
 * 获取不同等级坊市的tabs
 */
const getMarketDetailTabNames = (level) => {
	let names = []
	
	let source = ''
	switch(level) {
		case 1:
			source = '一级坊市'
			break;
			
		case 2:
			source = '二级坊市'
			break;
			
		case 3:
			source = '三级坊市'
			break;
			
		case 4:
			source = '四级坊市'
			break;
			
		case 5:
			source = '五级坊市'
			break;
			
		case 6:
			source = '六级坊市'
			break;
		
		case 100:
			source = '仙宝阁'
			break;
			
		case 101:
			source = '三生道台'
			break;
	}
	if(source) {
		exchange.forEach(item => {
			let position = item.position
			if(item.source==source) {
				if(names.indexOf(position)==-1) {
					names.push(position)
				}
			}
		})
	}
	return names
}

/**
 * 新玩家登录弹窗引导
 */
const getNewWords = (position) => {
	return wordsNew[wordsNew.findIndex(item => item.position==position)]
}

/**
 * 文字介绍页面
 */
const getIntroWords = (position) => {
	return wordsIntro[wordsIntro.findIndex(item => item.position==position)]
}

/**
 * 通过成就ID和数量范围确定成就信息
 */
const getAchievementInfo = (id,progress) => {
	let achievementInfo
	sectAchievement.forEach(item => {
		let sNum = 0
		let eNum = 1000000
		let range = item.range
		if(range.indexOf('-')!=-1) {
			let rangeArray = range.split('-')
			sNum = parseInt(rangeArray[0])
			eNum = parseInt(rangeArray[1])
		}else {
			sNum = parseInt(range.replace('以上',''))
		}
		
		if(item.id==id && progress>=sNum && progress<=eNum) {
			let maxNum = eNum
			let eText = eNum.toString()
			if(range.indexOf('以上')!=-1) {
				maxNum = sNum
				eText = range
			}
			item.maxNum = maxNum
			item.eText = eText
			item.progress = progress
			achievementInfo = item
		}
	})
	return achievementInfo
}

/**
 * 装备提品
 */
const getEquipStarInfo = (quality,st) => {
	return equipStar[equipStar.findIndex(item => item.quality==quality && item.count==st)]
}

/**
 * 通过pvpId获取pvp奖励信息
 */
const getPvpRewardArrayById = (id) => {
	let pvpArray = []
	pvpReward.forEach(pvp => {
		if(pvp.id==id) {
			pvpArray.push(pvp)
		}
	})
	return pvpArray
}

/**
 * 获取材料合成的原材料名称数组
 */
const getMaterialMixNameArray = () => {
	let source = '材料合成'
	
	let nameArray = []
	materialMix.forEach(item => {
		if(source==item.type) {
			let name = item.originName
			if(nameArray.indexOf(name)==-1) {
				nameArray.push(name)
			}
		}
	})
	return nameArray
}

/**
 * 获取指定原材料的合成数组
 */
const getMMNArrayByName = (name) => {
	let source = '材料合成'
	
	let nameArray = []
	materialMix.forEach(item => {
		if(source==item.type && name==item.originName) {
			nameArray.push(item)
		}
	})
	return nameArray
}

/**
 * 获取指定原材料的合成信息
 */
const getMixInfoByOrigin = (name,count) => {
	let source = '材料合成'
	return materialMix[materialMix.findIndex(item => item.originName==name && item.originCount==count && item.type==source)]
}

/**
 * 炼丹锻造考核
 * 获取指定配方的数组
 * text：破军剑锻造配方#截灵手套锻造配方#生机石锻造配方#炼魂锁锻造配方
 */
const getFormulaArrayFromAccess = (text) => {
	let formulaArray = []
	if(text) {
		let textArray = text.split('#')
		formulaTable.forEach((item)=>{
			if(textArray.indexOf(item.name)!=-1) {
				formulaArray.push(item)
			}
		})
	}
	return formulaArray
}

/**
 * 炼丹锻造考核信息
 */
const getAlchemyForgeAccessInfo = (formulaType,level) => {
	let typeName = ''
	switch(formulaType) {
		case 1:
			typeName = '锻造考核'
			break;
			
		case 2:
			typeName = '炼丹考核'
			break;
	}
	return alchemyForgeAccess[alchemyForgeAccess.findIndex(item => item.type==typeName && item.level==level)]
}

/**
 * 通过本源数量获取命魂消息
 */
const getLifeSoulByCount = (count) => {
	return discipleLifeSoul[discipleLifeSoul.findIndex(item => item.count==count)]
}

/**
 * 无极战境
 * 获取层数定义信息
 */
const getTowerInfo = (mapId) => {
	return tower[tower.findIndex(info => info.mapId==mapId)]
}

const getTowerElement = (mapId) => {
	let elementArray = []
	towerElement.forEach((ele)=>{
		if(ele.mapId==mapId) {
			elementArray.push(ele)
		}
	})
	return elementArray
}

/**
 * 无极战境首页数据
 * 层数、指定层数ID的奖励和奖励
 */
const getTowerInfoFromIntro = (mapId) => {
	let name = '无'
	let info1 = getTowerInfo(mapId)
	if(info1) {
		name = info1.mapName
	}
	
	let reward = '无'
	let info2 = towerReward[towerReward.findIndex(info => info.mapId==mapId)]
	if(info2) {
		reward = info2.reward.replace(/#/g,', ')
	}
	
	return {
		name:name,
		reward:reward
	}
}

const getTowerFight = (mapId,elementId) => {
	let fightArray = []
	towerFight.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			fightArray.push(info)
		}
	})
	return fightArray
}

const getTowerTextById = (textId) => {
	let text = ''
	const textInfo = towerText[towerText.findIndex(info => info.textId == textId)]
	if(textInfo) {
		text = textInfo.text
	}
	return text
}

const getTowerChanceArray = (mapId,elementId) => {
	let chanceArray = []
	towerChance.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			chanceArray.push(info)
		}
	})
	return chanceArray
}

const getTowerBusinessArray = (mapId,elementId) => {
	let businessArray = []
	towerBusiness.forEach((info)=>{
		if(info.mapId==mapId && info.elementId==elementId) {
			businessArray.push(info)
		}
	})
	return businessArray
}

const getTowerMaterialGainById = (id,type) => {
	let text = ''
	let info = towerMaterialGain[towerMaterialGain.findIndex(item => item.id==id)]
	if(info) {
		if(type==1) {
			text = info.text
		}else {
			text = info.text.replace(/#/g,',')
		}
	}
	return text
}

const getTowerMaterialConsumeById = (id,type) => {
	let text = ''
	let info = towerMaterialConsume[towerMaterialConsume.findIndex(item => item.id==id)]
	if(info) {
		if(type==1) {
			text = info.text
		}else {
			text = info.text.replace(/#/g,',')
		}
	}
	return text
}

const getTowerContinue = (mapId,continueId,operate) => {
	let conArray = []
	towerContinue.forEach((con)=>{
		if(con.mapId==mapId && con.eventId==continueId && con.operate==operate) {
			conArray.push(con)
		}
	})
	return conArray
}

export default {
	getBuilding,
	parseHomeMaterial,
	getRealm,
	parseWearEquip,
	getEquipInfo,
	getEquipTypeName,
	getEquipTypeNameByEquipName,
	getPhysiqueGiftName,
	getPhysiqueGift,
	getMaterialQualityName,
	getEquipQualityName,
	getEquipQualityNameWithColor,
	getEquipMaxLevel,
	getEquipTotalBoostValue,
	getAlchemyForgeName,
	getAlchemyForgeExt,
	getMaterialInfo,
	getDiscipleQuality,
	getSpecialDiscipleArrayFromHire,
	getSpecialDiscipleArrayFromNovel,
	getSpecialDiscipleByName,
	getDisciplePromoteRate,
	getSkillArrayById,
	getMapList,
	getMapInfo,
	getMapElement,
	getMapFight,
	getMapContinue,
	getMapTaskArray,
	getMapTaskInfo,
	getMapTaskInfoByJumpNumber,
	getMapMaterialGainById,
	getMapMaterialConsumeById,
	getMonsterInfoById,
	getMapTextById,
	getBusinessArray,
	getJumpArray,
	getMaterialArray,
	getChanceArray,
	getSpecialArray,
	getOperateColor,
	getBreakThroughArray,
	breakThroughByGreatRealm,
	getSkillMaxLayerLevel,
	getSkillInfo,
	getLandInfo,
	getDirectionArrayByType,
	getFormulaArrayByDirection,
	getEquipInitialInfoByName,
	getEquipFloorInfo,
	getEquipExtraNumberByQuality,
	getMapSpecialMaterialArray,
	exchangeMapMaterialFormat,
	getMaterialTypeByName,
	getMaterialNameByType,
	getNameByJob,
	getJobByName,
	getExchangeEquipInfo,
	getExchangeMaterialInfo,
	getMasterProperty,
	getDiscipleProperty,
	getSectUpgradeInfo,
	getMarketDetailTabNames,
	getFormulaInfo,
	getNewWords,
	getIntroWords,
	getAchievementInfo,
	getEquipStarInfo,
	getPvpRewardArrayById,
	getMaterialMixNameArray,
	getMMNArrayByName,
	getMixInfoByOrigin,
	getFormulaArrayFromAccess,
	getAlchemyForgeAccessInfo,
	getMaterialInfoByName,
	getLifeSoulByCount,
	getTowerInfo,
	getTowerElement,
	getTowerInfoFromIntro,
	getTowerFight,
	getTowerTextById,
	getTowerChanceArray,
	getTowerBusinessArray,
	getTowerMaterialGainById,
	getTowerContinue,
	getTowerMaterialConsumeById,
	getExchangeMaterialObj
}
