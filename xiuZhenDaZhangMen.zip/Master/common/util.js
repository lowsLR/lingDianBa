import md5 from '@/js_sdk/ccdzhang-dokey/md5.js'

/**
 * 获取本地全局的服务器时间
 */
const getServerTime = () => {
	let serverTime = 0
	try {
		serverTime = getApp().globalData.serverTime
	}catch(e) {}
	return serverTime
}

/**
 * 产生唯一uuid
 */
const generateUUID = () => { 
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16 | 0,
			v = c == 'x' ? r : (r & 0x3 | 0x8);
		return v.toString(16);
	});
}

/**
 * 账户命令请求签名
 */
const accountSign = (obj) => {
	var newObj = {}
	Object.keys(obj).sort().map(key => {
		newObj[key] = obj[key]
	})
	newObj['key'] = 'sXda0ln#1'
	
	let signText = ''
	Object.keys(newObj).map(key => {
		signText += key+'='+newObj[key]
		if(key!='key') {
			signText += '&'
		}
	})
	return toMd5(signText)
}

/**
 * 游戏命令请求签名
 */
const gameSign = (obj) => {
	let signText = 'cmd='+obj.cmd+'&rid='+obj.requestId+'&ts='+obj.timestamp+'&key=sXda0ln#1'
	let params = obj.params
	if(params) {
		var newObj = {}
		Object.keys(params).sort().map(key => {
			newObj[key] = params[key]
		})
		Object.keys(newObj).map(key => {
			signText += '&'+key+'='+newObj[key]
		})
	}
	return toMd5(signText)
}

/**
 * 获取用户clientId - App端
 */
const getClientId = () => {
	let clientId = ''
	let pushInfo = plus.push.getClientInfo()
	if(pushInfo) {
		clientId = pushInfo.clientid
	}
	return clientId
}

const toMd5 = (text) => {
	return md5(text).toLowerCase()
}

/**
 * 清除登录数据
 */
const clearLoginData = () => {
	getApp().globalData.accountToken = ''
	getApp().globalData.sectToken = ''
	getApp().globalData.gameUrlPre = ''
	getApp().globalData.disciples = []
	getApp().globalData.materialObj = {}
}

/**
 * 首页1-9的繁体转换
 */
const exchangeNumToFt = (num) => {
	return ['壹','贰','叁','肆','伍','陆','柒','玐','玖','拾'][(num-1)]
}

/**
 * 获取职位
 */
const getNameByPstn = (pstn) => {
	let name = ''
	switch(pstn) {
		case 1:
			name = '掌门'
			break;
			
		case 2:
			name = '普通弟子'
			break;
	}
	return name
}

/**
 * 获取性别
 */
const getNameBySex = (sex) => {
	let name = ''
	switch(sex) {
		case 0:
			name = '女'
			break;
			
		case 1:
			name = '男'
			break;
	}
	return name
}

/**
 * 跳转前页面数据转uri
 */
const toEncodeUri = (url,obj) => {
	return url+'?detail='+encodeURIComponent(JSON.stringify(obj).replace(/%/g, '%25'))
}

/**
 * 跳转后页面数据解析
 */
const toDecodeUri = (option) => {
	return JSON.parse(decodeURIComponent(option.detail))
}

/**
 * 解析时间秒成年月日，按最大的取
 */
const formatTimeBySeconds = (seconds) => {
	// let minutes = Math.floor(seconds/60)
	// let hours = Math.floor(seconds/3600)
	// let days = Math.floor(seconds/86400)
	// let years = Math.floor(seconds/31536000)
	// let timeText = years>0?years+'年':days>0?days+'天':hours>0?hours+'小时':minutes>0?minutes+'分钟':seconds+'秒'
	// return timeText
	let time = 1
	if(seconds>0) {
		time = Math.ceil(seconds/3600)
	}
	return time+'年'
}

/**
 * 解析 1=20#3=32 格式属性
 */
const parseProperty = (text) => {
	if(text) {
		let obj = {}
		let array = text.split('#')
		array.forEach((item)=>{
			let itemArray = item.split('=')
			obj[itemArray[0]] = parseFloat(itemArray[1])
		})
		return obj
	}
}

/**
 * 清除登录账号密码
 */
const keepLoginData = (account,password) => {
	uni.setStorage({
	    key: 'loginData',
	    data: {
			account:account,
			password:password
		}
	})
}

/**
 * 获取登录账号密码
 */
const getLoginData = (callback) => {
	uni.getStorage({
		key: 'loginData',
		success: function(res) {
			callback(res.data)
		}
	})
}

/**
 * 获取用户头像链接
 */
const getAvatarUrl = (sex,iconId,callback) => {
	let name = ''
	switch(sex) {
		case 0:
		case '女':
			name = 'woman'
			if(iconId>100) {
				name = 'special-woman'
			}
			break;
			
		case 1:
		case '男':
			name = 'man'
			if(iconId>100) {
				name = 'special-man'
			}
			break;
	}
	let iconIdStr = iconId
	if(iconId<10) {
		iconIdStr = '00'+iconId
	}else if(iconId<100) {
		iconIdStr = '0'+iconId
	}
	
	let iconUrl = '/static/avatar/'+name+'/'+iconIdStr+'.png'
	if(callback) {
		uni.getFileInfo({
			filePath:iconUrl,
			success: () => {
				callback(iconUrl)
			},
			fail: () => {
				iconUrl = getApp().globalData.avatarPre+iconIdStr+'.png'
				callback(iconUrl)
			}
		})
	}else {
		// 确定一定存在
		return iconUrl
	}
}

/**
 * 换行符转换
 */
const exchangeLineBreak = (text) => {
	return text.replace(/\n/g,'<br>')
}

/**
 * 获取类型格式id  xx(id)
 */
const getTextId = (text) => {
	let textId = 0
	if(text.indexOf('(')!=-1) {
		textId = parseInt(text.substring(text.indexOf('(')+1,text.indexOf(')')))
	}
	return textId
}

/**
 * 判断文本是否全是中文
 */
const isChinese = (text) => {
	let isTrue = true
	const reg = /[^\u4e00-\u9fa5]/
	if (reg.test(text)) {
		isTrue = false
	}
	return isTrue
}

/**
 * 转换数量单位
 */
const exchangeNum = (num) => {
	if(num > 99999 && num < 9999999) {
		return Math.floor(num/10000) + '万'
	}else if(num > 9999999) {
		 return Math.floor(num/10000000) / 10 + '亿'
	}else{
		return num
	}
}

/**
 * 完善弟子信息
 */
const improveDiscipleData = (info,_self) => {
	info.pstnName = getNameByPstn(info.pstn)
	info.jobName = _self.jsonParse.getNameByJob(info.job)
	let realmInfo = _self.jsonParse.getRealm(info.rm,info.rml)
	if(realmInfo) {
		info.realm = realmInfo
	}
	return info
}

/**
 * 更新弟子数组
 */
const updateDiscipleArray = (disciples,_self) => {
	disciples.forEach((info)=>{
		improveDiscipleData(info,_self)
	})
	return disciples
}

/**
 * 更新弟子信息
 */
const updateDiscipleData = (disciple) => {
	if(disciple) {
		let disciples = getApp().globalData.disciples
		if(disciples && disciples.length>0) {
			let index = disciples.findIndex(item => item.id==disciple.id)
			if(index!=-1) {
				disciples.splice(index,1,disciple)
			}
		}
	}
}

/**
 * 添加弟子
 */
const addDisciple = (disciple) => {
	getApp().globalData.disciples.push(disciple)
}

/**
 * 添加弟子数组
 */
const addDiscipleArray = (array) => {
	if(array) {
		let disciples = getApp().globalData.disciples
		array.forEach((item)=>{
			disciples.push(item)
		})
	}
}

/**
 * 删除弟子
 */
const deleteDisciple = (id) => {
	let disciples = getApp().globalData.disciples
	let index = disciples.findIndex(d => d.id==id)
	if(index!=-1) {
		disciples.splice(index,1)
	}
}

/**
 * 处理we 格式数据
 */
const handleWearText = (wearText) => {
	let wearObj = {}
	let wearArray = wearText.split('#')
	wearArray.forEach((text)=>{
		let textArray = text.split('=')
		wearObj[textArray[0]] = parseInt(textArray[1])
	})
	return wearObj
}

/**
 * 保存的物品的key
 */
const getMaterialKey = (type,id) => {
	return type+'-'+id
}

/**
 * 更新全局装备穿戴情况
 */
const updateEquipWearStatus = (eid,wear) => {
	let equips = getApp().globalData.equips
	let equip = equips[equips.findIndex(e => e.eid==eid)]
	if(equip) {
		equip.w = wear
	}
}

/**
 * 更新全局某个装备
 */
const updateEquip = (equip) => {
	if(equip) {
		let equips = getApp().globalData.equips
		let index = equips.findIndex(e => e.eid==equip.eid)
		if(index!=-1) {
			equips.splice(index,1,equip)
		}
	}
}

/**
 * 删除全局某个装备
 */
const deleteEquip = (eid) => {
	let equips = getApp().globalData.equips
	let index = equips.findIndex(e => e.eid==eid)
	if(index!=-1) {
		equips.splice(index,1)
	}
}

/**
 * 添加全局装备
 */
const addEquipArray = (array) => {
	if(array) {
		let equips = getApp().globalData.equips
		array.forEach((item)=>{
			equips.push(item)
		})
	}
}

/**
 * 解析全局物品
 */
const getMaterialObj = (text) => {
	let materialObj = {}
	if(text) {
		let materialsTextArray = text.split('#')
		materialsTextArray.forEach((item)=>{
			let itemArray = item.split(':')
			const type = parseInt(itemArray[0])
			const id = parseInt(itemArray[1])
			const count = parseInt(itemArray[2])
			materialObj[getMaterialKey(type,id)] = {
				type:type,
				id:id,
				count:count
			}
		})
	}
	return materialObj
}

/**
 * 更新全局物品
 * text  格式：1:10002:500#1:10003:100
 * isConsumed  要么是消耗，要么是获得
 */
const updateMaterialObj = (text,isConsumed) => {
	if(text && (typeof text === 'string')) {
		let materialObj = getApp().globalData.materialObj
		let materialsTextArray = text.split('#')
		materialsTextArray.forEach((item)=>{
			let itemArray = item.split(':')
			const type = parseInt(itemArray[0])
			const id = parseInt(itemArray[1])
			const count = parseInt(itemArray[2])
			let itemObj = materialObj[getMaterialKey(type,id)]
			if(isConsumed) {
				if(itemObj) {
					let remainCount = itemObj.count-count
					if(remainCount<0) {
						remainCount = 0
					}
					itemObj.count = remainCount
				}
			}else {
				if(itemObj) {
					itemObj.count += count
				}else {
					materialObj[getMaterialKey(type,id)] = {
						type:type,
						id:id,
						count:count
					}
				}
			}
		})
	}
}

/**
 * 更新背包装备
 */
const updateEquips = (equips) => {
	if(equips && Array.isArray(equips) && equips.length>0) {
		let globalEquips = getApp().globalData.equips
		equips.forEach((equip)=>{
			let index = globalEquips.findIndex(item => item.eid==equip.eid)
			if(index==-1) {
				globalEquips.push(equip)
			}else {
				globalEquips.splice(index,1,equip)
			}
		})
	}
}

/**
 * 更新背包弟子
 */
const updateDisciples = (disciples) => {
	if(disciples && Array.isArray(disciples) && disciples.length>0) {
		let globalDisciples = getApp().globalData.disciples
		disciples.forEach((disciple)=>{
			let index = globalDisciples.findIndex(item => item.id==disciple.id)
			if(index==-1) {
				globalDisciples.push(disciple)
			}else {
				globalDisciples.splice(index,1,disciple)
			}
		})
	}
}

/**
 * 获取保留战斗队列的key
 */
const getStorageQueueKey = () => {
	let queueKey = 'queue'
	let sectView = getApp().globalData.sectView
	if(sectView) {
		queueKey += '-'+sectView.sectId
	}
	return queueKey
}

const equipObj = {
	1:'气血',
	2:'灵力',
	3:'神念',
	4:'肉身',
	5:'破甲',
	6:'格挡',
	7:'命中',
	8:'躲闪',
	9:'暴击',
	10:'抗暴'
}
/**
 * 装备详情基础属性和附加属性的解析
 */
const parseEquipProperty = (text,symbol,type) => {
	let propertyArray = []
	if(text) {
		let array = text.split('#')  // 可能存在 多个相同的key
		array.forEach(obj => {
			let itemArray = obj.split('=')
			let key = parseInt(itemArray[0])
			let value = parseFloat(itemArray[1])
			if(value>0) {
				if(type==1) {  // 装备详情的提品用到
					let propertyName = equipObj[key]
					propertyArray.push({
						name:propertyName,
						value:value
					})
				}else if(type==2) {
					let text = ''
					if(key>6) {
						text += value*100+'%'
					}else {
						text += value
					}
					propertyArray.push(text)
				}else {
					let text = symbol+equipObj[key]
					if(key>6) {
						text += value*100+'%'
					}else {
						text += value
					}
					propertyArray.push(text)
				}
			}
		})
	}
	return propertyArray
}

/**
 * 无极战境中的buff 
 * 1=-1#2=92
 */
const parsePropertyTextFromTower = (text) => {
	let resultText = ''
	if(text) {
		let array = text.split('#')
		array.forEach(obj => {
			let itemArray = obj.split('=')
			let key = parseInt(itemArray[0])
			let value = parseFloat(itemArray[1])
			
			if(value!=0) {
				let typeText = ' 削弱 '
				if(value>0) {
					typeText = ' 增加 '
				}
				
				value = Math.abs(value)
				if(key>6) {
					value = (value*100).toFixed(2)+'%'
				}
				
				if(resultText) {
					resultText += '<br>'
				}
				resultText += equipObj[key]+typeText+value
			}
		})
	}
	return resultText
}

/**
 * 保留两位小数
 */
const keepTwoDecimal = (number) => {
	return parseFloat(number).toFixed(2)
}

/**
 * 通过职位pstn判断是否是掌门
 */
const isMaster = (pstn) => {
	return pstn==1
}

/**
 * [n,m) 的整数
 */
const getRandom = (m,n) => {
	var num = Math.floor(Math.random()*(m - n) + n)
	return num
}

/**
 * 转换 特殊效果
 * F抗暴+2=(0.024) - F破甲+1=(3.400)% - F格挡+1=(3.600)%
 */
const exchangeFR = (text) => {
	let result = ''
	if(text) {
		let handleText = text.replace('F','').replace('R','').replace('+1','').replace('+2','').replace('(','').replace(')','').replace('%','').replace(/ /g,'')
		let handleTextArray = handleText.split('=')
		let hta0 = handleTextArray[0]
		let hta1 = parseFloat(handleTextArray[1])
		if(hta1<1) {
			hta1 = hta1*100
		}
		hta1 = keepTwoDecimal(hta1)
		try {
			if(text.indexOf('F')!=-1) {
				if(text.indexOf('+1')!=-1) {
					result = '特殊效果：增加自身'+hta0+'属性'+hta1+'%'
				}else if(text.indexOf('+2')!=-1) {
					result = '特殊效果：增加全体'+hta0+'属性'+hta1+'%'
				}
			}else if(text.indexOf('R')!=-1) {
				if(text.indexOf('+1')!=-1) {
					result = '特殊效果：出手时增加自身'+hta0+'属性'+hta1+'%'
				}else if(text.indexOf('+2')!=-1) {
					result = '特殊效果：出手时增加全体'+hta0+'属性'+hta1+'%'
				}
			}
		}catch(e) {
			result = ''
		}
	}
	return result
}

/**
 * 获取背包指定id的弟子
 */
const getDiscipleById = (id) => {
	let disciples = getApp().globalData.disciples
	return disciples[disciples.findIndex(disciple => disciple.id==id)]
}

/**
 * 装备评分
 */
const getEquipScore = (bp,ep) => {
	let bpValue = 0
	let bpArray = bp.split('#')
	bpArray.forEach((item)=>{
		let itemArray = item.split('=')
		let value = parseFloat(itemArray[1])
		if(value>0) {
			bpValue += value
		}
	})
	let epValue = 0
	if(ep) {
		let epArray = ep.split('#')
		epArray.forEach((item)=>{
			let itemArray = item.split('=')
			let value = parseFloat(itemArray[1])
			if(value>0) {
				epValue += value
			}
		})
	}
	return Math.ceil(bpValue+epValue*1.1)
}

/**
 * 通过大小境界排序获取结果 disciples数组
 */
const getSortDisciples = (_self) => {
	let disciples = getApp().globalData.disciples
	let resultDisciples = JSON.parse(JSON.stringify(updateDiscipleArray(disciples,_self)))  // 不改变全局disciples数据
	resultDisciples.sort(function(a,b) {
		if(isMaster(a.pstn)) {
			return -1
		}else if(isMaster(b.pstn)) {
			return 1
		}else {
			if(a.rm==b.rm) {
				return b.rml-a.rml
			}else {
				return b.rm-a.rm
			}
		}
	})
	return resultDisciples
}

/**
 * 获取门派类别名
 */
const getSectTypeName = (type) => {
	let nameObj = {
		1:'正',
		2:'魔',
		3:'正'
	}
	return nameObj[type]
}

/**
 * 通过门派徽章ID获取对应的徽章路径
 */
const getSectIconPath = (sectIconId) => {
	return sectIconId?'/static/badge/'+sectIconId+'.png':''
}

/**
 * 滑动到顶部
 */
const scrollToTop = () => {
	uni.pageScrollTo({
	    scrollTop: 0,
	    duration: 300
	})
}

/**
 * 获取弟子状态
 */
const getDiscipleStatusText = (status) => {
	let statusObj = {
		1:'正常',
		2:'重伤',
		3:'驻守',
		4:'死亡',
		5:'驱逐',
		6:'仙斗'
	}
	let result = statusObj[status]
	if(!result) {
		result = ''
	}
	return result
}

/**
 * 判断queueText的弟子是否都存在
 * 1=2#2=5
 */
const queueExist = (queueText) => {
	let allExist = true
	if(queueText) {
		let disciples = getApp().globalData.disciples
		let queueArray = queueText.split('#')
		queueArray.forEach((text,index)=>{
			let itemArray = text.split('=')
			let disciple = disciples[disciples.findIndex(item => item.id==parseInt(itemArray[1]))]
			if(!disciple) {
				allExist = false
			}
		})
	}else {
		allExist = false
	}
	return allExist
}

/**
 * 判断当天是否出现
 */
const whetherInitByWeek = (appearDay) => {
	let isOk = false
	
	let currDay = new Date().getDay()
	let dayArray = []
	let days = appearDay.split('#')
	days.forEach((text)=>{
		if(text.indexOf('-')!=-1) {
			let textArray = text.split('-')
			let t1 = parseInt(textArray[0])
			let t2 = parseInt(textArray[1])+1
			for(let i=t1;i<t2;i++) {
				dayArray.push(i)
			}
		}else {
			dayArray.push(parseInt(text))
		}
	})
	if(dayArray.indexOf(currDay)!=-1) {
		isOk = true
	}
	return isOk
}							

export default {
	getServerTime,
	generateUUID,
	accountSign,
	gameSign,
	getClientId,
	toMd5,
	clearLoginData,
	exchangeNumToFt,
	getNameByPstn,
	getNameBySex,
	toEncodeUri,
	toDecodeUri,
	formatTimeBySeconds,
	parseProperty,
	keepLoginData,
	getLoginData,
	getAvatarUrl,
	exchangeLineBreak,
	getTextId,
	isChinese,
	exchangeNum,
	updateDiscipleArray,
	updateDiscipleData,
	addDisciple,
	addDiscipleArray,
	deleteDisciple,
	handleWearText,
	getMaterialKey,
	updateEquipWearStatus,
	updateEquip,
	deleteEquip,
	addEquipArray,
	getMaterialObj,
	updateMaterialObj,
	getStorageQueueKey,
	updateEquips,
	updateDisciples,
	parseEquipProperty,
	keepTwoDecimal,
	isMaster,
	getRandom,
	exchangeFR,
	getDiscipleById,
	getEquipScore,
	getSortDisciples,
	getSectTypeName,
	getSectIconPath,
	scrollToTop,
	getDiscipleStatusText,
	queueExist,
	whetherInitByWeek,
	parsePropertyTextFromTower
}
