// import {
// 	setTransactionReceiptStorage
// } from '@/test/tool.js'

const getIapChannel = (callback) => {
	plus.payment.getChannels(function(channels) {
		var iapChannel
		for (var i in channels) {
			var channel = channels[i]
			if (channel.id === 'appleiap') {
				iapChannel = channel
			}
		}
		if (iapChannel && callback) {
			callback(iapChannel)
		}
	}, false)
}

const toRequestOrder = (iapChannel, productIds, callback) => {
	if (iapChannel) {
		uni.showLoading({
			title: '检测支付环境',
			mask:true
		})
		iapChannel.requestOrder(productIds, (orderList) => { //必须调用此方法才能进行 iap 支付
			uni.hideLoading()
			callback(true)
		}, (e) => {
			uni.hideLoading()
			callback(false)
		})
	}
}

const toSendRequest = (iapChannel, productId, callback) => {
	if (iapChannel) {
		plus.payment.request(iapChannel, {
			productid: productId
		}, function(res) {
			const transactionReceipt = res.transactionReceipt
			// setTransactionReceiptStorage({
			// 	transactionReceipt:res.transactionReceipt,
			// 	transactionIdentifier:res.transactionIdentifier
			// })
			callback({
				transactionReceipt:res.transactionReceipt,
				transactionIdentifier:res.transactionIdentifier
			})
		}, function() {
			callback()
		})
	}
}



export default {
	getIapChannel,
	toRequestOrder,
	toSendRequest
}
